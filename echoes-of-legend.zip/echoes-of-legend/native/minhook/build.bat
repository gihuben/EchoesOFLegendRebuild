@echo off
REM ==========================================================================
REM Build MinHook.x64.dll for Artemis (user ruling A1: fetch source and build).
REM Source: official repo https://github.com/TsudaKageyu/minhook (master zip).
REM Same toolchain style as Artemis native builds: MSVC via vcvarsall x64.
REM   /MT  static CRT (matches the project; no MSVC runtime dependency)
REM   /O2  optimize
REM   /DMH_BUILD_DLL  makes MH_EXPORT expand to __declspec(dllexport)
REM Output name MUST be MinHook.x64.dll (guard.cpp:51 loads exactly that name).
REM ==========================================================================
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat" x64
if errorlevel 1 (echo VCVARS_FAILED & exit /b 1)
cd /d "%~dp0"
echo === include dir ===
dir /b include
if not exist build mkdir build
cd build
echo === compiling ===
cl /nologo /utf-8 /O2 /MT /DWIN32 /D_WINDOWS /DMH_BUILD_DLL /I"..\include" /I"..\src" /I"..\src\hde" ..\src\buffer.c ..\src\hook.c ..\src\trampoline.c ..\src\hde\hde64.c /LD /Fe:MinHook.x64.dll /link /DEF:"..\dll_resources\MinHook.def"
if errorlevel 1 (echo CL_FAILED & exit /b 2)
echo === artifact ===
dir /b MinHook.x64.dll
echo === exports ===
dumpbin /exports MinHook.x64.dll | findstr /i "MH_"
exit /b 0
