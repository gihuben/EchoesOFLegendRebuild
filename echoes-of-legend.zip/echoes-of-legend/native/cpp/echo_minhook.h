// ============================================================================
// echo_minhook.h —— MinHook 动态定位 + 免冻结（原子）挂钩
//
// 学习来源：样板 guard.cpp 的 `AtomicHookEnable` 段（含 `AllocRelayNear` /
//   `BuildRelayTrampoline` / `AtomicWriteEntryJump` / `ResolveForwarderTarget` /
//   `AtomicHookVerify`），按"职责单一、fail-open、零依赖"重实现。
//
// ============================================================================
// 【血证 · 为什么绝不能调用 `MH_EnableHook` 落补丁】（本条是本文件存在的全部理由）
//
//   现象（本工程实测，pc 逐字节相同 ⇒ 确定性 BUG，不是数据竞争）：
//     `java.lang.UnsatisfiedLinkError: ...\lwjgl.dll: 找不到指定的程序。`（错误码 127）
//     / `Can't find dependent libraries` / hs_err 里
//     `EXCEPTION_ACCESS_VIOLATION at pc=ntdll!LdrLoadDll+0x64`，指令 `mov r9d,[rdx]`。
//     崩溃时 `rdx`（第 3 参数 `PUNICODE_STRING ModuleFileName`）是**高 32 位被清零的半截栈地址**
//     （例 `0x0000000060bfa930`），而同现场 `r8`/`r9`/`r14` 却是完好的完整地址。
//
//   机制（MinHook 上游 `src/hook.c` 逐行核对过，不是猜测）：
//     `MH_EnableHook` → `EnableHook(target, TRUE)` → **`Freeze()`**
//     → 枚举进程**全部**线程 → `SuspendThread` + `ProcessThreadIPs()`
//     → `GetThreadContext` / **`SetThreadContext` 直接改写被挂起线程的 RIP**（`hook.c:257`）
//     → 落补丁字节 → `Unfreeze()`。
//     ⇒ 被改 RIP 的线程恢复后处于**不一致状态**（还在原函数里，但寄存器是另一个栈帧的）
//     ⇒ 随后走到 `LdrLoadDll+0x64` 用那个"旧 rdx"解引用 ⇒ **确定性崩溃**。
//     触发条件：装配时 JVM 线程已多（本工程实测 21 条，含 C1/C2 JIT 编译线程）。
//
//   修法（只换"落字节"这一步，MinHook 的能力一条不减）：
//     ① `MH_CreateHook(target, detour, &trampoline)` —— **只计算/分配 trampoline 并保存原字节，
//        不改写目标函数**（源码核对：落补丁只发生在 `EnableHook` 里）⇒ 白拿它的 trampoline；
//     ② 在目标 ±2GB 内分配 relay：`FF 25 00000000` + <绝对 detour 地址>（14 字节）；
//     ③ 目标入口 **8 字节**用 `InterlockedExchange64` **一次性原子写入**
//        `E9 <rel32→relay>` + **目标原有字节[5..7]**；
//     ④ **完全不 `SuspendThread`、完全不 `SetThreadContext`** ⇒ 从机制上根除本类崩溃。
//
//   为什么"8 字节原子写"安全：
//     · 入口指向指令边界（trampoline 已保证 ≥5 字节完整指令可搬移）；
//     · 8 字节对齐的 `InterlockedExchange64` 是**单次不可分割**存储 ⇒ 不存在撕裂；
//     · `E9` 本身已决定指令长度 5，尾部保留原字节 ⇒ 任何情况下都不越界。
//       ⚠️ 必须只覆盖 5 字节：MinHook trampoline 的搬移阈值是 `sizeof(JMP_REL)`=5，
//       若前两条完整指令只占 6~7 字节，trampoline 会跳到 `target+6/7`；若那里被写成 `CC`
//       ⇒ 直接跑 int3 崩掉。保留原字节就绝对安全。
//
//   ⚠️ 顺序铁律（别改回去）：`MH_CreateHook` → `*original = tramp` → **最后才**落补丁。
//     若先落补丁后给转发指针，补丁生效瞬间任何线程都会进 detour，而此时 `g_origXxx` 仍为 NULL
//     ⇒ detour 走进失败分支 ⇒ 调用方拿到假失败（`lwjgl.dll: 找不到指定的程序` 正是这类表现）。
//
// ============================================================================
// 【纪律】零 C++ 全局对象（POD + SRWLOCK）、SEH 包裹读内存、fail-open 不崩。
//   本文件只被 echo_native_guard.cpp 包含（单一 TU），inline + static 不会重复定义。
// ============================================================================
#pragma once

#include <windows.h>
#include <cstring>

typedef int (WINAPI *EchoMH_Init_t)(void);
typedef int (WINAPI *EchoMH_CreateHook_t)(LPVOID, LPVOID, LPVOID*);
typedef int (WINAPI *EchoMH_EnableHook_t)(LPVOID);
typedef int (WINAPI *EchoMH_DisableHook_t)(LPVOID);
typedef int (WINAPI *EchoMH_Uninit_t)(void);

struct EchoMinHook {
    HMODULE module;
    EchoMH_Init_t init;
    EchoMH_CreateHook_t create;
    /* ⚠️ `enable` 只保留用于诊断/回滚，**绝不再用于落补丁**（见上方血证）。 */
    EchoMH_EnableHook_t enable;
    EchoMH_DisableHook_t disable;
    EchoMH_Uninit_t uninit;
};

/** 从"调用者所在 DLL 的目录"拼 MinHook 路径（带边界检查）。 */
inline HMODULE EchoLoadModuleBesideSelf(const void* selfFn) {
    wchar_t self[MAX_PATH * 2] = { 0 };
    HMODULE selfMod = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)selfFn, &selfMod);
    if (selfMod) {
        GetModuleFileNameW(selfMod, self, (DWORD)(sizeof(self) / sizeof(wchar_t)));
    }
    if (self[0]) {
        wchar_t* slash = wcsrchr(self, L'\\');
        if (slash) {
            slash[1] = L'\0';
            wchar_t cand[MAX_PATH * 2];
            _snwprintf_s(cand, MAX_PATH * 2, _TRUNCATE, L"%sMinHook.x64.dll", self);
            HMODULE m = LoadLibraryW(cand);
            if (m) return m;
        }
    }
    HMODULE m = LoadLibraryW(L"MinHook.x64.dll");
    if (!m) m = LoadLibraryW(L"MinHook.dll");
    return m;
}

/** 装载 MinHook（幂等；失败 ⇒ 返回 false，调用方 fail-open）。 */
inline bool EchoMinHookLoad(EchoMinHook* mh, const void* selfFn) {
    if (!mh) return false;
    if (mh->module && mh->init && mh->create) return true;
    mh->module = EchoLoadModuleBesideSelf(selfFn);
    if (!mh->module) return false;
    mh->init = (EchoMH_Init_t)GetProcAddress(mh->module, "MH_Initialize");
    mh->create = (EchoMH_CreateHook_t)GetProcAddress(mh->module, "MH_CreateHook");
    mh->enable = (EchoMH_EnableHook_t)GetProcAddress(mh->module, "MH_EnableHook");
    mh->disable = (EchoMH_DisableHook_t)GetProcAddress(mh->module, "MH_DisableHook");
    mh->uninit = (EchoMH_Uninit_t)GetProcAddress(mh->module, "MH_Uninitialize");
    if (!mh->init || !mh->create) return false;
    mh->init(); // MH_ERROR_ALREADY_INITIALIZED(1) 可忽略
    return true;
}

// ============================================================================
// 原子（免冻结）挂钩 —— 与样板 guard.cpp `AtomicHookEnable` 同口径
// ============================================================================
#define ECHO_ATOMIC_HOOK_MAX 32

typedef struct EchoAtomicHookEntry {
    LPVOID target;       /* 实际被落补丁的地址（可能经转发桩解包） */
    LPVOID relay;        /* 我方分配的 14 字节 relay（±2GB 内） */
    LPVOID trampoline;   /* 等价于原函数的可调用入口（MinHook trampoline 或自研） */
    BYTE   original8[8]; /* 入口原 8 字节（落补丁前必须保存） */
    int    enabled;
} EchoAtomicHookEntry;

static EchoAtomicHookEntry g_echoAtomicHooks[ECHO_ATOMIC_HOOK_MAX];
static int g_echoAtomicHookCount = 0;
static SRWLOCK g_echoAtomicLock = SRWLOCK_INIT;

inline int EchoFindAtomicSlot(LPVOID target) {
    for (int i = 0; i < g_echoAtomicHookCount; ++i) {
        if (g_echoAtomicHooks[i].target == target) return i;
    }
    return -1;
}

/** 在目标 ±2GB 内分配可执行页并写入 14 字节 relay：`FF 25 00000000` + <绝对 detour>。 */
inline LPVOID EchoAllocRelayNear(LPVOID target, LPVOID detour) {
    if (target == NULL || detour == NULL) return NULL;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    const ULONG_PTR gran = (si.dwAllocationGranularity != 0) ? si.dwAllocationGranularity : 0x10000;
    const ULONG_PTR t = (ULONG_PTR)target;
    const ULONG_PTR lo = (t > 0x7FFF0000ULL) ? (t - 0x7FFF0000ULL) : gran;
    const ULONG_PTR hi = t + 0x7FFF0000ULL;
    for (ULONG_PTR a = (t & ~(gran - 1)); a < hi; a += gran) {
        if (a < lo) continue;
        LPVOID p = VirtualAlloc((LPVOID)a, gran, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
        if (p == NULL) continue;
        BYTE* c = (BYTE*)p;
        c[0] = 0xFF;
        c[1] = 0x25;                                     // jmp qword ptr [rip+0]
        *(DWORD*)(c + 2) = 0;                            // disp32 = 0 ⇒ 取紧随其后的 8 字节
        *(LPVOID*)(c + 6) = detour;                      // 绝对目标
        FlushInstructionCache(GetCurrentProcess(), p, 14);
        return p;
    }
    return NULL;
}

/**
 * 粗略解码一条指令长度（自研 relay 兜底用）。
 * 【安全边界·宁可不装绝不错搬】只接受"简单、不引用自身地址、不改控制流"的指令；
 *   含 RIP 相对寻址 / 相对 CALL/JMP/Jcc / `FF` 族 ⇒ 一律返回 -1（放弃）。
 */
inline int EchoDecodeInsnLen(const BYTE* p, int maxLen) {
    int i = 0;
    // 前缀（最多 4 个）
    while (i < maxLen && i < 4) {
        const BYTE b = p[i];
        if (b == 0xF0 || b == 0xF2 || b == 0xF3 || b == 0x2E || b == 0x36 || b == 0x3E ||
            b == 0x26 || b == 0x64 || b == 0x65 || b == 0x66 || b == 0x67) { ++i; continue; }
        break;
    }
    if (i >= maxLen) return -1;
    // REX
    const BYTE b0 = p[i];
    if (b0 >= 0x40 && b0 <= 0x4F) { ++i; if (i >= maxLen) return -1; }
    const BYTE op = p[i++];
    // 单字节无操作数
    if (op == 0x90 || op == 0xCC || op == 0xC3 || op == 0xCB || op == 0xF4 ||
        op == 0x98 || op == 0x99 || op == 0xC9 || op == 0x9C || op == 0x9D) return i;
    // push/pop 寄存器（50-5F）
    if (op >= 0x50 && op <= 0x5F) return i;
    // 【拒绝】相对 CALL/JMP 与相对 Jcc、两字节操作码族：搬移后语义必失效
    if (op == 0xE8 || op == 0xE9 || op == 0xEB || (op >= 0x70 && op <= 0x7F) || op == 0x0F) return -1;
    // 【拒绝】FF 族（含 `FF 25` RIP 相对间接跳转的转发桩）
    if (op == 0xFF) return -1;
    const bool is8  = (op == 0x80 || op == 0x83 || op == 0xC0 || op == 0xC1 || op == 0x6B);
    const bool imm8 = (op == 0xB0 || op == 0xB1 || op == 0xB2 || op == 0xB3 ||
                       op == 0xB4 || op == 0xB5 || op == 0xB6 || op == 0xB7 ||
                       op == 0x6A || op == 0xEB || op == 0xCD || op == 0xA8);
    const bool imm16 = (op == 0xC2 || op == 0xCA);
    const bool imm32 = (op == 0xB8 || op == 0xB9 || op == 0xBA || op == 0xBB ||
                        op == 0xBC || op == 0xBD || op == 0xBE || op == 0xBF ||
                        op == 0x68 || op == 0xE8 || op == 0xE9 || op == 0xA9);
    if (is8 || imm8) {
        if (i >= maxLen) return -1;
        const BYTE modrm = p[i++];
        const BYTE mod = (BYTE)(modrm >> 6), rm = (BYTE)(modrm & 7);
        if (mod != 3) {
            if (rm == 4) { ++i; if (i > maxLen) return -1; }          // SIB
            if (mod == 0 && rm == 5) i += 4;                          // RIP 相对（下面拒绝）
            else if (mod == 1) i += 1;
            else if (mod == 2) i += 4;
        }
        if (mod == 0 && rm == 5) return -1;                           // RIP 相对寻址：搬移会失效
        return (i + 1 <= maxLen) ? (i + 1) : -1;
    }
    if (imm16) return (i + 2 <= maxLen) ? (i + 2) : -1;
    if (imm32) return (i + 4 <= maxLen) ? (i + 4) : -1;
    // 其它带 ModRM 的指令
    if (i >= maxLen) return -1;
    {
        const BYTE modrm = p[i++];
        const BYTE mod = (BYTE)(modrm >> 6), rm = (BYTE)(modrm & 7);
        if (mod != 3) {
            if (rm == 4) { ++i; if (i > maxLen) return -1; }
            if (mod == 0 && rm == 5) return -1;                       // RIP 相对 ⇒ 拒绝
            if (mod == 1) i += 1;
            else if (mod == 2) i += 4;
        }
        return (i <= maxLen) ? i : -1;
    }
}

/**
 * 转发桩解包：`kernel32`/`gdi32` 的导出大量是 **6 字节转发桩**
 *   `FF 25 <disp32>`（`jmp qword ptr [rip+disp32]`），其目标是真实实现（常在 kernelbase）。
 * 这种入口 MinHook 与本工程自研解码器都**拒绝搬移**（RIP 相对，搬走后 disp 语义失效），
 * 标准做法是**解包**成真实实现再 hook。
 *
 * ⚠️⚠️ **只解包 `FF 25` 转发桩，绝不解包 `E9 rel32`**（这条是本工程踩过的坑，勿再放开）：
 *   `E9` 是**别的 hook 引擎/热补丁写上去的相对跳转**。MinHook 的 trampoline **本身就能
 *   正确搬移 `E9` 并重算 rel**（`trampoline.c` 的 `CopyInstruction` 处理 `JMP_REL`），
 *   因此"不解包、直接让 MinHook 处理"才是等价语义。
 *   若我方多解一层，实际 hook 的是对方 hook 的**中间层**：
 *     · trampoline 只在"对方中间层"的寄存器/栈假设下成立；
 *     · 我方 detour 转发时跳到的是中间层，而不是原函数 ⇒ 转发语义断裂，
 *       表现为 `System.load(lwjgl.dll)` 报 `找不到指定的程序`(127) /
 *       `Can't find dependent libraries`。
 *   ⇒ 判据严格：只认 `FF 25` / `48 FF 25`；其余（含 `E9`）一律返回 NULL（调用方不做解包）。
 *   解析出的目标还必须"看起来是代码"（VirtualQuery 验证已提交且可执行），否则不采用。
 */
inline LPVOID EchoResolveForwarderTarget(LPVOID target) {
    if (target == NULL) return NULL;
    BYTE b[8];
    __try {
        memcpy(b, target, sizeof(b));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return NULL;
    }
    LPVOID real = NULL;
    if (b[0] == 0x48 && b[1] == 0xFF && b[2] == 0x25) {
        INT32 disp = 0;
        memcpy(&disp, b + 3, 4);
        real = (LPVOID)((ULONG_PTR)target + 7 + (INT64)disp);
    } else if (b[0] == 0xFF && b[1] == 0x25) {
        INT32 disp = 0;
        memcpy(&disp, b + 2, 4);
        real = (LPVOID)((ULONG_PTR)target + 6 + (INT64)disp);
    } else {
        return NULL;      // 含 `E9`：交给 MinHook 自己搬，绝不多解一层
    }
    if (real == NULL || real == target) return NULL;
    // 严格验证：真实目标必须落在已提交且可执行的页上
    MEMORY_BASIC_INFORMATION mbi;
    if (VirtualQuery(real, &mbi, sizeof(mbi)) == 0) return NULL;
    if (mbi.State != MEM_COMMIT) return NULL;
    if ((mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE |
                        PAGE_EXECUTE_WRITECOPY)) == 0) return NULL;
    return real;
}

/**
 * 自研 relay + trampoline（MinHook 搬移失败时的补充路径，绝不放弃这层拦截）：
 *   · relay1（页首 14 字节）：`FF 25 00000000` + <detour 绝对地址> —— 目标入口 `E9 rel32` 跳这里；
 *   · trampoline（relay1 之后）：搬移入口被覆盖的完整指令 → `E9 rel32` 跳回 `target + copied`。
 * `*outOrig` 回传 trampoline（等价原函数的可调用入口，供 detour 放行转发）。
 */
inline bool EchoBuildRelayTrampoline(LPVOID target, LPVOID detour, LPVOID* outOrig, LPVOID* outRelay) {
    if (target == NULL || detour == NULL || outOrig == NULL || outRelay == NULL) return false;
    BYTE prologue[32];
    __try {
        memcpy(prologue, target, sizeof(prologue));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    int copied = 0;
    while (copied < 5) {                        // 至少要盖住 `E9 rel32` 的 5 字节
        const int len = EchoDecodeInsnLen(prologue + copied, 16);
        if (len <= 0) return false;
        copied += len;
        if (copied > 24) return false;
    }
    LPVOID page = EchoAllocRelayNear(target, detour);
    if (page == NULL) return false;
    BYTE* p = (BYTE*)page;
    p[0] = 0xFF; p[1] = 0x25;
    *(DWORD*)(p + 2) = 0;
    *(LPVOID*)(p + 6) = detour;
    BYTE* t = p + 14;
    memcpy(t, prologue, (size_t)copied);
    const long long back = (long long)((ULONG_PTR)target + copied) - ((ULONG_PTR)(t + copied) + 5);
    if (back > 0x7FFFFFFFLL || back < -0x80000000LL) return false;
    t[copied] = 0xE9;
    *(INT32*)(t + copied + 1) = (INT32)back;
    FlushInstructionCache(GetCurrentProcess(), p, (SIZE_T)(14 + copied + 5));
    *outOrig = (LPVOID)t;
    *outRelay = (LPVOID)p;
    return true;
}

/** 原子落跳转：只改前 **5** 字节（`E9 rel32`），尾部 3 字节保持原样（见文件头注释）。 */
inline bool EchoAtomicWriteEntryJump(LPVOID target, LPVOID relay) {
    if (target == NULL || relay == NULL) return false;
    const long long delta = (long long)((ULONG_PTR)relay - ((ULONG_PTR)target + 5));
    if (delta > 0x7FFFFFFFLL || delta < -0x80000000LL) return false;   // relay 必须落在 ±2GB 内
    BYTE patch[8];
    __try {
        memcpy(patch, target, 8);                   // 先照抄原有 8 字节（尾部 3 字节原样保留）
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    patch[0] = 0xE9;                                 // jmp rel32（只覆盖入口的 5 字节）
    *(INT32*)(patch + 1) = (INT32)delta;
    DWORD oldProt = 0;
    if (!VirtualProtect(target, 8, PAGE_EXECUTE_READWRITE, &oldProt)) return false;
    InterlockedExchange64((volatile LONG64*)target, *(LONG64*)patch);  // 单次不可分割存储
    VirtualProtect(target, 8, oldProt, &oldProt);
    FlushInstructionCache(GetCurrentProcess(), target, 8);
    return true;
}

/**
 * 【统一入口】装配一条免冻结挂钩。
 * 顺序铁律：`MH_CreateHook`（拿 trampoline）→ 交转发指针给调用方 → **最后才**落补丁。
 * `original` 既作输出、也作幂等判据（非空 ⇒ 视为已装配，直接返回 true）。
 */
inline bool EchoMinHookInstall(EchoMinHook* mh, const wchar_t* moduleName, const char* procName,
                              LPVOID detour, LPVOID* original) {
    if (!mh || !mh->create || !original || detour == NULL) return false;
    if (*original != nullptr) return true;                       // 幂等：已装配
    HMODULE mod = moduleName ? GetModuleHandleW(moduleName) : GetModuleHandleW(nullptr);
    if (!mod) return false;
    LPVOID target = (LPVOID)GetProcAddress(mod, procName);
    if (target == NULL) return false;

    // ① 转发桩解包（只认严格形态；解包只增覆盖面，不改动别人的 hook）
    LPVOID actualTarget = target;
    {
        LPVOID real = EchoResolveForwarderTarget(target);
        if (real != NULL && real != target) actualTarget = real;
    }

    AcquireSRWLockExclusive(&g_echoAtomicLock);
    int slot = EchoFindAtomicSlot(actualTarget);
    if (slot >= 0 && g_echoAtomicHooks[slot].enabled) {
        if (*original == nullptr) *original = g_echoAtomicHooks[slot].trampoline;
        ReleaseSRWLockExclusive(&g_echoAtomicLock);
        return true;                                             // 幂等：不重复落补丁
    }
    if (slot < 0) {
        if (g_echoAtomicHookCount >= ECHO_ATOMIC_HOOK_MAX) {
            ReleaseSRWLockExclusive(&g_echoAtomicLock);
            return false;
        }
        slot = g_echoAtomicHookCount++;
        g_echoAtomicHooks[slot].target = actualTarget;
        g_echoAtomicHooks[slot].relay = NULL;
        g_echoAtomicHooks[slot].trampoline = NULL;
        g_echoAtomicHooks[slot].enabled = 0;
        __try {
            memcpy(g_echoAtomicHooks[slot].original8, actualTarget, 8);  // 必须在落补丁前保存
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            g_echoAtomicHooks[slot].target = NULL;
            ReleaseSRWLockExclusive(&g_echoAtomicLock);
            return false;
        }
    }

    // ② MH_CreateHook：只拿 trampoline，**不改目标代码**
    LPVOID tramp = NULL;
    bool ok = (mh->create(actualTarget, detour, &tramp) == 0 && tramp != NULL);
    if (!ok) {
        // 自研兜底：MinHook 搬不动（入口已被改写 / 序言形态特殊）⇒ 我们自己搬
        LPVOID selfOrig = NULL;
        LPVOID selfRelay = NULL;
        if (!EchoBuildRelayTrampoline(actualTarget, detour, &selfOrig, &selfRelay)) {
            ReleaseSRWLockExclusive(&g_echoAtomicLock);
            return false;
        }
        *original = selfOrig;                                    // ① 先交转发指针
        g_echoAtomicHooks[slot].trampoline = selfOrig;
        if (!EchoAtomicWriteEntryJump(actualTarget, selfRelay)) { // ② 最后才让补丁生效
            *original = nullptr;
            g_echoAtomicHooks[slot].trampoline = NULL;
            ReleaseSRWLockExclusive(&g_echoAtomicLock);
            return false;
        }
        g_echoAtomicHooks[slot].relay = selfRelay;
        g_echoAtomicHooks[slot].enabled = 1;
        ReleaseSRWLockExclusive(&g_echoAtomicLock);
        return true;
    }
    LPVOID relay = g_echoAtomicHooks[slot].relay;
    if (relay == NULL) {
        relay = EchoAllocRelayNear(actualTarget, detour);
        if (relay == NULL) {
            ReleaseSRWLockExclusive(&g_echoAtomicLock);
            return false;
        }
        g_echoAtomicHooks[slot].relay = relay;
    }
    *original = tramp;                                           // ① 先交转发指针（零窗口）
    g_echoAtomicHooks[slot].trampoline = tramp;
    if (!EchoAtomicWriteEntryJump(actualTarget, relay)) {          // ② 最后才让补丁生效
        *original = nullptr;                                     // 落补丁失败 ⇒ 撤回，绝不留悬空
        g_echoAtomicHooks[slot].trampoline = NULL;
        ReleaseSRWLockExclusive(&g_echoAtomicLock);
        return false;
    }
    g_echoAtomicHooks[slot].enabled = 1;
    ReleaseSRWLockExclusive(&g_echoAtomicLock);
    return true;
}

/**
 * 【补丁完整性校验】核对每条免冻结 hook 的入口是否仍指向我方 relay；被第三方还原/覆盖即当场重写。
 * 判据只看入口前 5 字节是否为 `E9 <rel32→我们的 relay>`（我方补丁形态，不与任何第三方名字比较）。
 * 返回"仍完好"条数；`restored` 输出"当场重写恢复"条数。
 */
inline int EchoAtomicHookVerify(int* restored) {
    int ok = 0;
    int fixed = 0;
    AcquireSRWLockExclusive(&g_echoAtomicLock);
    for (int i = 0; i < g_echoAtomicHookCount; ++i) {
        EchoAtomicHookEntry& e = g_echoAtomicHooks[i];
        if (!e.enabled || e.target == NULL || e.relay == NULL) continue;
        BYTE now[5];
        __try {
            memcpy(now, e.target, 5);
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            continue;                                            // 读不到 ⇒ 跳过，绝不崩
        }
        const long long delta = (long long)((ULONG_PTR)e.relay - ((ULONG_PTR)e.target + 5));
        BYTE expect[5];
        expect[0] = 0xE9;
        *(INT32*)(expect + 1) = (INT32)delta;
        if (memcmp(now, expect, 5) == 0) {
            ++ok;
            continue;
        }
        if (EchoAtomicWriteEntryJump(e.target, e.relay)) ++fixed;  // 被改写 ⇒ 原子写回
    }
    ReleaseSRWLockExclusive(&g_echoAtomicLock);
    if (restored != NULL) *restored = fixed;
    return ok;
}

/** 已装配条数（诊断用）。 */
inline int EchoAtomicHookCount() {
    return g_echoAtomicHookCount;
}
