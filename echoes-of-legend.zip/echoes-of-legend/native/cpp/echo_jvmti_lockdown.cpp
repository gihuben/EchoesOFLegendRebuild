// ============================================================================
// echo_jvmti_lockdown.cpp —— 全局 JVMTI 函数表劫持（底层防御·原生层）+ 三层白名单
//
// 【设计要点】（47 槽位 typed proxy / 三层白名单 / 假成功拒绝 /
//   GetStackTrace 剔帧 / 能力查询清零）+ JVMTI 拦截思路（环境枚举与 agent 监控，
//   我方落地为"锁表 + 调用源不可信一律假成功/清零/剔帧"，不触碰 HotSpot 内部结构）。
//
// 【为什么锁 JVMTI 函数表】JVMTI 是"比 Instrumentation 更底层"的进程内接口：
//   · 敌方 agent 拿到任意 jvmtiEnv* 后可以 AddCapabilities 抢 can_redefine_any_class
//     （solo 能力先到先得）、SetEventCallbacks 注册自己的 CFLH 偷看/改写类字节、
//     RetransformClasses/RedefineClasses 改我方类、AddModuleOpens 给 java.base 开洞、
//     SuspendThread/StopThread 停我方线程、SetLocal*/ForceEarlyReturn* 改我方执行流……
//   这些通道**不经过** Java 层 Instrumentation 的可见面，Java 侧防御管不到 ⇒ 必须在
//   native 层把全局函数表 `jvmtiInterface_1_` 的敏感槽位换掉。
//
// 【本库做什么】把所有 jvmtiEnv 共享的全局静态表 `jvmtiInterface_1_` 的 47 个敏感槽位
//   替换为"类型化代理"（typed proxy）。代理调用前做三层白名单判定：
//     层1：类加载器精确匹配（本模组类加载器 == g_trusted_loader，无法伪造）
//     层2：包签名**严格前缀**（Lcom/echoxy/…; ⇒ 必须是类的真实包路径，防"子串注入"）
//     层3：调用栈扫描（栈上任一 Java 帧声明类可信 ⇒ 放行；敌方 native/agent 线程无我方帧）
//   可信调用者 → 转发给原函数（本模组一切正常）；
//   敌方/未知调用者 → 返回 JVMTI_ERROR_NONE（假成功：不报错、不进错误路径、实际未发生）。
//
// 【带 out 参数函数的铁律（0xc0000374 堆损坏血证）】绝不"拒绝且不转发"带 out 参数的函数
//   （调用方读到未初始化 buffer ⇒ 堆损坏）。三类特殊处理：
//     · GetStackTrace：无条件转发，随后剔除"我方帧"（只剔帧、不拒绝 ⇒ 原版/Forge 照常）；
//     · GetCapabilities / GetPotentialCapabilities：转发后清零（"这台 JVM 没有能力"）；
//     · DefineClass：JDK17 无此成员（仅记录 + 初始化 out 后再报错，绝不猜槽位号）。
//
// 【两种模式】
//   safe（选择性）：只锁 kSelectiveSlots 的 19 个槽位（事件注册/能力/类变换/类路径/模块操作）。
//   all（深锁）  ：再叠加 kDeepSlots 的 28 个槽位（线程控制/执行流/局部变量/断点/环境销毁/
//                 堆枚举/GC 干扰）——全部"无 out 参数"⇒ 假成功安全；RawMonitor* 一族
//                 **刻意排除**（JVM 回调上下文自发调用，锁了必死锁）。
//
// 【保命底线】白名单锚点未注入（极端情况）⇒ do_disable* 返回 -10 完全透明降级，
//   绝不拦截任何东西（宁可放敌，绝不误伤）。所有代理/回调被 SEH 包裹，异常静默吞掉。
//
// 【零 C++ 运行时依赖】不得使用任何"非常量初始化"的 C++ 全局对象（System.load 下 CRT
//   静态构造不执行 ⇒ std::mutex 解引用 NULL 崩，实测 hs_err）：全部用 POD + SRWLOCK。
//
// 构建（与样板同源）：
//   cl /nologo /utf-8 /O2 /MT /LD /DWIN32 /D_WINDOWS
//      /I"%JAVA_HOME%/include" /I"%JAVA_HOME%/include/win32"
//      echo_jvmti_lockdown.cpp /link /DLL /OUT:echo_jvmti_lockdown.dll
// 运行时装配：Java 侧 EchoJvmtiLockdown.ensure() 从 assets 解出本 DLL → System.load →
//   nInit(本模组类加载器, "com/echoxy/") → 按配置 nDisableSelective / nDisableAll。
//   JNI 导出名 = Java_com_echoxy_agent_EchoJvmtiLockdown_*（改包必须同步改这里）。
// ============================================================================

#include <jni.h>
#include <jvmti.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#ifdef _WIN32
  #include <windows.h>
  // 免冻结（原子）挂钩：`MH_EnableHook` 会 `Freeze()` 挂起进程全部线程并 `SetThreadContext`
  // 改写其 RIP ⇒ 寄存器被污染成其它栈帧的旧值 ⇒ `ntdll!LdrLoadDll+0x64` 确定性崩溃
  // （实测表现为 `lwjgl.dll: 找不到指定的程序` / `Can't find dependent libraries`）。
  // 详见 echo_minhook.h 文件头血证段。本文件的 `Agent_OnAttach` hook 同样必须走原子路径。
  #include "echo_minhook.h"
#else
  #include <sys/mman.h>
  #include <unistd.h>
  #include <sched.h>
#endif

// 跨平台指针级原子写入（POD，无 C++ 运行时依赖）
#ifdef _WIN32
#define ATOMIC_PTR_STORE(dst, val) (void)InterlockedExchangePointer((volatile PVOID*)(dst), (PVOID)(val))
#else
#define ATOMIC_PTR_STORE(dst, val) __atomic_store_n((dst), (val), __ATOMIC_SEQ_CST)
#endif

// 按成员名计算函数表槽位下标（jvmtiInterface_1_ 成员顺序随 JDK 版本变化，offsetof 最稳）
#define JVMTI_SLOT(member) (offsetof(jvmtiInterface_1_, member) / sizeof(void*))

// 互斥锁：静态初始化（编译期常量，不依赖 C++ 全局构造）
#ifdef _WIN32
static SRWLOCK g_lock = SRWLOCK_INIT;
#define LOCK_BEGIN() AcquireSRWLockExclusive(&g_lock)
#define LOCK_END() ReleaseSRWLockExclusive(&g_lock)
#else
static volatile int g_lock = 0;
#define LOCK_BEGIN() do { while (__atomic_exchange_n(&g_lock, 1, __ATOMIC_ACQ_REL)) sched_yield(); } while (0)
#define LOCK_END() __atomic_store_n(&g_lock, 0, __ATOMIC_RELEASE)
#endif

// 异常吞噬包装：Windows 用 SEH（不带 /EHsc 编译），Linux 用 try/catch
#ifdef _WIN32
#define GUARD_BEGIN      __try {
#define GUARD_END_ERR    } __except(EXCEPTION_EXECUTE_HANDLER) { return (jvmtiError)JVMTI_ERROR_INTERNAL; }
#define GUARD_END_VOID   } __except(EXCEPTION_EXECUTE_HANDLER) { return; }
#define GUARD_END_BOOL   } __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
#define GUARD_END_INT(v) } __except(EXCEPTION_EXECUTE_HANDLER) { return (v); }
#else
#define GUARD_BEGIN      try {
#define GUARD_END_ERR    } catch (...) { return (jvmtiError)JVMTI_ERROR_INTERNAL; }
#define GUARD_END_VOID   } catch (...) { return; }
#define GUARD_END_BOOL   } catch (...) { return false; }
#define GUARD_END_INT(v) } catch (...) { return (v); }
#endif

// ===== 【反调用检测】GetStackTrace"我方帧剔除"开关与计数（POD，常量初始化） =====
static volatile bool g_stackHideOn = true;
static volatile bool g_capHideOn = true;
static volatile bool g_deepLockOn = true;
static volatile unsigned long g_stackHiddenFrames = 0;
static volatile unsigned long g_capProbeHidden = 0;

namespace {

    JavaVM*   g_vm  = nullptr;
    jvmtiEnv* g_env = nullptr;
    // NATIVE AGENT 通道是否已通过 Agent_OnLoad/Agent_OnAttach 拉起（诊断用）
    bool      g_agentBooted = false;
    bool g_disabled    = false;
    bool g_selective   = false;   // true = 仅选择性代理（安全模式）
    bool g_have_backup = false;
    jvmtiInterface_1_* g_table   = nullptr;
    void**             g_backup  = nullptr;
    size_t             g_entries = 0;
    void*              g_proxy_slot[192] = { nullptr };

    // ===================== 白名单全局锚点 =====================
    jobject g_trusted_loader = nullptr;       // 本模组类加载器（全局强引用）
    char    g_trusted_pkg[160] = { 0 };       // 本模组包前缀（.data 清零由加载器保证）
    bool    g_trusted_init = false;

    // ===================== 内部原函数指针（备份表，规避代理自引用） =====================
    typedef jvmtiError (JNICALL* FN_GetClassLoader)(jvmtiEnv*, jclass, jobject*);
    typedef jvmtiError (JNICALL* FN_GetClassSignature)(jvmtiEnv*, jclass, char**, char**);
    typedef jvmtiError (JNICALL* FN_GetMethodDeclaringClass)(jvmtiEnv*, jmethodID, jclass*);
    typedef jvmtiError (JNICALL* FN_GetStackTrace)(jvmtiEnv*, jthread, jint, jint, jvmtiFrameInfo*, jint*);
    typedef jvmtiError (JNICALL* FN_Deallocate)(jvmtiEnv*, unsigned char*);
    typedef jvmtiError (JNICALL* FN_GetPotentialCapabilities)(jvmtiEnv*, jvmtiCapabilities*);
    typedef jvmtiError (JNICALL* FN_AddCapabilities)(jvmtiEnv*, const jvmtiCapabilities*);
    typedef jvmtiError (JNICALL* FN_SetEventCallbacks)(jvmtiEnv*, const jvmtiEventCallbacks*, jint);
    typedef jvmtiError (JNICALL* FN_SetEventNotificationMode)(jvmtiEnv*, jvmtiEventMode, jvmtiEvent, jthread);
    typedef jvmtiError (JNICALL* FN_GetLoadedClasses)(jvmtiEnv*, jint*, jclass**);
    typedef jvmtiError (JNICALL* FN_GetMethodName)(jvmtiEnv*, jmethodID, char**, char**, char**);

    static FN_GetClassLoader            fn_GetClassLoader = nullptr;
    static FN_GetClassSignature         fn_GetClassSignature = nullptr;
    static FN_GetMethodDeclaringClass   fn_GetMethodDeclaringClass = nullptr;
    static FN_GetStackTrace             fn_GetStackTrace = nullptr;
    static FN_Deallocate                fn_Deallocate = nullptr;
    static FN_GetPotentialCapabilities  fn_GetPotentialCapabilities = nullptr;
    static FN_AddCapabilities           fn_AddCapabilities = nullptr;
    static FN_SetEventCallbacks         fn_SetEventCallbacks = nullptr;
    static FN_SetEventNotificationMode  fn_SetEventNotificationMode = nullptr;
    static FN_GetLoadedClasses          fn_GetLoadedClasses = nullptr;
    static FN_GetMethodName             fn_GetMethodName = nullptr;

    // 无专用代理槽位的兜底（返回 NOT_AVAILABLE；仅对"无 out 参数"槽位生效）
    extern "C" jvmtiError JNICALL deny_stub() {
        return (jvmtiError)JVMTI_ERROR_NOT_AVAILABLE;
    }

    bool make_rw(void* addr, size_t len) {
#ifdef _WIN32
        DWORD oldp = 0;
        return VirtualProtect(addr, len, PAGE_READWRITE, &oldp) != 0;
#else
        long psc = sysconf(_SC_PAGESIZE);
        if (psc <= 0) return false;
        const size_t ps = (size_t)psc;
        uintptr_t start = (uintptr_t)addr & ~(uintptr_t)(ps - 1);
        uintptr_t end   = (uintptr_t)addr + len;
        size_t span = (size_t)((end - start + ps - 1) & ~(uintptr_t)(ps - 1));
        return mprotect((void*)start, span, PROT_READ | PROT_WRITE) == 0;
#endif
    }

    jvmtiEnv* get_jvmti() {
        if (g_env) return g_env;
        if (!g_vm) return nullptr;
        void* p = nullptr;
        if (g_vm->GetEnv(&p, JVMTI_VERSION_1_2) == JNI_OK ||
            g_vm->GetEnv(&p, JVMTI_VERSION_1_1) == JNI_OK ||
            g_vm->GetEnv(&p, JVMTI_VERSION_1_0) == JNI_OK) {
            g_env = (jvmtiEnv*)p;
        }
        return g_env;
    }

    // ===================== 三层白名单判定 =====================

    // 核心判定：类是否可信（层1 加载器精确匹配 + 层2 包签名严格前缀）
    bool class_is_trusted(JNIEnv* jni, jclass clazz) {
        if (!clazz || !jni || !g_trusted_init) return false;
        jvmtiEnv* jvmti = get_jvmti();
        if (!jvmti) return false;
        // ---- 层1：类加载器精确匹配（最可靠，无法伪造）----
        if (g_trusted_loader && fn_GetClassLoader) {
            jobject loader = nullptr;
            if (fn_GetClassLoader(jvmti, clazz, &loader) == JVMTI_ERROR_NONE && loader) {
                if (jni->IsSameObject(loader, g_trusted_loader)) return true;
            }
        }
        // ---- 层2：包签名严格前缀（Lcom/echoxy/…; 必须是类真实包路径，防"子串注入"）----
        if (g_trusted_pkg[0] != '\0' && fn_GetClassSignature) {
            char* sig = nullptr;
            if (fn_GetClassSignature(jvmti, clazz, &sig, nullptr) == JVMTI_ERROR_NONE && sig) {
                bool hit = false;
                const size_t pn = strlen(g_trusted_pkg);
                if (pn > 0 && sig[0] == 'L' && strncmp(sig + 1, g_trusted_pkg, pn) == 0) hit = true;
                if (fn_Deallocate) fn_Deallocate(jvmti, (unsigned char*)sig);
                if (hit) return true;
            }
        }
        return false;
    }

    // 层3：调用栈扫描——栈上任一帧声明类可信 → 放行
    bool stack_has_trusted_frame(JNIEnv* jni) {
        if (!g_trusted_init) return false;
        jvmtiEnv* jvmti = get_jvmti();
        if (!jvmti || !fn_GetStackTrace || !fn_GetMethodDeclaringClass) return false;
        jvmtiFrameInfo frames[24];
        jint count = 0;
        if (fn_GetStackTrace(jvmti, nullptr, 0, 24, frames, &count) != JVMTI_ERROR_NONE) return false;
        // ⚠️ GetMethodDeclaringClass 的返回是 JNI 本地引用（不是 JVMTI 分配内存）
        //   ⇒ 绝不可 Deallocate（曾致延迟堆损坏 0xc0000374）；用 Push/PopLocalFrame 统一释放。
        if (jni->PushLocalFrame(32) != JNI_OK) return false;
        bool trusted = false;
        for (jint i = 0; i < count; ++i) {
            jclass cls = nullptr;
            if (fn_GetMethodDeclaringClass(jvmti, frames[i].method, &cls) == JVMTI_ERROR_NONE && cls) {
                if (class_is_trusted(jni, cls)) {
                    trusted = true;
                    break;
                }
            }
        }
        jni->PopLocalFrame(nullptr);
        return trusted;
    }

    // 原始 JNIEnv 取用（vtable GetEnv hook 装好后必须走原函数，避免递归）
    JNIEnv* get_jni_env();

    // 代理入口的统一信任判定
    bool caller_trusted() {
        GUARD_BEGIN
            if (!g_trusted_init || !g_vm) return false;
            JNIEnv* jni = get_jni_env();
            if (!jni) return false;
            return stack_has_trusted_frame(jni);
        GUARD_END_BOOL
    }

    // ===================== 类型化代理（可信转发 / 敌方"假成功"拒绝） =====================
    // 每个代理与 JVMTI 原函数签名完全一致；调用前做 caller_trusted() 判定。
    // ⚠️ 假成功拒绝：不可信调用者拿到 JVMTI_ERROR_NONE（不报错、不进错误路径），
    //   我们**不转发**（实际效果未发生）。只用于"无 out 参数"的函数。
#define PROXY_FUNC(name, params, call) \
    extern "C" jvmtiError JNICALL proxy_##name params { \
        GUARD_BEGIN \
            if (g_backup && caller_trusted()) { \
                typedef jvmtiError (JNICALL *fn_t) params; \
                fn_t f = (fn_t)g_backup[JVMTI_SLOT(name)]; \
                return f call; \
            } \
        GUARD_END_ERR \
        return (jvmtiError)JVMTI_ERROR_NONE; /* 假成功：不转发但返回成功 */ \
    }

    // —— 事件 / 能力 / 监控（选择性集合）——
    PROXY_FUNC(SetEventCallbacks, (jvmtiEnv* env, const jvmtiEventCallbacks* callbacks, jint size_of_callbacks), (env, callbacks, size_of_callbacks))
    PROXY_FUNC(SetEventNotificationMode, (jvmtiEnv* env, jvmtiEventMode mode, jvmtiEvent event_type, jthread event_thread), (env, mode, event_type, event_thread))
    PROXY_FUNC(AddCapabilities, (jvmtiEnv* env, const jvmtiCapabilities* capabilities_ptr), (env, capabilities_ptr))
    PROXY_FUNC(RelinquishCapabilities, (jvmtiEnv* env, const jvmtiCapabilities* capabilities_ptr), (env, capabilities_ptr))
    PROXY_FUNC(SetVerboseFlag, (jvmtiEnv* env, jvmtiVerboseFlag flag, jboolean value), (env, flag, value))
    PROXY_FUNC(GenerateEvents, (jvmtiEnv* env, jvmtiEvent event_type), (env, event_type))

    // —— 类变换 / 注入 / 类路径（选择性集合）——
    PROXY_FUNC(RetransformClasses, (jvmtiEnv* env, jint class_count, const jclass* classes), (env, class_count, classes))
    PROXY_FUNC(RedefineClasses, (jvmtiEnv* env, jint class_count, const jvmtiClassDefinition* class_definitions), (env, class_count, class_definitions))
    PROXY_FUNC(AddToBootstrapClassLoaderSearch, (jvmtiEnv* env, const char* segment), (env, segment))
    PROXY_FUNC(AddToSystemClassLoaderSearch, (jvmtiEnv* env, const char* segment), (env, segment))
    PROXY_FUNC(SetNativeMethodPrefix, (jvmtiEnv* env, const char* prefix), (env, prefix))

    // —— 模块操作（JVMTI 1.2/JDK9+；全部无 out 参数 ⇒ 假成功安全）——
    PROXY_FUNC(AddModuleReads, (jvmtiEnv* env, jobject module, jobject to_module), (env, module, to_module))
    PROXY_FUNC(AddModuleExports, (jvmtiEnv* env, jobject module, const char* pkg, jobject to_module), (env, module, pkg, to_module))
    PROXY_FUNC(AddModuleOpens, (jvmtiEnv* env, jobject module, const char* pkg, jobject to_module), (env, module, pkg, to_module))
    PROXY_FUNC(AddModuleUses, (jvmtiEnv* env, jobject module, jclass service), (env, module, service))
    PROXY_FUNC(AddModuleProvides, (jvmtiEnv* env, jobject module, jclass service, jclass impl_class), (env, module, service, impl_class))

    // ==========================================================================================
    // 深锁段（kDeepSlots，28 个）：敌方拿到 jvmtiEnv 后无需任何 capability 就能对我方动手的通道。
    // 全部"无 out 参数"⇒ 假成功拒绝安全。RawMonitor* 一族（JVMTI 回调上下文锁原语）
    // **刻意排除**——JVM 会自发调用，锁了必死锁。
    // ==========================================================================================
    // —— 线程控制 ——
    PROXY_FUNC(SuspendThread, (jvmtiEnv* env, jthread thread), (env, thread))
    PROXY_FUNC(ResumeThread, (jvmtiEnv* env, jthread thread), (env, thread))
    PROXY_FUNC(StopThread, (jvmtiEnv* env, jthread thread, jobject exception), (env, thread, exception))
    PROXY_FUNC(InterruptThread, (jvmtiEnv* env, jthread thread), (env, thread))

    // —— 执行流控制（强制早退 / 弹栈）——
    PROXY_FUNC(NotifyFramePop, (jvmtiEnv* env, jthread thread, jint depth), (env, thread, depth))
    PROXY_FUNC(PopFrame, (jvmtiEnv* env, jthread thread), (env, thread))
    PROXY_FUNC(ForceEarlyReturnObject, (jvmtiEnv* env, jthread thread, jobject value), (env, thread, value))
    PROXY_FUNC(ForceEarlyReturnInt, (jvmtiEnv* env, jthread thread, jint value), (env, thread, value))
    PROXY_FUNC(ForceEarlyReturnLong, (jvmtiEnv* env, jthread thread, jlong value), (env, thread, value))
    PROXY_FUNC(ForceEarlyReturnFloat, (jvmtiEnv* env, jthread thread, jfloat value), (env, thread, value))
    PROXY_FUNC(ForceEarlyReturnDouble, (jvmtiEnv* env, jthread thread, jdouble value), (env, thread, value))
    PROXY_FUNC(ForceEarlyReturnVoid, (jvmtiEnv* env, jthread thread), (env, thread))

    // —— 局部变量改写 ——
    PROXY_FUNC(SetLocalObject, (jvmtiEnv* env, jthread thread, jint depth, jint slot, jobject value), (env, thread, depth, slot, value))
    PROXY_FUNC(SetLocalInt, (jvmtiEnv* env, jthread thread, jint depth, jint slot, jint value), (env, thread, depth, slot, value))
    PROXY_FUNC(SetLocalLong, (jvmtiEnv* env, jthread thread, jint depth, jint slot, jlong value), (env, thread, depth, slot, value))
    PROXY_FUNC(SetLocalFloat, (jvmtiEnv* env, jthread thread, jint depth, jint slot, jfloat value), (env, thread, depth, slot, value))
    PROXY_FUNC(SetLocalDouble, (jvmtiEnv* env, jthread thread, jint depth, jint slot, jdouble value), (env, thread, depth, slot, value))

    // —— 断点 / 字段监视（调试与窥探通道）——
    PROXY_FUNC(SetBreakpoint, (jvmtiEnv* env, jmethodID method, jlocation location), (env, method, location))
    PROXY_FUNC(ClearBreakpoint, (jvmtiEnv* env, jmethodID method, jlocation location), (env, method, location))
    PROXY_FUNC(SetFieldAccessWatch, (jvmtiEnv* env, jclass klass, jfieldID field), (env, klass, field))
    PROXY_FUNC(ClearFieldAccessWatch, (jvmtiEnv* env, jclass klass, jfieldID field), (env, klass, field))
    PROXY_FUNC(SetFieldModificationWatch, (jvmtiEnv* env, jclass klass, jfieldID field), (env, klass, field))
    PROXY_FUNC(ClearFieldModificationWatch, (jvmtiEnv* env, jclass klass, jfieldID field), (env, klass, field))

    // —— 环境销毁 / 堆枚举 / 扩展事件 / GC 干扰 ——
    PROXY_FUNC(DisposeEnvironment, (jvmtiEnv* env), (env))
    PROXY_FUNC(IterateOverInstancesOfClass, (jvmtiEnv* env, jclass klass, jvmtiHeapObjectFilter object_filter, jvmtiHeapObjectCallback heap_object_callback, const void* user_data), (env, klass, object_filter, heap_object_callback, user_data))
    PROXY_FUNC(SetExtensionEventCallback, (jvmtiEnv* env, jint extension_event_index, jvmtiExtensionEvent callback), (env, extension_event_index, callback))
    PROXY_FUNC(ForceGarbageCollection, (jvmtiEnv* env), (env))
    PROXY_FUNC(SetHeapSamplingInterval, (jvmtiEnv* env, jint sampling_interval), (env, sampling_interval))

    // ===================== 专用代理：能力查询清零（带 out 参数 ⇒ 转发后清零） =====================
    static jvmtiError cap_query_hide(jvmtiEnv* env, jvmtiCapabilities* cap, int slot) {
        typedef jvmtiError (JNICALL *fn_t)(jvmtiEnv*, jvmtiCapabilities*);
        fn_t f = (g_backup && slot > 0 && slot < 190) ? (fn_t) g_backup[slot] : nullptr;
        if (!f) return (jvmtiError) JVMTI_ERROR_NONE;
        jvmtiError rc = f(env, cap);
        if (rc == JVMTI_ERROR_NONE && cap != nullptr && g_capHideOn) {
            memset((void*) cap, 0, sizeof(jvmtiCapabilities));
            g_capProbeHidden++;
        }
        return rc;
    }

    extern "C" jvmtiError JNICALL proxy_GetCapabilities(jvmtiEnv* env, jvmtiCapabilities* cap) {
        GUARD_BEGIN
            if (caller_trusted()) {
                typedef jvmtiError (JNICALL *fn_t)(jvmtiEnv*, jvmtiCapabilities*);
                fn_t f = (g_backup) ? (fn_t) g_backup[JVMTI_SLOT(GetCapabilities)] : nullptr;
                if (f) return f(env, cap);
            }
            return cap_query_hide(env, cap, (int) JVMTI_SLOT(GetCapabilities));
        GUARD_END_ERR
        return (jvmtiError) JVMTI_ERROR_NONE;
    }

    extern "C" jvmtiError JNICALL proxy_GetPotentialCapabilities(jvmtiEnv* env, jvmtiCapabilities* cap) {
        GUARD_BEGIN
            if (caller_trusted()) {
                typedef jvmtiError (JNICALL *fn_t)(jvmtiEnv*, jvmtiCapabilities*);
                fn_t f = (g_backup) ? (fn_t) g_backup[JVMTI_SLOT(GetPotentialCapabilities)] : nullptr;
                if (f) return f(env, cap);
            }
            return cap_query_hide(env, cap, (int) JVMTI_SLOT(GetPotentialCapabilities));
        GUARD_END_ERR
        return (jvmtiError) JVMTI_ERROR_NONE;
    }

    // ===================== 专用代理：GetStackTrace（转发后剔除我方帧） =====================
    // 用户语义："禁止其他模组检测攻击/防御的调用源"。只剔我方帧（不拒绝、不空栈）：
    // 原版/Forge/JDK 的栈查询照常；第三方自己的逻辑不受影响；JVM 内部调用也不会拿到空栈。
    static const int kHideCacheSlots = 512;
    static jmethodID g_hideCacheId[kHideCacheSlots] = { nullptr };
    static unsigned char g_hideCacheVal[kHideCacheSlots] = { 0 };
    static volatile long g_hideCacheIdx = 0;

    // 某个 methodID 是否属于我方（带缓存；任何失败 ⇒ false = 保留）
    bool method_is_ours(JNIEnv* jni, jmethodID mid) {
        if (jni == nullptr || mid == nullptr) return false;
        int base = (int) g_hideCacheIdx;
        if (base < 0) base = -base;
        for (int i = 0; i < kHideCacheSlots; ++i) {
            int slot = (base + i) % kHideCacheSlots;
            if (g_hideCacheId[slot] == mid) return g_hideCacheVal[slot] != 0;
        }
        bool ours = false;
        GUARD_BEGIN
            jvmtiEnv* jvmti = get_jvmti();
            if (jvmti && fn_GetMethodDeclaringClass) {
                jclass cls = nullptr;
                if (fn_GetMethodDeclaringClass(jvmti, mid, &cls) == JVMTI_ERROR_NONE && cls) {
                    ours = class_is_trusted(jni, cls);
                }
                // 返回的是 JNI 本地引用 ⇒ 由外层 PopLocalFrame 释放，绝不 Deallocate
            }
        GUARD_END_BOOL
        int slot = (int) (++g_hideCacheIdx);
        if (slot < 0) slot = -slot;
        slot = slot % kHideCacheSlots;
        g_hideCacheId[slot] = mid;
        g_hideCacheVal[slot] = ours ? 1 : 0;
        return ours;
    }

    // 专用代理：无条件转发（保证 out 参数写满），随后按需剔除我方帧
    extern "C" jvmtiError JNICALL proxy_GetStackTrace(jvmtiEnv* env, jthread thread, jint max_depth,
                                                      jint start_depth, jvmtiFrameInfo* frame_buffer,
                                                      jint* count_ptr) {
        GUARD_BEGIN
            if (g_backup) {
                typedef jvmtiError (JNICALL *fn_t)(jvmtiEnv*, jthread, jint, jint, jvmtiFrameInfo*, jint*);
                fn_t f = (fn_t) g_backup[JVMTI_SLOT(GetStackTrace)];
                if (f) {
                    jvmtiError rc = f(env, thread, max_depth, start_depth, frame_buffer, count_ptr);
                    if (rc == JVMTI_ERROR_NONE && count_ptr != nullptr && frame_buffer != nullptr
                            && *count_ptr > 0 && g_stackHideOn && !caller_trusted()) {
                        JNIEnv* jni = nullptr;
                        if (g_vm && g_vm->GetEnv((void**) &jni, JNI_VERSION_1_8) == JNI_OK && jni
                                && jni->PushLocalFrame(32) == JNI_OK) {
                            jint count = *count_ptr;
                            jint w = 0;
                            for (jint i = 0; i < count; ++i) {
                                if (method_is_ours(jni, frame_buffer[i].method)) {
                                    ++g_stackHiddenFrames;
                                } else {
                                    if (w != i) frame_buffer[w] = frame_buffer[i];
                                    ++w;
                                }
                            }
                            jni->PopLocalFrame(nullptr);
                            *count_ptr = w;
                        }
                    }
                    return rc;
                }
            }
        GUARD_END_ERR
        return (jvmtiError) JVMTI_ERROR_NONE;
    }

    // ===================== 专用代理：DefineClass（JDK17 无此成员，仅记录） =====================
    // JDK 17 的 jvmti.h 没有 DefineClass 成员（188 个成员逐个核对）⇒ 没有槽位可装，
    // 保留本函数体仅作记录："这条曾被视为致命缺口，经查证是不存在的 API"。
    extern "C" jvmtiError JNICALL proxy_DefineClass(jvmtiEnv* env, const char* name, jobject loader,
                                                    const unsigned char* class_data, jint class_data_len,
                                                    const unsigned char** new_class_data,
                                                    jint* new_class_data_len, jclass* class_ptr) {
        (void) env; (void) name; (void) loader; (void) class_data; (void) class_data_len;
        if (new_class_data != nullptr) *new_class_data = nullptr;
        if (new_class_data_len != nullptr) *new_class_data_len = 0;
        if (class_ptr != nullptr) *class_ptr = nullptr;
        return (jvmtiError) JVMTI_ERROR_NOT_AVAILABLE;
    }

    // ===================== 槽位集合 =====================

    // 选择性集合（19 个）：事件注册 / 能力变更 / 类变换 / 类路径注入 / 模块操作 / 能力查询
    static const size_t kSelectiveSlots[] = {
        JVMTI_SLOT(SetEventCallbacks),
        JVMTI_SLOT(SetEventNotificationMode),
        JVMTI_SLOT(AddCapabilities),
        JVMTI_SLOT(RelinquishCapabilities),
        JVMTI_SLOT(SetVerboseFlag),
        JVMTI_SLOT(GenerateEvents),
        JVMTI_SLOT(AddToBootstrapClassLoaderSearch),
        JVMTI_SLOT(AddToSystemClassLoaderSearch),
        JVMTI_SLOT(SetNativeMethodPrefix),
        JVMTI_SLOT(RetransformClasses),
        JVMTI_SLOT(RedefineClasses),
        JVMTI_SLOT(AddModuleReads),
        JVMTI_SLOT(AddModuleExports),
        JVMTI_SLOT(AddModuleOpens),
        JVMTI_SLOT(AddModuleUses),
        JVMTI_SLOT(AddModuleProvides),
        JVMTI_SLOT(GetStackTrace),
        JVMTI_SLOT(GetCapabilities),
        JVMTI_SLOT(GetPotentialCapabilities),
    };

    // 深锁集合（28 个）：线程控制 / 执行流 / 局部变量 / 断点 / 环境销毁 / 堆枚举 / GC 干扰
    // 全部"无 out 参数"⇒ 假成功拒绝安全（带 out 的一律不进此表）。
    static const size_t kDeepSlots[] = {
        JVMTI_SLOT(SuspendThread),
        JVMTI_SLOT(ResumeThread),
        JVMTI_SLOT(StopThread),
        JVMTI_SLOT(InterruptThread),
        JVMTI_SLOT(NotifyFramePop),
        JVMTI_SLOT(PopFrame),
        JVMTI_SLOT(ForceEarlyReturnObject),
        JVMTI_SLOT(ForceEarlyReturnInt),
        JVMTI_SLOT(ForceEarlyReturnLong),
        JVMTI_SLOT(ForceEarlyReturnFloat),
        JVMTI_SLOT(ForceEarlyReturnDouble),
        JVMTI_SLOT(ForceEarlyReturnVoid),
        JVMTI_SLOT(SetLocalObject),
        JVMTI_SLOT(SetLocalInt),
        JVMTI_SLOT(SetLocalLong),
        JVMTI_SLOT(SetLocalFloat),
        JVMTI_SLOT(SetLocalDouble),
        JVMTI_SLOT(SetBreakpoint),
        JVMTI_SLOT(ClearBreakpoint),
        JVMTI_SLOT(SetFieldAccessWatch),
        JVMTI_SLOT(ClearFieldAccessWatch),
        JVMTI_SLOT(SetFieldModificationWatch),
        JVMTI_SLOT(ClearFieldModificationWatch),
        JVMTI_SLOT(DisposeEnvironment),
        JVMTI_SLOT(IterateOverInstancesOfClass),
        JVMTI_SLOT(SetExtensionEventCallback),
        JVMTI_SLOT(ForceGarbageCollection),
        JVMTI_SLOT(SetHeapSamplingInterval),
    };

    // 我方代理表：槽位下标 → 代理函数指针（仅"有专用代理"的槽位）
    void build_proxy_map() {
#define MAP(name) g_proxy_slot[JVMTI_SLOT(name)] = (void*)&proxy_##name
        MAP(SetEventCallbacks);
        MAP(SetEventNotificationMode);
        MAP(AddCapabilities);
        MAP(RelinquishCapabilities);
        MAP(SetVerboseFlag);
        MAP(GenerateEvents);
        MAP(RetransformClasses);
        MAP(RedefineClasses);
        MAP(AddToBootstrapClassLoaderSearch);
        MAP(AddToSystemClassLoaderSearch);
        MAP(SetNativeMethodPrefix);
        MAP(AddModuleReads);
        MAP(AddModuleExports);
        MAP(AddModuleOpens);
        MAP(AddModuleUses);
        MAP(AddModuleProvides);
        MAP(GetStackTrace);
        MAP(GetCapabilities);
        MAP(GetPotentialCapabilities);
        // 深锁段
        MAP(SuspendThread);
        MAP(ResumeThread);
        MAP(StopThread);
        MAP(InterruptThread);
        MAP(NotifyFramePop);
        MAP(PopFrame);
        MAP(ForceEarlyReturnObject);
        MAP(ForceEarlyReturnInt);
        MAP(ForceEarlyReturnLong);
        MAP(ForceEarlyReturnFloat);
        MAP(ForceEarlyReturnDouble);
        MAP(ForceEarlyReturnVoid);
        MAP(SetLocalObject);
        MAP(SetLocalInt);
        MAP(SetLocalLong);
        MAP(SetLocalFloat);
        MAP(SetLocalDouble);
        MAP(SetBreakpoint);
        MAP(ClearBreakpoint);
        MAP(SetFieldAccessWatch);
        MAP(ClearFieldAccessWatch);
        MAP(SetFieldModificationWatch);
        MAP(ClearFieldModificationWatch);
        MAP(DisposeEnvironment);
        MAP(IterateOverInstancesOfClass);
        MAP(SetExtensionEventCallback);
        MAP(ForceGarbageCollection);
        MAP(SetHeapSamplingInterval);
#undef MAP
    }

    // 从备份表取内部原函数指针（代理自用；避免代理调用自身）
    void init_orig_fns(jvmtiEnv* env) {
        (void) env;
        if (!g_backup) return;
        fn_GetClassLoader          = (FN_GetClassLoader) g_backup[JVMTI_SLOT(GetClassLoader)];
        fn_GetClassSignature       = (FN_GetClassSignature) g_backup[JVMTI_SLOT(GetClassSignature)];
        fn_GetMethodDeclaringClass = (FN_GetMethodDeclaringClass) g_backup[JVMTI_SLOT(GetMethodDeclaringClass)];
        fn_GetStackTrace           = (FN_GetStackTrace) g_backup[JVMTI_SLOT(GetStackTrace)];
        fn_Deallocate              = (FN_Deallocate) g_backup[JVMTI_SLOT(Deallocate)];
        fn_GetPotentialCapabilities = (FN_GetPotentialCapabilities) g_backup[JVMTI_SLOT(GetPotentialCapabilities)];
        fn_AddCapabilities         = (FN_AddCapabilities) g_backup[JVMTI_SLOT(AddCapabilities)];
        fn_SetEventCallbacks       = (FN_SetEventCallbacks) g_backup[JVMTI_SLOT(SetEventCallbacks)];
        fn_SetEventNotificationMode = (FN_SetEventNotificationMode) g_backup[JVMTI_SLOT(SetEventNotificationMode)];
        fn_GetLoadedClasses        = (FN_GetLoadedClasses) g_backup[JVMTI_SLOT(GetLoadedClasses)];
        fn_GetMethodName           = (FN_GetMethodName) g_backup[JVMTI_SLOT(GetMethodName)];
    }

    // ===================== 锁定 / 解锁 =====================

    int do_enable();

    // 公共安装流程：拷贝原表 → 建代理表 → 取原函数 → 置可写 → 替换槽位
    int install_slots(bool deep) {
        LOCK_BEGIN();
        int rc = 0;
        if (!g_trusted_init) { rc = -10; goto done; }  // 无锚点 → 透明降级
        {
            jvmtiEnv* env = get_jvmti();
            if (!env) { rc = -1; goto done; }
            g_table = (jvmtiInterface_1_*)env->functions;
            if (!g_table) { rc = -2; goto done; }
            g_entries = sizeof(jvmtiInterface_1_) / sizeof(void*);
            if (g_entries < 64) { rc = -3; goto done; }

            if (!g_have_backup) {
                g_backup = (void**)malloc(g_entries * sizeof(void*));
                if (!g_backup) { rc = -4; goto done; }
                memcpy(g_backup, (const void*)g_table, g_entries * sizeof(void*));
                g_have_backup = true;
            }
            build_proxy_map();
            init_orig_fns(env);
            if (!make_rw((void*)g_table, sizeof(jvmtiInterface_1_))) { rc = -5; goto done; }

            void** slots = (void**)g_table;
            for (size_t idx : kSelectiveSlots) {
                if (idx < g_entries && slots[idx]) {
                    void* replacement = (idx < 190 && g_proxy_slot[idx])
                            ? g_proxy_slot[idx] : (void*)&deny_stub;
                    ATOMIC_PTR_STORE(&slots[idx], replacement);
                }
            }
            if (deep && g_deepLockOn) {
                for (size_t idx : kDeepSlots) {
                    if (idx < g_entries && slots[idx]) {
                        void* replacement = (idx < 190 && g_proxy_slot[idx])
                                ? g_proxy_slot[idx] : (void*)&deny_stub;
                        ATOMIC_PTR_STORE(&slots[idx], replacement);
                    }
                }
            }
            g_disabled = true;
            g_selective = !deep;
            rc = 0;
        }
    done:
        LOCK_END();
        return rc;
    }

    int do_disable() {
        // 升级语义：安全模式 → 先还原再全锁（否则 g_disabled 短路）
        if (g_disabled && g_selective) {
            int r = do_enable();
            if (r != 0) return r;
        }
        if (g_disabled) return 0;
        return install_slots(true);
    }

    int do_disable_selective() {
        // 降级语义：全锁 → 先还原再安全锁
        if (g_disabled && !g_selective) {
            int r = do_enable();
            if (r != 0) return r;
        }
        if (g_disabled) return 0;
        return install_slots(false);
    }

    int do_enable() {
        LOCK_BEGIN();
        int rc = 0;
        if (!g_disabled) { rc = 0; goto done; }
        if (!g_have_backup || !g_table) { rc = -1; goto done; }
        if (!make_rw((void*)g_table, sizeof(jvmtiInterface_1_))) { rc = -2; goto done; }
        {
            void** slots = (void**)g_table;
            for (size_t idx : kSelectiveSlots) {
                if (idx < g_entries && slots[idx]) {
                    ATOMIC_PTR_STORE(&slots[idx], g_backup[idx]);
                }
            }
            // 深锁段一并还原（状态机对称：曾经装过就必须还原）
            for (size_t idx : kDeepSlots) {
                if (idx < g_entries && slots[idx]) {
                    ATOMIC_PTR_STORE(&slots[idx], g_backup[idx]);
                }
            }
            g_disabled = false;
            g_selective = false;
            rc = 0;
        }
    done:
        LOCK_END();
        return rc;
    }

    // 完整性重断言：检查已装槽位是否仍是我的代理（防敌方还原/篡改）；
    // 返回被"修回"的槽位数（0 = 完好）。
    int recheck_integrity() {
        if (!g_disabled || !g_table || !g_have_backup) return 0;
        int fixed = 0;
        LOCK_BEGIN();
        void** slots = (void**)g_table;
        for (size_t idx : kSelectiveSlots) {
            if (idx < g_entries && slots[idx]) {
                void* want = (idx < 190 && g_proxy_slot[idx]) ? g_proxy_slot[idx] : (void*)&deny_stub;
                if (slots[idx] != want) { ATOMIC_PTR_STORE(&slots[idx], want); ++fixed; }
            }
        }
        for (size_t idx : kDeepSlots) {
            if (g_deepLockOn && idx < g_entries && slots[idx]) {
                void* want = (idx < 190 && g_proxy_slot[idx]) ? g_proxy_slot[idx] : (void*)&deny_stub;
                if (slots[idx] != want) { ATOMIC_PTR_STORE(&slots[idx], want); ++fixed; }
            }
        }
        LOCK_END();
        return fixed;
    }

    // 自检：代理表是否已建、原函数是否可取
    int guard_probe() {
        if (!g_table || !g_have_backup) return 0;
        int n = 0;
        for (size_t idx : kSelectiveSlots) {
            if (idx < 190 && g_proxy_slot[idx]) ++n;
        }
        for (size_t idx : kDeepSlots) {
            if (idx < 190 && g_proxy_slot[idx]) ++n;
        }
        return n;
    }

    // ===================== ClassFileLoadHook（CFLH · 学习自样板 artemis_boot_agent.cpp） =====================
    // 【是什么】JVMTI 的"类字节入关口"事件：defineClass / JNI DefineClass / retransform 全都会经过它，
    //   连 **JVM 隐藏类、lambda、代理生成的类** 也看得到（ClassFileTransformer 看不到的那部分）。
    // 【怎么用】注册即成为"回调链上第一个"，此后任何第三方 agent 的回调都排在我方之后。
    // 【纪律】本回调**只观察、绝不改写**（不写 new_class_data_len / new_class_data）——
    //   改写会让"字节码与类元数据不一致"，是崩溃高发点；需要改写时走 Java 侧 ClassFileTransformer。
    // 【对齐样板】`AddCapabilities` 是"全有或全无"的原子语义 ⇒ 必须**分批**抢，
    //   混在一起时一颗失败会拖垮整组（样板 artemis_boot_agent.cpp:194-216 实证）。
    static volatile long g_cflhCalls = 0;
    static volatile int  g_cflhOn    = 0;

    void JNICALL on_class_file_load(jvmtiEnv* jvmti_env, JNIEnv* jni_env, jclass class_being_redefined,
                                    jobject loader, const char* name, jobject protection_domain,
                                    jint class_data_len, const unsigned char* class_data,
                                    jint* new_class_data_len, unsigned char** new_class_data) {
        (void)jvmti_env; (void)jni_env; (void)class_being_redefined; (void)loader;
        (void)name; (void)protection_domain; (void)class_data_len; (void)class_data;
        (void)new_class_data_len; (void)new_class_data;   // ⚠️ 绝不改写
        InterlockedIncrement(&g_cflhCalls);
    }

    /**
     * 装 CFLH：分批抢能力 → 注册回调 → 使能事件。
     * ⚠️ 必须在**我方调用链内**调用（栈上有 com/echoxy 帧），否则会被本库自己的
     *    `AddCapabilities` 代理判成不可信而返回"假成功"（能力其实没拿到）。
     */
    bool install_cflh() {
        jvmtiEnv* env = get_jvmti();
        if (!env) return false;
        if (g_cflhOn) return true;                       // 幂等

        // ① 分批抢能力：全有或全无 ⇒ 分三批，任一批成功即可继续
        jvmtiCapabilities c1;
        memset(&c1, 0, sizeof(c1));
        c1.can_generate_all_class_hook_events = 1;
        c1.can_generate_early_class_hook_events = 1;
        c1.can_retransform_classes = 1;
        const jvmtiError e1 = env->AddCapabilities(&c1);
        if (e1 != JVMTI_ERROR_NONE) {
            // 退到最小集重试（某些 JVM 不支持 early hook / retransform）
            jvmtiCapabilities cMin;
            memset(&cMin, 0, sizeof(cMin));
            cMin.can_generate_all_class_hook_events = 1;
            if (env->AddCapabilities(&cMin) != JVMTI_ERROR_NONE) {
                return false;                            // 连最基本能力都拿不到 ⇒ 放弃（不崩）
            }
        }

        // ② 注册回调（只有 ClassFileLoadHook 一个槽位，其余留空由 JVM 忽略）
        jvmtiEventCallbacks cb;
        memset(&cb, 0, sizeof(cb));
        cb.ClassFileLoadHook = &on_class_file_load;
        const jvmtiError e2 = env->SetEventCallbacks(&cb, (jint)sizeof(cb));
        if (e2 != JVMTI_ERROR_NONE) {
            return false;
        }

        // ③ 使能事件
        const jvmtiError e3 = env->SetEventNotificationMode(
                JVMTI_ENABLE, JVMTI_EVENT_CLASS_FILE_LOAD_HOOK, NULL);
        if (e3 != JVMTI_ERROR_NONE) {
            return false;
        }
        g_cflhOn = 1;
        return true;
    }

    long cflh_calls() { return g_cflhCalls; }
    int  cflh_on()     { return g_cflhOn; }

}  // namespace

// ===================== JNI 导出（对应 Java 侧 com.echoxy.agent.EchoJvmtiLockdown） =====================

// 白名单锚点注入：System.load 后立即调用（本模组类加载器 + 包前缀）。
extern "C" JNIEXPORT void JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nInit(JNIEnv* env, jclass, jobject loader, jstring pkg) {
    GUARD_BEGIN
        if (!env || !loader) return;
        jobject gref = env->NewGlobalRef(loader);
        if (!gref) return;
        if (g_trusted_loader) env->DeleteGlobalRef(g_trusted_loader);
        g_trusted_loader = gref;
        g_trusted_init = true;
        if (pkg) {
            const char* s = env->GetStringUTFChars(pkg, nullptr);
            if (s) {
                strncpy(g_trusted_pkg, s, sizeof(g_trusted_pkg) - 1);
                g_trusted_pkg[sizeof(g_trusted_pkg) - 1] = '\0';
                env->ReleaseStringUTFChars(pkg, s);
            }
        }
    GUARD_END_VOID
}

// 锚点状态：0=就绪 / -1=未注入 / -2=无加载器
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nAnchorStatus(JNIEnv*, jclass) {
    if (!g_trusted_init) return -1;
    return g_trusted_loader ? 0 : -2;
}

// 运行时开关（配置下发）：栈帧隐藏 / 能力探测阻断 / 深锁
extern "C" JNIEXPORT void JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nSetRuntime(JNIEnv*, jclass, jboolean stackHide,
                                                    jboolean capHide, jboolean deepLock) {
    g_stackHideOn = (stackHide != JNI_FALSE);
    g_capHideOn = (capHide != JNI_FALSE);
    g_deepLockOn = (deepLock != JNI_FALSE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nSetStackHide(JNIEnv*, jclass, jboolean on) {
    g_stackHideOn = (on != JNI_FALSE);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nStackHiddenFrames(JNIEnv*, jclass) {
    return (jlong) g_stackHiddenFrames;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nCapProbeHidden(JNIEnv*, jclass) {
    return (jlong) g_capProbeHidden;
}

// 状态位图：bit0 disabled / bit1 selective / bit2 backup / bit3 anchor / bit4 deep / bit5 stackHide
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nStatus(JNIEnv*, jclass) {
    int s = 0;
    if (g_disabled)  s |= 1;
    if (g_selective) s |= 2;
    if (g_have_backup) s |= 4;
    if (g_trusted_init) s |= 8;
    if (g_deepLockOn) s |= 16;
    if (g_stackHideOn) s |= 32;
    return s;
}
// ===================== ClassFileLoadHook 开关与状态 =====================
// 【必须在 Java 调用链内调用】栈上有 com/echoxy 帧 ⇒ 本库自己的 AddCapabilities 代理才会转发真调用；
// 若从纯 native 线程调用，会被判成不可信而"假成功"（能力其实没拿到）。
extern "C" JNIEXPORT jboolean JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nEnableCflh(JNIEnv*, jclass) {
    return install_cflh() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nCflhStatus(JNIEnv* env, jclass) {
    char buf[128];
    _snprintf_s(buf, sizeof(buf), _TRUNCATE, "on=%d calls=%ld", cflh_on(), cflh_calls());
    return env ? env->NewStringUTF(buf) : nullptr;
}


extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nPid(JNIEnv*, jclass) {
#ifdef _WIN32
    return (jint) GetCurrentProcessId();
#else
    return (jint) getpid();
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nDisableAll(JNIEnv*, jclass) {
    return do_disable();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nDisableSelective(JNIEnv*, jclass) {
    return do_disable_selective();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nEnableAll(JNIEnv*, jclass) {
    return do_enable();
}

// 完整性重断言（返回本次修回槽位数；0 = 完好）
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nRecheckIntegrity(JNIEnv*, jclass) {
    return recheck_integrity();
}

// 自检（返回已建代理数；0 = 未安装）
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nGuardProbe(JNIEnv*, jclass) {
    return guard_probe();
}

// 跨 DLL 导出：供 echo_native_guard 的原生守护线程周期重断言（返回修回槽位数）
extern "C" __declspec(dllexport) int EchoJvmtiRecheck(void) {
    return recheck_integrity();
}
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_8;
}

extern "C" JNIEXPORT void JNICALL JNI_OnUnload(JavaVM*, void*) {
    do_enable();  // 卸载时自动恢复，避免进程遗留僵尸状态
}

// =====================================================================================
// 注入守卫：Agent_OnAttach hook + JavaVM::GetEnv hook +
// JvmtiEnvBase 链表遍历 + JvmtiMonitor 周期扫描
//
// 与"锁表"的分工：
//   · 锁表（47 槽位代理）解决"**已有** env 拿去做破坏"；
//   · 本段解决"**新** env / **新** agent 从哪来"：
//       ① instrument.dll!Agent_OnAttach —— 运行时外部 agent 注入的唯一 native 入口（MinHook 内联）；
//       ② JavaVM vtable::GetEnv —— 每个请求 JVMTI 的调用方都经过这里（可记录、可拒绝）；
//       ③ JvmtiEnvBase 链表（_head_environment/_magic=0x71EE/_next）—— 枚举 env（只做可达段：
//          从我方 env 沿 _next 向后遍历 + magic 校验；head 指针位于 jvm.dll 静态数据段，
//          未证可达前不上线，坚守"未证可达 ⇒ 不上线"铁律）。
//
// 配置（Java 侧系统属性 → nEnableInjectGuard 下发）：
//   refuseAttach : 非我方 Agent_OnAttach 一律拒绝（默认 true —— 防运行时注入）
//   refuseGetEnv : 非白名单调用者 GetEnv(JVMTI) 返回 JNI_EVERSION（默认 false —— 记录优先）
//   invalidate   : 对遍历到的"非我方 env"改 magic 使其失效（默认 false —— 高风险，需显式开）
//   monitorSec   : JvmtiMonitor 扫描间隔秒（0 = 关闭线程；默认 5）
// =====================================================================================
static volatile bool  g_refuseAttach = true;
static volatile bool  g_refuseGetEnv = false;
static volatile bool  g_invalidateEnvs = false;
static volatile int   g_monitorSec = 5;
static volatile long  g_envSeen = 0;
static volatile long  g_getEnvDenied = 0;
static volatile long  g_attachSeen = 0;
static volatile long  g_attachDenied = 0;
static volatile long  g_envChainLen = 0;
static volatile long  g_invalidated = 0;
static volatile bool  g_injectGuardArmed = false;

// JvmtiEnvBase 布局（JDK17，jvmtiEnvBase.hpp 实证）：
//   jvmtiEnv _jvmti_external;   // 首字段（offset 0，8 字节）
//   jint     _magic;            // offset 8（JVMTI_MAGIC = 0x71EE）
//   JvmtiEnvBase* _next;        // offset 16
#define JVMTI_ENV_MAGIC        0x71EE
#define JVMTI_ENV_DISPOSED     0xDEFC
#define JVMTI_ENV_MAGIC_OFF    8
#define JVMTI_ENV_NEXT_OFF     16

namespace {

    // ===================== MinHook 动态定位（与样板同款多路径） =====================
    // ⚠️ 本段**刻意不取 `MH_EnableHook`**：它为落补丁会 `Freeze()` 挂起进程全部线程并
    // `SetThreadContext` 改写其 RIP ⇒ 寄存器被污染成其它栈帧的旧值 ⇒ `LdrLoadDll+0x64`
    // 用旧 `rdx` 解引用 ⇒ 确定性 AV 崩溃。落补丁一律走 echo_minhook.h 的原子路径。
    typedef int (WINAPI *MH_Init_t)(void);
    typedef int (WINAPI *MH_CreateHook_t)(LPVOID, LPVOID, LPVOID*);
    typedef int (WINAPI *MH_Uninit_t)(void);
    typedef int (WINAPI *MH_RemoveHook_t)(LPVOID);

    typedef jint (JNICALL *AgentOnAttach_t)(JavaVM*, char*, void*);
    typedef jint (JNICALL *GetEnv_t)(JavaVM*, void**, jint);

    HMODULE g_mhModule = nullptr;
    MH_Init_t g_mhInit = nullptr;
    MH_CreateHook_t g_mhCreate = nullptr;
    MH_Uninit_t g_mhUninit = nullptr;
    AgentOnAttach_t g_origAgentOnAttach = nullptr;
    GetEnv_t g_origGetEnv = nullptr;

    // 取原始 JNIEnv（hook 安装后走原 GetEnv，绝不递归到 hook）
    JNIEnv* get_jni_env() {
        JNIEnv* jni = nullptr;
        if (!g_vm) return nullptr;
        if (g_origGetEnv) {
            if (g_origGetEnv(g_vm, (void**)&jni, JNI_VERSION_1_8) != JNI_OK) return nullptr;
            return jni;
        }
        if (g_vm->GetEnv((void**)&jni, JNI_VERSION_1_8) != JNI_OK) return nullptr;
        return jni;
    }

    // ===================== MinHook 装载 =====================
    bool load_minhook() {
        if (g_mhModule) return true;
        // ① 本 DLL 自身目录（echoes-native）
        wchar_t self[MAX_PATH * 2] = { 0 };
        HMODULE selfMod = nullptr;
        GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCWSTR)&load_minhook, &selfMod);
        if (selfMod) GetModuleFileNameW(selfMod, self, (DWORD)(sizeof(self) / sizeof(wchar_t)));
        if (self[0]) {
            wchar_t* slash = wcsrchr(self, L'\\');
            if (slash) {
                slash[1] = L'\0';
                wchar_t cand[MAX_PATH * 2];
                _snwprintf_s(cand, MAX_PATH * 2, _TRUNCATE, L"%sMinHook.x64.dll", self);
                g_mhModule = LoadLibraryW(cand);
            }
        }
        // ② 裸名回退
        if (!g_mhModule) g_mhModule = LoadLibraryW(L"MinHook.x64.dll");
        if (!g_mhModule) g_mhModule = LoadLibraryW(L"MinHook.dll");
        if (!g_mhModule) return false;
        g_mhInit   = (MH_Init_t)GetProcAddress(g_mhModule, "MH_Initialize");
        g_mhCreate = (MH_CreateHook_t)GetProcAddress(g_mhModule, "MH_CreateHook");
        g_mhUninit = (MH_Uninit_t)GetProcAddress(g_mhModule, "MH_Uninitialize");
        return g_mhInit && g_mhCreate;
    }

    // ===================== Agent_OnAttach hook（防运行时注入） =====================
    bool options_is_ours(const char* options) {
        if (!options || !options[0]) return true;  // 无参数（内部/JVM 自发）⇒ 视为我方，放行
        // 我方 attach 有三种形态：echoes-agent.jar / echoes-attach0.jar / echo_jvmti_lockdown；
        // 判据只认"我方制品名"，不点名任何第三方（铁律⑤）
        if (strstr(options, "echoes-agent") || strstr(options, "echoes-attach0")
                || strstr(options, "echo_jvmti") || strstr(options, "echo-jvmti")) {
            return true;
        }
        return false;
    }

    jint JNICALL hook_AgentOnAttach(JavaVM* vm, char* options, void* reserved) {
        g_attachSeen++;
        if (g_refuseAttach && !options_is_ours(options)) {
            g_attachDenied++;
            return (jint)-1;  // attach 失败：外部 agent 拿不到 Instrumentation
        }
        if (g_origAgentOnAttach) return g_origAgentOnAttach(vm, options, reserved);
        return (jint)-1;
    }

    // ===================== JavaVM vtable::GetEnv hook =====================
    jint JNICALL hook_GetEnv(JavaVM* vm, void** penv, jint version) {
        jint rc = g_origGetEnv ? g_origGetEnv(vm, penv, version) : JNI_EVERSION;
        if (rc == JNI_OK && penv && *penv) {
            g_envSeen++;
            // 只对 JVMTI 版本请求做拦截（JNI_VERSION_1_1 = 取 JNIEnv 的常规路径，绝不拦）
            const bool jvmtiRequest = version != JNI_VERSION_1_1;
            if (jvmtiRequest && g_refuseGetEnv && !caller_trusted()) {
                *penv = nullptr;
                g_getEnvDenied++;
                return JNI_EVERSION;
            }
        }
        return rc;
    }

    bool install_getenv_hook() {
        if (!g_vm) return false;
        JNIInvokeInterface_* itf = *(JNIInvokeInterface_**)g_vm;
        if (!itf) return false;
        void** slot = (void**)&itf->GetEnv;
        if (*slot == (void*)&hook_GetEnv) return true;   // 已挂
        g_origGetEnv = (GetEnv_t)*slot;
        if (!g_origGetEnv || g_origGetEnv == (GetEnv_t)&hook_GetEnv) return false;
        if (!make_rw((void*)itf, sizeof(JNIInvokeInterface_))) return false;
        ATOMIC_PTR_STORE(slot, (void*)&hook_GetEnv);
        return true;
    }

    bool install_attach_hook() {
        if (g_origAgentOnAttach) return true;
        if (!load_minhook()) return false;
        HMODULE instr = GetModuleHandleW(L"instrument.dll");
        if (!instr) return false;
        void* target = (void*)GetProcAddress(instr, "Agent_OnAttach");
        if (!target) return false;
        if (g_mhInit() != 0) {
            // MH_ERROR_ALREADY_INITIALIZED(1) 也视为可用
        }
        // 【免冻结装配】绝不调用 `MH_EnableHook`：它会 `Freeze()` 挂起进程全部线程并
        // `SetThreadContext` 改写其 RIP ⇒ 寄存器被污染 ⇒ `LdrLoadDll+0x64` 确定性崩溃
        // （实测 `lwjgl.dll: 找不到指定的程序`）。改为 `MH_CreateHook` 拿 trampoline +
        // 8 字节 `InterlockedExchange64` 原子落 `E9 rel32`（详见 echo_minhook.h）。
        EchoMinHook mh = {};
        mh.module = g_mhModule;
        mh.init = g_mhInit;
        mh.create = g_mhCreate;
        return EchoMinHookInstall(&mh, L"instrument.dll", "Agent_OnAttach",
                                  (LPVOID)&hook_AgentOnAttach, (LPVOID*)&g_origAgentOnAttach);
    }

    // ===================== JvmtiEnvBase 链表（可达段） =====================
    // 从我方 env 起沿 _next 遍历（magic 校验）；统计链长，可选"使能失效"。
    void scan_env_chain() {
        jvmtiEnv* base = get_jvmti();
        if (!base) return;
        long n = 0;
        jvmtiEnv* cur = base;
        for (int i = 0; i < 64 && cur; ++i) {
            unsigned char* p = (unsigned char*)cur;
            int magic = *(int*)(p + JVMTI_ENV_MAGIC_OFF);
            if (magic != JVMTI_ENV_MAGIC) break;
            ++n;
            // 使能失效：我方 env 之后的（外部）env 改 magic（默认关闭）
            if (g_invalidateEnvs && i > 0 && magic == JVMTI_ENV_MAGIC) {
                if (make_rw(p + JVMTI_ENV_MAGIC_OFF, 4)) {
                    *(int*)(p + JVMTI_ENV_MAGIC_OFF) = JVMTI_ENV_DISPOSED;
                    ++g_invalidated;
                }
            }
            cur = *(jvmtiEnv**)(p + JVMTI_ENV_NEXT_OFF);
        }
        g_envChainLen = n;
    }

    // ===================== JvmtiMonitor 周期线程 =====================
    DWORD WINAPI monitor_thread(LPVOID) {
        for (;;) {
            Sleep((DWORD)(g_monitorSec > 0 ? g_monitorSec : 5) * 1000u);
            GUARD_BEGIN
                scan_env_chain();
            GUARD_END_INT(0)
        }
        return 0;  // 不可达（无限循环）；满足编译器返回值要求
    }

    bool start_monitor() {
        if (g_monitorSec <= 0) return true;
        HANDLE h = CreateThread(nullptr, 0, monitor_thread, nullptr, 0, nullptr);
        if (h) { CloseHandle(h); return true; }
        return false;
    }

}  // namespace

// ===================== 注入守卫 JNI 导出 =====================

extern "C" JNIEXPORT jboolean JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nEnableInjectGuard(JNIEnv*, jclass, jboolean refuseAttach,
                                                           jboolean refuseGetEnv, jboolean invalidate,
                                                           jint monitorSec) {
    g_refuseAttach = (refuseAttach != JNI_FALSE);
    g_refuseGetEnv = (refuseGetEnv != JNI_FALSE);
    g_invalidateEnvs = (invalidate != JNI_FALSE);
    g_monitorSec = (int)monitorSec;
    bool ok = false;
    GUARD_BEGIN
        const bool att = install_attach_hook();
        const bool ge = install_getenv_hook();
        const bool mon = start_monitor();
        g_injectGuardArmed = att || ge;
        ok = g_injectGuardArmed;
        (void)mon;
    GUARD_END_BOOL
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nInjectGuardStatus(JNIEnv* env, jclass) {
    char buf[320];
    _snprintf_s(buf, sizeof(buf), _TRUNCATE,
                "attachHook=%d getenvHook=%d envSeen=%ld getenvDenied=%ld attachSeen=%ld "
                "attachDenied=%ld chainLen=%ld invalidated=%ld",
                g_origAgentOnAttach ? 1 : 0, g_origGetEnv ? 1 : 0,
                (long)g_envSeen, (long)g_getEnvDenied, (long)g_attachSeen,
                (long)g_attachDenied, (long)g_envChainLen, (long)g_invalidated);
    return env->NewStringUTF(buf);
}
// =====================================================================================
// NATIVE AGENT 入口（对齐 OpenJDK 标准；2026-11 新增，**不吞没既有流程**）
//
// 两个标准符号：
//   · `Agent_OnLoad`   —— 由 `-agentpath:<dll>` 触发（启动参数，可选）；
//   · `Agent_OnAttach` —— 由 `VirtualMachine.attach(pid).loadAgentPath(<dll>)` 触发
//                        ⇒ **运行时挂载，完全不需要启动参数**（这是本通道的核心价值）。
//   · `Agent_OnUnload` —— 卸载回调（清理）。
//
// 【为什么这里只"取 env + 记录 vm"，不直接锁表】
//   锁表依赖三层白名单锚点（`g_trusted_loader` / `g_trusted_pkg`），那由 Java 侧
//   `nInit` 下发。若在 agent 入口提前锁表，锚点尚不存在 ⇒ 会把**我方自己的**调用链
//   也判成不可信 ⇒ 直接废掉自身功能。
//   ⇒ 本入口只负责"更早把 JVMTI env 拿到手"（这是 agent 通道的天然优势），
//     真正的锁定仍由既有 Java 侧 `ensure()` 驱动的 `nDisableAll/nDisableSelective` 完成。
//     既有的 JNA / vm / enqueue / impl 四种挂载方式一条不减、行为不变。
// =====================================================================================
static jint native_agent_boot(JavaVM* vm) {
    if (!vm) return JNI_ERR;
    g_vm = vm;                       // agent 通道下 JNI_OnLoad 不会被调用，必须自己记
    jvmtiEnv* env = get_jvmti();
    if (!env) {
        OutputDebugStringW(L"[echo] 原生 agent：GetEnv(JVMTI) 失败，通道降级\n");
        return JNI_ERR;              // 拿不到 env ⇒ 失败返回（绝不崩）
    }
    g_agentBooted = true;
    OutputDebugStringW(L"[echo] 原生 agent 已挂载（Agent_OnLoad / Agent_OnAttach）\n");
    return JNI_OK;
}

extern "C" JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM* vm, char* options, void* reserved) {
    (void)options;
    (void)reserved;
    return native_agent_boot(vm);
}

extern "C" JNIEXPORT jint JNICALL Agent_OnAttach(JavaVM* vm, char* options, void* reserved) {
    (void)options;
    (void)reserved;
    return native_agent_boot(vm);
}

extern "C" JNIEXPORT void JNICALL Agent_OnUnload(JavaVM* vm) {
    (void)vm;                        // 锁表恢复仍走既有 JNI_OnUnload（do_enable）
}

// 诊断：agent 通道是否已拉起（1=是）
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoJvmtiLockdown_nAgentBooted(JNIEnv*, jclass) {
    return g_agentBooted ? 1 : 0;
}
