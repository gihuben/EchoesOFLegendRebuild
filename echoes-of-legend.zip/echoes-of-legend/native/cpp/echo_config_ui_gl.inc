// ============================================================================
// echo_config_ui_gl.inc —— GL overlay 呈现层（被 echo_config_ui.cpp 直接 include）
// ----------------------------------------------------------------------------
// 【为什么必须走 GL】实测 + 资料核实：游戏窗口在 DWM 的 flip model 下，GDI 对窗口
//   DC 的写入**不会显示**（DWM 直接合成 GL 交换链，忽略 GDI 表面）。所以：
//     · 宿主（简单 GL 窗口）能看到界面；
//     · 游戏里看不到界面（不崩，但什么也没有）—— 这正是用户实测的现象。
//   参考：Mumble overlay/opengl.cpp、Khronos「The best way to draw a 2D image
//         directly on a hooked window」、SO「hooking OpenGL to draw an overlay」。
//
// 【做法】
//   1) GDI+ 把整张界面画到**离屏 DIB**（32bpp BGRA，top-down）；
//   2) 在 wglSwapBuffers **之前**：上传 DIB 为纹理 → VAO/VBO + 最简 shader 画一个
//      覆盖面板矩形的四边形 → 与游戏画面**同帧同次交换**上屏（物理上不可能闪）；
//   3) 画前严格保存 GL 状态、画后逐项恢复（否则会坏掉游戏渲染）。
//
// 【依赖】本文件假设已被包含在 echo_config_ui.cpp 内部（可见 g_L / g_open /
//   DrawUiFrame / DiagWriteLine 等），并由 build.gradle 链接 opengl32.lib。
// ============================================================================
#include <GL/gl.h>
#include <cstddef>
// GL 2.0 类型（gl.h 1.1 里没有）
typedef ptrdiff_t GLsizeiptr;
typedef char GLchar;

// ---------------------------------------------------------------- GL 函数指针
typedef void (WINAPI* PFN_glGenVertexArrays)(GLsizei, GLuint*);
typedef void (WINAPI* PFN_glBindVertexArray)(GLuint);
typedef void (WINAPI* PFN_glDeleteVertexArrays)(GLsizei, const GLuint*);
typedef void (WINAPI* PFN_glGenBuffers)(GLsizei, GLuint*);
typedef void (WINAPI* PFN_glBindBuffer)(GLenum, GLuint);
typedef void (WINAPI* PFN_glBufferData)(GLenum, GLsizeiptr, const void*, GLenum);
typedef void (WINAPI* PFN_glDeleteBuffers)(GLsizei, const GLuint*);
typedef GLuint (WINAPI* PFN_glCreateShader)(GLenum);
typedef void (WINAPI* PFN_glShaderSource)(GLuint, GLsizei, const char* const*, const GLint*);
typedef void (WINAPI* PFN_glCompileShader)(GLuint);
typedef void (WINAPI* PFN_glGetShaderiv)(GLuint, GLenum, GLint*);
typedef void (WINAPI* PFN_glGetShaderInfoLog)(GLuint, GLsizei, GLsizei*, char*);
typedef GLuint (WINAPI* PFN_glCreateProgram)(void);
typedef void (WINAPI* PFN_glAttachShader)(GLuint, GLuint);
typedef void (WINAPI* PFN_glLinkProgram)(GLuint);
typedef void (WINAPI* PFN_glGetProgramiv)(GLuint, GLenum, GLint*);
typedef void (WINAPI* PFN_glGetProgramInfoLog)(GLuint, GLsizei, GLsizei*, char*);
typedef void (WINAPI* PFN_glUseProgram)(GLuint);
typedef GLint (WINAPI* PFN_glGetUniformLocation)(GLuint, const char*);
typedef void (WINAPI* PFN_glUniform1i)(GLint, GLint);
typedef void (WINAPI* PFN_glVertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
typedef void (WINAPI* PFN_glEnableVertexAttribArray)(GLuint);
typedef void (WINAPI* PFN_glDeleteProgram)(GLuint);
typedef void (WINAPI* PFN_glDeleteShader)(GLuint);
typedef void (WINAPI* PFN_glActiveTexture)(GLenum);
typedef void (WINAPI* PFN_glBindAttribLocation)(GLuint, GLuint, const char*);

// GL 1.1 由 opengl32.lib 直接提供；GL>=1.2 用 wglGetProcAddress 取
// （GL_BGRA / GL_CLAMP_TO_EDGE 是 1.2 常量，某些头文件没有，这里兜底定义）
#ifndef GL_BGRA
#define GL_BGRA 0x80E1
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_UNSIGNED_INT
#define GL_UNSIGNED_INT 0x1405
#endif
#ifndef GL_VERTEX_ARRAY_BINDING
#define GL_VERTEX_ARRAY_BINDING 0x85B5
#endif
#ifndef GL_CURRENT_PROGRAM
#define GL_CURRENT_PROGRAM 0x8B8D
#endif
#ifndef GL_BLEND_SRC_RGB
#define GL_BLEND_SRC_RGB 0x80C9
#endif
#ifndef GL_BLEND_DST_RGB
#define GL_BLEND_DST_RGB 0x80C8
#endif
// MSVC 自带的 gl.h 只到 GL 1.1，下面这些常量必须自己补
#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_ACTIVE_TEXTURE
#define GL_ACTIVE_TEXTURE 0x84E0
#endif
#ifndef GL_TEXTURE_BINDING_2D
#define GL_TEXTURE_BINDING_2D 0x8069
#endif
#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER 0x8892
#endif
#ifndef GL_DYNAMIC_DRAW
#define GL_DYNAMIC_DRAW 0x88E8
#endif
#ifndef GL_STREAM_DRAW
#define GL_STREAM_DRAW 0x88E0
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER 0x8B31
#endif
#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#endif
#ifndef GL_COMPILE_STATUS
#define GL_COMPILE_STATUS 0x8B81
#endif
#ifndef GL_LINK_STATUS
#define GL_LINK_STATUS 0x8B82
#endif
#ifndef GL_RGBA8
#define GL_RGBA8 0x8058
#endif
#ifndef GL_UNPACK_ROW_LENGTH
#define GL_UNPACK_ROW_LENGTH 0x0CF2
#endif


struct GlUiFn {
    PFN_glGenVertexArrays GenVertexArrays;
    PFN_glBindVertexArray BindVertexArray;
    PFN_glDeleteVertexArrays DeleteVertexArrays;
    PFN_glGenBuffers GenBuffers;
    PFN_glBindBuffer BindBuffer;
    PFN_glBufferData BufferData;
    PFN_glDeleteBuffers DeleteBuffers;
    PFN_glCreateShader CreateShader;
    PFN_glShaderSource ShaderSource;
    PFN_glCompileShader CompileShader;
    PFN_glGetShaderiv GetShaderiv;
    PFN_glGetShaderInfoLog GetShaderInfoLog;
    PFN_glCreateProgram CreateProgram;
    PFN_glAttachShader AttachShader;
    PFN_glLinkProgram LinkProgram;
    PFN_glGetProgramiv GetProgramiv;
    PFN_glGetProgramInfoLog GetProgramInfoLog;
    PFN_glUseProgram UseProgram;
    PFN_glGetUniformLocation GetUniformLocation;
    PFN_glUniform1i Uniform1i;
    PFN_glVertexAttribPointer VertexAttribPointer;
    PFN_glEnableVertexAttribArray EnableVertexAttribArray;
    PFN_glDeleteProgram DeleteProgram;
    PFN_glDeleteShader DeleteShader;
    PFN_glActiveTexture ActiveTexture;
    PFN_glBindAttribLocation BindAttribLocation;
};
static GlUiFn g_glfn = {};

/** 取 GL 扩展函数指针（必须在 GL 上下文 current 时调用）。 */
static void* EchoGlProc(const char* name) {
    void* p = (void*)wglGetProcAddress(name);
    // 某些驱动对 1.1 函数返回 NULL 或 -1，回落到 opengl32 导出
    if (p == (void*)1 || p == (void*)2 || p == (void*)3 || p == (void*)-1 || p == NULL) {
        HMODULE m = GetModuleHandleW(L"opengl32.dll");
        if (m != NULL) {
            p = (void*)GetProcAddress(m, name);
        }
    }
    return p;
}

// ---------------------------------------------------------------- DIB 离屏表面
struct EchoDib {
    HDC dc;
    HBITMAP bmp;
    HBITMAP oldBmp;
    void* bits;
    int w;
    int h;
};
static EchoDib g_dib = {};

static void DibFree(void) {
    if (g_dib.dc != NULL) {
        if (g_dib.oldBmp != NULL) {
            SelectObject(g_dib.dc, g_dib.oldBmp);
            g_dib.oldBmp = NULL;
        }
        DeleteDC(g_dib.dc);
        g_dib.dc = NULL;
    }
    if (g_dib.bmp != NULL) {
        DeleteObject(g_dib.bmp);
        g_dib.bmp = NULL;
    }
    g_dib.bits = NULL;
    g_dib.w = 0;
    g_dib.h = 0;
}

/** 确保 DIB 尺寸为 w×h（32bpp，top-down ⇒ biHeight 取负）。缓存复用。 */
static BOOL DibEnsure(HDC ref, int w, int h) {
    if (g_dib.dc != NULL && g_dib.w == w && g_dib.h == h) {
        return TRUE;
    }
    DibFree();
    if (ref == NULL || w <= 0 || h <= 0) {
        return FALSE;
    }
    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;          // 负 = top-down（与 GL UV 对齐）
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    void* bits = NULL;
    HBITMAP bmp = CreateDIBSection(ref, &bi, DIB_RGB_COLORS, &bits, NULL, 0);
    if (bmp == NULL || bits == NULL) {
        if (bmp != NULL) {
            DeleteObject(bmp);
        }
        return FALSE;
    }
    HDC dc = CreateCompatibleDC(ref);
    if (dc == NULL) {
        DeleteObject(bmp);
        return FALSE;
    }
    g_dib.oldBmp = (HBITMAP)SelectObject(dc, bmp);
    g_dib.dc = dc;
    g_dib.bmp = bmp;
    g_dib.bits = bits;
    g_dib.w = w;
    g_dib.h = h;
    return TRUE;
}

// ---------------------------------------------------------------- shader 源码
static const char* kVertSrc =
    "#version 150\n"
    "in vec2 aPos;\n"
    "in vec2 aUV;\n"
    "out vec2 vUV;\n"
    "void main() {\n"
    "    vUV = aUV;\n"
    "    gl_Position = vec4(aPos, 0.0, 1.0);\n"
    "}\n";

static const char* kFragSrc =
    "#version 150\n"
    "uniform sampler2D uTex;\n"
    "in vec2 vUV;\n"
    "out vec4 oColor;\n"
    "void main() {\n"
    "    oColor = texture(uTex, vUV);\n"
    "}\n";

struct GlUiState {
    BOOL tried;      // 是否已尝试初始化
    BOOL ready;      // 是否可用
    GLuint prog;
    GLuint vao;
    GLuint vbo;
    GLuint tex;
    GLint uTex;
    int texW;
    int texH;
};
static GlUiState g_glui = {};

// 模糊背景层纹理（毛玻璃底层；在 GlOverlayInit 里创建）
static GLuint g_blurTex = 0;
static int    g_blurTexW = 0, g_blurTexH = 0;

static GLuint GlCompile(GLenum type, const char* src) {
    GLuint sh = g_glfn.CreateShader(type);
    if (sh == 0) {
        return 0;
    }
    g_glfn.ShaderSource(sh, 1, &src, NULL);
    g_glfn.CompileShader(sh);
    GLint ok = 0;
    g_glfn.GetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512] = {};
        g_glfn.GetShaderInfoLog(sh, (GLsizei)sizeof(log) - 1, NULL, log);
        DiagWriteLine(L"[gl] shader compile failed");
        DiagWriteLine(L"[gl] (log omitted; see MSVC build)");
        g_glfn.DeleteShader(sh);
        return 0;
    }
    return sh;
}

/** 初始化 GL overlay 资源。必须在 GL 上下文 current 时调用（首次 hook 内）。 */
static BOOL GlOverlayInit(void) {
    if (g_glui.tried) {
        return g_glui.ready;
    }
    g_glui.tried = TRUE;

    g_glfn.GenVertexArrays = (PFN_glGenVertexArrays)EchoGlProc("glGenVertexArrays");
    g_glfn.BindVertexArray = (PFN_glBindVertexArray)EchoGlProc("glBindVertexArray");
    g_glfn.DeleteVertexArrays = (PFN_glDeleteVertexArrays)EchoGlProc("glDeleteVertexArrays");
    g_glfn.GenBuffers = (PFN_glGenBuffers)EchoGlProc("glGenBuffers");
    g_glfn.BindBuffer = (PFN_glBindBuffer)EchoGlProc("glBindBuffer");
    g_glfn.BufferData = (PFN_glBufferData)EchoGlProc("glBufferData");
    g_glfn.DeleteBuffers = (PFN_glDeleteBuffers)EchoGlProc("glDeleteBuffers");
    g_glfn.CreateShader = (PFN_glCreateShader)EchoGlProc("glCreateShader");
    g_glfn.ShaderSource = (PFN_glShaderSource)EchoGlProc("glShaderSource");
    g_glfn.CompileShader = (PFN_glCompileShader)EchoGlProc("glCompileShader");
    g_glfn.GetShaderiv = (PFN_glGetShaderiv)EchoGlProc("glGetShaderiv");
    g_glfn.GetShaderInfoLog = (PFN_glGetShaderInfoLog)EchoGlProc("glGetShaderInfoLog");
    g_glfn.CreateProgram = (PFN_glCreateProgram)EchoGlProc("glCreateProgram");
    g_glfn.AttachShader = (PFN_glAttachShader)EchoGlProc("glAttachShader");
    g_glfn.LinkProgram = (PFN_glLinkProgram)EchoGlProc("glLinkProgram");
    g_glfn.GetProgramiv = (PFN_glGetProgramiv)EchoGlProc("glGetProgramiv");
    g_glfn.GetProgramInfoLog = (PFN_glGetProgramInfoLog)EchoGlProc("glGetProgramInfoLog");
    g_glfn.UseProgram = (PFN_glUseProgram)EchoGlProc("glUseProgram");
    g_glfn.GetUniformLocation = (PFN_glGetUniformLocation)EchoGlProc("glGetUniformLocation");
    g_glfn.Uniform1i = (PFN_glUniform1i)EchoGlProc("glUniform1i");
    g_glfn.VertexAttribPointer = (PFN_glVertexAttribPointer)EchoGlProc("glVertexAttribPointer");
    g_glfn.EnableVertexAttribArray = (PFN_glEnableVertexAttribArray)EchoGlProc("glEnableVertexAttribArray");
    g_glfn.DeleteProgram = (PFN_glDeleteProgram)EchoGlProc("glDeleteProgram");
    g_glfn.DeleteShader = (PFN_glDeleteShader)EchoGlProc("glDeleteShader");
    g_glfn.ActiveTexture = (PFN_glActiveTexture)EchoGlProc("glActiveTexture");
    g_glfn.BindAttribLocation = (PFN_glBindAttribLocation)EchoGlProc("glBindAttribLocation");

    if (g_glfn.GenVertexArrays == NULL || g_glfn.CreateShader == NULL ||
        g_glfn.CreateProgram == NULL || g_glfn.BindVertexArray == NULL ||
        g_glfn.VertexAttribPointer == NULL || g_glfn.ActiveTexture == NULL) {
        DiagWriteLine(L"[gl] required GL2/GL3 entry points missing (not a core-profile context?)");
        return FALSE;
    }

    const GLuint vs = GlCompile(GL_VERTEX_SHADER, kVertSrc);
    if (vs == 0) {
        return FALSE;
    }
    const GLuint fs = GlCompile(GL_FRAGMENT_SHADER, kFragSrc);
    if (fs == 0) {
        g_glfn.DeleteShader(vs);
        return FALSE;
    }
    const GLuint prog = g_glfn.CreateProgram();
    if (prog == 0) {
        g_glfn.DeleteShader(vs);
        g_glfn.DeleteShader(fs);
        return FALSE;
    }
    g_glfn.AttachShader(prog, vs);
    g_glfn.AttachShader(prog, fs);
    // #version 150 没有 layout(location=)，必须 link 前显式绑定属性槽位
    if (g_glfn.BindAttribLocation != NULL) {
        g_glfn.BindAttribLocation(prog, 0, "aPos");
        g_glfn.BindAttribLocation(prog, 1, "aUV");
    }
    g_glfn.LinkProgram(prog);
    GLint ok = 0;
    g_glfn.GetProgramiv(prog, GL_LINK_STATUS, &ok);
    g_glfn.DeleteShader(vs);
    g_glfn.DeleteShader(fs);
    if (!ok) {
        char log[512] = {};
        g_glfn.GetProgramInfoLog(prog, (GLsizei)sizeof(log) - 1, NULL, log);
        DiagWriteLine(L"[gl] program link failed");
        g_glfn.DeleteProgram(prog);
        return FALSE;
    }
    g_glui.prog = prog;
    g_glui.uTex = g_glfn.GetUniformLocation(prog, "uTex");

    // VAO + VBO（顶点：x,y,u,v 交错）
    g_glfn.GenVertexArrays(1, &g_glui.vao);
    g_glfn.GenBuffers(1, &g_glui.vbo);
    if (g_glui.vao == 0 || g_glui.vbo == 0) {
        DiagWriteLine(L"[gl] VAO/VBO creation failed");
        return FALSE;
    }
    g_glfn.BindVertexArray(g_glui.vao);
    g_glfn.BindBuffer(GL_ARRAY_BUFFER, g_glui.vbo);
    g_glfn.BufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(4 * 4 * sizeof(float)), NULL, GL_DYNAMIC_DRAW);
    const GLint posLoc = 0;   // 已在 link 前 glBindAttribLocation(prog,0,"aPos") / (prog,1,"aUV")
    g_glfn.EnableVertexAttribArray((GLuint)posLoc);
    g_glfn.VertexAttribPointer((GLuint)posLoc, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (const void*)0);
    g_glfn.EnableVertexAttribArray((GLuint)(posLoc + 1));
    g_glfn.VertexAttribPointer((GLuint)(posLoc + 1), 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float),
                               (const void*)(2 * sizeof(float)));
    g_glfn.BindVertexArray(0);
    g_glfn.BindBuffer(GL_ARRAY_BUFFER, 0);

    // 纹理
    glGenTextures(1, &g_glui.tex);
    if (g_glui.tex == 0) {
        DiagWriteLine(L"[gl] texture creation failed");
        return FALSE;
    }
    g_glfn.ActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_glui.tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);

    // 模糊背景纹理：毛玻璃底层（1/8 或更小尺寸，LINEAR 放大成模糊）
    if (g_blurTex == 0) {
        glGenTextures(1, &g_blurTex);
        if (g_blurTex != 0) {
            g_glfn.ActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, g_blurTex);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glBindTexture(GL_TEXTURE_2D, 0);
        }
    }
    g_glui.ready = TRUE;
    DiagWriteLine(L"[gl] overlay ready (core-profile GL2/GL3 paths loaded)");
    return TRUE;
}

/**
 * 用 GL 把界面贴到**当前后缓冲**（必须在 wglSwapBuffers 之前调用）。
 * 完整保存/恢复 GL 状态；任何失败都返回 FALSE 且不改动状态之外的东西。
 */
// ---------------------------------------------------------------- 模糊背景缓冲
static unsigned char* g_readBuf = NULL;
static size_t g_readBufCap = 0;
static unsigned char* g_blurBuf = NULL;
static size_t g_blurBufCap = 0;

/** 一块纹理 + 四边形（保证画完恢复 VAO/VBO 绑定）。 */
static void DrawQuadTextured(GLuint tex, float x0, float y0, float x1, float y1) {
    const float verts[16] = {
        x0, y0, 0.0f, 0.0f,
        x1, y0, 1.0f, 0.0f,
        x0, y1, 0.0f, 1.0f,
        x1, y1, 1.0f, 1.0f
    };
    g_glfn.UseProgram(g_glui.prog);
    if (g_glui.uTex >= 0) {
        g_glfn.Uniform1i(g_glui.uTex, 0);
    }
    g_glfn.ActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex);
    g_glfn.BindVertexArray(g_glui.vao);
    g_glfn.BindBuffer(GL_ARRAY_BUFFER, g_glui.vbo);
    g_glfn.BufferData(GL_ARRAY_BUFFER, (GLsizeiptr)sizeof(verts), verts, GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    g_glfn.BindVertexArray(0);
    g_glfn.BindBuffer(GL_ARRAY_BUFFER, 0);
}

/**
 * 抓面板背后的游戏画面并做「降采样近似高斯模糊」，作为毛玻璃底层。
 *
 * <p>为什么用 glReadPixels 而不是 GDI BitBlt：GL 的读回走 GL 自己的管线，
 * 在渲染线程里是安全的；GDI 的 BitBlt 读 GL 窗口像素在本机直接把 gdi32full 读崩过两次。</p>
 *
 * @return TRUE = 已经画好模糊底层
 */
static BOOL DrawBlurBackdrop(int cw, int ch) {
    if (!g_glui.ready || g_blurTex == 0) {
        return FALSE;
    }
    const int pw = g_L.panelW;
    const int ph = g_L.panelH;
    if (pw <= 16 || ph <= 16) {
        return FALSE;
    }
    // 读回窗口坐标 → GL 坐标（GL 原点在左下）
    const int rx = g_L.panelX;
    const int ry = ch - (g_L.panelY + ph);
    if (rx < 0 || ry < 0 || rx + pw > cw || ry + ph > ch) {
        return FALSE;   // 面板超出窗口（放大动画期间）⇒ 这帧不模糊
    }

    const size_t readNeed = (size_t)pw * (size_t)ph * 4u;
    if (g_readBufCap < readNeed) {
        if (g_readBuf != NULL) {
            free(g_readBuf);
        }
        g_readBuf = (unsigned char*)malloc(readNeed);
        g_readBufCap = (g_readBuf != NULL) ? readNeed : 0;
        if (g_readBuf == NULL) {
            return FALSE;
        }
    }
    glPixelStorei(GL_PACK_ALIGNMENT, 4);
    glPixelStorei(GL_PACK_ROW_LENGTH, 0);
    glReadPixels(rx, ry, pw, ph, GL_BGRA, GL_UNSIGNED_BYTE, g_readBuf);

    // 8×8 盒式降采样（BGRA）
    const int bw = pw / 8 > 1 ? pw / 8 : 1;
    const int bh = ph / 8 > 1 ? ph / 8 : 1;
    const size_t blurNeed = (size_t)bw * (size_t)bh * 4u;
    if (g_blurBufCap < blurNeed) {
        if (g_blurBuf != NULL) {
            free(g_blurBuf);
        }
        g_blurBuf = (unsigned char*)malloc(blurNeed);
        g_blurBufCap = (g_blurBuf != NULL) ? blurNeed : 0;
        if (g_blurBuf == NULL) {
            return FALSE;
        }
    }
    for (int by = 0; by < bh; ++by) {
        for (int bx = 0; bx < bw; ++bx) {
            unsigned sum0 = 0, sum1 = 0, sum2 = 0, sum3 = 0, cnt = 0;
            const int y0 = by * 8;
            const int x0 = bx * 8;
            for (int y = y0; y < y0 + 8 && y < ph; ++y) {
                const unsigned char* row = g_readBuf + ((size_t)y * (size_t)pw + (size_t)x0) * 4u;
                for (int x = 0; x < 8 && x0 + x < pw; ++x, row += 4) {
                    sum0 += row[0];
                    sum1 += row[1];
                    sum2 += row[2];
                    sum3 += row[3];
                    ++cnt;
                }
            }
            unsigned char* dst = g_blurBuf + ((size_t)by * (size_t)bw + (size_t)bx) * 4u;
            if (cnt == 0) {
                dst[0] = dst[1] = dst[2] = dst[3] = 0;
            } else {
                dst[0] = (unsigned char)(sum0 / cnt);
                dst[1] = (unsigned char)(sum1 / cnt);
                dst[2] = (unsigned char)(sum2 / cnt);
                dst[3] = (unsigned char)(sum3 / cnt);
            }
        }
    }

    // 上传 + 画（纹理 LINEAR 放大 ⇒ 视觉上就是模糊）
    g_glfn.ActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_blurTex);
    if (g_blurTexW != bw || g_blurTexH != bh) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, bw, bh, 0, GL_BGRA, GL_UNSIGNED_BYTE, NULL);
        g_blurTexW = bw;
        g_blurTexH = bh;
    }
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, bw, bh, GL_BGRA, GL_UNSIGNED_BYTE, g_blurBuf);

    const float openE = EaseOutCubic(g_openT);
    const float zoom = 0.94f + 0.06f * openE;
    const float lift = (1.0f - openE) * 26.0f * (float)g_L.uiScale;
    const float cwx = (float)g_L.panelX + (float)g_L.panelW * 0.5f;
    const float cwy = (float)g_L.panelY + (float)g_L.panelH * 0.5f;
    const float halfW = (float)g_L.panelW * 0.5f * zoom;
    const float halfH = (float)g_L.panelH * 0.5f * zoom;
    const float lx0 = cwx - halfW;
    const float lx1 = cwx + halfW;
    const float ly0 = cwy - halfH + lift;
    const float ly1 = cwy + halfH + lift;
    const float x0 = 2.0f * lx0 / (float)cw - 1.0f;
    const float x1 = 2.0f * lx1 / (float)cw - 1.0f;
    const float y0 = 1.0f - 2.0f * ly0 / (float)ch;
    const float y1 = 1.0f - 2.0f * ly1 / (float)ch;
    DrawQuadTextured(g_blurTex, x0, y0, x1, y1);
    return TRUE;
}

static BOOL GlOverlayPresent(HDC hdc) {
    if (!g_open) {
        return FALSE;
    }
    if (!GlOverlayInit()) {
        return FALSE;
    }
    RECT rc = {};
    if (!GetClientRect(g_hwnd, &rc)) {
        return FALSE;
    }
    const int cw = rc.right - rc.left;
    const int ch = rc.bottom - rc.top;
    if (cw < 64 || ch < 64 || g_L.panelW <= 0 || g_L.panelH <= 0) {
        return FALSE;
    }

    // 1) GDI+ 渲染到 DIB（面板尺寸）
    if (!DibEnsure(hdc, g_L.panelW, g_L.panelH)) {
        DiagWriteLine(L"[gl] DIB ensure failed");
        return FALSE;
    }
    g_drawOffsetX = g_L.panelX;
    g_drawOffsetY = g_L.panelY;
    // 清空 DIB（全透明）
    {
        Graphics g(g_dib.dc);
        g.SetCompositingMode(CompositingModeSourceCopy);
        g.Clear(Color(0, 0, 0, 0));
    }
    DrawUiFrame(g_dib.dc);
    g_drawOffsetX = 0;
    g_drawOffsetY = 0;

    // 2) 保存 GL 状态（逐项成对恢复）
    GLint prevProgram = 0, prevVao = 0, prevTex = 0, prevActive = GL_TEXTURE0;
    GLint prevBlendSrc = GL_ONE, prevBlendDst = GL_ZERO;
    GLint prevViewport[4] = { 0, 0, 0, 0 };
    GLboolean prevBlend = glIsEnabled(GL_BLEND);
    GLboolean prevDepth = glIsEnabled(GL_DEPTH_TEST);
    GLboolean prevScissor = glIsEnabled(GL_SCISSOR_TEST);
    GLboolean prevCull = glIsEnabled(GL_CULL_FACE);
    GLboolean prevColorMask[4] = { GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE };
    GLboolean prevDepthMask = GL_TRUE;
    glGetIntegerv(GL_CURRENT_PROGRAM, &prevProgram);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prevVao);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prevTex);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &prevActive);
    glGetIntegerv(GL_BLEND_SRC_RGB, &prevBlendSrc);
    glGetIntegerv(GL_BLEND_DST_RGB, &prevBlendDst);
    glGetIntegerv(GL_VIEWPORT, prevViewport);
    glGetBooleanv(GL_COLOR_WRITEMASK, prevColorMask);
    glGetBooleanv(GL_DEPTH_WRITEMASK, &prevDepthMask);

    // 3) 上传纹理
    // 0) 先画"毛玻璃底层"：把面板背后的游戏画面模糊后铺满面板
    DrawBlurBackdrop(cw, ch);

    // 1) 界面纹理
    g_glfn.ActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_glui.tex);
    if (g_glui.texW != g_dib.w || g_glui.texH != g_dib.h) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, g_dib.w, g_dib.h, 0,
                     GL_BGRA, GL_UNSIGNED_BYTE, NULL);
        g_glui.texW = g_dib.w;
        g_glui.texH = g_dib.h;
    }
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, g_dib.w, g_dib.h,
                    GL_BGRA, GL_UNSIGNED_BYTE, g_dib.bits);

    // 4) 设置绘制状态
    glViewport(0, 0, cw, ch);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glDepthMask(GL_FALSE);

    // 5) 顶点（NDC）：覆盖面板矩形
    //    ★弹入动画：围绕面板中心从 94% 放大到 100%，同时自下而上轻微上浮。
    const float openE = EaseOutCubic(g_openT);
    const float zoom = 0.94f + 0.06f * openE;
    const float lift = (1.0f - openE) * 26.0f * (float)g_L.uiScale;
    const float cwx = (float)g_L.panelX + (float)g_L.panelW * 0.5f;
    const float cwy = (float)g_L.panelY + (float)g_L.panelH * 0.5f;
    const float halfW = (float)g_L.panelW * 0.5f * zoom;
    const float halfH = (float)g_L.panelH * 0.5f * zoom;
    const float lx0 = cwx - halfW;
    const float lx1 = cwx + halfW;
    const float ly0 = cwy - halfH + lift;
    const float ly1 = cwy + halfH + lift;
    const float x0 = 2.0f * lx0 / (float)cw - 1.0f;
    const float x1 = 2.0f * lx1 / (float)cw - 1.0f;
    const float y0 = 1.0f - 2.0f * ly0 / (float)ch;
    const float y1 = 1.0f - 2.0f * ly1 / (float)ch;
    const float verts[16] = {
        x0, y0, 0.0f, 0.0f,   // TL
        x1, y0, 1.0f, 0.0f,   // TR
        x0, y1, 0.0f, 1.0f,   // BL
        x1, y1, 1.0f, 1.0f    // BR
    };
    DrawQuadTextured(g_glui.tex, x0, y0, x1, y1);

    // 6) 恢复 GL 状态
    glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
    if (prevBlend) {
        glEnable(GL_BLEND);
    } else {
        glDisable(GL_BLEND);
    }
    glBlendFunc((GLenum)prevBlendSrc, (GLenum)prevBlendDst);
    if (prevDepth) {
        glEnable(GL_DEPTH_TEST);
    } else {
        glDisable(GL_DEPTH_TEST);
    }
    if (prevScissor) {
        glEnable(GL_SCISSOR_TEST);
    } else {
        glDisable(GL_SCISSOR_TEST);
    }
    if (prevCull) {
        glEnable(GL_CULL_FACE);
    } else {
        glDisable(GL_CULL_FACE);
    }
    glColorMask(prevColorMask[0], prevColorMask[1], prevColorMask[2], prevColorMask[3]);
    glDepthMask(prevDepthMask);
    g_glfn.UseProgram((GLuint)prevProgram);
    g_glfn.ActiveTexture((GLenum)prevActive);
    glBindTexture(GL_TEXTURE_2D, (GLuint)prevTex);
    g_glfn.BindVertexArray((GLuint)prevVao);

    return TRUE;
}

static void GlOverlayShutdown(void) {
    if (!g_glui.ready) {
        return;
    }
    if (g_glui.tex != 0) {
        glDeleteTextures(1, &g_glui.tex);
    }
    if (g_glui.vbo != 0 && g_glfn.DeleteBuffers != NULL) {
        g_glfn.DeleteBuffers(1, &g_glui.vbo);
    }
    if (g_glui.vao != 0 && g_glfn.DeleteVertexArrays != NULL) {
        g_glfn.DeleteVertexArrays(1, &g_glui.vao);
    }
    if (g_glui.prog != 0 && g_glfn.DeleteProgram != NULL) {
        g_glfn.DeleteProgram(g_glui.prog);
    }
    ZeroMemory(&g_glui, sizeof(g_glui));
    DibFree();
}
