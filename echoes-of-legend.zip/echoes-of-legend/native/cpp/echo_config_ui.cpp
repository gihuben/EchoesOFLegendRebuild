// ============================================================================
// ECHO_CONFIG_UI.DLL —— 回响物语 · 纯原生配置界面（独立自持，零依赖现有 DLL）
// ----------------------------------------------------------------------------
// 【用户裁决】不要外部窗口，直接在游戏画面上用原生 GDI 覆盖绘制。
//   · 配置全关时 guard/jvmti 都不加载 ⇒ 本 DLL 完全独立：mod 侧 System.load
//     绝对路径注入、自己 hook 换帧、自己画、自己收输入、自己读写配置。
//   · 为什么用 GDI+ 而不是纯 gdi32：纯 GDI 无抗锯齿 / 无 alpha 圆角 / 无渐变，
//     画不出「平滑曲线 / 胶囊 / 玻璃」。GDI+ 是同一套系统原生库，提供几何级
//     抗锯齿、ARGB 混合、渐变画刷、抗锯齿文字 ⇒ 才能复刻琉璃玻璃材质。
//
// 【渲染时机】hook opengl32!wglSwapBuffers（GLFW 每帧调用）：先调原函数完成换帧，
//   再取游戏窗口 DC 绘制 ⇒ 界面「长在」游戏画面上，无独立窗口、不夺焦点、不暂停。
//   另配 16ms 定时器兜底：游戏暂停/不渲染时界面也能刷新（鼠标悬停、动画不冻住）。
//
// 【高斯模糊】取面板区域像素 → StretchBlt 降到 1/8 → HALFTONE 放大回来（降采样
//   近似高斯），再叠加半透明玻璃色 ⇒ 接近 CSS backdrop-filter 的磨砂玻璃。
//   全屏独占下读不回像素时自动降级为纯半透明（fail-open）。
//
// 【输入】子类化游戏窗口 WndProc，界面打开时吞掉鼠标/滚轮/键盘；关闭立即恢复。
//   Esc / 右上 X / 面板外点击 = 取消；底部「保存并关闭」= 写回 config/echoes.txt。
//
// 【配置】C 侧全权解析与写回（UTF-8）：保留全部注释行、空行与键顺序，只改值。
//   零 C++ 全局对象（POD + SRWLOCK 常量初始化）；任何一步失败都 fail-open。
// ============================================================================

#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <windowsx.h>
// GDI+ 头里用到 IStream / IPicture 等 COM 接口；WIN32_LEAN_AND_MEAN 会把 objidl.h
// 排除在 windows.h 之外 ⇒ 必须在这里显式包含，否则 gdiplus.h 编译不过。
#include <objidl.h>
#include <gdiplus.h>
using namespace Gdiplus;

#include <jni.h>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <cstdlib>
#include <cmath>
#include <cstdint>

// MinHook：只借它的 trampoline 生成能力（RIP-relative 重定位），
// 绝不调 MH_EnableHook（原因见第九节的血证注释）。
// 以 MH_STATIC 静态编进本 DLL ⇒ 运行期不依赖 MinHook.x64.dll。
#include "MinHook.h"

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

// ============================================================================
// 一、材质令牌（映射琉璃玻璃库 glass.css 的暗/亮两套色板）
// ============================================================================
struct EchoUiTheme {
    DWORD panelTop, panelBottom;   // 面板竖向渐变（玻璃厚度）
    DWORD floatLayer;              // 浮层（更实，tooltip 用）
    DWORD pillOff, pillOn, knob;   // 胶囊轨道 / 品牌色 / 滑块
    DWORD textMain, textSub, textFaint;
    DWORD edgeLight, brand, brandGlow;
    DWORD navActive, navHover, rowHover, danger;
    BOOL  dark;
};

static const EchoUiTheme kDark = {
    0xA00E1218, 0xA8141A22, 0xE61B222C,
    0xBE2A3240, 0xFF4DA3F0, 0xFFFFFFFF,
    0xFFE6EAF2, 0xFF9AA4B8, 0xFF6C7688,
    0x2EFFFFFF, 0xFF4DA3F0, 0x554DA3F0,
    0x334DA3F0, 0x1AFFFFFF, 0x14FFFFFF, 0xFFFF6B6B,
    TRUE
};

static const EchoUiTheme kLight = {
    0xC9F7FAFF, 0xCDF2F6FC, 0xF2FFFFFF,
    0xD8C8D2E0, 0xFF1D6FC0, 0xFFFFFFFF,
    0xFF1A1F28, 0xFF5A6472, 0xFF8892A0,
    0x33FFFFFF, 0xFF1D6FC0, 0x441D6FC0,
    0x2A1D6FC0, 0x14000000, 0x0F000000, 0xFFCF2B2B,
    FALSE
};

// ============================================================================
// 二、配置模型（定长 POD，零动态分配）
// ============================================================================
#define ECHO_MAX_LINES   512
#define ECHO_MAX_GROUPS   32
#define ECHO_LINE_CHARS  768
#define ECHO_NAME_CHARS  128

enum EchoLineKind { LINE_RAW = 0, LINE_COMMENT = 1, LINE_KEY = 2, LINE_BLANK = 3 };

struct EchoCfgLine {
    wchar_t text[ECHO_LINE_CHARS];
    int     kind;
    int     keyStart, keyLen;
    int     valStart, valLen;
    int     group;
    BOOL    booleanLike;
};

struct EchoCfgGroup {
    wchar_t name[ECHO_NAME_CHARS];
    int     firstLine, lineCount, keyCount;
};

// ============================================================================
// 三、全局状态（POD；SRWLOCK 常量初始化 ⇒ 无 C++ 全局构造）
// ============================================================================
static SRWLOCK g_lock = SRWLOCK_INIT;

static BOOL      g_open = FALSE;
static BOOL      g_hooked = FALSE;
static HWND      g_hwnd = NULL;
static WNDPROC   g_oldWndProc = NULL;
static BOOL      g_subclassed = FALSE;
static ULONGLONG g_lastDrawTick = 0;
static ULONGLONG g_lastSwapTick = 0;

static wchar_t   g_configPath[MAX_PATH] = {};

static EchoCfgLine  g_lines[ECHO_MAX_LINES];
static int          g_lineCount = 0;
static EchoCfgGroup g_groups[ECHO_MAX_GROUPS];
static int          g_groupCount = 0;
static int          g_activeGroup = 0;
static BOOL         g_dirty = FALSE;
static BOOL         g_themeDarkSel = TRUE;

// 动画 / 交互
static float     g_openT = 0.0f;
static float     g_scrollCur = 0.0f;
static float     g_scrollTarget = 0.0f;
static float     g_toggleAnim[ECHO_MAX_LINES];
static float     g_toggleTarget[ECHO_MAX_LINES];
static float     g_toggleT[ECHO_MAX_LINES];      // 开关弹入进度 0..1
static float     g_toggleFrom[ECHO_MAX_LINES];   // 弹入起点值
static ULONGLONG g_lastAnimTick = 0;             // 上一帧时刻（算帧间隔 dt）
static ULONGLONG g_pageStamp = 0;                // 切页时刻（列表行重新级联弹入）
static ULONGLONG g_openStamp = 0;
static int       g_hoverRow = -1;
static int       g_hoverNav = -1;
static BOOL      g_hoverSave = FALSE;
static BOOL      g_hoverCancel = FALSE;
static BOOL      g_hoverClose = FALSE;
static BOOL      g_hoverTheme = FALSE;
static BOOL      g_dragging = FALSE;
static int       g_dragStartY = 0;
static float     g_dragStartScroll = 0.0f;
static int       g_mouseX = -1, g_mouseY = -1;
static int       g_tooltipLine = -1;
// 绘制偏移：GL 路径把界面画进「面板尺寸」的离屏 DIB，需要减去面板左上角坐标；
// GDI 回退路径偏移为 0。
static int       g_drawOffsetX = 0;
static int       g_drawOffsetY = 0;

// ---- 面板底的「磨砂玻璃」缓存 ----
// 只抓一次背景并模糊，之后每帧贴回。原因（两条实测血证）：
//   ① 每帧 BitBlt 读回会把「自己上一帧画好的界面」也读进去 ⇒ 中间态可见 ⇒ 高频频闪；
//   ② 从 GL 窗口 DC 读回像素在渲染线程上有崩掉 gdi32full 的风险（本工程崩过两次）。
// ⇒ 一次性抓取 + SEH 保护 + 失败自动降级为纯半透明玻璃。
static HDC     g_blurDC = NULL;
static HBITMAP g_blurBmp = NULL;
static HBITMAP g_blurOldBmp = NULL;
static BOOL    g_blurValid = FALSE;
// GDI 读回开关（默认 FALSE：BitBlt 读 GL 窗口像素在渲染线程上必崩；
// 模糊改由 GL overlay 阶段用 glReadPixels 实现后即可打开）
static BOOL    g_allowGdiReadback = FALSE;
static int     g_blurW = 0;
static int     g_blurH = 0;

// 布局
struct EchoUiLayout {
    int panelX, panelY, panelW, panelH;
    int titleH, footerH, pad;
    int navX, navY, navW, navH;
    int listX, listY, listW, listH;
    int rowH, pillW, pillH, knobS;
    float uiScale;
};
static EchoUiLayout g_L = {};

static ULONG_PTR g_gdiplusToken = 0;
static BOOL      g_gdiplusReady = FALSE;
static BOOL      g_vehInstalled = FALSE;

static const wchar_t* kFontUI = L"Microsoft YaHei UI";
static const wchar_t* kFontFallback = L"Segoe UI";

// ---- 崩溃诊断（VEH）：把异常码 / 崩溃地址 / 所属模块+偏移 落到 %TEMP%\echo_config_ui_diag.txt，
//      用于离线定位（绝不在游戏里弹框、也不改异常处置）----
static void DiagWriteLine(const wchar_t* line) {
    wchar_t path[MAX_PATH] = {};
    GetTempPathW(MAX_PATH, path);
    wcscat_s(path, MAX_PATH, L"echo_config_ui_diag.txt");
    HANDLE h = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL,
                           OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        return;
    }
    char utf8[2048] = {};
    WideCharToMultiByte(CP_UTF8, 0, line, -1, utf8, (int)sizeof(utf8) - 1, NULL, NULL);
    DWORD written = 0;
    WriteFile(h, utf8, (DWORD)strlen(utf8), &written, NULL);
    WriteFile(h, "\r\n", 2, &written, NULL);
    CloseHandle(h);
}

static LONG WINAPI EchoVehFilter(EXCEPTION_POINTERS* ep) {
    if (ep == NULL || ep->ExceptionRecord == NULL) {
        return EXCEPTION_CONTINUE_SEARCH;
    }
    const DWORD code = ep->ExceptionRecord->ExceptionCode;
    void* addr = ep->ExceptionRecord->ExceptionAddress;

    wchar_t modName[MAX_PATH] = L"?";
    DWORD modOffset = 0;
    HMODULE mod = NULL;
    if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCWSTR)addr, &mod) && mod != NULL) {
        GetModuleFileNameW(mod, modName, MAX_PATH);
        modOffset = (DWORD)((ULONG_PTR)addr - (ULONG_PTR)mod);
    }
    const wchar_t* access = L"?";
    if (code == EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters >= 2) {
        const ULONG_PTR kind = ep->ExceptionRecord->ExceptionInformation[0];
        access = (kind == 0) ? L"read" : ((kind == 1) ? L"write" : L"execute");
    }
    wchar_t line[1600];
    _snwprintf_s(line, 1600, _TRUNCATE,
                 L"[veh] code=0x%08X addr=%p module=%ls+0x%X access=%ls "
                 L"open=%d hooked=%d lines=%d groups=%d",
                 (unsigned)code, addr, modName, (unsigned)modOffset, access,
                 g_open ? 1 : 0, g_hooked ? 1 : 0, g_lineCount, g_groupCount);
    DiagWriteLine(line);
    return EXCEPTION_CONTINUE_SEARCH;
}

static void EnsureVeh(void) {
    if (!g_vehInstalled) {
        if (AddVectoredExceptionHandler(1, EchoVehFilter) != NULL) {
            g_vehInstalled = TRUE;
        }
    }
}

// ---- 前向声明（顺序无关，但必须在使用前可见）----
static void EchoHide(void);
static void DrawUiFrame(HDC dcIn);
static BOOL CfgBoolValue(int lineIdx);
static void CfgSetValue(int lineIdx, const wchar_t* value);
static BOOL CfgSave(void);

// ============================================================================
// 四、基础工具
// ============================================================================
static int Clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float Lerpf(float a, float b, float t) { return a + (b - a) * t; }

static float EaseOutCubic(float t) {
    t = Clampf(t, 0.0f, 1.0f);
    const float u = 1.0f - t;
    return 1.0f - u * u * u;
}

/** 回弹缓动（easeOutBack）：胶囊开关"弹一下"的过冲效果。 */
static float EaseOutBack(float t) {
    t = Clampf(t, 0.0f, 1.0f);
    const float c1 = 1.70158f;
    const float c3 = c1 + 1.0f;
    const float u = t - 1.0f;
    return 1.0f + c3 * u * u * u + c1 * u * u;
}

/** 稳定的伪随机（按索引）。 */
static DWORD Argb(int a, int r, int g, int b);   // 前向声明：HslToArgb 会用到

static float Hash01(int n) {
    unsigned x = (unsigned)n * 2654435761u;
    x ^= x >> 15;
    x *= 2246822519u;
    x ^= x >> 13;
    return (float)(x & 0xFFFFFFu) / 16777215.0f;
}

/** HSL → ARGB（星空彩色渐变用）。h/s/l 均为 0..1。 */
static DWORD HslToArgb(float h, float s, float l) {
    h = fmodf(h, 1.0f);
    if (h < 0.0f) {
        h += 1.0f;
    }
    float r = l, g = l, b = l;
    if (s > 0.001f) {
        const float q = (l < 0.5f) ? (l * (1.0f + s)) : (l + s - l * s);
        const float p = 2.0f * l - q;
        const float hh[3] = { h + 1.0f / 3.0f, h, h - 1.0f / 3.0f };
        float out[3];
        for (int i = 0; i < 3; ++i) {
            float t = hh[i];
            if (t < 0.0f) {
                t += 1.0f;
            }
            if (t > 1.0f) {
                t -= 1.0f;
            }
            if (t < 1.0f / 6.0f) {
                out[i] = p + (q - p) * 6.0f * t;
            } else if (t < 0.5f) {
                out[i] = q;
            } else if (t < 2.0f / 3.0f) {
                out[i] = p + (q - p) * (2.0f / 3.0f - t) * 6.0f;
            } else {
                out[i] = p;
            }
        }
        r = out[0];
        g = out[1];
        b = out[2];
    }
    return Argb(255, (int)(r * 255.0f), (int)(g * 255.0f), (int)(b * 255.0f));
}


static DWORD Argb(int a, int r, int g, int b) {
    return ((DWORD)(a & 0xFF) << 24) | ((DWORD)(r & 0xFF) << 16)
         | ((DWORD)(g & 0xFF) << 8) | (DWORD)(b & 0xFF);
}

static DWORD FadeArgb(DWORD c, float mul) {
    const int a = (int)(((c >> 24) & 0xFF) * Clampf(mul, 0.0f, 1.0f));
    return (c & 0x00FFFFFF) | ((DWORD)Clampi(a, 0, 255) << 24);
}

static DWORD LerpArgb(DWORD c1, DWORD c2, float t) {
    const int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
    const int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
    return Argb((int)Lerpf((float)a1, (float)a2, t), (int)Lerpf((float)r1, (float)r2, t),
                (int)Lerpf((float)g1, (float)g2, t), (int)Lerpf((float)b1, (float)b2, t));
}

static int Utf8ToWide(const char* src, int srcLen, wchar_t* dst, int dstCap) {
    if (src == NULL || dstCap <= 0) {
        return 0;
    }
    const int n = MultiByteToWideChar(CP_UTF8, 0, src, srcLen, dst, dstCap - 1);
    if (n <= 0) {
        dst[0] = 0;
        return 0;
    }
    dst[n] = 0;
    return n;
}

static char* WideToUtf8Alloc(const wchar_t* src) {
    const int need = WideCharToMultiByte(CP_UTF8, 0, src, -1, NULL, 0, NULL, NULL);
    if (need <= 0) {
        return NULL;
    }
    char* out = (char*)malloc((size_t)need);
    if (out == NULL) {
        return NULL;
    }
    WideCharToMultiByte(CP_UTF8, 0, src, -1, out, need, NULL, NULL);
    return out;
}

static float QueryUiScale(HWND hwnd) {
    float scale = 1.0f;
    if (hwnd != NULL) {
        typedef UINT(WINAPI* GetDpiForWindow_t)(HWND);
        static GetDpiForWindow_t fn = NULL;
        static BOOL tried = FALSE;
        if (!tried) {
            tried = TRUE;
            HMODULE user32 = GetModuleHandleW(L"user32.dll");
            if (user32 != NULL) {
                fn = (GetDpiForWindow_t)(void*)GetProcAddress(user32, "GetDpiForWindow");
            }
        }
        if (fn != NULL) {
            const UINT dpi = fn(hwnd);
            if (dpi >= 72) {
                scale = (float)dpi / 96.0f;
            }
        } else {
            HDC dc = GetDC(hwnd);
            if (dc != NULL) {
                scale = (float)GetDeviceCaps(dc, LOGPIXELSX) / 96.0f;
                ReleaseDC(hwnd, dc);
            }
        }
    }
    return Clampf(scale, 1.0f, 3.0f);
}

// ============================================================================
// 五、配置解析 / 写回
// ============================================================================
static void CfgReset(void) {
    ZeroMemory(g_lines, sizeof(g_lines));
    ZeroMemory(g_groups, sizeof(g_groups));
    g_lineCount = 0;
    g_groupCount = 0;
    g_activeGroup = 0;
    g_dirty = FALSE;
}

static BOOL IsBlankW(const wchar_t* s) {
    for (; *s != 0; ++s) {
        if (*s != L' ' && *s != L'\t' && *s != L'\r') {
            return FALSE;
        }
    }
    return TRUE;
}

/** 注释行是否为分组标题：`# —— 底层 ——`（全角）或 `# -- 底层 --`（ASCII）。 */
static BOOL ParseGroupTitle(const wchar_t* line, wchar_t* outName, int cap) {
    const wchar_t* p = line;
    while (*p == L' ' || *p == L'\t') {
        ++p;
    }
    if (*p != L'#') {
        return FALSE;
    }
    ++p;
    const wchar_t* dash = wcsstr(p, L"\u2014\u2014");
    if (dash != NULL) {
        dash += 2;
    } else {
        dash = wcsstr(p, L"--");
        if (dash == NULL) {
            return FALSE;
        }
        dash += 2;
    }
    const wchar_t* end = wcsstr(dash, L"\u2014\u2014");
    if (end == NULL) {
        end = wcsstr(dash, L"--");
        if (end == NULL) {
            return FALSE;
        }
    }
    while (dash < end && (*dash == L' ' || *dash == L'\t')) {
        ++dash;
    }
    int n = 0;
    for (const wchar_t* q = dash; q < end && n < cap - 1; ++q) {
        outName[n++] = *q;
    }
    while (n > 0 && (outName[n - 1] == L' ' || outName[n - 1] == L'\t')) {
        --n;
    }
    outName[n] = 0;
    return n > 0;
}

static BOOL ParseKeyValue(wchar_t* line, int* keyStart, int* keyLen, int* valStart, int* valLen) {
    wchar_t* p = line;
    while (*p == L' ' || *p == L'\t') {
        ++p;
    }
    if (*p == 0 || *p == L'#') {
        return FALSE;
    }
    wchar_t* eq = wcschr(p, L'=');
    if (eq == NULL) {
        return FALSE;
    }
    wchar_t* kEnd = eq;
    while (kEnd > p && (kEnd[-1] == L' ' || kEnd[-1] == L'\t')) {
        --kEnd;
    }
    if (kEnd == p) {
        return FALSE;
    }
    wchar_t* vStart = eq + 1;
    while (*vStart == L' ' || *vStart == L'\t') {
        ++vStart;
    }
    wchar_t* vEnd = vStart + wcslen(vStart);
    while (vEnd > vStart && (vEnd[-1] == L'\r' || vEnd[-1] == L' ' || vEnd[-1] == L'\t')) {
        --vEnd;
    }
    *keyStart = (int)(p - line);
    *keyLen = (int)(kEnd - p);
    *valStart = (int)(vStart - line);
    *valLen = (int)(vEnd - vStart);
    return TRUE;
}

static BOOL CfgLoad(const wchar_t* path) {
    CfgReset();
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    LARGE_INTEGER size = {};
    GetFileSizeEx(f, &size);
    if (size.QuadPart <= 0 || size.QuadPart > (LONGLONG)(8 * 1024 * 1024)) {
        CloseHandle(f);
        return FALSE;
    }
    const DWORD bytes = (DWORD)size.QuadPart;
    char* buf = (char*)malloc(bytes + 1);
    if (buf == NULL) {
        CloseHandle(f);
        return FALSE;
    }
    DWORD read = 0;
    const BOOL ok = ReadFile(f, buf, bytes, &read, NULL);
    CloseHandle(f);
    if (!ok) {
        free(buf);
        return FALSE;
    }
    buf[read] = 0;

    const char* text = buf;
    if ((unsigned char)text[0] == 0xEF && (unsigned char)text[1] == 0xBB && (unsigned char)text[2] == 0xBF) {
        text += 3;
    }

    const char* lineStart = text;
    int lineIdx = 0;
    int currentGroup = -1;
    while (*lineStart != 0 && lineIdx < ECHO_MAX_LINES) {
        const char* nl = strchr(lineStart, '\n');
        const int len = (nl == NULL) ? (int)strlen(lineStart) : (int)(nl - lineStart);
        EchoCfgLine* L = &g_lines[lineIdx];
        const int useLen = (len > 0 && lineStart[len - 1] == '\r') ? len - 1 : len;
        Utf8ToWide(lineStart, useLen, L->text, ECHO_LINE_CHARS);
        L->group = currentGroup;

        if (IsBlankW(L->text)) {
            L->kind = LINE_BLANK;
        } else {
            wchar_t gname[ECHO_NAME_CHARS];
            if (ParseGroupTitle(L->text, gname, ECHO_NAME_CHARS)) {
                L->kind = LINE_COMMENT;
                if (g_groupCount < ECHO_MAX_GROUPS) {
                    EchoCfgGroup* G = &g_groups[g_groupCount];
                    wcsncpy_s(G->name, ECHO_NAME_CHARS, gname, _TRUNCATE);
                    G->firstLine = lineIdx;
                    G->lineCount = 1;
                    G->keyCount = 0;
                    currentGroup = g_groupCount;
                    ++g_groupCount;
                }
                L->group = currentGroup;
            } else if (L->text[0] == L'#') {
                L->kind = LINE_COMMENT;
            } else {
                int ks = 0, kl = 0, vs = 0, vl = 0;
                if (ParseKeyValue(L->text, &ks, &kl, &vs, &vl)) {
                    L->kind = LINE_KEY;
                    L->keyStart = ks;
                    L->keyLen = kl;
                    L->valStart = vs;
                    L->valLen = vl;
                    const wchar_t* v = L->text + vs;
                    L->booleanLike = (vl == 4 && _wcsnicmp(v, L"true", 4) == 0)
                                  || (vl == 5 && _wcsnicmp(v, L"false", 5) == 0);
                    if (L->group >= 0 && L->group < g_groupCount) {
                        ++g_groups[L->group].keyCount;
                        ++g_groups[L->group].lineCount;
                    }
                } else {
                    L->kind = LINE_RAW;
                }
            }
        }
        ++lineIdx;
        if (nl == NULL) {
            break;
        }
        lineStart = nl + 1;
    }
    g_lineCount = lineIdx;

    if (g_groupCount == 0 && g_lineCount > 0) {
        wcsncpy_s(g_groups[0].name, ECHO_NAME_CHARS, L"通用", _TRUNCATE);
        g_groups[0].firstLine = 0;
        g_groups[0].lineCount = g_lineCount;
        g_groups[0].keyCount = 0;
        for (int i = 0; i < g_lineCount; ++i) {
            g_lines[i].group = 0;
            if (g_lines[i].kind == LINE_KEY) {
                ++g_groups[0].keyCount;
            }
        }
        g_groupCount = 1;
    }

    // 初始化开关动画到当前值（打开瞬间不播滑入）
    for (int i = 0; i < g_lineCount; ++i) {
        if (g_lines[i].kind == LINE_KEY && g_lines[i].booleanLike) {
            const float v = CfgBoolValue(i) ? 1.0f : 0.0f;
            g_toggleAnim[i] = v;
            g_toggleTarget[i] = v;
        } else {
            g_toggleAnim[i] = 0.0f;
            g_toggleTarget[i] = 0.0f;
        }
    }
    free(buf);
    return g_lineCount > 0;
}

static BOOL CfgBoolValue(int lineIdx) {
    if (lineIdx < 0 || lineIdx >= g_lineCount) {
        return FALSE;
    }
    const EchoCfgLine* L = &g_lines[lineIdx];
    if (L->kind != LINE_KEY || !L->booleanLike) {
        return FALSE;
    }
    return _wcsnicmp(L->text + L->valStart, L"true", 4) == 0;
}

static void CfgSetValue(int lineIdx, const wchar_t* value) {
    if (lineIdx < 0 || lineIdx >= g_lineCount || value == NULL) {
        return;
    }
    EchoCfgLine* L = &g_lines[lineIdx];
    if (L->kind != LINE_KEY) {
        return;
    }
    wchar_t rebuilt[ECHO_LINE_CHARS];
    wcsncpy_s(rebuilt, ECHO_LINE_CHARS, L->text + L->keyStart, (size_t)L->keyLen);
    rebuilt[L->keyLen] = 0;
    wcscat_s(rebuilt, ECHO_LINE_CHARS, L"=");
    wcsncat_s(rebuilt, ECHO_LINE_CHARS, value, _TRUNCATE);
    wcsncpy_s(L->text, ECHO_LINE_CHARS, rebuilt, _TRUNCATE);

    int ks = 0, kl = 0, vs = 0, vl = 0;
    if (ParseKeyValue(L->text, &ks, &kl, &vs, &vl)) {
        L->keyStart = ks;
        L->keyLen = kl;
        L->valStart = vs;
        L->valLen = vl;
        L->booleanLike = (vl == 4 && _wcsnicmp(L->text + vs, L"true", 4) == 0)
                      || (vl == 5 && _wcsnicmp(L->text + vs, L"false", 5) == 0);
    }
    g_dirty = TRUE;
}

static BOOL CfgSave(void) {
    if (g_configPath[0] == 0 || g_lineCount <= 0) {
        return FALSE;
    }
    HANDLE f = CreateFileW(g_configPath, GENERIC_WRITE, FILE_SHARE_READ,
                           NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    BOOL ok = TRUE;
    for (int i = 0; i < g_lineCount && ok; ++i) {
        char* utf8 = WideToUtf8Alloc(g_lines[i].text);
        if (utf8 == NULL) {
            continue;
        }
        DWORD written = 0;
        if (!WriteFile(f, utf8, (DWORD)strlen(utf8), &written, NULL)) {
            ok = FALSE;
        }
        if (ok) {
            WriteFile(f, "\r\n", 2, &written, NULL);
        }
        free(utf8);
    }
    CloseHandle(f);
    if (ok) {
        g_dirty = FALSE;
    }
    return ok;
}

// ============================================================================
// 六、布局
// ============================================================================
static void ComputeLayout(int clientW, int clientH) {
    // 【用户裁决】整体放大到 2 倍：uiScale 直接乘 2 ⇒ 面板、字号、行高、胶囊、间距按同一
    // 比例放大，面板仍然居中（中心位置不变）；尺寸会被窗口边界夹住，避免超出画面。
    const float s = Clampf(QueryUiScale(g_hwnd) * 2.0f, 1.0f, 4.0f);
    g_L.uiScale = s;

    int w = (int)(560.0f * s);
    int h = (int)(400.0f * s);
    w = Clampi(w, 300, clientW - (int)(48 * s));
    h = Clampi(h, 220, clientH - (int)(48 * s));

    g_L.panelW = w;
    g_L.panelH = h;
    g_L.panelX = (clientW - w) / 2;
    g_L.panelY = (clientH - h) / 2;

    g_L.pad = (int)(16 * s);
    g_L.titleH = (int)(46 * s);
    g_L.footerH = (int)(52 * s);

    int navW = (int)(146 * s);
    navW = Clampi(navW, (int)(100 * s), w / 2);

    g_L.navX = g_L.panelX + g_L.pad;
    g_L.navY = g_L.panelY + g_L.titleH;
    g_L.navW = navW;
    g_L.navH = g_L.panelH - g_L.titleH - g_L.footerH;

    g_L.listX = g_L.navX + g_L.navW + (int)(12 * s);
    g_L.listY = g_L.navY;
    g_L.listW = (g_L.panelX + g_L.panelW - g_L.pad) - g_L.listX;
    g_L.listH = g_L.navH;

    g_L.rowH = (int)(38 * s);
    g_L.pillW = (int)(40 * s);
    g_L.pillH = (int)(20 * s);
    g_L.knobS = (int)(16 * s);
}

static int CollectRows(int group, int* out, int cap) {
    int n = 0;
    for (int i = 0; i < g_lineCount && n < cap; ++i) {
        if (g_lines[i].kind == LINE_KEY && g_lines[i].group == group) {
            out[n++] = i;
        }
    }
    return n;
}

static float MaxScroll(int totalCount) {
    const float content = (float)(totalCount * g_L.rowH);
    const float max = content - (float)g_L.listH;
    return max > 0.0f ? max : 0.0f;
}

// ============================================================================
// 七、GDI+ 绘制
// ============================================================================
static void AddRoundedRect(GraphicsPath* path, float x, float y, float w, float h, float r) {
    if (r > h * 0.5f) {
        r = h * 0.5f;
    }
    if (r > w * 0.5f) {
        r = w * 0.5f;
    }
    if (r <= 0.5f) {
        path->AddRectangle(RectF(x, y, w, h));
        return;
    }
    const float d = r * 2.0f;
    path->AddArc(x, y, d, d, 180.0f, 90.0f);
    path->AddArc(x + w - d, y, d, d, 270.0f, 90.0f);
    path->AddArc(x + w - d, y + h - d, d, d, 0.0f, 90.0f);
    path->AddArc(x, y + h - d, d, d, 90.0f, 90.0f);
    path->CloseFigure();
}

static void DrawTextAt(Graphics* g, const wchar_t* text, float sizePx,
                       float x, float y, float w, float h, DWORD color, BOOL bold,
                       StringAlignment hAlign) {
    if (text == NULL || text[0] == 0 || w <= 1.0f) {
        return;
    }
    // GDI+ 的 FontFamily 不可赋值 ⇒ 先探测再用可用名构造
    const wchar_t* famName = kFontUI;
    {
        FontFamily probe(kFontUI);
        if (!probe.IsAvailable()) {
            famName = kFontFallback;
        }
    }
    FontFamily family(famName);
    Gdiplus::Font font(&family, sizePx, bold ? FontStyleBold : FontStyleRegular, UnitPixel);
    if (!font.IsAvailable()) {
        return;
    }
    SolidBrush brush(Color((ARGB)color));
    StringFormat fmt;
    fmt.SetAlignment(hAlign);
    fmt.SetLineAlignment(StringAlignmentCenter);
    fmt.SetTrimming(StringTrimmingEllipsisCharacter);
    fmt.SetFormatFlags(StringFormatFlagsNoWrap);
    g->DrawString(text, -1, &font, RectF(x, y, w, h), &fmt, &brush);
}

/** 释放模糊缓存。 */
static void ReleaseBlurCache(void) {
    if (g_blurDC != NULL) {
        if (g_blurOldBmp != NULL) {
            SelectObject(g_blurDC, g_blurOldBmp);
            g_blurOldBmp = NULL;
        }
        DeleteDC(g_blurDC);
        g_blurDC = NULL;
    }
    if (g_blurBmp != NULL) {
        DeleteObject(g_blurBmp);
        g_blurBmp = NULL;
    }
    g_blurValid = FALSE;
    g_blurW = 0;
    g_blurH = 0;
}

/**
 * 抓一次面板区域的背景并做成「降采样近似高斯模糊」缓存。
 *
 * <p>只在打开后首帧调用一次（抓到的窗口内容 = 游戏刚换帧的干净画面，不含我方界面）。
 * 任何 SEH 异常都只降级（g_blurValid 保持 FALSE ⇒ 面板走纯半透明玻璃），绝不向外抛。</p>
 */
static BOOL CaptureBlurCache(HDC dc, int x, int y, int w, int h) {
    ReleaseBlurCache();
    if (dc == NULL || w <= 16 || h <= 16) {
        return FALSE;
    }
    const int sw = w / 8 > 2 ? w / 8 : 2;
    const int sh = h / 8 > 2 ? h / 8 : 2;

    HDC m2 = NULL;
    HBITMAP b2 = NULL;
    __try {
        g_blurDC = CreateCompatibleDC(dc);
        g_blurBmp = CreateCompatibleBitmap(dc, w, h);
        m2 = CreateCompatibleDC(dc);
        b2 = CreateCompatibleBitmap(dc, sw, sh);
        if (g_blurDC == NULL || g_blurBmp == NULL || m2 == NULL || b2 == NULL) {
            __leave;
        }
        HGDIOBJ o1 = SelectObject(g_blurDC, g_blurBmp);
        g_blurOldBmp = (HBITMAP)o1;
        HGDIOBJ o2 = SelectObject(m2, b2);

        // 1) 抓窗口该区域的干净像素
        if (!BitBlt(g_blurDC, 0, 0, w, h, dc, x, y, SRCCOPY)) {
            SelectObject(g_blurDC, o1);
            SelectObject(m2, o2);
            __leave;
        }
        // 2) 缩小（HALFTONE 平均）→ 3) 放大回大图 = 近似高斯
        SetStretchBltMode(m2, HALFTONE);
        SetBrushOrgEx(m2, 0, 0, NULL);
        if (!StretchBlt(m2, 0, 0, sw, sh, g_blurDC, 0, 0, w, h, SRCCOPY)) {
            SelectObject(g_blurDC, o1);
            SelectObject(m2, o2);
            __leave;
        }
        SetStretchBltMode(g_blurDC, HALFTONE);
        SetBrushOrgEx(g_blurDC, 0, 0, NULL);
        if (!StretchBlt(g_blurDC, 0, 0, w, h, m2, 0, 0, sw, sh, SRCCOPY)) {
            SelectObject(g_blurDC, o1);
            SelectObject(m2, o2);
            __leave;
        }
        SelectObject(g_blurDC, o1);
        SelectObject(m2, o2);
        g_blurValid = TRUE;
        g_blurW = w;
        g_blurH = h;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        DiagWriteLine(L"[blur] capture raised SEH -> blur disabled (fail-open, glass only)");
        g_blurValid = FALSE;
    }
    if (b2 != NULL) {
        DeleteObject(b2);
    }
    if (m2 != NULL) {
        DeleteDC(m2);
    }
    if (!g_blurValid) {
        ReleaseBlurCache();
    }
    return g_blurValid;
}

/** 单帧绘制（在 SwapBuffers 之后 / 定时器里调用）。 */
/**
 * 把界面画到给定 DC。
 *   · GL 路径传 DIB 的 memDC（离屏）⇒ 再由 GL 贴到后缓冲（DWM flip model 下唯一可见的方式）；
 *   · GDI 回退路径传 NULL ⇒ 自己取窗口 DC（仅在没有 GL 时兜底）。
 */
// 外观设置浮层（被 DrawUiFrame 调用 ⇒ 必须在它之前 include）
#include "echo_config_ui_appearance.inc"

static void DrawUiFrame(HDC dcIn) {
    if (!g_open || g_hwnd == NULL || !IsWindow(g_hwnd)) {
        return;
    }
    RECT rc = {};
    if (!GetClientRect(g_hwnd, &rc)) {
        return;
    }
    const int cw = rc.right - rc.left;
    const int ch = rc.bottom - rc.top;
    if (cw < 64 || ch < 64) {
        return;
    }
    ComputeLayout(cw, ch);

    // 动画推进
    const ULONGLONG now = GetTickCount64();
    g_openT = Clampf((float)(now - g_openStamp) / 220.0f, 0.0f, 1.0f);
    for (int i = 0; i < g_lineCount; ++i) {
        const float tgt = g_toggleTarget[i];
        const float cur = g_toggleAnim[i];
        const float d = tgt - cur;
        if (g_toggleT[i] < 1.0f) {
            // 胶囊开关弹入：240ms easeOutBack（带轻微过冲回弹）
            g_toggleT[i] += (float)(now - g_lastAnimTick) / 240.0f;
            if (g_toggleT[i] > 1.0f) {
                g_toggleT[i] = 1.0f;
            }
            g_toggleAnim[i] = Lerpf(g_toggleFrom[i], tgt, EaseOutBack(g_toggleT[i]));
        } else {
            g_toggleAnim[i] = tgt;
        }
    }

    // 主题动态化：换色/明暗切换时由 CurrentTheme() 重算（见 appearance.inc）
    const EchoUiTheme* T = CurrentTheme();
    const float s = g_L.uiScale;
    const float openE = EaseOutCubic(g_openT);

    BOOL ownDc = FALSE;
    HDC dc = dcIn;
    if (dc == NULL) {
        dc = GetDC(g_hwnd);
        ownDc = TRUE;
    }
    if (dc == NULL) {
        return;
    }

    // 面板底：首帧抓一次「干净的游戏画面」并模糊成缓存，之后每帧直接贴回。
    //   · 抓取发生在 SwapBuffers 之后 ⇒ 窗口里是游戏刚换好的新帧，不含我方界面；
    //   · 之后不再读像素 ⇒ 不会把自己上一帧的界面糊进去（那是高频频闪的根因）；
    //   · 抓取放在 SEH 里 ⇒ 万一驱动不允许读回，自动降级为纯半透明玻璃，游戏不崩。
    // 【默认关闭 GDI 读回】实测：BitBlt 从 GL 窗口 DC 读像素在渲染线程上必崩
    // gdi32full.dll+0x5e4d7（连崩两次）。模糊改由下一阶段的 GL overlay 用
    // glReadPixels 实现（GL 自己的读回，安全），届时再打开下面这段。
    // 面板底一律走 GDI+ 半透明玻璃 + 顶部高光 + 内描边（纯绘制、零读取 ⇒ 不可能崩）。
    if (g_allowGdiReadback) {
        if (!g_blurValid || g_blurW != g_L.panelW || g_blurH != g_L.panelH) {
            CaptureBlurCache(dc, g_L.panelX, g_L.panelY, g_L.panelW, g_L.panelH);
        }
        if (g_blurValid && g_blurDC != NULL) {
            BitBlt(dc, g_L.panelX, g_L.panelY, g_L.panelW, g_L.panelH, g_blurDC, 0, 0, SRCCOPY);
        }
    }

    {
        Graphics g(dc);
        g.SetSmoothingMode(SmoothingModeAntiAlias);
        // 透明背景上不用 ClearType（会出彩边）；AntiAliasGridFit 更安全
        g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
        g.SetCompositingQuality(CompositingQualityHighQuality);
        g.SetCompositingMode(CompositingModeSourceOver);
        // GL 路径画到「面板尺寸」的离屏 DIB：把客户区绝对坐标平移到面板内坐标
        if (g_drawOffsetX != 0 || g_drawOffsetY != 0) {
            g.TranslateTransform((float)(-g_drawOffsetX), (float)(-g_drawOffsetY));
        }

        const float px = (float)g_L.panelX;
        const float py = (float)g_L.panelY;
        const float pw = (float)g_L.panelW;
        const float ph = (float)g_L.panelH;

        // ---- 阴影 + 品牌泛光 ----
        {
            GraphicsPath shadow;
            AddRoundedRect(&shadow, px - 2.0f, py + 4.0f, pw + 4.0f, ph + 6.0f, 18.0f * s);
            for (int i = 4; i >= 1; --i) {
                Pen sp(Color((BYTE)Clampi((int)(9 * openE * Clampf(g_optShadow, 0.0f, 1.0f)), 0, 255), 0, 0, 0), (float)(i * 2) * s);
                sp.SetLineJoin(LineJoinRound);
                g.DrawPath(&sp, &shadow);
            }
            Pen glow(Color((ARGB)FadeArgb(T->brandGlow, openE * Clampf(g_optGlow, 0.0f, 1.0f))), 6.0f * s);
            glow.SetLineJoin(LineJoinRound);
            g.DrawPath(&glow, &shadow);
        }

        // ---- 面板玻璃 ----
        {
            GraphicsPath panel;
            AddRoundedRect(&panel, px, py, pw, ph, 18.0f * s);
            LinearGradientBrush brush(
                PointF(px, py), PointF(px, py + ph),
                // 玻璃不透明度：乘「外观设置」的不透明度滑条（0.3..1），并留足透明度让下层模糊透出
                Color((ARGB)FadeArgb(T->panelTop, openE * Clampf(g_optOpacity, 0.3f, 1.0f))),
                Color((ARGB)FadeArgb(T->panelBottom, openE * Clampf(g_optOpacity, 0.3f, 1.0f))));
            g.FillPath(&brush, &panel);
            Pen edge(Color((ARGB)FadeArgb(T->edgeLight, openE)), 1.0f);
            g.DrawPath(&edge, &panel);
        }

        // ---- 标题栏 ----
        {
            const float tx = px + (float)g_L.pad;
            const float ty = py;
            const float th = (float)g_L.titleH;
            DrawTextAt(&g, L"回响物语 · 配置", 15.0f * s, tx, ty, 200.0f * s, th,
                       FadeArgb(T->textMain, openE), TRUE, StringAlignmentNear);
            if (g_activeGroup >= 0 && g_activeGroup < g_groupCount) {
                DrawTextAt(&g, g_groups[g_activeGroup].name, 11.5f * s,
                           tx + 122.0f * s, ty, 150.0f * s, th,
                           FadeArgb(T->textSub, openE), FALSE, StringAlignmentNear);
            }
            // 关闭圆钮
            const float btnR = 14.0f * s;
            const float cx = px + pw - (float)g_L.pad - btnR;
            const float cy = ty + th * 0.5f;
            {
                if (g_hoverClose) {
                    SolidBrush bg(Color((ARGB)FadeArgb(T->navHover, openE)));
                    g.FillEllipse(&bg, cx - btnR, cy - btnR, btnR * 2, btnR * 2);
                }
                Pen pk(Color((ARGB)FadeArgb(g_hoverClose ? T->danger : T->textSub, openE)), 1.6f * s);
                pk.SetStartCap(LineCapRound);
                pk.SetEndCap(LineCapRound);
                const float d = 4.2f * s;
                g.DrawLine(&pk, cx - d, cy - d, cx + d, cy + d);
                g.DrawLine(&pk, cx + d, cy - d, cx - d, cy + d);
            }
            // 主题胶囊
            {
                const float tw = 54.0f * s;
                const float thh = 20.0f * s;
                const float tx2 = cx - btnR - 8.0f * s - tw;
                const float ty2 = cy - thh * 0.5f;
                GraphicsPath p;
                AddRoundedRect(&p, tx2, ty2, tw, thh, thh * 0.5f);
                SolidBrush bg(Color((ARGB)FadeArgb(g_hoverTheme ? T->navHover : T->navActive, openE)));
                g.FillPath(&bg, &p);
                Pen e(Color((ARGB)FadeArgb(T->edgeLight, openE)), 1.0f);
                g.DrawPath(&e, &p);
                DrawTextAt(&g, g_themeDarkSel ? L"暗色" : L"亮色", 11.0f * s,
                           tx2, ty2, tw, thh, FadeArgb(T->textMain, openE), FALSE,
                           StringAlignmentCenter);
            }
        }

        // ---- 左侧分页栏背景：星空（彩色渐变闪烁 + 海水般流动）----
        // 原理同 ARTEMIS 的星空渲染：大量散点在时间维度上
        //   · 位置：纵向匀速漂移（下 → 上循环）+ 横向正弦摆动（海浪）
        //   · 颜色：色相随时间/位置连续变化（彩虹渐变）
        //   · 亮度：每颗独立正弦闪烁（相位/频率各不相同，避免同步脉冲）
        {
            const float t = (float)(now % 1000000ULL) / 1000.0f;
            g.SetClip(RectF((float)g_L.navX, (float)g_L.navY,
                            (float)g_L.navW, (float)g_L.navH));
            for (int i = 0; i < 72; ++i) {
                const float r1 = Hash01(i * 3 + 1);
                const float r2 = Hash01(i * 7 + 3);
                const float r3 = Hash01(i * 11 + 5);
                const float r4 = Hash01(i * 13 + 7);
                // 海水流动：纵向缓慢下移并按高度循环
                float fy = fmodf(r2 * (float)g_L.navH + t * (9.0f + r3 * 20.0f) * s,
                                 (float)g_L.navH);
                const float y = (float)g_L.navY + fy;
                // 横向波浪摆动
                const float x = (float)g_L.navX + r1 * (float)g_L.navW +
                    sinf(t * (0.5f + r4 * 0.9f) + r3 * 6.2832f) * (4.0f + r3 * 9.0f) * s;
                // 独立闪烁
                const float tw = 0.35f + 0.65f * (0.5f + 0.5f *
                    sinf(t * (1.2f + r2 * 2.4f) + r1 * 6.2832f));
                // 彩色渐变（色相随时间和纵向位置流动）
                const float hue = fmodf(t * 0.06f + r1 * 0.7f + (y - (float)g_L.navY) /
                                        (float)g_L.navH * 0.35f, 1.0f);
                const DWORD col = HslToArgb(hue, 0.85f, 0.62f);
                const float rad = (0.9f + r3 * 1.9f) * s;
                SolidBrush br(Color((ARGB)FadeArgb(col, tw * openE * 0.85f)));
                g.FillEllipse(&br, x - rad, y - rad, rad * 2.0f, rad * 2.0f);
            }
            g.ResetClip();
        }

        // ---- 左侧分组导航 ----
        {
            const float navRowH = 26.0f * s;
            const float gap = 2.0f * s;
            for (int i = 0; i <= g_groupCount; ++i) {   // 最后一个分组索引 = 「外观」页
                const float ny = (float)g_L.navY + (float)i * (navRowH + gap);
                if (ny + navRowH > (float)(g_L.navY + g_L.navH)) {
                    break;
                }
                const BOOL act = (i == g_activeGroup);
                const BOOL hov = (i == g_hoverNav);
                if (act || hov) {
                    GraphicsPath p;
                    AddRoundedRect(&p, (float)g_L.navX, ny, (float)g_L.navW, navRowH, 8.0f * s);
                    SolidBrush bg(Color((ARGB)FadeArgb(act ? T->navActive : T->navHover, openE)));
                    g.FillPath(&bg, &p);
                }
                const float dotR = 2.6f * s;
                const float dx = (float)g_L.navX + 12.0f * s;
                const float dy = ny + navRowH * 0.5f;
                SolidBrush dot(Color((ARGB)FadeArgb(act ? T->brand : T->textFaint, openE)));
                g.FillEllipse(&dot, dx - dotR, dy - dotR, dotR * 2, dotR * 2);
                const wchar_t* navLabel = (i == g_groupCount) ? L"外观" : g_groups[i].name;
                DrawTextAt(&g, navLabel, 12.0f * s,
                           (float)g_L.navX + 24.0f * s, ny,
                           (float)g_L.navW - 30.0f * s, navRowH,
                           FadeArgb(act ? T->textMain : T->textSub, openE), act,
                           StringAlignmentNear);
            }
        }

        // ---- 右侧行列表 ----
        // 外观页：右侧直接画外观控件（滑条/调色板/明暗），不画配置行
        if (g_activeGroup >= g_groupCount) {
            DrawAppearancePage(&g, T, s, openE);
        } else {
        {
            int rows[ECHO_MAX_LINES];
            const int rowCount = CollectRows(g_activeGroup, rows, ECHO_MAX_LINES);
            const float maxScroll = MaxScroll(rowCount);
            g_scrollTarget = Clampf(g_scrollTarget, 0.0f, maxScroll);
            g_scrollCur = Lerpf(g_scrollCur, g_scrollTarget, 0.35f);
            if (fabsf(g_scrollCur - g_scrollTarget) < 0.4f) {
                g_scrollCur = g_scrollTarget;
            }

            g.SetClip(RectF((float)g_L.listX, (float)g_L.listY,
                            (float)g_L.listW, (float)g_L.listH));

            for (int r = 0; r < rowCount; ++r) {
                const float ry = (float)g_L.listY + (float)(r * g_L.rowH) - g_scrollCur;
                if (ry + (float)g_L.rowH < (float)g_L.listY - 4) {
                    continue;
                }
                if (ry > (float)(g_L.listY + g_L.listH)) {
                    break;
                }
                const int li = rows[r];
                float anim = 1.0f;
                if (r < 14) {
                    // 级联：打开面板 **或** 切换左侧分组，都让行重新依次弹入
                    const ULONGLONG stamp = (g_pageStamp > g_openStamp) ? g_pageStamp : g_openStamp;
                    const float delay = 40.0f + (float)r * 30.0f;
                    anim = EaseOutCubic(Clampf(((float)(now - stamp) - delay) / 200.0f, 0.0f, 1.0f));
                }
                const float slide = (1.0f - anim) * 12.0f * s;

                if (li == g_hoverRow) {
                    GraphicsPath hp;
                    AddRoundedRect(&hp, (float)g_L.listX, ry + 1.0f * s,
                                   (float)g_L.listW, (float)g_L.rowH - 2.0f * s, 8.0f * s);
                    SolidBrush hb(Color((ARGB)FadeArgb(T->rowHover, anim * openE)));
                    g.FillPath(&hb, &hp);
                }

                const EchoCfgLine* L = &g_lines[li];
                wchar_t keyName[ECHO_NAME_CHARS];
                int kn = L->keyLen;
                if (kn > ECHO_NAME_CHARS - 1) {
                    kn = ECHO_NAME_CHARS - 1;
                }
                wcsncpy_s(keyName, ECHO_NAME_CHARS, L->text + L->keyStart, (size_t)kn);
                keyName[kn] = 0;

                const float textW = (float)g_L.listW - (float)g_L.pillW - 24.0f * s;
                DrawTextAt(&g, keyName, 12.0f * s,
                           (float)g_L.listX + 10.0f * s, ry + slide, textW, (float)g_L.rowH,
                           FadeArgb(T->textMain, anim * openE), FALSE, StringAlignmentNear);

                if (L->booleanLike) {
                    const float pillX = (float)(g_L.listX + g_L.listW) - (float)g_L.pillW - 10.0f * s;
                    const float pillY = ry + ((float)g_L.rowH - (float)g_L.pillH) * 0.5f + slide;
                    const float tt = g_toggleAnim[li];
                    GraphicsPath track;
                    AddRoundedRect(&track, pillX, pillY, (float)g_L.pillW, (float)g_L.pillH,
                                   (float)g_L.pillH * 0.5f);
                    SolidBrush tb(Color((ARGB)FadeArgb(LerpArgb(T->pillOff, T->pillOn, tt), anim * openE)));
                    g.FillPath(&tb, &track);
                    Pen te(Color((ARGB)FadeArgb(T->edgeLight, anim * openE)), 1.0f);
                    g.DrawPath(&te, &track);
                    const float knobS = (float)g_L.knobS;
                    const float travel = (float)g_L.pillW - knobS - 4.0f * s;
                    const float kx = pillX + 2.0f * s + travel * tt;
                    const float ky = pillY + ((float)g_L.pillH - knobS) * 0.5f;
                    SolidBrush kb(Color((ARGB)FadeArgb(T->knob, anim * openE)));
                    g.FillEllipse(&kb, kx, ky, knobS, knobS);
                } else {
                    wchar_t val[ECHO_NAME_CHARS];
                    int vn = L->valLen;
                    if (vn > ECHO_NAME_CHARS - 1) {
                        vn = ECHO_NAME_CHARS - 1;
                    }
                    wcsncpy_s(val, ECHO_NAME_CHARS, L->text + L->valStart, (size_t)vn);
                    val[vn] = 0;
                    if (val[0] == 0) {
                        wcscpy_s(val, ECHO_NAME_CHARS, L"(空)");
                    }
                    const float rightEdge = (float)(g_L.listX + g_L.listW) - 10.0f * s;
                    DrawTextAt(&g, val, 11.5f * s, rightEdge - 110.0f * s, ry + slide,
                               110.0f * s, (float)g_L.rowH,
                               FadeArgb(T->textSub, anim * openE), FALSE, StringAlignmentFar);
                }
            }
            g.ResetClip();

            // 滚动条
            if (maxScroll > 0.5f) {
                const float trackW = 3.0f * s;
                const float trackX = (float)(g_L.listX + g_L.listW) - trackW - 2.0f * s;
                const float thumbH = (float)g_L.listH *
                    ((float)g_L.listH / ((float)rowCount * (float)g_L.rowH));
                const float thumbY = (float)g_L.listY + (float)g_L.listH - thumbH -
                    (maxScroll > 0.5f ? (g_scrollCur / maxScroll) *
                        ((float)g_L.listH - thumbH) : 0.0f);
                GraphicsPath tp;
                AddRoundedRect(&tp, trackX, (float)g_L.listY, trackW, (float)g_L.listH, trackW * 0.5f);
                SolidBrush tb(Color((ARGB)FadeArgb(0x22FFFFFF, openE)));
                g.FillPath(&tb, &tp);
                GraphicsPath hp2;
                AddRoundedRect(&hp2, trackX, thumbY, trackW, thumbH, trackW * 0.5f);
                SolidBrush hb2(Color((ARGB)FadeArgb(T->textFaint, openE)));
                g.FillPath(&hb2, &hp2);
            }
        }

        }   // end else (配置行)
        // ---- 底部按钮 ----
        {
            const float by = py + ph - (float)g_L.footerH + 10.0f * s;
            const float bh = 30.0f * s;
            const float bw = 96.0f * s;
            const float bx2 = px + pw - (float)g_L.pad - bw;
            const float bx1 = bx2 - bw - 10.0f * s;

            {
                GraphicsPath p;
                AddRoundedRect(&p, bx2, by, bw, bh, bh * 0.5f);
                SolidBrush bg(Color((ARGB)FadeArgb(T->pillOn, openE)));
                g.FillPath(&bg, &p);
                Pen e(Color((ARGB)FadeArgb(0x55FFFFFF, openE)), 1.0f);
                g.DrawPath(&e, &p);
                const DWORD fg = g_themeDarkSel ? 0xFF06121F : 0xFFFFFFFF;
                DrawTextAt(&g, g_dirty ? L"保存并关闭" : L"关闭", 12.0f * s,
                           bx2, by, bw, bh, FadeArgb(fg, openE), TRUE, StringAlignmentCenter);
            }
            {
                GraphicsPath p;
                AddRoundedRect(&p, bx1, by, bw, bh, bh * 0.5f);
                SolidBrush bg(Color((ARGB)FadeArgb(T->navHover, openE)));
                g.FillPath(&bg, &p);
                Pen e(Color((ARGB)FadeArgb(T->edgeLight, openE)), 1.0f);
                g.DrawPath(&e, &p);
                DrawTextAt(&g, L"取消", 12.0f * s, bx1, by, bw, bh,
                           FadeArgb(T->textMain, openE), FALSE, StringAlignmentCenter);
            }
            // 左侧提示
            {
                wchar_t hint[160];
                const int keyCount = (g_groupCount > 0 && g_activeGroup >= 0 &&
                                      g_activeGroup < g_groupCount)
                                         ? g_groups[g_activeGroup].keyCount : 0;
                _snwprintf_s(hint, 160, _TRUNCATE,
                             L"%d 项 · 悬停看说明 · 滚轮下拉 · 保存写入 echoes.txt", keyCount);
                DrawTextAt(&g, hint, 10.5f * s, px + (float)g_L.pad, by,
                           bx1 - px - (float)g_L.pad - 8.0f * s, bh,
                           FadeArgb(T->textFaint, openE), FALSE, StringAlignmentNear);
            }
        }


        // ---- 悬停说明（tooltip，取键行上方的注释） ----
        if (g_tooltipLine >= 0 && g_tooltipLine < g_lineCount && g_mouseX > 0) {
            // 找该键行上方最近的注释行
            const wchar_t* tip = NULL;
            for (int i = g_tooltipLine - 1; i >= 0; --i) {
                if (g_lines[i].kind == LINE_KEY) {
                    break;
                }
                if (g_lines[i].kind == LINE_COMMENT && g_lines[i].text[0] == L'#') {
                    const wchar_t* t = g_lines[i].text;
                    while (*t == L'#' || *t == L' ') {
                        ++t;
                    }
                    if (*t != 0) {
                        tip = t;
                        break;
                    }
                }
            }
            if (tip != NULL) {
                const wchar_t* famName = kFontUI;
                {
                    FontFamily probe(kFontUI);
                    if (!probe.IsAvailable()) {
                        famName = kFontFallback;
                    }
                }
                FontFamily family(famName);
                Gdiplus::Font tf(&family, 11.0f * s, FontStyleRegular, UnitPixel);
                RectF bounds;
                g.MeasureString(tip, -1, &tf, PointF(0, 0), &bounds);
                const float tw = bounds.Width + 16.0f * s;
                const float th2 = 26.0f * s;
                float txx = (float)g_mouseX + 14.0f * s;
                float tyy = (float)g_mouseY + 16.0f * s;
                if (txx + tw > (float)(g_L.panelX + g_L.panelW - 8)) {
                    txx = (float)(g_L.panelX + g_L.panelW - 8) - tw;
                }
                if (tyy + th2 > (float)(g_L.panelY + g_L.panelH - 8)) {
                    tyy = (float)g_mouseY - th2 - 10.0f * s;
                }
                GraphicsPath tp;
                AddRoundedRect(&tp, txx, tyy, tw, th2, 9.0f * s);
                SolidBrush tb(Color((ARGB)FadeArgb(T->floatLayer, openE)));
                g.FillPath(&tb, &tp);
                Pen te2(Color((ARGB)FadeArgb(T->edgeLight, openE)), 1.0f);
                g.DrawPath(&te2, &tp);
                SolidBrush tbr(Color((ARGB)FadeArgb(T->textMain, openE)));
                StringFormat tf2;
                tf2.SetAlignment(StringAlignmentCenter);
                tf2.SetLineAlignment(StringAlignmentCenter);
                tf2.SetTrimming(StringTrimmingEllipsisCharacter);
                tf2.SetFormatFlags(StringFormatFlagsNoWrap);
                g.DrawString(tip, -1, &tf, RectF(txx, tyy, tw, th2), &tf2, &tbr);
            }
        }
    }

    if (ownDc) {
        ReleaseDC(g_hwnd, dc);
    }
    g_lastDrawTick = now;
    g_lastAnimTick = now;   // 供下一帧算 dt（胶囊开关弹入用）
}

// ============================================================================
// 七·五、GL overlay 呈现层（DWM flip model 下 GDI 不可见 ⇒ 必须用 GL 贴图）
// ============================================================================
// 换帧 hook：复用项目里**已验证**的原子 hook 实现（guard.dll 的「摧毁渲染」同款）
// 它完整处理了：转发桩解包 / near relay / 8 字节原子写 / MinHook trampoline（含 RIP 重定位）。
// 自写版本在游戏里踩过坑：opengl32!wglSwapBuffers 是转发桩，rel32 算错 ⇒ 执行垃圾地址。
#include "echo_minhook.h"

#include "echo_config_ui_gl.inc"

// ============================================================================
// 八、输入
// ============================================================================
static BOOL HitRect(int px, int py, int x, int y, int w, int h) {
    return px >= x && py >= y && px < x + w && py < y + h;
}

static int HitTest(int mx, int my) {
    g_hoverRow = -1;
    g_hoverNav = -1;
    g_hoverSave = FALSE;
    g_hoverCancel = FALSE;
    g_hoverClose = FALSE;
    g_hoverTheme = FALSE;
    g_tooltipLine = -1;

    const float s = g_L.uiScale;
    const float px = (float)g_L.panelX;
    const float py = (float)g_L.panelY;
    const float pw = (float)g_L.panelW;

    // 面板外
    if (!HitRect(mx, my, g_L.panelX, g_L.panelY, g_L.panelW, g_L.panelH)) {
        return -1;
    }

    // 关闭圆钮
    const float btnR = 14.0f * s;
    const float cx = px + pw - (float)g_L.pad - btnR;
    const float cy = py + (float)g_L.titleH * 0.5f;
    const float ddx = (float)mx - cx;
    const float ddy = (float)my - cy;
    if (ddx * ddx + ddy * ddy <= btnR * btnR) {
        g_hoverClose = TRUE;
        return -1;
    }
    // 主题胶囊
    {
        const float tw = 54.0f * s, thh = 20.0f * s;
        const float tx2 = cx - btnR - 8.0f * s - tw;
        const float ty2 = cy - thh * 0.5f;
        if (HitRect(mx, my, (int)tx2, (int)ty2, (int)tw, (int)thh)) {
            g_hoverTheme = TRUE;
            return -1;
        }
    }
    // 底部按钮
    {
        const float by = py + (float)g_L.panelH - (float)g_L.footerH + 10.0f * s;
        const float bh = 30.0f * s;
        const float bw = 96.0f * s;
        const float bx2 = px + pw - (float)g_L.pad - bw;
        const float bx1 = bx2 - bw - 10.0f * s;
        if (HitRect(mx, my, (int)bx2, (int)by, (int)bw, (int)bh)) {
            g_hoverSave = TRUE;
            return -1;
        }
        if (HitRect(mx, my, (int)bx1, (int)by, (int)bw, (int)bh)) {
            g_hoverCancel = TRUE;
            return -1;
        }
    }
    // 左侧导航
    {
        const float navRowH = 26.0f * s;
        const float gap = 2.0f * s;
        for (int i = 0; i <= g_groupCount; ++i) {   // 含「外观」页
            const float ny = (float)g_L.navY + (float)i * (navRowH + gap);
            if (ny + navRowH > (float)(g_L.navY + g_L.navH)) {
                break;
            }
            if (HitRect(mx, my, g_L.navX, (int)ny, g_L.navW, (int)navRowH)) {
                g_hoverNav = i;
                return -1;
            }
        }
    }
    // 行列表
    if (HitRect(mx, my, g_L.listX, g_L.listY, g_L.listW, g_L.listH)) {
        int rows[ECHO_MAX_LINES];
        const int rowCount = CollectRows(g_activeGroup, rows, ECHO_MAX_LINES);
        for (int r = 0; r < rowCount; ++r) {
            const float ry = (float)g_L.listY + (float)(r * g_L.rowH) - g_scrollCur;
            if ((float)my >= ry && (float)my < ry + (float)g_L.rowH) {
                g_hoverRow = rows[r];
                g_tooltipLine = rows[r];
                return rows[r];
            }
        }
    }
    return -1;
}

static LRESULT CALLBACK EchoWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (g_open) {
        switch (msg) {
        case WM_MOUSEMOVE: {
            const int mx = GET_X_LPARAM(lParam);
            const int my = GET_Y_LPARAM(lParam);
            g_mouseX = mx;
            g_mouseY = my;
            if (g_dragging) {
                int rows[ECHO_MAX_LINES];
                const int rowCount = CollectRows(g_activeGroup, rows, ECHO_MAX_LINES);
                const float maxScroll = MaxScroll(rowCount);
                if (maxScroll > 0.5f) {
                    g_scrollTarget = Clampf(g_dragStartScroll -
                                            (float)(my - g_dragStartY) * 2.4f, 0.0f, maxScroll);
                }
                return 0;
            }
            HitTest(mx, my);
            return 0;
        }
        case WM_MOUSELEAVE:
            g_mouseX = -1;
            g_mouseY = -1;
            g_hoverRow = -1;
            g_tooltipLine = -1;
            return 0;
        case WM_LBUTTONDOWN: {
            const int mx = GET_X_LPARAM(lParam);
            const int my = GET_Y_LPARAM(lParam);
            const int hit = HitTest(mx, my);

            if (g_hoverClose || g_hoverCancel) {
                EchoHide();
                return 0;
            }
            if (g_hoverTheme) {
                g_themeDarkSel = !g_themeDarkSel;
                SaveUiConfig();
                return 0;
            }
            if (g_hoverSave) {
                if (g_dirty) {
                    CfgSave();
                }
                EchoHide();
                return 0;
            }
            // 「外观」页：滑条 / 调色板 / 明暗（页面内其他点击一律吞掉）
            if (g_activeGroup >= g_groupCount) {
                const int av = HitTestAppearance(mx, my);
                if (av >= 0 && av <= 3) {
                    g_dragSlider = av;
                    UpdateSlider(av, mx);
                    return 0;
                }
                if (av >= 4 && av <= 11) {
                    g_themeSeed = kSwatches[av - 4];   // 换色：整套品牌色立即重算
                    SaveUiConfig();
                    return 0;
                }
                if (av == 12) {
                    g_themeDarkSel = !g_themeDarkSel;
                    SaveUiConfig();
                }
                return 0;
            }
            if (g_hoverNav >= 0) {
                if (g_activeGroup != g_hoverNav) {
                    g_activeGroup = g_hoverNav;
                    g_pageStamp = GetTickCount64();   // 切页 ⇒ 列表行重新依次弹入
                }
                g_scrollTarget = 0.0f;
                g_scrollCur = 0.0f;
                return 0;
            }
            if (hit >= 0) {
                const EchoCfgLine* L = &g_lines[hit];
                if (L->booleanLike) {
                    const BOOL nv = !CfgBoolValue(hit);
                    CfgSetValue(hit, nv ? L"true" : L"false");
                    g_toggleFrom[hit] = g_toggleAnim[hit];
                    g_toggleT[hit] = 0.0f;
                    g_toggleTarget[hit] = nv ? 1.0f : 0.0f;
                }
                return 0;
            }
            // 面板外点击 ⇒ 取消并关闭
            EchoHide();
            return 0;
        }
        case WM_LBUTTONUP:
            g_dragging = FALSE;
            return 0;
        case WM_MOUSEWHEEL: {
            const int delta = GET_WHEEL_DELTA_WPARAM(wParam) / WHEEL_DELTA;
            int rows[ECHO_MAX_LINES];
            const int rowCount = CollectRows(g_activeGroup, rows, ECHO_MAX_LINES);
            const float maxScroll = MaxScroll(rowCount);
            g_scrollTarget = Clampf(g_scrollTarget -
                                    (float)delta * (float)g_L.rowH * 1.2f, 0.0f, maxScroll);
            return 0;
        }
        case WM_SETCURSOR:
            // 界面打开期间强制箭头光标（游戏内光标被 GLFW 隐藏时也能看见指针）
            if (LOWORD(lParam) == HTCLIENT) {
                SetCursor(LoadCursorW(NULL, (LPCWSTR)IDC_ARROW));
                return TRUE;
            }
            break;
        case WM_KEYDOWN:
            if (wParam == VK_ESCAPE) {
                EchoHide();
                return 0;
            }
            break;
        // 【不做定时器兜底 · 血证】曾用 16ms SetTimer 兜底"游戏不渲染时也刷新"，
        // 结果与 SwapBuffers 路径交替绘制：定时器那一拍读到的是"我们自己上一次画好的
        // 界面"，再被 BlurRegion 模糊一遍 ⇒ 实测整屏「模糊/清晰」高频频闪。
        // 结论：绘制只留换帧这一条路径（游戏暂停菜单仍在渲染，SwapBuffers 照常每帧调用）。
        default:
            break;
        }
    }
    return CallWindowProcW(g_oldWndProc, hwnd, msg, wParam, lParam);
}

// ============================================================================
// 九、换帧 hook（opengl32!wglSwapBuffers）
// ----------------------------------------------------------------------------
// 【血证 · 为什么不能用自写 trampoline】首版只做「拷走前 N 字节 + E9 回跳」，
//   实测进游戏第一次换帧就 EXCEPTION_ACCESS_VIOLATION at gdi32full.dll+0x5e4d7
//   （栈顶 org.lwjgl.system.JNI::invokePV ⇒ 就是被 hook 的 wglSwapBuffers 本体）。
//   原因：真实实现入口里有 RIP-relative 指令（mov rax,[rip+disp] / lea / jmp [rip]），
//   指令被搬到新地址后相对位移全部错位 ⇒ 一跳就崩。
//
// 【为什么也不用 MH_EnableHook】echo_minhook.h 里的血证：MH_EnableHook 内部会
//   Freeze() ⇒ 枚举全进程线程 SuspendThread + SetThreadContext 改写 RIP ⇒
//   落补丁瞬间把 JVM 线程 RIP 改到不一致状态 ⇒ 确定性崩溃（LdrLoadDll+0x64）。
//
// 【最终方案】取 MinHook 的能力、不用它的落补丁：
//   ① MH_CreateHook(target, detour, &tramp) —— 只计算 trampoline 并保存原字节，
//      **不改写目标**（MinHook 的 trampoline.c 会做 RIP 重定位，这是自写做不到的）；
//   ② 自己分配 relay（FF 25 00000000 + 绝对 detour）；
//   ③ 目标入口 8 字节用 InterlockedExchange64 一次性原子写入
//      「E9 <rel32→relay>」+ 目标原有字节[5..7]（保留尾部，绝不越界写成 CC）；
//   ④ 完全不 SuspendThread / 完全不 SetThreadContext。
// ============================================================================
typedef BOOL(WINAPI* wglSwapBuffers_t)(HDC);
static wglSwapBuffers_t g_origWglSwap = NULL;
static volatile LONG     g_frameBusy = 0;
static bool              g_mhInit = false;
static EchoMinHook       g_echoMh = {};   // 复用 guard 同款原子 hook（POD）
/** 绘制包装：用 SEH 兜住 DrawFrame（函数体内无 C++ 对象 ⇒ 允许 __try），
 *  任何异常都不许传出 detour。 */
static void SafeDrawFrame(void) {
    __try {
        DrawUiFrame(NULL);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        DiagWriteLine(L"[safe-draw] DrawUiFrame raised SEH, swallowed (fail-open)");
    }
}

static BOOL WINAPI HookWglSwapBuffers(HDC hdc) {
    // ===== 关键：在 swap **之前**把界面画进后缓冲 =====
    // 原因：游戏窗口在 DWM flip model 下，GDI 对窗口 DC 的写入不会显示
    //（宿主能看到是因为宿主窗口是普通 GL 窗口）。只有把界面画进 GL 后缓冲、
    // 与游戏画面**同帧同次交换**上屏，才既可见又不闪。
    if (g_open && InterlockedCompareExchange(&g_frameBusy, 1, 0) == 0) {
        BOOL drawn = FALSE;
        __try {
            drawn = GlOverlayPresent(hdc);
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            DiagWriteLine(L"[gl] GlOverlayPresent raised SEH (swallowed)");
            drawn = FALSE;
        }
        if (!drawn) {
            // GL 路径不可用 ⇒ 退回 GDI 直画（普通窗口可见；flip model 下不可见，但至少不崩）
            __try {
                DrawUiFrame(NULL);
            } __except (EXCEPTION_EXECUTE_HANDLER) {
                DiagWriteLine(L"[safe-draw] DrawUiFrame raised SEH, swallowed");
            }
        }
        InterlockedExchange(&g_frameBusy, 0);
    }

    BOOL r = TRUE;
    if (g_origWglSwap != NULL) {
        __try {
            r = g_origWglSwap(hdc);
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            DiagWriteLine(L"[safe-swap] original wglSwapBuffers raised SEH (trampoline suspect)");
            r = TRUE;
        }
    }
    g_lastSwapTick = GetTickCount64();
    return r;
}

static BOOL InstallSwapHook(void) {
    if (g_hooked) {
        return TRUE;
    }
    // 复用已验证的原子 hook：转发桩解包 / near relay / 8 字节原子写 全在它内部
    if (!EchoMinHookLoad(&g_echoMh, (const void*)InstallSwapHook)) {
        DiagWriteLine(L"[hook] EchoMinHookLoad failed (MinHook.x64.dll missing beside DLL?)");
        return FALSE;
    }
    void* orig = NULL;
    if (!EchoMinHookInstall(&g_echoMh, L"opengl32.dll", "wglSwapBuffers",
                            (LPVOID)HookWglSwapBuffers, &orig)) {
        DiagWriteLine(L"[hook] EchoMinHookInstall failed (fail-open, no hook)");
        return FALSE;
    }
    g_origWglSwap = (wglSwapBuffers_t)orig;
    g_hooked = TRUE;
    DiagWriteLine(L"[hook] installed via EchoMinHook (verified atomic path)");
    return TRUE;
}

// ============================================================================
// 十、生命周期 / 导出 / JNI
// ============================================================================
static HWND FindGameWindow(void) {
    struct Ctx {
        DWORD pid;
        HWND best;
        LONG bestArea;
    } ctx = {};
    ctx.pid = GetCurrentProcessId();
    EnumWindows([](HWND h, LPARAM lp) -> BOOL {
        Ctx* c = (Ctx*)lp;
        DWORD pid = 0;
        GetWindowThreadProcessId(h, &pid);
        if (pid != c->pid || !IsWindowVisible(h)) {
            return TRUE;
        }
        RECT rc = {};
        if (!GetClientRect(h, &rc)) {
            return TRUE;
        }
        const LONG area = (rc.right - rc.left) * (rc.bottom - rc.top);
        if (area > c->bestArea) {
            c->bestArea = area;
            c->best = h;
        }
        return TRUE;
    }, (LPARAM)&ctx);
    return ctx.best;
}

static BOOL EnsureGdiplus(void) {
    if (g_gdiplusReady) {
        return TRUE;
    }
    GdiplusStartupInput input;
    input.GdiplusVersion = 1;
    input.DebugEventCallback = NULL;
    input.SuppressBackgroundThread = FALSE;
    input.SuppressExternalCodecs = FALSE;
    if (GdiplusStartup(&g_gdiplusToken, &input, NULL) != Status::Ok) {
        return FALSE;
    }
    g_gdiplusReady = TRUE;
    return TRUE;
}

static void EchoHide(void) {
    AcquireSRWLockExclusive(&g_lock);
    const BOOL wasOpen = g_open;
    g_open = FALSE;

    if (g_subclassed && g_hwnd != NULL && g_oldWndProc != NULL) {
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)g_oldWndProc);
        g_subclassed = FALSE;
        g_oldWndProc = NULL;
    }
    ReleaseBlurCache();   // 关闭即释放（下次打开重新抓干净背景）
    ReleaseSRWLockExclusive(&g_lock);
    if (wasOpen && g_hwnd != NULL && IsWindow(g_hwnd)) {
        InvalidateRect(g_hwnd, NULL, FALSE);
    }
}

static void DiagStep(int step, const wchar_t* tag) {
    wchar_t line[512];
    _snwprintf_s(line, 512, _TRUNCATE,
                 L"[show] step=%d %ls (open=%d hooked=%d lines=%d groups=%d)",
                 step, tag, g_open ? 1 : 0, g_hooked ? 1 : 0, g_lineCount, g_groupCount);
    DiagWriteLine(line);
}

extern "C" __declspec(dllexport) int EchoConfigUi_ShowA(const char* configPathUtf8) {
    if (configPathUtf8 == NULL) {
        return 0;
    }
    DiagStep(0, L"enter");
    EnsureVeh();   // 诊断：把 SEH 位置落到 %TEMP%\echo_config_ui_diag.txt
    DiagStep(1, L"veh-ok");
    if (!EnsureGdiplus()) {
        DiagWriteLine(L"[show] GdiplusStartup failed");
        return 0;
    }
    DiagStep(2, L"gdiplus-ok");
    AcquireSRWLockExclusive(&g_lock);
    DiagStep(3, L"lock");
    Utf8ToWide(configPathUtf8, (int)strlen(configPathUtf8), g_configPath, MAX_PATH);
    DiagStep(4, L"path");
    if (g_hwnd == NULL || !IsWindow(g_hwnd)) {
        g_hwnd = FindGameWindow();
    }
    DiagStep(5, L"window");
    if (g_hwnd == NULL) {
        ReleaseSRWLockExclusive(&g_lock);
        return 0;
    }
    // 【不再 hook wglSwapBuffers】改由 Forge 的 RenderGuiEvent.Post 驱动 Present：
    //   · 时机就在 swap 之前、GL 上下文 current（与游戏画面同帧上屏 ⇒ 不闪）；
    //   · 不碰任何系统函数 ⇒ 没有转发桩 / rel32 截断 / trampoline 那些坑
    //     （本机实测：hook 在游戏里失败，自写版本还崩过两次）。
    // hook 代码保留（InstallSwapHook）但默认不启用，仅作诊断/回退。
    DiagStep(6, L"no-hook (event-driven)");
    CfgLoad(g_configPath);
    LoadUiConfig();
    DiagStep(7, L"cfgload");
    g_openStamp = GetTickCount64();
    g_openT = 0.0f;
    g_scrollCur = 0.0f;
    g_scrollTarget = 0.0f;
    g_activeGroup = 0;
    g_hoverRow = -1;
    g_hoverNav = -1;
    g_tooltipLine = -1;
    g_dirty = FALSE;
    ReleaseBlurCache();   // 每次打开都重新抓一份干净背景


    RECT rc = {};
    if (GetClientRect(g_hwnd, &rc)) {
        ComputeLayout(rc.right - rc.left, rc.bottom - rc.top);
    }
    if (!g_subclassed) {
        g_oldWndProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)EchoWndProc);
        if (g_oldWndProc != NULL) {
            g_subclassed = TRUE;
        }
    }
    g_open = TRUE;

    ReleaseSRWLockExclusive(&g_lock);
    return 1;
}

extern "C" __declspec(dllexport) void EchoConfigUi_Hide(void) {
    EchoHide();
}

extern "C" __declspec(dllexport) int EchoConfigUi_ToggleA(const char* configPathUtf8) {
    if (g_open) {
        EchoHide();
        return 0;
    }
    return EchoConfigUi_ShowA(configPathUtf8);
}

extern "C" __declspec(dllexport) int EchoConfigUi_IsOpen(void) {
    return g_open ? 1 : 0;
}

/**
 * 由宿主每帧调用（Forge 的 RenderGuiEvent.Post）：把界面贴到当前后缓冲。
 *
 * <p>为什么走宿主事件而不是 hook：事件发生在 swap 之前、GL 上下文 current，
 * 与游戏画面同帧上屏 ⇒ 不闪；且完全不碰系统函数 ⇒ 无转发桩/rel32/trampoline 风险。</p>
 *
 * @return 1=已绘制，0=未打开或 GL 不可用
 */
extern "C" __declspec(dllexport) int EchoConfigUi_Present(void) {
    if (!g_open || g_hwnd == NULL || !IsWindow(g_hwnd)) {
        return 0;
    }
    HDC dc = GetDC(g_hwnd);
    if (dc == NULL) {
        return 0;
    }
    int ok = 0;
    __try {
        ok = GlOverlayPresent(dc) ? 1 : 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        DiagWriteLine(L"[gl] Present raised SEH (swallowed)");
        ok = 0;
    }
    ReleaseDC(g_hwnd, dc);
    return ok;
}

extern "C" __declspec(dllexport) int EchoConfigUi_Status(void) {
    return (g_hooked ? 1 : 0) | (g_open ? 2 : 0) | (g_gdiplusReady ? 4 : 0)
         | (g_subclassed ? 8 : 0) | (g_lineCount > 0 ? 16 : 0)
         | ((g_groupCount > 0 ? 1 : 0) << 5);
}

extern "C" {

JNIEXPORT jint JNICALL Java_com_echoxy_client_EchoConfigUi_show0
    (JNIEnv* env, jclass cls, jstring path) {
    (void)cls;
    if (path == NULL) {
        return 0;
    }
    const char* utf8 = env->GetStringUTFChars(path, NULL);
    if (utf8 == NULL) {
        return 0;
    }
    const int r = EchoConfigUi_ShowA(utf8);
    env->ReleaseStringUTFChars(path, utf8);
    return r;
}

JNIEXPORT void JNICALL Java_com_echoxy_client_EchoConfigUi_hide0
    (JNIEnv* env, jclass cls) {
    (void)env;
    (void)cls;
    EchoConfigUi_Hide();
}

JNIEXPORT jint JNICALL Java_com_echoxy_client_EchoConfigUi_isOpen0
    (JNIEnv* env, jclass cls) {
    (void)env;
    (void)cls;
    return EchoConfigUi_IsOpen();
}

JNIEXPORT jint JNICALL Java_com_echoxy_client_EchoConfigUi_status0
    (JNIEnv* env, jclass cls) {
    (void)env;
    (void)cls;
    return EchoConfigUi_Status();
}

JNIEXPORT jint JNICALL Java_com_echoxy_client_EchoConfigUi_present0
    (JNIEnv* env, jclass cls) {
    (void)env;
    (void)cls;
    return EchoConfigUi_Present();
}

} // extern "C"

// ============================================================================
// 十一、DllMain
// ============================================================================
BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
    }
    return TRUE;
}
