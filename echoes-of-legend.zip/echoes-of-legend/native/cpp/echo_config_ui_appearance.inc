// ============================================================================
// echo_config_ui_appearance.inc —— 外观设置「分页」+ 主题换色
// ----------------------------------------------------------------------------
// 被 echo_config_ui.cpp 直接 include（在 DrawUiFrame 之前）。
// 依赖 cpp 里的：g_L / AddRoundedRect / DrawTextAt / FadeArgb / Argb / Clampf /
//   HslToArgb / DiagWriteLine / g_themeDarkSel / g_configPath。
//
// 【设计】外观不再是浮层，而是左侧导航栏里的**最后一页**（索引 = g_groupCount）：
//   · 右侧列表区直接画 4 条滑条 + 一行调色板 + 明暗胶囊；
//   · 调色板仿琉璃玻璃库的「壁纸取色」：一条源色派生整套品牌色；
//   · 全部持久化到 <gameDir>/echoes-native/config_ui.txt。
// ============================================================================

// ---- 外观状态 ----
static DWORD g_themeSeed = 0xFF4DA3F0;   // 主题源色（换色只改这一个值）
static float g_optBlur = 1.0f;           // 模糊强度 0..1
static float g_optOpacity = 1.0f;        // 玻璃不透明度 0.3..1
static float g_optGlow = 1.0f;           // 品牌泛光
static float g_optShadow = 1.0f;         // 投影

static int   g_dragSlider = -1;          // 正在拖动的滑条 0..3
static int   g_hoverSlider = -1;         // 悬停的滑条
static int   g_hoverSwatch = -1;         // 悬停的色板格

// 控件几何（绘制时写入，命中测试用）
static int   g_sliderX[4] = { 0, 0, 0, 0 };
static int   g_sliderY[4] = { 0, 0, 0, 0 };
static int   g_sliderW[4] = { 0, 0, 0, 0 };
static int   g_swatchX[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
static int   g_swatchY[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
static int   g_swatchS = 0;
static int   g_themeToggleX = 0, g_themeToggleY = 0, g_themeToggleW = 0, g_themeToggleH = 0;

static const wchar_t* kSliderLabels[4] = {
    L"模糊", L"不透明度", L"泛光", L"阴影"
};

// 调色板（点一下即整套换色）
static const DWORD kSwatches[8] = {
    0xFF4DA3F0,  // 蓝（默认）
    0xFF3FD8C8,  // 青
    0xFF52D96B,  // 绿
    0xFFB6D94A,  // 青柠
    0xFFFF9F45,  // 橙
    0xFFFF6B6B,  // 红
    0xFFF06292,  // 粉
    0xFFA78BFA   // 紫
};

/** RGB → HSL（0..1）。 */
static void RgbToHsl(DWORD c, float* h, float* s, float* l) {
    const float r = (float)((c >> 16) & 0xFF) / 255.0f;
    const float g = (float)((c >> 8) & 0xFF) / 255.0f;
    const float b = (float)(c & 0xFF) / 255.0f;
    const float mx = (r > g) ? ((r > b) ? r : b) : ((g > b) ? g : b);
    const float mn = (r < g) ? ((r < b) ? r : b) : ((g < b) ? g : b);
    *l = (mx + mn) * 0.5f;
    if (mx <= mn + 0.0001f) {
        *h = 0.0f;
        *s = 0.0f;
        return;
    }
    const float d = mx - mn;
    *s = (*l > 0.5f) ? (d / (2.0f - mx - mn)) : (d / (mx + mn));
    if (mx == r) {
        *h = fmodf((g - b) / d + (g < b ? 6.0f : 0.0f), 6.0f) / 6.0f;
    } else if (mx == g) {
        *h = ((b - r) / d + 2.0f) / 6.0f;
    } else {
        *h = ((r - g) / d + 4.0f) / 6.0f;
    }
}

/**
 * 由源色派生整套主题（仿琉璃玻璃库的壁纸取色：一条源色带动全部品牌色）。
 * 只覆盖「品牌相关」字段；玻璃/文字保持原明暗基色，避免对比度崩掉。
 */
static void BuildThemeOverrides(DWORD seed, BOOL dark, EchoUiTheme* t) {
    float h = 0.0f, s = 0.0f, l = 0.5f;
    RgbToHsl(seed, &h, &s, &l);
    const float sat = Clampf(s, 0.45f, 0.95f);
    // 暗色主题把品牌色提亮（深底上要跳出来），亮色主题压深一点
    const float brandL = dark ? 0.62f : 0.46f;
    const DWORD brand = HslToArgb(h, sat, brandL);
    const int r = (int)((brand >> 16) & 0xFF);
    const int g = (int)((brand >> 8) & 0xFF);
    const int b = (int)(brand & 0xFF);

    t->pillOn = brand;
    t->brand = brand;
    t->brandGlow = Argb(0x55, r, g, b);
    t->navActive = Argb(0x33, r, g, b);
    t->navHover = dark ? 0x1AFFFFFF : 0x14000000;
    t->rowHover = dark ? 0x14FFFFFF : 0x0F000000;
}

/** 当前生效主题（seed / 明暗变化时重算，否则用缓存）。 */
static const EchoUiTheme* CurrentTheme(void) {
    static EchoUiTheme cache = {};
    static BOOL built = FALSE;
    static DWORD lastSeed = 0;
    static BOOL lastDark = FALSE;
    if (!built || lastSeed != g_themeSeed || lastDark != g_themeDarkSel) {
        cache = g_themeDarkSel ? kDark : kLight;
        BuildThemeOverrides(g_themeSeed, g_themeDarkSel, &cache);
        built = TRUE;
        lastSeed = g_themeSeed;
        lastDark = g_themeDarkSel;
    }
    return &cache;
}

/** 外观配置文件路径：<gameDir>\echoes-native\config_ui.txt。 */
static void UiConfigPath(wchar_t* out, int cap) {
    out[0] = 0;
    if (g_configPath[0] == 0) {
        return;
    }
    wchar_t tmp[MAX_PATH];
    wcsncpy_s(tmp, MAX_PATH, g_configPath, _TRUNCATE);
    wchar_t* p1 = wcsrchr(tmp, L'\\');
    if (p1 == NULL) {
        return;
    }
    *p1 = 0;
    wchar_t* p2 = wcsrchr(tmp, L'\\');
    if (p2 == NULL) {
        return;
    }
    *p2 = 0;
    _snwprintf_s(out, (size_t)cap, _TRUNCATE, L"%s\\echoes-native\\config_ui.txt", tmp);
}

static void SaveUiConfig(void) {
    wchar_t p[MAX_PATH];
    UiConfigPath(p, MAX_PATH);
    if (p[0] == 0) {
        return;
    }
    wchar_t dir[MAX_PATH];
    wcsncpy_s(dir, MAX_PATH, p, _TRUNCATE);
    wchar_t* slash = wcsrchr(dir, L'\\');
    if (slash != NULL) {
        *slash = 0;
        CreateDirectoryW(dir, NULL);
    }
    FILE* f = NULL;
    if (_wfopen_s(&f, p, L"wb") != 0 || f == NULL) {
        return;
    }
    fprintf(f, "blur=%.3f\ropacity=%.3f\roglow=%.3f\rshadow=%.3f\rdark=%d\rseed=%lu\r",
            g_optBlur, g_optOpacity, g_optGlow, g_optShadow, g_themeDarkSel ? 1 : 0,
            (unsigned long)g_themeSeed);
    fclose(f);
}

static void LoadUiConfig(void) {
    wchar_t p[MAX_PATH];
    UiConfigPath(p, MAX_PATH);
    if (p[0] == 0) {
        return;
    }
    FILE* f = NULL;
    if (_wfopen_s(&f, p, L"rb") != 0 || f == NULL) {
        return;
    }
    char line[256];
    while (fgets(line, sizeof(line), f) != NULL) {
        float v = 0.0f;
        unsigned long u = 0;
        if (sscanf_s(line, "blur=%f", &v) == 1) {
            g_optBlur = Clampf(v, 0.0f, 1.0f);
        } else if (sscanf_s(line, "opacity=%f", &v) == 1) {
            g_optOpacity = Clampf(v, 0.3f, 1.0f);
        } else if (sscanf_s(line, "glow=%f", &v) == 1) {
            g_optGlow = Clampf(v, 0.0f, 1.0f);
        } else if (sscanf_s(line, "shadow=%f", &v) == 1) {
            g_optShadow = Clampf(v, 0.0f, 1.0f);
        } else if (sscanf_s(line, "dark=%f", &v) == 1) {
            g_themeDarkSel = (v != 0.0f) ? TRUE : FALSE;
        } else if (sscanf_s(line, "seed=%lu", &u) == 1) {
            g_themeSeed = (DWORD)u;
        }
    }
    fclose(f);
}

/** 该滑条当前值指针。 */
static float* SliderValue(int idx) {
    switch (idx) {
    case 0:  return &g_optBlur;
    case 1:  return &g_optOpacity;
    case 2:  return &g_optGlow;
    case 3:  return &g_optShadow;
    default: return NULL;
    }
}

/** 拖动/点击时按 x 更新滑条。 */
static void UpdateSlider(int idx, int mx) {
    if (idx < 0 || idx > 3 || g_sliderW[idx] <= 0) {
        return;
    }
    float v = (float)(mx - g_sliderX[idx]) / (float)g_sliderW[idx];
    v = Clampf(v, 0.0f, 1.0f);
    switch (idx) {
    case 0:  g_optBlur = v; break;
    case 1:  g_optOpacity = 0.3f + 0.7f * v; break;   // 下限 0.3（太透看不清字）
    case 2:  g_optGlow = v; break;
    case 3:  g_optShadow = v; break;
    default: break;
    }
}

/**
 * 绘制「外观」分页内容（画在**右侧列表区**，不是浮层）。
 * 布局：标题 → 4 条滑条 → 调色板 → 明暗胶囊。
 */
static void DrawAppearancePage(Graphics* g, const EchoUiTheme* T, float s, float openE) {
    const int lx = g_L.listX;
    const int ly = g_L.listY;
    const int lw = g_L.listW;
    const int rowH = (int)(46.0f * s);

    DrawTextAt(g, L"外观设置", 13.0f * s, (float)lx, (float)ly, (float)lw, 26.0f * s,
               FadeArgb(T->textMain, openE), TRUE, StringAlignmentNear);
    DrawTextAt(g, L"拖动即时生效 · 自动保存", 10.0f * s, (float)lx,
               (float)ly + 26.0f * s, (float)lw, 18.0f * s,
               FadeArgb(T->textFaint, openE), FALSE, StringAlignmentNear);

    const int baseY = ly + (int)(58.0f * s);

    // ---- 4 条滑条 ----
    for (int i = 0; i < 4; ++i) {
        const int ry = baseY + i * rowH;
        DrawTextAt(g, kSliderLabels[i], 11.5f * s, (float)lx, (float)ry,
                   (float)(int)(88.0f * s), (float)rowH * 0.55f,
                   FadeArgb(T->textSub, openE), FALSE, StringAlignmentNear);

        const int trackX = lx + (int)(98.0f * s);
        const int trackW = lw - (int)(98.0f * s) - (int)(48.0f * s);
        const int trackY = ry + (int)(11.0f * s);
        g_sliderX[i] = trackX;
        g_sliderY[i] = trackY;
        g_sliderW[i] = trackW;

        const float* val = SliderValue(i);
        const float raw = (val != NULL) ? *val : 0.0f;
        // 不透明度是按 0.3..1.0 存的 ⇒ 显示时映射回 0..1
        const float v = (i == 1) ? Clampf((raw - 0.3f) / 0.7f, 0.0f, 1.0f)
                                 : Clampf(raw, 0.0f, 1.0f);

        GraphicsPath tr;
        AddRoundedRect(&tr, (float)trackX, (float)trackY, (float)trackW, 5.0f * s, 2.5f * s);
        SolidBrush tb(Color((ARGB)FadeArgb(0x33FFFFFF, openE)));
        g->FillPath(&tb, &tr);

        const float fillW = (float)trackW * v;
        if (fillW > 1.0f) {
            GraphicsPath fl;
            AddRoundedRect(&fl, (float)trackX, (float)trackY, fillW, 5.0f * s, 2.5f * s);
            SolidBrush fb(Color((ARGB)FadeArgb(T->pillOn, openE)));
            g->FillPath(&fb, &fl);
        }
        {
            const float kx = (float)trackX + fillW;
            const float kr = 7.0f * s;
            const BOOL hot = (g_dragSlider == i || g_hoverSlider == i);
            SolidBrush kb(Color((ARGB)FadeArgb(T->knob, openE)));
            g->FillEllipse(&kb, kx - kr, (float)trackY + 2.5f * s - kr, kr * 2, kr * 2);
            Pen ke(Color((ARGB)FadeArgb(hot ? T->pillOn : T->edgeLight, openE)),
                   hot ? 1.8f : 1.0f);
            g->DrawEllipse(&ke, kx - kr, (float)trackY + 2.5f * s - kr, kr * 2, kr * 2);
        }
        {
            wchar_t pct[32];
            _snwprintf_s(pct, 32, _TRUNCATE, L"%d%%", (int)(v * 100.0f + 0.5f));
            DrawTextAt(g, pct, 10.5f * s, (float)(trackX + trackW + 10), (float)ry,
                       (float)(int)(38.0f * s), (float)rowH * 0.55f,
                       FadeArgb(T->textFaint, openE), FALSE, StringAlignmentFar);
        }
    }

    // ---- 调色板（换色）----
    {
        const int py = baseY + 4 * rowH + (int)(8.0f * s);
        DrawTextAt(g, L"主题色", 11.5f * s, (float)lx, (float)py,
                   (float)(int)(88.0f * s), 22.0f * s,
                   FadeArgb(T->textSub, openE), FALSE, StringAlignmentNear);

        const int swS = (int)(20.0f * s);
        const int gap = (int)(7.0f * s);
        const int sx0 = lx + (int)(98.0f * s);
        g_swatchS = swS;
        for (int i = 0; i < 8; ++i) {
            const int sx = sx0 + i * (swS + gap);
            if (sx + swS > lx + lw - (int)(6.0f * s)) {
                break;
            }
            g_swatchX[i] = sx;
            g_swatchY[i] = py;
            const DWORD col = kSwatches[i];
            const BOOL sel = (col == g_themeSeed);
            const BOOL hot = (g_hoverSwatch == i);
            SolidBrush sb(Color((ARGB)FadeArgb(col, openE)));
            g->FillEllipse(&sb, (float)sx, (float)py + 1.0f * s, (float)swS, (float)swS);
            if (sel || hot) {
                Pen ring(Color((ARGB)FadeArgb(sel ? T->textMain : T->edgeLight, openE)),
                         sel ? 2.0f : 1.4f);
                g->DrawEllipse(&ring, (float)sx - 1.0f, (float)py + 1.0f * s - 1.0f,
                               (float)(swS + 2), (float)(swS + 2));
            }
        }
    }

    // ---- 明暗切换 ----
    {
        const int ty = baseY + 4 * rowH + (int)(46.0f * s);
        const int tw = (int)(72.0f * s);
        const int th = (int)(24.0f * s);
        g_themeToggleX = lx + (int)(98.0f * s);
        g_themeToggleY = ty;
        g_themeToggleW = tw;
        g_themeToggleH = th;

        GraphicsPath p;
        AddRoundedRect(&p, (float)g_themeToggleX, (float)ty, (float)tw, (float)th,
                       (float)th * 0.5f);
        SolidBrush bg(Color((ARGB)FadeArgb(T->navActive, openE)));
        g->FillPath(&bg, &p);
        Pen e(Color((ARGB)FadeArgb(T->edgeLight, openE)), 1.0f);
        g->DrawPath(&e, &p);
        DrawTextAt(g, g_themeDarkSel ? L"暗色" : L"亮色", 11.0f * s,
                   (float)g_themeToggleX, (float)ty, (float)tw, (float)th,
                   FadeArgb(T->textMain, openE), FALSE, StringAlignmentCenter);
    }
}

/** 外观页命中：0..3=滑条，4..11=色板，12=明暗，-1=无。 */
static int HitTestAppearance(int mx, int my) {
    g_hoverSlider = -1;
    g_hoverSwatch = -1;
    const int padH = (int)(10.0f * g_L.uiScale);
    for (int i = 0; i < 4; ++i) {
        if (g_sliderW[i] <= 0) {
            continue;
        }
        if (mx >= g_sliderX[i] - 10 && mx <= g_sliderX[i] + g_sliderW[i] + 10 &&
            my >= g_sliderY[i] - padH && my <= g_sliderY[i] + padH) {
            g_hoverSlider = i;
            return i;
        }
    }
    if (g_swatchS > 0) {
        for (int i = 0; i < 8; ++i) {
            if (g_swatchX[i] == 0) {
                continue;
            }
            if (mx >= g_swatchX[i] && mx <= g_swatchX[i] + g_swatchS &&
                my >= g_swatchY[i] && my <= g_swatchY[i] + g_swatchS) {
                g_hoverSwatch = i;
                return 4 + i;
            }
        }
    }
    if (g_themeToggleW > 0 && mx >= g_themeToggleX && mx <= g_themeToggleX + g_themeToggleW &&
        my >= g_themeToggleY && my <= g_themeToggleY + g_themeToggleH) {
        return 12;
    }
    return -1;
}
