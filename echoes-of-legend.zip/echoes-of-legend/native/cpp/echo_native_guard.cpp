// ============================================================================
// echo_native_guard.cpp —— 原生层守卫（A1 / A3 / A4 + 原生隐藏最高优先级守护线程）
//
// 学习来源：样板 guard.cpp 对应能力段（按"职责单一、可配置、fail-open"重实现）。
//
// 【A1 原生库注入拦截】hook ntdll!LdrLoadDll + kernel32!LoadLibraryExW：
//   · 路径判据：<gameDir>\mods\ / <gameDir>\natives\ 子树（可配置，默认关，防误伤正常 mod）；
//   · 内容判据：SHA-256 命中"第三方 jar 内嵌原生库"黑名单（零误拦，默认开）；
//   · 我方 DLL 所在目录（echoes-native）与任何不确定路径一律放行（fail-open）。
//
// 【A3 渲染/热路径守卫】
//   · gdi32!SwapBuffers：GDI 防御（可配置阻断：第三方用 GDI 在游戏窗口上画覆盖层）；
//   · opengl32!wglSwapBuffers：只计数（观测，绝不改渲染语义）；
//   · user32!SetWindowsHookExW：只计数（低级钩子观测，默认关）；
//   · ntdll!NtCreateThreadEx：只计数（热路径观测，默认关）。
//
// 【A4 Instrumentation 句柄兜底】JVMTI 堆迭代（tag 法）：JPLIS 持有 InstrumentationImpl
//   的 JNI 全局引用（GC root ⇒ 堆上仍可达）⇒ 即使 Java 层交付路径被篡改，我方仍能捞回
//   真实句柄（mNativeAgent != 0 校验）。只读、命中即停、绝不改写对象。
//
// 【原生隐藏最高优先级守护线程】CreateThread 原生线程（不在 Java Thread 列表 ⇒ 天然隐藏），
//   默认 THREAD_PRIORITY_TIME_CRITICAL（可配 highest/time_critical/realtime），周期 200ms：
//     ① 重断言 JVMTI 锁（跨 DLL 调 echo_jvmti_lockdown!EchoJvmtiRecheck）
//     ② 重装被摘的库加载 hook（幂等）
//     ③ 句柄兜底低频探测
//     ④ 回调 Java 侧自保 tick（线程清理/服务表/禁生成巡检等 Java 逻辑）
//   可选 `hide`：SetThreadDescription 伪装名 + 尽力从调试枚举隐藏（默认关，风险自控）。
//
// 【纪律】/MT、零 C++ 全局对象（POD + SRWLOCK）、SEH 包裹、fail-open 不崩；
//   JNI 导出名 = Java_com_echoxy_agent_EchoNativeGuard_*。
//
// 构建：cl /nologo /utf-8 /O2 /MT /LD /DWIN32 /D_WINDOWS /I%JAVA_HOME%/include
//          /I%JAVA_HOME%/include/win32 echo_native_guard.cpp /link /DLL
// ============================================================================

#include <jni.h>
#include <jvmti.h>
#include <windows.h>
#include <winternl.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <intrin.h>

#include "echo_minhook.h"

static SRWLOCK g_lock = SRWLOCK_INIT;
#define LOCK_BEGIN() AcquireSRWLockExclusive(&g_lock)
#define LOCK_END() ReleaseSRWLockExclusive(&g_lock)
#define GUARD_BEGIN __try {
#define GUARD_END_VOID } __except(EXCEPTION_EXECUTE_HANDLER) { return; }
#define GUARD_END_BOOL } __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
#define GUARD_END_JINT(v) } __except(EXCEPTION_EXECUTE_HANDLER) { return (v); }
#define GUARD_END_INT(v) } __except(EXCEPTION_EXECUTE_HANDLER) { return (v); }
#define GUARD_END_NT(v) } __except(EXCEPTION_EXECUTE_HANDLER) { return (NTSTATUS)(v); }

// ============================================================================
// 全局（POD）
// ============================================================================
static JavaVM* g_vm = nullptr;
static EchoMinHook g_mh = {};

// A1
static volatile bool g_loadBlockOn = true;
static volatile bool g_pathBlockOn = false;
static volatile bool g_hashBlockOn = true;
// `LdrLoadDll` hook 意愿：**默认关**（对齐样板 `g_forceUnload{false}`——只钩
// `LoadLibraryExW`、根本不钩 `LdrLoadDll`）。开它会让判据跑在**所有**装载路径上（含
// 依赖递归、DllMain 内装载），是本工程多次启动故障的源头；确需时由配置显式开启。
static volatile bool g_ldrHookWanted = false;
static wchar_t g_modsPrefix[1024] = { 0 };
static wchar_t g_nativesPrefix[1024] = { 0 };
static wchar_t g_ownDir[1024] = { 0 };
// 可信路径前缀（`buildPrefixes` 一次性解析；GDI 判据热路径只做字符串比较，零 API 调用）
static wchar_t g_gameDir[1024] = { 0 };     // 游戏目录（含 -natives / libraries 子树）
static wchar_t g_javaHome[1024] = { 0 };    // JDK 根（jvm.dll 上两级）
static wchar_t g_sysDir[1024] = { 0 };      // System32 / SysWOW64（显卡驱动也在这）
static wchar_t g_winDir[1024] = { 0 };      // Windows 目录
static char g_hashList[64][65] = { { 0 } };
static volatile long g_hashCount = 0;
static volatile long g_loadCalls = 0;
static volatile long g_loadDenied = 0;
static volatile long g_ldrBadParam = 0;   // LdrLoadDll 参数不自洽（坏 rdx）被可控失败的次数
static volatile long g_hashHits = 0;
static volatile long g_pathHits = 0;

// A3
static volatile int g_gdiMode = 1;   // 0=off 1=glfw_pass（只拦第三方 GDI 绘制） 2=force（全吞=白屏能力）
static volatile bool g_lowLevelHookOn = false;
static volatile bool g_hotApiHookOn = false;
static volatile long g_glSwapCalls = 0;
static volatile long g_gdiSwapCalls = 0;
static volatile long g_gdiSwapBlocked = 0;
static volatile long g_lowHookCalls = 0;
static volatile long g_hotThreadCalls = 0;

// A4
static volatile jobject g_realInstrumentation = nullptr;
static volatile bool g_handleGiveUp = false;
static volatile long g_handleTries = 0;
static volatile long g_handleHits = 0;
static char g_handleDiag[192] = "未尝试";

// 守护线程
static volatile bool g_daemonOn = false;
static volatile bool g_daemonHide = false;
static volatile int  g_daemonPeriodMs = 200;
static volatile int  g_daemonPrio = 2;   // 0=highest 1=time_critical 2=realtime（默认最高档）
static volatile long g_daemonTicks = 0;
static volatile long g_daemonRechecks = 0;
static volatile long g_daemonRehooks = 0;
static volatile long g_daemonTicksJava = 0;
static HANDLE g_daemonThread = nullptr;
static jclass g_tickClass = nullptr;
static jmethodID g_tickMethod = nullptr;

// ============================================================================
// 最小 SHA-256（零分配；detour 内不可阻塞/不可抛）
// ============================================================================
struct Sha256Ctx { unsigned int h[8]; unsigned char buf[64]; size_t len; };
static const unsigned int kSha256K[64] = {
    0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
    0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
    0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
    0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
    0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
    0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
    0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
    0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
};
static unsigned int rotr(unsigned int x, int n) { return (x >> n) | (x << (32 - n)); }
static void sha256Init(Sha256Ctx* s) {
    s->h[0]=0x6a09e667u; s->h[1]=0xbb67ae85u; s->h[2]=0x3c6ef372u; s->h[3]=0xa54ff53au;
    s->h[4]=0x510e527fu; s->h[5]=0x9b05688cu; s->h[6]=0x1f83d9abu; s->h[7]=0x5be0cd19u;
    s->len = 0;
}
static void sha256Block(Sha256Ctx* s, const unsigned char* p) {
    unsigned int w[64];
    for (int i = 0; i < 16; ++i) {
        w[i] = ((unsigned int)p[i*4] << 24) | ((unsigned int)p[i*4+1] << 16)
             | ((unsigned int)p[i*4+2] << 8) | (unsigned int)p[i*4+3];
    }
    for (int i = 16; i < 64; ++i) {
        unsigned int s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >> 3);
        unsigned int s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    unsigned int a=s->h[0],b=s->h[1],c=s->h[2],d=s->h[3],e=s->h[4],f=s->h[5],g=s->h[6],h=s->h[7];
    for (int i = 0; i < 64; ++i) {
        unsigned int S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
        unsigned int ch = (e & f) ^ ((~e) & g);
        unsigned int t1 = h + S1 + ch + kSha256K[i] + w[i];
        unsigned int S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
        unsigned int mj = (a & b) ^ (a & c) ^ (b & c);
        unsigned int t2 = S0 + mj;
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    s->h[0]+=a; s->h[1]+=b; s->h[2]+=c; s->h[3]+=d;
    s->h[4]+=e; s->h[5]+=f; s->h[6]+=g; s->h[7]+=h;
}
static void sha256Update(Sha256Ctx* s, const unsigned char* p, size_t n) {
    size_t i = 0;
    while (i < n) {
        size_t take = 64 - s->len;
        if (take > n - i) take = n - i;
        memcpy(s->buf + s->len, p + i, take);
        s->len += take;
        i += take;
        if (s->len == 64) { sha256Block(s, s->buf); s->len = 0; }
    }
}
static void sha256Final(Sha256Ctx* s, unsigned char out[32]) {
    size_t l = s->len;
    s->buf[l++] = 0x80;
    if (l > 56) { while (l < 64) s->buf[l++] = 0; sha256Block(s, s->buf); l = 0; }
    while (l < 56) s->buf[l++] = 0;
    for (int i = 7; i >= 0; --i) s->buf[56 + i] = (unsigned char)((0ULL >> ((7 - i) * 8)) & 0xFF);
    sha256Block(s, s->buf);
    for (int i = 0; i < 8; ++i) {
        out[i*4]   = (unsigned char)(s->h[i] >> 24);
        out[i*4+1] = (unsigned char)(s->h[i] >> 16);
        out[i*4+2] = (unsigned char)(s->h[i] >> 8);
        out[i*4+3] = (unsigned char)(s->h[i]);
    }
}
static bool fileSha256(const wchar_t* path, char outHex[65]) {
    outHex[0] = 0;
    HANDLE h = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    Sha256Ctx ctx;
    sha256Init(&ctx);
    unsigned char buf[64 * 1024];
    DWORD read = 0;
    while (ReadFile(h, buf, sizeof(buf), &read, nullptr) && read > 0) {
        sha256Update(&ctx, buf, read);
    }
    CloseHandle(h);
    unsigned char dig[32];
    sha256Final(&ctx, dig);
    static const char* hex = "0123456789abcdef";
    for (int i = 0; i < 32; ++i) {
        outHex[i*2]   = hex[dig[i] >> 4];
        outHex[i*2+1] = hex[dig[i] & 0xF];
    }
    outHex[64] = 0;
    return true;
}

static bool hashBlocked(const wchar_t* path) {
    // 黑名单为空(未装载/旗标关) ⇒ 立即 false（与"本段不存在"逐字节等价，且**绝不打开文件**）
    if (!g_hashBlockOn || g_hashCount <= 0) return false;
    if (!path) return false;
    char hex[65];
    if (!fileSha256(path, hex)) return false;
    for (long i = 0; i < g_hashCount; ++i) {
        if (strcmp(hex, g_hashList[i]) == 0) return true;
    }
    return false;
}

// ============================================================================
// 装载拦截判据 —— 与样板 `ShouldDenyLoadLibraryExWPath` 逐条同构
// 铁律：**全部**条件同时满足才拒绝；任一不确定一律放行（fail-open）。
// ============================================================================
#define ECHO_PATH_CAP ((size_t)MAX_PATH * 8)

/** 有限长度探测：`capChars` 内找到 NUL ⇒ true；找不到 ⇒ 视为非法/不确定串。 */
static bool hasBoundedNul(const wchar_t* p, size_t capChars) {
    if (!p) return false;
    size_t i = 0;
    while (i < capChars && p[i] != L'\0') ++i;
    return i < capChars;
}

/** 是否"限定绝对路径"（`X:\...` 或 `\\server\...`）；裸模块名/相对名一律 false。 */
static bool isQualifiedAbsolutePath(const wchar_t* p) {
    if (!p || !p[0]) return false;
    if (p[0] == L'\\' && p[1] == L'\\') return true;
    const bool drive = ((p[0] >= L'A' && p[0] <= L'Z') || (p[0] >= L'a' && p[0] <= L'z'))
                       && p[1] == L':' && (p[2] == L'\\' || p[2] == L'/');
    return drive;
}

/** 是否像原生镜像文件（按后缀，纯形态判定，不看任何具体名字）。 */
static bool looksLikeNativeImageName(const wchar_t* p) {
    if (!p) return false;
    const wchar_t* dot = wcsrchr(p, L'.');
    if (!dot) return false;
    return _wcsicmp(dot, L".dll") == 0 || _wcsicmp(dot, L".exe") == 0
        || _wcsicmp(dot, L".sys") == 0 || _wcsicmp(dot, L".node") == 0;
}

/** 是否含上级跳转 `..`（含则实际落点不确定 ⇒ 放行）。有界扫描，绝不做无界 wcsstr。 */
static bool containsUpDir(const wchar_t* p) {
    if (!p) return false;
    size_t i = 0;
    while (i + 1 < ECHO_PATH_CAP && p[i] != L'\0') {
        if (p[i] == L'.' && p[i + 1] == L'.') return true;
        ++i;
    }
    return false;
}

static bool ownPathMatch(const wchar_t* path) {
    if (!path || g_ownDir[0] == 0) return false;
    return _wcsnicmp(path, g_ownDir, wcslen(g_ownDir)) == 0;
}

/**
 * 是否落在 mods\/natives\ 子树。
 * ⚠️ 前缀为空时必须**不命中**：否则 `_wcsnicmp(path, L"", 0) == 0` 恒为真，
 * 会把一切绝对路径都判成"子树内"⇒ 全量误拦（实测表现：`Can't find dependent libraries`）。
 */
static bool inBlockedSubtree(const wchar_t* path) {
    if (!path) return false;
    if (g_modsPrefix[0] != 0 && wcslen(g_modsPrefix) > 0
            && _wcsnicmp(path, g_modsPrefix, wcslen(g_modsPrefix)) == 0) {
        return true;
    }
    if (g_nativesPrefix[0] != 0 && wcslen(g_nativesPrefix) > 0
            && _wcsnicmp(path, g_nativesPrefix, wcslen(g_nativesPrefix)) == 0) {
        return true;
    }
    return false;
}

// ============================================================================
// 被拦路径取证（纯内存写；落盘交给守护线程 —— detour 在 loader lock 下，绝不做 IO）
// 只记前 32 条，够定位"到底拦了什么"；多线程写用 Interlocked 取槽位，最坏丢一条。
// ============================================================================
#define DENY_RING 32
static wchar_t g_denyRing[DENY_RING][260];
static volatile long g_denyWrite = 0;

static void recordDenied(const wchar_t* path) {
    if (!path) return;
    const long idx = InterlockedIncrement(&g_denyWrite) - 1;
    if (idx < 0 || idx >= DENY_RING) return;
    wchar_t* dst = g_denyRing[idx];
    dst[0] = L'\0';
    __try {
        long i = 0;
        for (; i < 259 && path[i] != L'\0'; ++i) dst[i] = path[i];
        dst[i] = L'\0';
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        dst[0] = L'\0';
    }
}

/** 装载拦截总判据（对齐样板 `ShouldDenyLoadLibraryExWPath`）。 */
static bool denyForPath(const wchar_t* path) {
    if (!g_loadBlockOn || !path || !path[0]) return false;
    if (!hasBoundedNul(path, ECHO_PATH_CAP)) return false;              // 不确定 ⇒ 放行
    if (!isQualifiedAbsolutePath(path)) return false;                   // 裸名/相对名 ⇒ 交给加载器
    if (g_pathBlockOn && inBlockedSubtree(path)) {
        if (containsUpDir(path)) return false;                          // 实际落点不确定 ⇒ 放行
        if (ownPathMatch(path)) return false;                           // 我方库 ⇒ 绝不拦
        if (GetFileAttributesW(path) == INVALID_FILE_ATTRIBUTES) return false;  // 不存在 ⇒ 交给系统报错
        g_pathHits++;
        recordDenied(path);
        return true;
    }
    // 不在子树（或子树判据关闭）⇒ 只走**内容哈希**判据（与路径无关，覆盖 %TEMP% 解包等绕过）
    if (looksLikeNativeImageName(path) && hashBlocked(path)) {
        g_hashHits++;
        recordDenied(path);
        return true;
    }
    return false;
}

/** SEH 包裹：判定过程任何异常都退化为"放行"，绝不让异常穿出 detour。 */
static bool denyForPathGuard(const wchar_t* path) {
    bool deny = false;
    __try {
        deny = denyForPath(path);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        deny = false;
    }
    return deny;
}

// ---- 库加载 hook ----
typedef NTSTATUS(NTAPI* LdrLoadDll_t)(PWCHAR, ULONG, PUNICODE_STRING, PHANDLE);
typedef HMODULE(WINAPI* LoadLibraryExW_t)(LPCWSTR, HANDLE, DWORD);
static LdrLoadDll_t g_origLdrLoadDll = nullptr;
static LoadLibraryExW_t g_origLoadLibraryExW = nullptr;

// ============================================================================
// 自研 14 字节热补丁 —— 与样板 `HotPatchEntry` / `InstallHotPatch` /
// `HotPatchForward_LoadLibraryExW` 逐条同构（本工程 /MT + 零 C++ 全局对象纪律，
// 故用 SRWLOCK 替代 `std::mutex`，加解锁与样板同序、同临界区）。
//
// 【为什么 `LoadLibraryExW` 必须用热补丁，而不是 MinHook/trampoline】
//   · 它是**低频入口**（游戏自身几乎不调用，只有"装载一个 dll"时才走）；
//   · 热补丁范式是"还原原字节 → 调用原入口 → 重打补丁"，成立前提正是低频；
//   · 样板对 `LoadLibraryExW` / 窗口钩子 / `WriteProcessMemory` 一律用这条路径，
//     并且**明确不使用 MinHook**（零依赖）⇒ 把出错面压到最小。
//   反例（本工程血证）：高频入口（`VirtualProtect`/`NtCreateThreadEx`）绝不能热补丁。
//
// 【为什么入口写 14 字节绝对跳转】
//   不需要指令长度反汇编（那才是 hook 库的真正难点）：
//   主路径是"拒绝"（直接返回，不碰原函数）；只有放行路径才需要调原函数，
//   此时用"还原 → 调用 → 重打"完成转发，于是**永远无需搬运/重定位原指令**。
// ============================================================================
typedef struct EchoHotPatchEntry {
    LPVOID target;
    BYTE   original[14];
    int    installed;
} EchoHotPatchEntry;

static EchoHotPatchEntry g_hpLoadExW = { NULL, { 0 }, 0 };
static SRWLOCK g_hotPatchLock = SRWLOCK_INIT;

#define HOTPATCH_BEGIN() AcquireSRWLockExclusive(&g_hotPatchLock)
#define HOTPATCH_END()   ReleaseSRWLockExclusive(&g_hotPatchLock)

/** 写入跳转补丁（入口 14 字节）：`FF 25 00000000 <绝对 detour>`。 */
static bool applyHotPatchBytes(EchoHotPatchEntry* e, LPVOID detour) {
    if (!e || !e->target || !detour) return false;
    DWORD oldProt = 0;
    if (!VirtualProtect(e->target, 14, PAGE_EXECUTE_READWRITE, &oldProt)) return false;
    BYTE patch[14];
    patch[0] = 0xFF;
    patch[1] = 0x25;                          // jmp qword ptr [rip+0]
    *(DWORD*)(patch + 2) = 0;                 // disp32 = 0
    *(LPVOID*)(patch + 6) = detour;           // 紧随其后的 8 字节绝对地址
    memcpy(e->target, patch, 14);
    VirtualProtect(e->target, 14, oldProt, &oldProt);
    FlushInstructionCache(GetCurrentProcess(), e->target, 14);
    return true;
}

/** 临时还原原 14 字节（仅放行路径调用原函数前使用）。 */
static void restoreHotPatchBytes(EchoHotPatchEntry* e) {
    if (!e || !e->target) return;
    DWORD oldProt = 0;
    if (!VirtualProtect(e->target, 14, PAGE_EXECUTE_READWRITE, &oldProt)) return;
    memcpy(e->target, e->original, 14);
    VirtualProtect(e->target, 14, oldProt, &oldProt);
    FlushInstructionCache(GetCurrentProcess(), e->target, 14);
}

/** 安装热补丁：保存原 14 字节 → 写入跳转。任一步失败都回滚为"未安装"。 */
static bool installHotPatch(EchoHotPatchEntry* e, LPVOID target, LPVOID detour) {
    if (!e || !target || !detour) return false;
    __try {
        memcpy(e->original, target, 14);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;                          // 读不到入口 ⇒ 不装（绝不留半截补丁）
    }
    e->target = target;
    if (!applyHotPatchBytes(e, detour)) {
        e->target = NULL;
        return false;
    }
    e->installed = 1;
    return true;
}

// ============================================================================
// 诊断落盘（**绝不在 detour 里调用**）
//
// ⚠️ `LdrLoadDll` / `LoadLibraryExW` 是在**加载器锁（loader lock）**下被调用的。
//   在 detour 里调用 `CreateFileW`/`WriteFile` 会重入加载器与文件系统，
//   轻则让这一次加载返回失败（实测表现：`Can't find dependent libraries`），
//   重则直接死锁整个进程。⇒ detour 内**零 IO、零分配**（对齐样板：detour 只做
//   计数与 `OutputDebugString` 级提示）；落盘只允许发生在 `nInit` / 守护线程。
// ============================================================================
static volatile long g_diagCalls = 0;

/** 仅在非 detour 上下文（nInit / 守护线程）调用：直接落盘。 */
static void diagLog(const char* msg) {
    if (!msg || g_ownDir[0] == 0) return;
    wchar_t path[1200];
    _snwprintf_s(path, 1200, _TRUNCATE, L"%shook-diag.log", g_ownDir);
    HANDLE h = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(h, msg, (DWORD)strlen(msg), &w, NULL);
    WriteFile(h, "\r\n", 2, &w, NULL);
    CloseHandle(h);
}

/** 守护线程调用：把"被拦路径"取证刷到盘上（自身不在 loader lock）。 */
static void flushDenyLog() {
    static long sFlushed = 0;
    const long n = g_denyWrite;
    if (n <= sFlushed) return;
    char line[400];
    for (long i = sFlushed; i < n && i < DENY_RING; ++i) {
        char narrow[300];
        narrow[0] = '\0';
        WideCharToMultiByte(CP_ACP, 0, g_denyRing[i], -1, narrow, (int)sizeof(narrow) - 1, NULL, NULL);
        _snprintf_s(line, sizeof(line), _TRUNCATE, "DENIED[%ld] %s", i, narrow);
        diagLog(line);
    }
    sFlushed = (n < DENY_RING) ? n : DENY_RING;
}

/**
 * 【参数自洽性体检 · 对齐样板 guard.cpp 的核心血证修法】
 *
 * 实测规律（样板连续 6/6 轮取证恒定）：进入 `LdrLoadDll` detour 时，C 第 3 参数
 * `ModuleFileName`（=`rdx`）**可能是被截断了高 32 位的指针**（`rdx == (r8+0x30) & 0xFFFFFFFF`），
 * 而 `r8`（真第 3 参数）反而完好。把这种坏指针**原样转发**给系统加载器
 * ⇒ `ntdll!LdrLoadDll+0x64` 执行 `mov r9d,[rdx]` 时直接 AV 崩掉整个进程
 * （`pc` 逐字节相同 = 确定性崩溃）。
 *
 * 修法（不削弱）：转发前做**只读**体检，不自洽 ⇒ 记录计数 + 本次**可控失败**，
 * 绝不把坏指针继续往下灌。坏指针本来就不可能加载成功（必然 AV），
 * 现在只是把"进程直接死（全部能力归零）"换成"这一次加载失败 + 有据可查"。
 *
 * 判据全部来自 WIN32 结构不变式（纯形态判定，不看任何模块名/路径）：
 *   ① `Length` 必须偶数（字节数，2 对齐）；
 *   ② `Length <= MaximumLength`；
 *   ③ `MaximumLength` 必须是合理小值（真实 DLL 路径远小于 64KB）；
 *   ④ `Buffer` 非空时首尾两字节必须可读（SEH 探测，读不到即判坏）。
 * 任何异常都被吞掉并返回 false（安全侧）。
 */
static bool ldrParamSane(PUNICODE_STRING us, const wchar_t** outBuf, unsigned short* outLen) {
    if (outBuf) *outBuf = nullptr;
    if (outLen) *outLen = 0;
    if (us == nullptr) return true;              // 无模块名（合法用法）⇒ 放行
    unsigned short len = 0, maxLen = 0;
    const wchar_t* buf = nullptr;
    bool sane = true;
    __try {
        len = us->Length;
        maxLen = us->MaximumLength;
        buf = us->Buffer;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        sane = false;
    }
    if (sane) {
        if ((len & 1) != 0 || maxLen > 0xFFFE || len > maxLen) {
            sane = false;
        } else if (buf != nullptr) {
            __try {
                volatile wchar_t h = buf[0];
                volatile wchar_t t = (maxLen >= 2) ? buf[(maxLen / 2) - 1] : h;
                (void)h;
                (void)t;
            } __except (EXCEPTION_EXECUTE_HANDLER) {
                sane = false;
            }
        }
    }
    if (sane && outBuf) *outBuf = buf;
    if (sane && outLen) *outLen = len;
    return sane;
}

/**
 * `ntdll!LdrLoadDll` detour —— 与样板 `HookedLdrLoadDll` 逐条同构。
 *
 * 三步：
 *   ① **参数自洽性体检**（样板核心血证修法）：`ModuleFileName` 可能是一个高 32 位被截断的
 *      半截指针（`rdx == (r8+0x30) & 0xFFFFFFFF`）。把它原样转发 ⇒ `LdrLoadDll+0x64` 的
 *      `mov r9d,[rdx]` 直接 AV 崩进程。⇒ 不自洽就**这一次可控失败**，绝不往下灌。
 *   ② **用 `Length` 精确复制到本地缓冲后再判据**（对齐样板 `guard.cpp:606-611`）。
 *      ⚠️⚠️ 这一步是必须的，曾因省略它导致 GL 全挂：
 *        `ModuleFileName->Buffer` **不保证是 NUL 结尾的长缓冲**（常见是栈上短串）。
 *        若直接把它交给路径判据（那套判据是为 Java 传来的合法 `LPCWSTR` 设计的，
 *        内部会做"最多 2080 字符的有界扫描"），扫描就会读进未提交页触发 AV。
 *        AV 虽被 `__except` 吞掉并返回"放行"，但异常发生在 **loader lock 内**，
 *        加载器状态已被扰动 ⇒ 后续 GLFW 创建 GL context 失败
 *        （实测：`WGL: The driver does not appear to support OpenGL`）。
 *        ⇒ 先按 `Length` 复制到本地 NUL 结尾缓冲，判据再也不会越界。
 *   ③ 其余一律原样转发（fail-open）。
 *
 * ⚠️ detour 内零 IO、零分配（loader lock 约束）。
 */
static NTSTATUS NTAPI hook_LdrLoadDll(PWCHAR pathToFile, ULONG flags, PUNICODE_STRING moduleFileName,
                                      PHANDLE moduleHandle) {
    g_loadCalls++;
    g_diagCalls++;
    const wchar_t* nameBuf = nullptr;
    unsigned short lenBytes = 0;
    const bool sane = ldrParamSane(moduleFileName, &nameBuf, &lenBytes);
    if (!sane) {
        g_ldrBadParam++;
        SetLastError(ERROR_INVALID_PARAMETER);
        if (moduleHandle) *moduleHandle = nullptr;
        return (NTSTATUS)0xC0000034L;   // STATUS_OBJECT_NAME_NOT_FOUND（"这个模块加载不了"）
    }
    // ⚠️⚠️ **绝不读第 1 参数 `PathToFile`**（与样板 `HookedLdrLoadDll` 完全一致）。
    //   实测：本机 `ntdll!LdrLoadDll` 会以 `PathToFile = 1` 这类**哨兵值**被调用
    //   （反汇编 `cmp word ptr [rdi], r14w` 处 `rdi == 0x1` ⇒ 读地址 0x1 ⇒ AV 0xc0000005）。
    //   判据只允许用**第 3 参数**按 `Length` 复制出来的本地缓冲。
    wchar_t rawPath[MAX_PATH * 2];
    rawPath[0] = L'\0';
    const wchar_t* decisionPath = nullptr;
    if (nameBuf != nullptr && lenBytes > 0) {
        __try {
            size_t chars = (size_t)lenBytes / sizeof(wchar_t);
            if (chars >= (size_t)(MAX_PATH * 2)) chars = (size_t)(MAX_PATH * 2) - 1;
            for (size_t i = 0; i < chars; ++i) rawPath[i] = nameBuf[i];
            rawPath[chars] = L'\0';
            decisionPath = rawPath;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            decisionPath = nullptr;      // 复制失败 ⇒ 不做判据，直接转发（fail-open）
        }
    }
    if (g_loadBlockOn && decisionPath && denyForPathGuard(decisionPath)) {
        g_loadDenied++;
        SetLastError(ERROR_ACCESS_DENIED);
        if (moduleHandle) *moduleHandle = nullptr;
        return (NTSTATUS)0xC0000022L;   // STATUS_ACCESS_DENIED
    }
    if (g_origLdrLoadDll) return g_origLdrLoadDll(pathToFile, flags, moduleFileName, moduleHandle);
    SetLastError(ERROR_MOD_NOT_FOUND);
    if (moduleHandle) *moduleHandle = nullptr;
    return (NTSTATUS)0xC0000135L;       // STATUS_DLL_NOT_FOUND
}

/**
 * `kernel32!LoadLibraryExW` detour —— 与样板 `HookedLoadLibraryExW` 逐条同构。
 *
 * 关键细节（样板原样保留）：**`hFile != NULL` 一律转发**。
 *   从已打开的句柄装载时，`lpLibFileName` 仅是参考名、不参与路径解析，
 *   对它做判据等于拿错的信息去拒绝一次合法装载。
 */
static HMODULE WINAPI hook_LoadLibraryExW(LPCWSTR fileName, HANDLE file, DWORD flags) {
    g_loadCalls++;
    g_diagCalls++;
    if (g_loadBlockOn && file == NULL && denyForPathGuard(fileName)) {
        g_loadDenied++;
        OutputDebugStringW(L"[nativeLibs] deny LoadLibraryExW\n");
        SetLastError(ERROR_ACCESS_DENIED);
        return nullptr;
    }
    if (!g_origLoadLibraryExW) {
        SetLastError(ERROR_INVALID_FUNCTION);   // 理论不可达（补丁只在转发器就绪后落下）
        return nullptr;
    }
    return g_origLoadLibraryExW(fileName, file, flags);
}

// ---- 安全转发器（放行路径）：临时还原 → 调用原入口 → 重新打补丁 ----
// detour 函数体里的 `g_origLoadLibraryExW(...)` 会走到这里 ⇒ detour 逻辑零改动即可复用。
// 转发器与装配/还原共用同一把锁，保证"还原-调用-重打"窗口内没有第二个线程参与。
// 重打失败 ⇒ 永久退化为"未挂钩"（绝不留半截补丁 —— 半截补丁才是崩溃源）。
// ⚠️ 用 `__finally` 保证异常/AV 情况下锁一定释放（本工程 /MT 纪律不用 RAII 对象）。
static HMODULE WINAPI hotPatchForward_LoadLibraryExW(LPCWSTR fileName, HANDLE file, DWORD flags) {
    HMODULE r = nullptr;
    HOTPATCH_BEGIN();
    __try {
        if (!g_hpLoadExW.installed || !g_hpLoadExW.target) {
            SetLastError(ERROR_INVALID_FUNCTION);
        } else {
            restoreHotPatchBytes(&g_hpLoadExW);
            LoadLibraryExW_t fn = (LoadLibraryExW_t)g_hpLoadExW.target;
            r = fn(fileName, file, flags);
            if (!applyHotPatchBytes(&g_hpLoadExW, (LPVOID)&hook_LoadLibraryExW)) {
                g_hpLoadExW.installed = 0;
            }
        }
    } __finally {
        HOTPATCH_END();
    }
    return r;
}


// ============================================================================
// A3 · 渲染/热路径（对齐样板 `InstallSwapHooksHotPatch`）
//
// 【为什么 SwapBuffers / wglSwapBuffers 必须用 trampoline（原子写），绝不能用热补丁】
//   样板血证（用户实测，已到 Render thread / DISPATCHING 阶段）：
//     `EXCEPTION_UNCAUGHT_CXX_EXCEPTION (0xe06d7363) at KERNELBASE.dll+0xc41ca`
//     Java 栈 = `GLFW.glfwSwapBuffers` ⇒ **GLFW 每帧调用 `wglSwapBuffers`**。
//     热补丁的"还原→调用→重打"窗口与渲染线程并发 ⇒ 其它线程执行到半截字节 ⇒ 进程崩。
//   铁律：热补丁只装低频入口；**高频入口必须 trampoline**。
//   我方 `EchoMinHookInstall` 走的正是"原子写 5 字节 + MinHook trampoline"，等价样板
//   的 `AtomicHookEnable` ⇒ 一致。
// ============================================================================
typedef BOOL(WINAPI* SwapBuffers_t)(HDC);
typedef BOOL(WINAPI* wglSwapBuffers_t)(HDC);
typedef HHOOK(WINAPI* SetWindowsHookExW_t)(int, HOOKPROC, HINSTANCE, DWORD);
typedef LONG(NTAPI* NtCreateThreadEx_t)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, HANDLE, PVOID, PVOID,
                                        ULONG, SIZE_T, SIZE_T, SIZE_T, PVOID);
static SwapBuffers_t g_origSwapBuffers = nullptr;
static wglSwapBuffers_t g_origWglSwapBuffers = nullptr;
static SetWindowsHookExW_t g_origSetWindowsHookExW = nullptr;
static NtCreateThreadEx_t g_origNtCreateThreadEx = nullptr;

static void buildPrefixes();   // 前置声明：定义在本文件后部的 JNI 段

/**
 * 调用方模块是否"可信"（⇒ 放行 `SwapBuffers`）。
 *
 * 判据来源（按**路径归属**，不枚举任何具体模块名 ⇒ 不针对）：
 *   · 我方目录（echoes-native）            —— 自身
 *   · 游戏目录（含 `-natives` / `libraries`）—— GLFW / LWJGL / 游戏自带原生库
 *   · System32 / Windows 目录              —— opengl32、以及**显卡驱动**（nvoglv64 / atio6axx…）
 *   · JDK 根                               —— jvm / zip / net 等 JVM 自带库
 *   · 取不到模块（JIT / 动态代码）         —— 不确定 ⇒ 放行
 * 其余（`mods\` 子树、`%TEMP%` 解包、任意目录）⇒ 第三方 ⇒ 阻断其整屏 GDI 覆盖。
 *
 * ⚠️ 为什么不能"只认 glfw/opengl32/lwjgl 的白名单"（实测血证）：
 *   GLFW 的交换调用链会经过**显卡驱动**，模块名白名单必然漏掉它 ⇒ 判成第三方 ⇒ 阻断
 *   ⇒ 逻辑照跑、可交互，但**画面全白**（已实测）。也不能反过来"只拦 mods 子树"，
 *   敌方可以把 DLL 放到任意目录。⇒ 于是用"路径归属"取代"模块名"，两端都覆盖。
 */
static bool callerIsTrustedForSwap() {
    const void* ret = _ReturnAddress();
    if (!ret) return true;                  // 不确定 ⇒ 放行（fail-open）
    HMODULE mod = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                            (LPCWSTR)ret, &mod) || !mod) {
        return true;                        // JIT/动态代码 ⇒ 放行
    }
    wchar_t path[MAX_PATH * 2] = { 0 };
    if (GetModuleFileNameW(mod, path, MAX_PATH * 2) == 0) return true;
    if (g_ownDir[0] && _wcsnicmp(path, g_ownDir, wcslen(g_ownDir)) == 0) return true;
    if (g_sysDir[0] && _wcsnicmp(path, g_sysDir, wcslen(g_sysDir)) == 0) return true;
    if (g_winDir[0] && _wcsnicmp(path, g_winDir, wcslen(g_winDir)) == 0) return true;
    if (g_javaHome[0] && _wcsnicmp(path, g_javaHome, wcslen(g_javaHome)) == 0) return true;
    if (g_gameDir[0] && _wcsnicmp(path, g_gameDir, wcslen(g_gameDir)) == 0) {
        // 游戏目录内：`mods\` 子树的原生库属第三方（拦）；其余（-natives 等）放行
        if (g_modsPrefix[0] && wcslen(g_modsPrefix) > 0
                && _wcsnicmp(path, g_modsPrefix, wcslen(g_modsPrefix)) == 0) {
            return false;
        }
        return true;
    }
    return false;                           // 其它目录 ⇒ 第三方
}

/**
 * 把 OpenGL 后台缓冲涂成纯白。
 *
 * 为什么需要它（"定格" vs "白屏"的差别）：
 *   单纯吞掉 `SwapBuffers` 只会让屏幕**停在最后一次成功交换的画面**（实测：画面定格在
 *   右键那一刻）。要得到"纯白屏"，必须先在当前 GL 上下文里把颜色缓冲清成白色，
 *   再正常交换一次 ⇒ 屏幕变成整片白。
 *
 * 取函数指针走 `opengl32.dll` 导出（`glClearColor`/`glClear`），不依赖 lwjgl 的 JNI 绑定；
 * 失败（无 GL 上下文 / 未加载）时静默降级为"不交换"（仍然看不到游戏画面）。
 */
static void clearSwapBufferToWhite() {
    static HMODULE sGl = nullptr;
    static void (WINAPI* sClearColor)(float, float, float, float) = nullptr;
    static void (WINAPI* sClear)(unsigned int) = nullptr;
    if (sGl == nullptr) {
        sGl = GetModuleHandleW(L"opengl32.dll");
        if (sGl != nullptr) {
            sClearColor = (void (WINAPI*)(float, float, float, float))
                    GetProcAddress(sGl, "glClearColor");
            sClear = (void (WINAPI*)(unsigned int))GetProcAddress(sGl, "glClear");
        }
    }
    if (sClearColor != nullptr && sClear != nullptr) {
        sClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        sClear(0x00004000u | 0x00000100u);   // GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT
    }
}

static BOOL WINAPI hook_SwapBuffers(HDC hdc) {
    g_gdiSwapCalls++;
    if (g_gdiMode == 0) {                    // off：纯观测（默认）
        if (g_origSwapBuffers) return g_origSwapBuffers(hdc);
        return TRUE;
    }
    if (g_gdiMode == 2) {                    // force：清成纯白后正常交换 ⇒ 整屏白屏
        clearSwapBufferToWhite();
        g_gdiSwapBlocked++;
        if (g_origSwapBuffers) return g_origSwapBuffers(hdc);
        return TRUE;
    }
    // glfw_pass：渲染链放行；其它（第三方 GDI 整屏覆盖）清白阻断
    if (callerIsTrustedForSwap()) {
        if (g_origSwapBuffers) return g_origSwapBuffers(hdc);
        return TRUE;
    }
    clearSwapBufferToWhite();
    g_gdiSwapBlocked++;
    if (g_origSwapBuffers) return g_origSwapBuffers(hdc);
    return TRUE;
}

static BOOL WINAPI hook_wglSwapBuffers(HDC hdc) {
    g_glSwapCalls++;
    if (g_origWglSwapBuffers) return g_origWglSwapBuffers(hdc);
    return TRUE;
}

static HHOOK WINAPI hook_SetWindowsHookExW(int id, HOOKPROC proc, HINSTANCE inst, DWORD tid) {
    g_lowHookCalls++;
    if (g_origSetWindowsHookExW) return g_origSetWindowsHookExW(id, proc, inst, tid);
    return nullptr;
}

static LONG NTAPI hook_NtCreateThreadEx(PHANDLE h, ACCESS_MASK da, POBJECT_ATTRIBUTES oa, HANDLE ph,
                                        PVOID fn, PVOID arg, ULONG flags, SIZE_T zs, SIZE_T ms,
                                        SIZE_T cs, PVOID attr) {
    g_hotThreadCalls++;
    if (g_origNtCreateThreadEx) return g_origNtCreateThreadEx(h, da, oa, ph, fn, arg, flags, zs, ms, cs, attr);
    return -1;
}

/**
 * 幂等装配 A3（`nArmRendering` 与守护线程共用）。
 * `opengl32.dll` 在早期可能尚未加载 ⇒ 由守护线程周期补装（样板同样"心跳反复补装那一条"）。
 * 已装条目由 `EchoMinHookInstall` 的幂等判据直接返回 ⇒ 重复调用零副作用。
 */
static int armRenderHooks() {
    static bool sLogged = false;
    const bool logIt = !sLogged;
    if (!EchoMinHookLoad(&g_mh, (const void*)&armRenderHooks)) {
        if (logIt) { sLogged = true; diagLog("armRenderHooks: MinHook 不可用"); }
        return 0;
    }
    int armed = 0;
    char line[200];
    if (g_gdiMode != 0) {
        const bool ok = EchoMinHookInstall(&g_mh, L"gdi32.dll", "SwapBuffers",
                                           (LPVOID)&hook_SwapBuffers, (LPVOID*)&g_origSwapBuffers);
        if (ok) ++armed;
        if (logIt) {
            _snprintf_s(line, sizeof(line), _TRUNCATE, "arm gdi32!SwapBuffers ok=%d orig=%p",
                        ok ? 1 : 0, (void*)g_origSwapBuffers);
            diagLog(line);
        }
    }
    {
        const bool ok = EchoMinHookInstall(&g_mh, L"opengl32.dll", "wglSwapBuffers",
                                           (LPVOID)&hook_wglSwapBuffers, (LPVOID*)&g_origWglSwapBuffers);
        if (ok) ++armed;
        if (logIt) {
            _snprintf_s(line, sizeof(line), _TRUNCATE, "arm opengl32!wglSwapBuffers ok=%d orig=%p",
                        ok ? 1 : 0, (void*)g_origWglSwapBuffers);
            diagLog(line);
        }
    }
    if (g_lowLevelHookOn) {
        const bool ok = EchoMinHookInstall(&g_mh, L"user32.dll", "SetWindowsHookExW",
                                           (LPVOID)&hook_SetWindowsHookExW, (LPVOID*)&g_origSetWindowsHookExW);
        if (ok) ++armed;
        if (logIt) {
            _snprintf_s(line, sizeof(line), _TRUNCATE, "arm user32!SetWindowsHookExW ok=%d", ok ? 1 : 0);
            diagLog(line);
        }
    }
    if (g_hotApiHookOn) {
        const bool ok = EchoMinHookInstall(&g_mh, L"ntdll.dll", "NtCreateThreadEx",
                                           (LPVOID)&hook_NtCreateThreadEx, (LPVOID*)&g_origNtCreateThreadEx);
        if (ok) ++armed;
        if (logIt) {
            _snprintf_s(line, sizeof(line), _TRUNCATE, "arm ntdll!NtCreateThreadEx ok=%d orig=%p",
                        ok ? 1 : 0, (void*)g_origNtCreateThreadEx);
            diagLog(line);
        }
    }
    if (logIt) sLogged = true;
    return armed;
}

// ============================================================================
// ============================================================================
// B · 注入入口拦截（对齐样板 `InstallInjectGuards187` 的 10 条 detour；
//     但判据按样板自己在 guard.cpp:652 写下的正确做法实现）
//
// 【样板自身的 bug（我方修正，勿改回）】
//   样板 `ShouldDenyInject187()` 在**辅助函数内部**取 `_ReturnAddress()`：
//     static bool ShouldDenyInject187() { return CallerIsThirdPartyModsModuleGuard(_ReturnAddress()); }
//   而样板注释明确写过：在辅助函数里取会得到**本 DLL 内的返回地址** ⇒ 调用方被误判为自己
//   ⇒ 判据永远放行（静默失效）。正解：在 **detour 函数体内**取 `_ReturnAddress()` 再传参。
//   ⇒ 下面每个 detour 都用 `INJ_DENY_CHECK(...)` 宏，宏在**展开处**（即 detour 内）取地址。
//
// 【判据（防伪装，三级）】
//   受信 ⇒ 放行：系统目录 / Windows / JDK / 我方目录 / `-natives\` / `\libraries\` / 我方 jar 前缀
//   其余 ⇒ 拦：`mods\`、**游戏目录根**、`%TEMP%`、任意其它目录
//   无模块（JIT / 动态代码）⇒ 放行（否则 JVM 的 JIT/GC 会当场崩）
//   ⚠️ 与样板不同：样板只拦 `mods\`，拦不到"放游戏主目录/WIN 目录"的注入；这里把**游戏根
//      与任意非受信目录**一并判为第三方，正好堵住该缺口。
// ============================================================================
typedef LONG(NTAPI* NtQueueApcThread_t)(HANDLE, PVOID, PVOID, PVOID, PVOID);
typedef LONG(NTAPI* NtWriteVirtualMemory_t)(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
typedef LONG(NTAPI* NtProtectVirtualMemory_t)(HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);
typedef LONG(NTAPI* NtMapViewOfSection_t)(HANDLE, HANDLE, PVOID*, ULONG_PTR, SIZE_T, PLARGE_INTEGER,
                                          PSIZE_T, DWORD, ULONG, ULONG);
typedef LONG(NTAPI* RtlCreateUserThread_t)(HANDLE, PSECURITY_DESCRIPTOR, BOOLEAN, ULONG,
                                           PSIZE_T, PSIZE_T, PVOID, PVOID, PHANDLE, PHANDLE);
typedef LONG(NTAPI* NtCreateThread_t)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, HANDLE, PHANDLE,
                                      PVOID, PVOID, PVOID);
typedef DWORD(WINAPI* QueueUserAPC_t)(PAPCFUNC, HANDLE, ULONG_PTR);
typedef BOOL(WINAPI* SetThreadContext_t)(HANDLE, const CONTEXT*);
typedef HANDLE(WINAPI* CreateRemoteThread_t)(HANDLE, LPSECURITY_ATTRIBUTES, SIZE_T,
                                             LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD);
typedef HWINEVENTHOOK(WINAPI* SetWinEventHook_t)(DWORD, DWORD, HMODULE, WINEVENTPROC, DWORD, DWORD, DWORD);

static NtQueueApcThread_t g_origNtQueueApcThread = nullptr;
static NtWriteVirtualMemory_t g_origNtWriteVirtualMemory = nullptr;
static NtProtectVirtualMemory_t g_origNtProtectVirtualMemory = nullptr;
static NtMapViewOfSection_t g_origNtMapViewOfSection = nullptr;
static RtlCreateUserThread_t g_origRtlCreateUserThread = nullptr;
static NtCreateThread_t g_origNtCreateThread = nullptr;
static QueueUserAPC_t g_origQueueUserAPC = nullptr;
static SetThreadContext_t g_origSetThreadContext = nullptr;
static CreateRemoteThread_t g_origCreateRemoteThread = nullptr;
static SetWinEventHook_t g_origSetWinEventHook = nullptr;

// 注入守卫总开关（运行期可关：关掉后所有 detour 立即纯转发，零行为差）
static volatile bool g_injectionGuardOn = false;
static volatile long g_injCalls = 0;
static volatile long g_injDenied = 0;
static int g_injArmed = 0;

#define ECHO_STATUS_ACCESS_DENIED ((LONG)0xC0000022L)

/** 有界大小写不敏感子串查找（纯内存，detour 内零文件 IO）。 */
static bool containsNoAllocCI(const wchar_t* hay, const wchar_t* needle) {
    if (!hay || !needle || !needle[0]) return false;
    const size_t nl = wcslen(needle);
    for (size_t i = 0; i + nl <= ECHO_PATH_CAP; ++i) {
        if (hay[i] == L'\0') return false;
        if (_wcsnicmp(hay + i, needle, nl) == 0) return true;
    }
    return false;
}

static bool startsWithNoAllocCI(const wchar_t* s, const wchar_t* prefix) {
    if (!s || !prefix || !prefix[0]) return false;
    return _wcsnicmp(s, prefix, wcslen(prefix)) == 0;
}

/** 调用方模块是否"受信"（⇒ 放行注入类 API）。 */
static bool callerIsTrustedForInjection(const void* caller) {
    if (!caller) return true;
    HMODULE mod = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                            (LPCWSTR)caller, &mod) || !mod) {
        return true;                                   // JIT / 动态代码 ⇒ 放行（不能崩 JVM）
    }
    wchar_t path[MAX_PATH * 2] = { 0 };
    if (GetModuleFileNameW(mod, path, MAX_PATH * 2) == 0) return true;
    if (startsWithNoAllocCI(path, g_sysDir)) return true;
    if (startsWithNoAllocCI(path, g_winDir)) return true;
    if (startsWithNoAllocCI(path, g_javaHome)) return true;
    if (startsWithNoAllocCI(path, g_ownDir)) return true;
    if (containsNoAllocCI(path, L"-natives\\")) return true;      // 游戏自带 GLFW/LWJGL
    if (containsNoAllocCI(path, L"\\libraries\\")) return true;   // 启动器库
    // mods 内的**我方**制品 ⇒ 放行（jar 解出的原生库路径含我方名）
    if (containsNoAllocCI(path, L"\\mods\\")
            && (containsNoAllocCI(path, L"echoes") || containsNoAllocCI(path, L"modid-"))) {
        return true;
    }
    return false;                                      // 其余（mods / 游戏根 / %TEMP% / 任意）⇒ 第三方
}

static bool shouldDenyInjection(const void* caller) {
    if (!g_injectionGuardOn) return false;              // 总开关关 ⇒ 一律放行
    bool deny = false;
    __try {
        deny = !callerIsTrustedForInjection(caller);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        deny = false;                                  // 判定异常 ⇒ fail-open
    }
    return deny;
}

/** 统一判据宏：**必须在 detour 函数体内展开**（`_ReturnAddress()` 才拿得到真实调用方）。 */
#define INJ_DENY_CHECK(failRet)                                              \
    do {                                                                     \
        g_injCalls++;                                                        \
        if (shouldDenyInjection(_ReturnAddress())) {                          \
            g_injDenied++;                                                   \
            return (failRet);                                                \
        }                                                                    \
    } while (0)

// ---- 1) APC 注入（不产生新线程，审计盲区）----
static DWORD WINAPI hook_QueueUserAPC(PAPCFUNC pfnAPC, HANDLE hThread, ULONG_PTR dwData) {
    INJ_DENY_CHECK(0);
    if (!g_origQueueUserAPC) { SetLastError(ERROR_INVALID_FUNCTION); return 0; }
    return g_origQueueUserAPC(pfnAPC, hThread, dwData);
}
static LONG NTAPI hook_NtQueueApcThread(HANDLE th, PVOID apc, PVOID a1, PVOID a2, PVOID a3) {
    INJ_DENY_CHECK(ECHO_STATUS_ACCESS_DENIED);
    if (!g_origNtQueueApcThread) return ECHO_STATUS_ACCESS_DENIED;
    return g_origNtQueueApcThread(th, apc, a1, a2, a3);
}

// ---- 2) 线程劫持主干 ----
static BOOL WINAPI hook_SetThreadContext(HANDLE hThread, const CONTEXT* ctx) {
    INJ_DENY_CHECK(FALSE);
    if (!g_origSetThreadContext) { SetLastError(ERROR_INVALID_FUNCTION); return FALSE; }
    return g_origSetThreadContext(hThread, ctx);
}

// ---- 3) NT 直调内存族（kernel32 钩的系统性旁路）----
static LONG NTAPI hook_NtWriteVirtualMemory(HANDLE ph, PVOID base, PVOID buf, SIZE_T n, PSIZE_T written) {
    INJ_DENY_CHECK(ECHO_STATUS_ACCESS_DENIED);
    if (!g_origNtWriteVirtualMemory) return ECHO_STATUS_ACCESS_DENIED;
    return g_origNtWriteVirtualMemory(ph, base, buf, n, written);
}
static LONG NTAPI hook_NtProtectVirtualMemory(HANDLE ph, PVOID* base, PSIZE_T sz, ULONG prot, PULONG oldProt) {
    INJ_DENY_CHECK(ECHO_STATUS_ACCESS_DENIED);
    if (!g_origNtProtectVirtualMemory) return ECHO_STATUS_ACCESS_DENIED;
    return g_origNtProtectVirtualMemory(ph, base, sz, prot, oldProt);
}
// 手动映射 DLL（完全绕过 LdrLoadDll）：调用方非受信即拒
static LONG NTAPI hook_NtMapViewOfSection(HANDLE section, HANDLE ph, PVOID* base, ULONG_PTR zeroBits,
                                          SIZE_T commit, PLARGE_INTEGER offset, PSIZE_T viewSize,
                                          DWORD inherit, ULONG allocType, ULONG protect) {
    INJ_DENY_CHECK(ECHO_STATUS_ACCESS_DENIED);
    if (!g_origNtMapViewOfSection) return ECHO_STATUS_ACCESS_DENIED;
    return g_origNtMapViewOfSection(section, ph, base, zeroBits, commit, offset, viewSize,
                                    inherit, allocType, protect);
}

// ---- 4) 线程创建旁路 ----
static LONG NTAPI hook_RtlCreateUserThread(HANDLE ph, PSECURITY_DESCRIPTOR sd, BOOLEAN suspended,
                                           ULONG zeroBits, PSIZE_T maxStack, PSIZE_T initStack,
                                           PVOID start, PVOID param, PHANDLE thOut, PHANDLE cid) {
    INJ_DENY_CHECK(ECHO_STATUS_ACCESS_DENIED);
    if (!g_origRtlCreateUserThread) return ECHO_STATUS_ACCESS_DENIED;
    return g_origRtlCreateUserThread(ph, sd, suspended, zeroBits, maxStack, initStack,
                                     start, param, thOut, cid);
}
static LONG NTAPI hook_NtCreateThread(PHANDLE thOut, ACCESS_MASK access, POBJECT_ATTRIBUTES oa,
                                      HANDLE ph, PHANDLE cid, PVOID clientCtx, PVOID teb, PVOID suspended) {
    INJ_DENY_CHECK(ECHO_STATUS_ACCESS_DENIED);
    if (!g_origNtCreateThread) return ECHO_STATUS_ACCESS_DENIED;
    return g_origNtCreateThread(thOut, access, oa, ph, cid, clientCtx, teb, suspended);
}
static HANDLE WINAPI hook_CreateRemoteThread(HANDLE ph, LPSECURITY_ATTRIBUTES sa, SIZE_T stackSize,
                                             LPTHREAD_START_ROUTINE start, LPVOID param,
                                             DWORD flags, LPDWORD tid) {
    INJ_DENY_CHECK(NULL);
    if (!g_origCreateRemoteThread) { SetLastError(ERROR_INVALID_FUNCTION); return nullptr; }
    return g_origCreateRemoteThread(ph, sa, stackSize, start, param, flags, tid);
}

// ---- 5) 窗口事件钩子（WINEVENT_INCONTEXT 是进程内注入原语）----
static HWINEVENTHOOK WINAPI hook_SetWinEventHook(DWORD evMin, DWORD evMax, HMODULE mod,
                                                 WINEVENTPROC proc, DWORD pid, DWORD tid, DWORD flags) {
    INJ_DENY_CHECK(nullptr);
    if (!g_origSetWinEventHook) { SetLastError(ERROR_INVALID_FUNCTION); return nullptr; }
    return g_origSetWinEventHook(evMin, evMax, mod, proc, pid, tid, flags);
}

/**
 * 幂等装配注入入口守卫（10 条）。已装的由 `EchoMinHookInstall` 幂等直返 ⇒ 可反复调用。
 * 全部走 trampoline + 原子写（与 A3 同一路径）：这些入口里 `NtProtectVirtualMemory` /
 * `NtMapViewOfSection` 被 JVM 类加载/JIT/内存管理高频调用，**绝不能用热补丁**。
 */
static int armInjectionGuards() {
    if (!EchoMinHookLoad(&g_mh, (const void*)&armInjectionGuards)) return 0;
    int n = 0;
    if (EchoMinHookInstall(&g_mh, L"kernel32.dll", "QueueUserAPC",
                           (LPVOID)&hook_QueueUserAPC, (LPVOID*)&g_origQueueUserAPC)) ++n;
    if (EchoMinHookInstall(&g_mh, L"ntdll.dll", "NtQueueApcThread",
                           (LPVOID)&hook_NtQueueApcThread, (LPVOID*)&g_origNtQueueApcThread)) ++n;
    if (EchoMinHookInstall(&g_mh, L"kernel32.dll", "SetThreadContext",
                           (LPVOID)&hook_SetThreadContext, (LPVOID*)&g_origSetThreadContext)) ++n;
    if (EchoMinHookInstall(&g_mh, L"ntdll.dll", "NtWriteVirtualMemory",
                           (LPVOID)&hook_NtWriteVirtualMemory, (LPVOID*)&g_origNtWriteVirtualMemory)) ++n;
    if (EchoMinHookInstall(&g_mh, L"ntdll.dll", "NtProtectVirtualMemory",
                           (LPVOID)&hook_NtProtectVirtualMemory, (LPVOID*)&g_origNtProtectVirtualMemory)) ++n;
    if (EchoMinHookInstall(&g_mh, L"ntdll.dll", "NtMapViewOfSection",
                           (LPVOID)&hook_NtMapViewOfSection, (LPVOID*)&g_origNtMapViewOfSection)) ++n;
    if (EchoMinHookInstall(&g_mh, L"ntdll.dll", "RtlCreateUserThread",
                           (LPVOID)&hook_RtlCreateUserThread, (LPVOID*)&g_origRtlCreateUserThread)) ++n;
    if (EchoMinHookInstall(&g_mh, L"ntdll.dll", "NtCreateThread",
                           (LPVOID)&hook_NtCreateThread, (LPVOID*)&g_origNtCreateThread)) ++n;
    if (EchoMinHookInstall(&g_mh, L"kernel32.dll", "CreateRemoteThread",
                           (LPVOID)&hook_CreateRemoteThread, (LPVOID*)&g_origCreateRemoteThread)) ++n;
    if (EchoMinHookInstall(&g_mh, L"user32.dll", "SetWinEventHook",
                           (LPVOID)&hook_SetWinEventHook, (LPVOID*)&g_origSetWinEventHook)) ++n;
    g_injArmed = n;
    return n;
}

// A4 · Instrumentation 句柄兜底（JVMTI 堆迭代 tag 法）
// ============================================================================
static jvmtiIterationControl JNICALL tag_instances_cb(jlong class_tag, jlong size, jlong* tag_ptr,
                                                      void* user_data) {
    (void) class_tag; (void) size; (void) user_data;
    if (tag_ptr) *tag_ptr = 1;
    return JVMTI_ITERATION_CONTINUE;
}

static int capture_real_instrumentation() {
    if (g_realInstrumentation) return 0;
    if (g_handleGiveUp) return 2;
    g_handleTries++;
    GUARD_BEGIN
        if (!g_vm) { strcpy_s(g_handleDiag, "no vm"); return 1; }
        JNIEnv* env = nullptr;
        if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_8) != JNI_OK || !env) {
            strcpy_s(g_handleDiag, "no jnienv");
            return 1;
        }
        jvmtiEnv* jvmti = nullptr;
        if (g_vm->GetEnv((void**)&jvmti, JVMTI_VERSION_1_2) != JNI_OK || !jvmti) {
            strcpy_s(g_handleDiag, "no jvmti env");
            return 1;
        }
        jvmtiCapabilities caps;
        memset(&caps, 0, sizeof(caps));
        caps.can_tag_objects = 1;
        if (jvmti->AddCapabilities(&caps) != JVMTI_ERROR_NONE) {
            strcpy_s(g_handleDiag, "no can_tag_objects");
            return 1;
        }
        jclass cls = env->FindClass("sun/instrument/InstrumentationImpl");
        if (!cls) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            strcpy_s(g_handleDiag, "class not loaded");
            return 1;
        }
        jvmtiError rc = jvmti->IterateOverInstancesOfClass(cls, JVMTI_HEAP_OBJECT_EITHER,
                                                           tag_instances_cb, nullptr);
        if (rc != JVMTI_ERROR_NONE) {
            strcpy_s(g_handleDiag, "iterate failed");
            return 1;
        }
        jlong tags[1] = { 1 };
        jint count = 0;
        jobject* objs = nullptr;
        rc = jvmti->GetObjectsWithTags(1, tags, &count, &objs, nullptr);
        if (rc != JVMTI_ERROR_NONE || count <= 0 || !objs) {
            strcpy_s(g_handleDiag, "no instances");
            return 1;
        }
        jfieldID fid = env->GetFieldID(cls, "mNativeAgent", "J");
        if (!fid) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            fid = nullptr;
        }
        jobject found = nullptr;
        if (fid) {
            for (jint i = 0; i < count; ++i) {
                if (env->GetLongField(objs[i], fid) != 0) { found = objs[i]; break; }
            }
        }
        if (!found && count > 0) found = objs[0];
        if (found) {
            g_realInstrumentation = env->NewGlobalRef(found);
            if (g_realInstrumentation) {
                g_handleHits++;
                strcpy_s(g_handleDiag, "hit");
                return 0;
            }
            strcpy_s(g_handleDiag, "newglobalref failed");
            return 2;
        }
        strcpy_s(g_handleDiag, "instances=0");
        return 1;
    GUARD_END_INT(1)
    return 1;
}

// ============================================================================
// 原生隐藏最高优先级守护线程
// ============================================================================
typedef HRESULT(WINAPI* SetThreadDescription_t)(HANDLE, PCWSTR);

DWORD WINAPI daemon_thread(LPVOID) {
    // ① 优先级三档（真实递进，不是同一档换名字）：
    //   0 highest       = NORMAL_PRIORITY_CLASS + THREAD_PRIORITY_HIGHEST      ⇒ 基准优先级 10
    //   1 time_critical = HIGH_PRIORITY_CLASS  + THREAD_PRIORITY_TIME_CRITICAL ⇒ 基准优先级 15（安全最高）
    //   2 realtime      = REALTIME_PRIORITY_CLASS + THREAD_PRIORITY_TIME_CRITICAL ⇒ 基准优先级 31（真最高）
    //   ⚠️ 档 2 需要 SeIncreaseBasePriorityPrivilege（管理员）；普通进程 `SetPriorityClass` 会
    //      静默失败 ⇒ 自动降级为 15，仍然是最高的安全档，绝不因权限不足而丢掉优先级。
    const int prio = g_daemonPrio;
    if (prio == 2) {
        if (!SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS)) {
            SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);   // 无权 ⇒ 降级到 15
        }
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    } else if (prio == 0) {
        SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
    } else {
        SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    }
    // ② 伪装名（不在 Java 线程列表；Win10+ 可设描述名，兼容失败静默）
    if (g_daemonHide) {
        HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
        if (k32) {
            SetThreadDescription_t std = (SetThreadDescription_t)GetProcAddress(k32, "SetThreadDescription");
            if (std) std(GetCurrentThread(), L"Worker");
        }
    }
    // ③ 周期守护：200ms（可配）
    for (;;) {
        Sleep((DWORD)(g_daemonPeriodMs > 0 ? g_daemonPeriodMs : 200));
        g_daemonTicks++;
        GUARD_BEGIN
            // a) 重断言 JVMTI 锁（跨 DLL）
            HMODULE jl = GetModuleHandleW(L"echo_jvmti_lockdown.dll");
            if (jl) {
                typedef int (*Recheck_t)(void);
                Recheck_t rc = (Recheck_t)GetProcAddress(jl, "EchoJvmtiRecheck");
                if (rc && rc() > 0) g_daemonRechecks++;
            }
            // a2) 补装渲染观测 hook（幂等，零副作用）：
            //     `opengl32.dll` 在 early attach 时可能尚未加载 ⇒ `wglSwapBuffers` 那条装不上。
            //     它同时是下面 b) 的**事件源**（渲染循环是否已启动），所以必须先保证它装上。
            //     已装的条目由幂等判据直接返回 ⇒ 只有"还有缺口"时才真正进入装配路径。
            if (!g_origWglSwapBuffers || (g_gdiMode != 0 && !g_origSwapBuffers)
                    || (g_lowLevelHookOn && !g_origSetWindowsHookExW)
                    || (g_hotApiHookOn && !g_origNtCreateThreadEx)) {
                if (armRenderHooks() > 0) g_daemonRehooks++;
            }
            // a2b) 注入入口守卫补装（幂等；已装齐则零开销）
            if (g_injectionGuardOn && g_injArmed < 10) {
                armInjectionGuards();
            }
            // a3) 把"被装载拦截判据拒绝的路径"取证刷盘
            //     （detour 在 loader lock 下只写内存，IO 一律放到本线程）
            flushDenyLog();
            // b) 补装（幂等）：
            //    · `LoadLibraryExW` 热补丁 —— **事件驱动，绝不按时间猜**。
            //      热补丁的 14 字节无法原子写，"还原-调用-重打"窗口里被并发调用就会执行
            //      半截跳转。启动早期 GLFW/opengl32/驱动会密集加载 dll，此时装配必崩。
            //      判据换成**精确事件**：`opengl32!wglSwapBuffers`（或 `gdi32!SwapBuffers`）
            //      一旦被调用 ⇒ GL context 已建成、渲染循环已启动 ⇒ 启动期密集加载已结束。
            //      这两条观测 hook 本身是 MinHook trampoline（无窗口），可以最早装、安全计数。
            //      兜底：无声渲染环境（专用服务器/无 GL）永不触发 ⇒ 300 拍（≈60s）后补装。
            //    · `LdrLoadDll` —— MinHook trampoline，无窗口，缺了随时补。
            const bool renderLoopUp = (g_glSwapCalls > 0) || (g_gdiSwapCalls > 0);
            if ((renderLoopUp || g_daemonTicks >= 300) && !g_hpLoadExW.installed) {
                HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
                LPVOID pExW = k32 ? (LPVOID)GetProcAddress(k32, "LoadLibraryExW") : nullptr;
                HOTPATCH_BEGIN();
                if (pExW && installHotPatch(&g_hpLoadExW, pExW, (LPVOID)&hook_LoadLibraryExW)) {
                    g_origLoadLibraryExW = &hotPatchForward_LoadLibraryExW;
                    g_daemonRehooks++;
                }
                HOTPATCH_END();
            }
            if (g_ldrHookWanted && !g_origLdrLoadDll) {
                if (EchoMinHookLoad(&g_mh, (const void*)&daemon_thread)) {
                    EchoMinHookInstall(&g_mh, L"ntdll.dll", "LdrLoadDll",
                                       (LPVOID)&hook_LdrLoadDll, (LPVOID*)&g_origLdrLoadDll);
                    g_daemonRehooks++;
                }
            }
            // b2) 补丁完整性：热补丁入口前 14 字节必须仍是我方 `FF 25 <detour>`。
            //     敌方直接写回原始字节（或第三方 hook 抢占）即视为被摘 ⇒ 当场重打。
            //     ⚠️ 整个检测+重打都在同一把热补丁锁内完成，避免与"还原-调用-重打"
            //        窗口竞争而被误判成"被摘"。
            if (g_hpLoadExW.installed && g_hpLoadExW.target) {
                HOTPATCH_BEGIN();
                BYTE expect[14];
                expect[0] = 0xFF;
                expect[1] = 0x25;
                *(DWORD*)(expect + 2) = 0;
                *(LPVOID*)(expect + 6) = (LPVOID)&hook_LoadLibraryExW;
                bool intact = true;
                __try {
                    intact = (memcmp(g_hpLoadExW.target, expect, 14) == 0);
                } __except (EXCEPTION_EXECUTE_HANDLER) {
                    intact = true;                 // 读不到 ⇒ 本拍跳过，绝不误重打
                }
                if (!intact) {
                    if (!applyHotPatchBytes(&g_hpLoadExW, (LPVOID)&hook_LoadLibraryExW)) {
                        g_hpLoadExW.installed = 0;
                    }
                    g_daemonRehooks++;
                }
                HOTPATCH_END();
            }
            // c) 句柄兜底低频探测（每 10 拍 ≈ 2s）
            if (!g_realInstrumentation && !g_handleGiveUp && (g_daemonTicks % 10) == 0) {
                capture_real_instrumentation();
            }
        GUARD_END_INT(0)
        // d) 回调 Java 侧自保 tick（每 5 拍 ≈ 1s；无绑定则跳过）
        if (g_tickClass && g_tickMethod && (g_daemonTicks % 5) == 0) {
            JNIEnv* env = nullptr;
            if (g_vm && g_vm->AttachCurrentThread((void**)&env, nullptr) == JNI_OK && env) {
                env->CallStaticVoidMethod(g_tickClass, g_tickMethod);
                if (env->ExceptionCheck()) env->ExceptionClear();
                g_daemonTicksJava++;
                g_vm->DetachCurrentThread();
            }
        }
    }
    return 0;  // 不可达
}

// ============================================================================
// LdrLoadDll 坏参数 VEH 修正（学习自样板 guard.cpp：ResolveLdrLoadDllSites /
// LdrLoadDllFaultProbe / IsUsableUnicodeString）
//
// 血证（样板实测）：MinHook 内联 hook ntdll!LdrLoadDll 后，本环境（Windows 11 + 该 JVM）
// 的调用会带"高 32 位被截断的 rdx"，LdrLoadDll+0x64 处 `mov r9d,[rdx]` 读坏地址
// ⇒ 加载失败（我方现象：lwjgl.dll 127 "找不到指定的程序"）。
// 修法：在崩溃点捕获 AV —— rdx 截断且 `r8+0x30` 是合法 UNICODE_STRING 时把 rdx 修正为它
// （调用继续）；否则把 rdx 指向静态零值 UNICODE_STRING（可控失败、不崩）。
// 只修正参数、不削弱拦截（detour 语义一字未动）。
// ============================================================================
static ULONG_PTR g_ldrEntry = 0;
static ULONG_PTR g_ldrCrashSite = 0;
static bool g_ldrResolved = false;
static bool g_ldrVehInstalled = false;
static volatile long g_ldrFixCount = 0;
static volatile long g_ldrSafeFail = 0;

static void ResolveLdrLoadDllSites() {
    if (g_ldrResolved) return;
    g_ldrResolved = true;
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll) return;
    FARPROC p = GetProcAddress(ntdll, "LdrLoadDll");
    if (!p) return;
    g_ldrEntry = (ULONG_PTR)p;
    __try {
        const BYTE* q = (const BYTE*)g_ldrEntry;
        for (int off = 0; off < 0x100; ++off) {
            // 指令模式 `74 ?? 44 8B 0A`（je short + mov r9d,[rdx]）
            if (q[off] == 0x74 && q[off + 2] == 0x44 && q[off + 3] == 0x8B && q[off + 4] == 0x0A) {
                g_ldrCrashSite = g_ldrEntry + (ULONG_PTR)off + 2;
                return;
            }
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        g_ldrCrashSite = 0;
    }
}

static bool IsUsableUnicodeString(const void* p) {
    if (!p) return false;
    __try {
        const unsigned short len = *(const unsigned short*)p;
        const unsigned short max = *((const unsigned short*)p + 1);
        const void* buf = *((const void**)p + 1);
        if (max == 0 && len == 0) return true;   // 空字符串合法
        if (len > max || max > 0x7FFF) return false;
        if (buf == nullptr && len != 0) return false;
        if (buf != nullptr) {
            volatile unsigned short probe = *(const unsigned short*)buf;
            (void)probe;
        }
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static LONG CALLBACK LdrLoadDllFaultProbe(EXCEPTION_POINTERS* ep) {
    if (!ep || !ep->ExceptionRecord || !ep->ContextRecord) return EXCEPTION_CONTINUE_SEARCH;
    if (ep->ExceptionRecord->ExceptionCode != EXCEPTION_ACCESS_VIOLATION) return EXCEPTION_CONTINUE_SEARCH;
    ResolveLdrLoadDllSites();
    if (g_ldrCrashSite == 0) return EXCEPTION_CONTINUE_SEARCH;
    const ULONG_PTR pc = (ULONG_PTR)ep->ExceptionRecord->ExceptionAddress;
    if (pc != g_ldrCrashSite) return EXCEPTION_CONTINUE_SEARCH;
    CONTEXT* c = ep->ContextRecord;
    const ULONG_PTR rdx = (ULONG_PTR)c->Rdx;
    if (rdx == 0 || rdx > 0xFFFFFFFFULL) return EXCEPTION_CONTINUE_SEARCH;  // 只修"截断形态"
    const ULONG_PTR cand = (ULONG_PTR)c->R8 + 0x30ULL;
    if (IsUsableUnicodeString((const void*)cand)) {
        c->Rdx = (DWORD64)cand;
        g_ldrFixCount++;
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    // 【对齐样板：候选不可信 ⇒ 绝不硬修】
    // 校验不过就把异常按原样交给上层（`EXCEPTION_CONTINUE_SEARCH`），
    // **绝不**把 rdx 指到"空 UNICODE_STRING"——那会让加载器拿空名去解析，
    // 产生 `Can't find dependent libraries` 这种假失败（把别人的错算到自己头上）。
    // 宁可维持现状（可能在别处失败/被上层处理），也不拿猜测改寄存器。
    g_ldrSafeFail++;
    return EXCEPTION_CONTINUE_SEARCH;
}

static void InstallLdrFaultProbe() {
    if (g_ldrVehInstalled) return;
    g_ldrVehInstalled = true;
    // ⚠️ 必须在**任何 hook 落补丁之前**扫描崩溃点：`ResolveLdrLoadDllSites` 从
    // `GetProcAddress(ntdll,"LdrLoadDll")` 的入口起扫 `74 ?? 44 8B 0A`；一旦我方
    // （或第三方）已经把入口前几字节换成 `E9`，这条扫描就再也找不到崩溃点 ⇒
    // VEH 形同未装 ⇒ 样板记载的"截断 rdx 确定性崩溃"会原样复现。
    ResolveLdrLoadDllSites();
    AddVectoredExceptionHandler(1, LdrLoadDllFaultProbe);
}

static void buildPrefixes() {
    wchar_t dir[MAX_PATH * 2] = { 0 };
    GetCurrentDirectoryW(MAX_PATH * 2, dir);
    _snwprintf_s(g_modsPrefix, 1024, _TRUNCATE, L"%s\\mods\\", dir);
    _snwprintf_s(g_nativesPrefix, 1024, _TRUNCATE, L"%s\\natives\\", dir);
    _snwprintf_s(g_gameDir, 1024, _TRUNCATE, L"%s", dir);
    // 可信系统目录（缓存，GDI 判据热路径只做字符串比较）
    if (GetSystemDirectoryW(g_sysDir, 1024) == 0) g_sysDir[0] = L'\0';
    if (GetWindowsDirectoryW(g_winDir, 1024) == 0) g_winDir[0] = L'\0';
    // JDK 根：jvm.dll 位于 <jdk>\bin\server\jvm.dll ⇒ 去掉最后两段
    {
        HMODULE jvmMod = GetModuleHandleW(L"jvm.dll");
        wchar_t jp[MAX_PATH * 2] = { 0 };
        if (jvmMod && GetModuleFileNameW(jvmMod, jp, MAX_PATH * 2) > 0) {
            for (int k = 0; k < 2; ++k) {
                wchar_t* s = wcsrchr(jp, L'\\');
                if (!s) break;
                *s = L'\0';
            }
            _snwprintf_s(g_javaHome, 1024, _TRUNCATE, L"%s", jp);
        }
    }
    // 我方目录 = 本 DLL 所在目录（echoes-native）
    wchar_t self[MAX_PATH * 2] = { 0 };
    HMODULE selfMod = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)&buildPrefixes, &selfMod);
    if (selfMod) {
        GetModuleFileNameW(selfMod, self, MAX_PATH * 2);
        wchar_t* slash = wcsrchr(self, L'\\');
        if (slash) {
            slash[1] = L'\0';
            _snwprintf_s(g_ownDir, 1024, _TRUNCATE, L"%s", self);
        }
    }
}

// ============================================================================
// JNI 导出
// ============================================================================
extern "C" JNIEXPORT jboolean JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nInit(JNIEnv*, jclass) {
    GUARD_BEGIN
        buildPrefixes();
        // ① VEH 必须**先于任何 hook 落补丁**装配（对齐样板 guard.cpp）：
        //    `ResolveLdrLoadDllSites` 要从 `ntdll!LdrLoadDll` 的**原始入口**扫描崩溃点
        //    `74 ?? 44 8B 0A`；一旦入口先被换成 `E9`，扫描就永远找不到 ⇒ VEH 形同未装
        //    ⇒ 样板记载的"高 32 位被截断的 rdx ⇒ LdrLoadDll+0x64 确定性崩溃"会原样复现
        //    （实测表现：`lwjgl.dll: 找不到指定的程序` / `Can't find dependent libraries`）。
        InstallLdrFaultProbe();
        const bool mh = EchoMinHookLoad(&g_mh, (const void*)&buildPrefixes);
        if (!mh) return JNI_FALSE;
        char initDiag[320];
        // 【实证】把两个目标的"原始入口 / 解包后地址 / 入口前 8 字节"记下来。
        // 这是区分"入口被第三方改写成 E9/FF25（解包可能误判）"与"入口是原始序言"的唯一证据，
        // 也顺便确认 `ResolveLdrLoadDllSites` 扫到的崩溃点偏移是否合理。
        {
            HMODULE nt = GetModuleHandleW(L"ntdll.dll");
            HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
            LPVOID pLdr = nt ? (LPVOID)GetProcAddress(nt, "LdrLoadDll") : nullptr;
            LPVOID pExW = k32 ? (LPVOID)GetProcAddress(k32, "LoadLibraryExW") : nullptr;
            BYTE bL[8] = { 0 }, bE[8] = { 0 };
            if (pLdr) { __try { memcpy(bL, pLdr, 8); } __except (EXCEPTION_EXECUTE_HANDLER) { } }
            if (pExW) { __try { memcpy(bE, pExW, 8); } __except (EXCEPTION_EXECUTE_HANDLER) { } }
            LPVOID aL = pLdr ? EchoResolveForwarderTarget(pLdr) : nullptr;
            LPVOID aE = pExW ? EchoResolveForwarderTarget(pExW) : nullptr;
            _snprintf_s(initDiag, sizeof(initDiag), _TRUNCATE,
                        "entry scan: LdrLoadDll=%p bytes=%02X %02X %02X %02X %02X %02X %02X %02X actual=%p crashSite=+0x%llX veh=%d",
                        pLdr, bL[0], bL[1], bL[2], bL[3], bL[4], bL[5], bL[6], bL[7], aL,
                        (unsigned long long)(g_ldrCrashSite && g_ldrEntry ? (g_ldrCrashSite - g_ldrEntry) : 0ULL),
                        g_ldrVehInstalled ? 1 : 0);
            diagLog(initDiag);
            if (pExW) {
                _snprintf_s(initDiag, sizeof(initDiag), _TRUNCATE,
                            "entry scan: LoadLibraryExW=%p bytes=%02X %02X %02X %02X %02X %02X %02X %02X actual=%p",
                            pExW, bE[0], bE[1], bE[2], bE[3], bE[4], bE[5], bE[6], bE[7], aE);
                diagLog(initDiag);
            }
        }
        // ② 立即武装：`LdrLoadDll`（MinHook trampoline）。
        //    为什么它可以在最早的 `IWP <clinit>` 链内装：trampoline 是"入口一条 jmp，
        //    原指令搬进跳板"，**没有"还原-调用-重打"窗口** ⇒ 并发调用永不撕裂 ⇒ 最早装是安全的。
        //    而且 HotSpot 的 `os::dll_load` 就是走 `LdrLoadDll` ⇒ 一条即可覆盖全部 dll 加载。
        bool ok = false;
        if (g_ldrHookWanted) {
            ok = EchoMinHookInstall(&g_mh, L"ntdll.dll", "LdrLoadDll",
                                    (LPVOID)&hook_LdrLoadDll, (LPVOID*)&g_origLdrLoadDll);
        }
        // ③ `kernel32!LoadLibraryExW` 的**热补丁必须延后**（对齐样板 `SetupApiHooks` 的时机）：
        //    热补丁范式是"还原原 14 字节 → 调用原入口 → 重打 14 字节"，那 14 字节**无法原子写**。
        //    启动早期（GLFW / opengl32 / JVM 同时高频加载 dll）多线程并发撞上重打窗口 ⇒
        //    执行半截跳转 ⇒ 实测表现：`WGL: The driver does not appear to support OpenGL`。
        //    ⇒ 交给守护线程在启动高峰之后（≈1s）补装；期间的加载拦截由 `LdrLoadDll` 全量覆盖。
        char tail[256];
        _snprintf_s(tail, sizeof(tail), _TRUNCATE,
                    "nInit done LdrLoadDll=%p veh=%d crashSite=+0x%llX hotpatch=0(delayed)",
                    (void*)g_origLdrLoadDll, g_ldrVehInstalled ? 1 : 0,
                    (unsigned long long)(g_ldrCrashSite && g_ldrEntry ? (g_ldrCrashSite - g_ldrEntry) : 0ULL));
        diagLog(tail);
        return ok ? JNI_TRUE : JNI_FALSE;
    GUARD_END_BOOL
    return JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nSetLoadBlock(JNIEnv*, jclass, jboolean on, jboolean pathBlock,
                                                    jboolean ldrHook) {
    g_loadBlockOn = (on != JNI_FALSE);
    g_pathBlockOn = (pathBlock != JNI_FALSE);
    g_ldrHookWanted = (ldrHook != JNI_FALSE);
    // 运行期改开关只影响判据；装配本身由 nInit / 守护线程统一负责（幂等）。
    // 唯一需要"事后补装"的是 LdrLoadDll（它受 ldrHook 门控，且 nInit 时可能尚未开）。
    if (g_ldrHookWanted && !g_origLdrLoadDll && g_daemonOn && g_daemonTicks > 0) {
        GUARD_BEGIN
            if (EchoMinHookLoad(&g_mh, (const void*)&buildPrefixes)) {
                EchoMinHookInstall(&g_mh, L"ntdll.dll", "LdrLoadDll",
                                   (LPVOID)&hook_LdrLoadDll, (LPVOID*)&g_origLdrLoadDll);
            }
        GUARD_END_VOID
    }
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nSetBlockedHashes(JNIEnv* env, jclass, jstring csv) {
    if (!env) return 0;
    LOCK_BEGIN();
    g_hashCount = 0;
    if (csv) {
        const char* s = env->GetStringUTFChars(csv, nullptr);
        if (s) {
            const char* p = s;
            while (*p && g_hashCount < 64) {
                while (*p == ',' || *p == ' ' || *p == '\r' || *p == '\n' || *p == '\t') ++p;
                if (!*p) break;
                const char* start = p;
                while (*p && *p != ',') ++p;
                if ((size_t)(p - start) == 64) {
                    char* dst = g_hashList[g_hashCount];
                    for (size_t i = 0; i < 64; ++i) {
                        char c = start[i];
                        if (c >= 'A' && c <= 'F') c = (char)(c - 'A' + 'a');
                        dst[i] = c;
                    }
                    dst[64] = 0;
                    g_hashCount++;
                }
            }
            env->ReleaseStringUTFChars(csv, s);
        }
    }
    LOCK_END();
    return (jint)g_hashCount;
}
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nArmRendering(JNIEnv*, jclass, jint gdiMode,
                                                    jboolean lowLevel, jboolean hotApi) {
    g_gdiMode = (int)gdiMode;
    g_lowLevelHookOn = (lowLevel != JNI_FALSE);
    g_hotApiHookOn = (hotApi != JNI_FALSE);
    return (jint)armRenderHooks();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nToggleGdiForce(JNIEnv*, jclass) {
    // 切换 GDI 全吞（force ⇄ off）：仅供"摧毁渲染"物品调用。
    // `g_gdiMode == 2` ⇒ 所有 `gdi32!SwapBuffers` 直接返回 TRUE 不交换 ⇒ 整屏白屏；
    // 再切回 0 ⇒ 纯转发 ⇒ 画面恢复。装配是幂等的（`armRenderHooks` 内判据已装则直返），
    // 所以这里只需改模式 + 确保 hook 在位。
    const int prev = g_gdiMode;
    const int next = (prev == 2) ? 0 : 2;
    g_gdiMode = next;                       // 先落模式，再确保 hook 在位
    const int armed = armRenderHooks();
    {
        char dbg[192];
        _snprintf_s(dbg, sizeof(dbg), _TRUNCATE,
                    "toggleGdiForce: %d -> %d (armRenderHooks=%d gdiHook=%p)",
                    prev, next, armed, (void*)g_origSwapBuffers);
        diagLog(dbg);
    }
    return (jint)g_gdiMode;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nGetGdiMode(JNIEnv*, jclass) {
    return (jint)g_gdiMode;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nArmDaemon(JNIEnv* env, jclass, jboolean hide,
                                                 jint priority, jint periodMs, jclass tickClass) {
    g_daemonHide = (hide != JNI_FALSE);
    g_daemonPrio = (int)priority;
    g_daemonPeriodMs = (int)periodMs;
    if (env && tickClass) {
        if (g_tickClass) { env->DeleteGlobalRef(g_tickClass); g_tickClass = nullptr; g_tickMethod = nullptr; }
        g_tickClass = (jclass)env->NewGlobalRef(tickClass);
        if (g_tickClass) {
            g_tickMethod = env->GetStaticMethodID(g_tickClass, "nativeTick", "()V");
            if (!g_tickMethod && env->ExceptionCheck()) env->ExceptionClear();
        }
    }
    if (!g_daemonOn) {
        g_daemonThread = CreateThread(nullptr, 0, daemon_thread, nullptr, 0, nullptr);
        g_daemonOn = g_daemonThread != nullptr;
    }
    return g_daemonOn ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nArmInjection(JNIEnv*, jclass, jboolean on) {
    g_injectionGuardOn = (on != JNI_FALSE);
    if (!g_injectionGuardOn) {
        return 0;                       // 关：detour 全部纯转发（零行为差）
    }
    return (jint)armInjectionGuards();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nInjectionStatus(JNIEnv* env, jclass) {
    char buf[256];
    _snprintf_s(buf, sizeof(buf), _TRUNCATE, "on=%d armed=%d calls=%ld denied=%ld",
                g_injectionGuardOn ? 1 : 0, g_injArmed, (long)g_injCalls, (long)g_injDenied);
    return env ? env->NewStringUTF(buf) : nullptr;
}


extern "C" JNIEXPORT jstring JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nStatus(JNIEnv* env, jclass) {
    char buf[720];
    _snprintf_s(buf, sizeof(buf), _TRUNCATE,
                "loadBlock=%d pathBlock=%d hashes=%ld loadCalls=%ld denied=%ld badParam=%ld "
                "pathHits=%ld hashHits=%ld "
                "glSwap=%ld gdiBlocked=%ld lowHook=%ld hotThread=%ld handle=%ld diag=%s | "
                "daemon=%d prio=%d period=%d ticks=%ld recheck=%ld rehook=%ld tickJava=%ld",
                g_loadBlockOn ? 1 : 0, g_pathBlockOn ? 1 : 0, (long)g_hashCount,
                (long)g_loadCalls, (long)g_loadDenied, (long)g_ldrBadParam,
                (long)g_pathHits, (long)g_hashHits,
                (long)g_glSwapCalls, (long)g_gdiSwapBlocked, (long)g_lowHookCalls,
                (long)g_hotThreadCalls, (long)g_handleHits, g_handleDiag,
                g_daemonOn ? 1 : 0, g_daemonPrio, g_daemonPeriodMs,
                (long)g_daemonTicks, (long)g_daemonRechecks, (long)g_daemonRehooks,
                (long)g_daemonTicksJava);
    return env ? env->NewStringUTF(buf) : nullptr;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nProbeHandleNow(JNIEnv*, jclass) {
    return (jint)capture_real_instrumentation();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nHasRealInstrumentation(JNIEnv*, jclass) {
    return g_realInstrumentation ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nTakeRealInstrumentation(JNIEnv*, jclass) {
    return g_realInstrumentation;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_echoxy_agent_EchoNativeGuard_nHandleDiag(JNIEnv* env, jclass) {
    return env ? env->NewStringUTF(g_handleDiag) : nullptr;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_8;
}
