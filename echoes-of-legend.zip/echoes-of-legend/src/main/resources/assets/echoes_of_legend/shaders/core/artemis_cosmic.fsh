#version 150

#define M_PI 3.1415926535897932384626433832795

#moj_import <fog.glsl>

// 物品图集：剑贴图本身即蒙版（**贴图为白色的像素** = 星空覆盖区）
uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

uniform float time;
uniform float yaw;
uniform float pitch;
// 【2026-10-18】opacity 已按用户要求退出最终 alpha 计算（改为白色区直接 alpha=1.0，
// 好让"白色被星空完全覆盖、不露底色"）。声明与 json 条目一并移除，
// 否则 GLSL 会把它优化掉、MC 打 "could not find uniform" 警告。
uniform vec4 cosmicColor0;

in float vertexDistance;
in vec2 texCoord0;
in vec3 fPos;

out vec4 fragColor;

float hash(float n) {
    return fract(sin(n * 127.1) * 43758.5453);
}

vec3 hash3(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
    p *= 17.0;
    return fract(p * (p.x + p.y + p.z)) * 2.0 - 1.0;
}

float perlinNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float n000 = dot(hash3(i + vec3(0.0, 0.0, 0.0)), f - vec3(0.0, 0.0, 0.0));
    float n100 = dot(hash3(i + vec3(1.0, 0.0, 0.0)), f - vec3(1.0, 0.0, 0.0));
    float n010 = dot(hash3(i + vec3(0.0, 1.0, 0.0)), f - vec3(0.0, 1.0, 0.0));
    float n110 = dot(hash3(i + vec3(1.0, 1.0, 0.0)), f - vec3(1.0, 1.0, 0.0));
    float n001 = dot(hash3(i + vec3(0.0, 0.0, 1.0)), f - vec3(0.0, 0.0, 1.0));
    float n101 = dot(hash3(i + vec3(1.0, 0.0, 1.0)), f - vec3(1.0, 0.0, 1.0));
    float n011 = dot(hash3(i + vec3(0.0, 1.0, 1.0)), f - vec3(0.0, 1.0, 1.0));
    float n111 = dot(hash3(i + vec3(1.0, 1.0, 1.0)), f - vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
}

mat4 rotationMatrix(vec3 axis, float angle) {
    axis = normalize(axis);
    float s = sin(angle);
    float c = cos(angle);
    float oc = 1.0 - c;
    return mat4(oc * axis.x * axis.x + c,         oc * axis.x * axis.y - axis.z * s, oc * axis.z * axis.x + axis.y * s, 0.0,
                oc * axis.x * axis.y + axis.z * s, oc * axis.y * axis.y + c,         oc * axis.y * axis.z - axis.x * s, 0.0,
                oc * axis.z * axis.x - axis.y * s, oc * axis.y * axis.z + axis.x * s, oc * axis.z * axis.z + c,         0.0,
                0.0, 0.0, 0.0, 1.0);
}

void main(void) {
    vec4 mask = texture(Sampler0, texCoord0);

    // 【2026-10-18 用户第 1 条】星空**只应用在贴图是白色的部分**（原来是 max(mask.r, mask.a)
    //   ⇒ 等价于 "凡是不透明像素全画星空"，整把剑连同剑柄都被星空糊住，且叠在原模型上
    //   会看成"第二个模型"）。
    //   白度 = 三通道最小值：纯白 (1,1,1) 得 1.0，任何有色通道都会把它拉低。
    //   artnew.png（32x32，不透明像素 214 个）实测白度分布完全分化，中间无过渡像素：
    //       min=255    -> 107 px（50%，剑身刃部正中，纯 255,255,255）
    //       min=0      ->  68 px（轮廓/描边，纯黑）
    //       min<=51    ->  32 px（剑柄与护手的蓝、青系装饰）
    //       min=153/162->   7 px（浅色反光点）
    //   ⇒ 0.64 与 1.00 之间是真空档，阈值取 0.75~0.94 可干净切分，且不会被驱动采样抖动影响：
    //     剑身白色 -> 全额星空；剑柄/护手/轮廓 -> 完全无星空，保持原贴图外观。
    //   采样状态是 NEAREST（blur=false, mipmap=false）⇒ 不存在插值把白色"渗"进彩色区。
    float whiteness = min(min(mask.r, mask.g), mask.b);
    float whiteMask = smoothstep(0.75, 0.94, whiteness);
    // 只保留贴图本身的可见性（透明像素不画），白色区域 alpha 直接到 1.0
    // ⇒ 用户第 1 条"完全覆盖白色，不要看到底色"：白色刀刃被星空实心盖住，不半透。
    float maskCover = whiteMask * mask.a;

    // 视线方向 -> 相机 yaw/pitch 反向旋转 -> 天空球方向（星空随视角转动 = 视差）
    vec3 dir = normalize(vec3(-fPos.x, -fPos.y, -fPos.z));
    float sb = sin(pitch);
    float cb = cos(pitch);
    dir = normalize(vec3(dir.x, dir.y * cb - dir.z * sb, dir.y * sb + dir.z * cb));
    float sa = sin(-yaw);
    float ca = cos(-yaw);
    dir = normalize(vec3(dir.z * sa + dir.x * ca, dir.y, dir.z * ca - dir.x * sa));

    // 深蓝底色 + 程序化星云（缓慢流动）
    vec3 col = cosmicColor0.rgb * 0.5;
    float neb1 = perlinNoise(dir * 1.7 + vec3(time * 0.012, time * 0.007, 0.0));
    float neb2 = perlinNoise(dir * 3.4 - vec3(0.0, time * 0.010, time * 0.006));
    col += cosmicColor0.rgb * (neb1 * neb1 * 0.55 + neb2 * neb2 * 0.25);
    col += vec3(0.02, 0.03, 0.08);

    // 细密星尘（每像素随机稀疏亮点）
    float dust = pow(fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453), 42.0);
    col += vec3(0.55, 0.6, 0.8) * dust * 0.8;
    float dust2 = pow(fract(sin(dot(gl_FragCoord.xy * 1.73 + 0.31, vec2(12.9898, 78.233))) * 43758.5453), 120.0);
    col += vec3(1.0) * dust2 * 1.1;

    // 16 层星星网格：层缩放不同 -> 视差不同（立体厚度），正弦闪烁
    for (int i = 0; i < 16; i++) {
        int mult = 16 - i;
        int j = i + 7;
        float rand1 = (j * j * 4321.0 + j * 8.0) * 2.0;
        int k = j + 1;
        float rand2 = (k * k * k * 239.0 + k * 37.0) * 3.6;
        float rand3 = rand1 * 347.4 + rand2 * 63.4;
        vec3 axis = normalize(vec3(sin(rand1), sin(rand2), cos(rand3)));
        // 显式 vec4 行向量乘法（避免 vec3*mat4 的驱动重载歧义）
        vec4 ray4 = vec4(dir, 0.0) * rotationMatrix(axis, mod(rand3, 2.0 * M_PI));
        vec3 ray = normalize(ray4.xyz);
        float rawu = 0.5 + (atan(ray.z, ray.x) / (2.0 * M_PI));
        float rawv = 0.5 + (asin(ray.y) / M_PI);
        float scale = mult * 0.5 + 2.75;
        float u = rawu * scale;
        float v = rawv * scale * 0.6;
        int tu = int(mod(floor(u * 16.0), 16.0));
        int tv = int(mod(floor(v * 16.0), 16.0));
        int position = ((171 * tu) + (489 * tv) + (303 * (i + 31)) + 17209) ^ 10086;
        int symbol = int(mod(float(position), 81.0));
        if (symbol >= 0 && symbol < 10) {
            float ru = clamp(mod(u, 1.0) * 16.0 - float(tu), 0.0, 1.0);
            float rv = clamp(mod(v, 1.0) * 16.0 - float(tv), 0.0, 1.0);
            // 程序化星形（圆斑 + 十字光芒），替代贴图星形图元
            vec2 c = vec2(ru, rv) - 0.5;
            float glyph = pow(max(0.0, 1.0 - length(c) / 0.30), 3.0);
            float cross = pow(max(0.0, 1.0 - abs(c.x) / 0.07), 2.0) * pow(max(0.0, 1.0 - abs(c.y) / 0.45), 2.0)
                        + pow(max(0.0, 1.0 - abs(c.y) / 0.07), 2.0) * pow(max(0.0, 1.0 - abs(c.x) / 0.45), 2.0);
            float tcol = glyph * 0.9 + cross * 1.0;
            float a = tcol * (0.5 + (1.0 / float(mult)) * 1.0) * (1.0 - smoothstep(0.15, 0.48, abs(rawv - 0.5)));
            // 【2026-09-19 用户第 2 条】星点颜色跟随 cosmicColor0（Java 侧由 EchoesHue 循环色相给出，
            // 与彩字共用同一取色来源）⇒ "剑的星空会变色、渐变，和彩字一样"；原闪烁节奏保留
            vec3 starTint = mix(vec3(0.85, 0.90, 1.0), normalize(cosmicColor0.rgb + vec3(0.001)), 0.65);
            vec3 starColor = starTint;
            starColor *= 0.72 + 0.28 * sin(time * (0.8 + 0.4 * hash(rand1 * 0.13)) + rand2);
            col += starColor * a * 1.35;
        }
    }

    col *= ColorModulator.rgb;
    col *= 1.35;
    // 【2026-10-18 用户第 1 条】不再乘 opacity(0.85) —— 用户要求"白色要被星空完全覆盖、
    //   不要看到底色"。半透明会让下面原模型的白色透上来，看起来像"白底 + 一层星空"。
    //   现在白色区域 alpha = 1.0（实心盖住），只有 smoothstep 过渡带与贴图透明处才 < 1。
    vec4 finalColor = vec4(clamp(col, 0.0, 1.0), maskCover);
    fragColor = linear_fog(finalColor * 1.25, vertexDistance, FogStart, FogEnd, FogColor);
}
