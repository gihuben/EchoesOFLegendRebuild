#version 150

/*
 * echoes_pulsar.vsh —— 中子星（脉冲星）特效的顶点着色器（2026-10-18）
 *
 * 与 echoes_vortex.vsh 保持完全一致的接口：Java 侧只画一个覆盖特效区的 quad，
 * 所有图形都在片元着色器里按像素坐标算，所以顶点阶段只做最基本的坐标系投影。
 *
 * 【为什么必须给 vertexColor 赋值】artemis_cosmic.vsh 曾漏掉这一行导致顶点色全 0
 * （片元里乘上去就黑掉了）；这里显式透传，避免同类问题。
 */

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    texCoord0 = UV0;
}
