#version 150

/*
 * echoes_sword_gui.vsh —— tooltip 里那柄「立体星空剑」的顶点着色器（2026-10-18）
 *
 * 走的是镜花 FullscreenSwordTooltipRenderer 的那条路：把**真实的 BakedModel 几何**
 * 送进 GUI 里画（不是贴图四边形），因此这里是标准的物品顶点格式
 * （Position / Color / UV0 / UV2 / Normal），与 BLOCK 顶点格式逐字段一致。
 *
 * 与 artemis_cosmic.vsh 的区别：这里**不做 fog**。
 * GUI 上下文里 FogStart/FogEnd 是默认值（0 / 1），若沿用线雾公式会把整柄剑算成
 * FogColor（全黑）—— 这正是"世界里好看、tooltip 里全黑"的经典陷阱。
 */

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    texCoord0 = UV0;
}
