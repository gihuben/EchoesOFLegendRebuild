#version 150

/*
 * ==========================================================================
 * echoes_sword_gui.fsh —— tooltip 中央那柄「立体星空剑」（2026-10-18）
 * ==========================================================================
 *
 * 【用户规格】
 *  ① "原本的展示 ARTEMIS 的贴图去掉，改成渲染立体的模型（参考镜花的实现）"
 *     "模型大小（剑的最长长度）和脉冲星的直径一样大" —— 由 Java 侧的 scale 保证。
 *  ② "模型会旋转" —— Java 侧 Axis.YP 自转。
 *  ③ 【2026-10-18 用户第 1 条】"我的旋转剑的模型的星空渲染部分和手持的同步
 *     （即变色和星空类型）" ⇒
 *       · 变色：`tint` 由 Java 侧用 `EchoesHue.hueToRgb(cycleHue(t, COSMIC_SPEED))` 驱动，
 *               与手持星空（ArtemisCosmicRenderer）走**同一个取色函数、同一速率**，
 *               所以两处同时变色、节奏完全一致。
 *       · 星空类型：本文件**原样搬用** artemis_cosmic.fsh 的 16 层视差星点网格算法
 *               （层间缩放递变 ⇒ 视差厚度；球面格点哈希 ⇒ 稀疏星；程序化圆斑+十字光芒；
 *                逐层正弦闪烁），保证"看起来是同一片星空"而不是另一种斑点。
 *
 * 【为什么是一个 pass 而不是两遍】
 *  手持时的星空是"原贴图 + 白色区叠星空"两层。GUI 里若也画两遍，就必须把
 *  ItemRenderer.render 内部的 display 变换完全复现两遍，差一点就错位。
 *  这里把两层合进**一个片元**：采样物品图集 → 白度蒙版 → 白色区替换成星空。
 *  一遍画完，天然不可能错位。
 *
 * 【白度蒙版与 artemis_cosmic.fsh 同一条判据】
 *  whiteness = min(R,G,B)，smoothstep(0.75, 0.94)。
 *  依据 artnew.png 实测：纯白 107/214（剑身刃部），其余 ≤51（轮廓/剑柄），
 *  中间是 0.64~1.00 的真空档 ⇒ 切得干净，彩色部分不会被误染。
 *
 * 【方向怎么来（关键）】
 *  手持那份用 `fPos`（相机空间位置）normalize 成方向。GUI 里没有相机视角，
 *  这里用**屏幕坐标**构造一个伪球面方向，并随 time 极缓慢平移/旋转 ⇒
 *  星空相对屏幕稳定，剑转过去时像"透过剑身看见同一片星海"，
 *  而不是把图案钉死在贴图上（那会看起来像印花）。
 *
 * 【关键陷阱】GUI 下没有 fog。本文件**刻意不 import fog.glsl**，
 *  否则 FogEnd=1 会把整柄剑算成全黑（世界里那份不能直接搬过来，这是原因）。
 */

const float PI  = 3.14159265359;
const float TAU = 6.28318530718;

uniform sampler2D Sampler0;    // 物品图集（剑的贴图就在里面）
uniform vec4 ColorModulator;
uniform float time;
uniform vec4  tint;            // 由 EchoesHue 驱动 ⇒ 与手持星空同时变色
uniform float opacity;

in vec4 vertexColor;
in vec2 texCoord0;
out vec4 fragColor;

float hash1(float n) {
    return fract(sin(n * 127.1) * 43758.5453);
}

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm2(vec2 p) {
    float s = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; ++i) {
        s += a * vnoise(p);
        p *= 2.03;
        a *= 0.5;
    }
    return s;
}

/* 与 artemis_cosmic.fsh 同款的轴角旋转矩阵（显式 vec4 行乘，避开驱动重载歧义） */
mat4 rotationMatrix(vec3 axis, float angle) {
    axis = normalize(axis);
    float s = sin(angle);
    float c = cos(angle);
    float oc = 1.0 - c;
    return mat4(oc * axis.x * axis.x + c,         oc * axis.x * axis.y - axis.z * s, oc * axis.z * axis.x + axis.y * s, 0.0,
                oc * axis.x * axis.y + axis.z * s, oc * axis.y * axis.y + c,         oc * axis.y * axis.z - axis.x * s, 0.0,
                oc * axis.z * axis.x - axis.y * s, oc * axis.y * axis.z + axis.x * s, oc * axis.z * axis.z + c,         0.0,
                0.0, 0.0, 0.0, 1.0);
}

void main(void) {
    vec4 tex = texture(Sampler0, texCoord0);

    // 贴图透明处直接丢弃 ⇒ 保持剑的轮廓（不是一块方片）
    if (tex.a < 0.05) {
        discard;
    }

    // 白度蒙版：只有"贴图上是白色"的像素才叠星空（与 artemis_cosmic.fsh 同判据）
    float whiteness = min(min(tex.r, tex.g), tex.b);
    float whiteMask = smoothstep(0.75, 0.94, whiteness);

    /* ---------- 星空：与手持（artemis_cosmic.fsh）完全同款的 16 层视差星点 ---------- */

    // 屏幕坐标 -> 伪球面方向（随 time 极缓慢旋转，模拟手持时视角的微动）
    // 系数 0.010 是实测校准值：太小 ⇒ dir 几乎恒定 ⇒ 剑身上只有一两颗星；
    // 太大 ⇒ 星星被拉成条纹。0.010 时一柄剑（约 200 像素）恰好横跨 2~3 个星格。
    vec2 sp = gl_FragCoord.xy * 0.010;
    vec3 dir = normalize(vec3(sp, 2.0));
    float yawA = time * 0.035;
    float sy = sin(yawA);
    float cy = cos(yawA);
    dir = normalize(vec3(dir.z * sy + dir.x * cy, dir.y, dir.z * cy - dir.x * sy));

    // 星云底（两层不同速度 fbm，缓慢流动）—— 与手持同一取色源 tint
    float neb1 = fbm2(sp * 5.5 + vec2(time * 0.075, time * 0.030));
    float neb2 = fbm2(sp * 11.0 - vec2(0.0, time * 0.055));
    vec3 col = tint.rgb * 0.16;
    col += tint.rgb * (neb1 * neb1 * 0.62 + neb2 * neb2 * 0.26);
    col += vec3(0.015, 0.022, 0.055);

    // 细密星尘（每像素随机稀疏亮点，与手持同款两层）
    float dust1 = pow(fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453), 42.0);
    col += vec3(0.55, 0.60, 0.80) * dust1 * 0.75;
    float dust2 = pow(fract(sin(dot(gl_FragCoord.xy * 1.73 + 0.31, vec2(12.9898, 78.233))) * 43758.5453), 120.0);
    col += vec3(1.0) * dust2 * 1.05;

    // 16 层星星：层缩放不同 ⇒ 视差不同（立体厚度）；球面格点哈希决定哪里有星；
    // 程序化"圆斑 + 十字光芒"当星形；逐层正弦闪烁。**逐行与 artemis_cosmic.fsh 对齐。**
    for (int i = 0; i < 16; i++) {
        int mult = 16 - i;
        int j = i + 7;
        float rand1 = (float(j) * float(j) * 4321.0 + float(j) * 8.0) * 2.0;
        int k = j + 1;
        float rand2 = (float(k) * float(k) * float(k) * 239.0 + float(k) * 37.0) * 3.6;
        float rand3 = rand1 * 347.4 + rand2 * 63.4;
        vec3 axis = normalize(vec3(sin(rand1), sin(rand2), cos(rand3)));
        vec4 ray4 = vec4(dir, 0.0) * rotationMatrix(axis, mod(rand3, TAU));
        vec3 ray = normalize(ray4.xyz);
        float rawu = 0.5 + (atan(ray.z, ray.x) / TAU);
        float rawv = 0.5 + (asin(ray.y) / PI);
        float scale = float(mult) * 0.5 + 2.75;
        float u = rawu * scale;
        float v = rawv * scale * 0.6;
        int tu = int(mod(floor(u * 16.0), 16.0));
        int tv = int(mod(floor(v * 16.0), 16.0));
        int position = ((171 * tu) + (489 * tv) + (303 * (i + 31)) + 17209) ^ 10086;
        int symbol = int(mod(float(position), 81.0));
        if (symbol >= 0 && symbol < 10) {
            float ru = clamp(mod(u, 1.0) * 16.0 - float(tu), 0.0, 1.0);
            float rv = clamp(mod(v, 1.0) * 16.0 - float(tv), 0.0, 1.0);
            vec2 c = vec2(ru, rv) - 0.5;
            float glyph = pow(max(0.0, 1.0 - length(c) / 0.30), 3.0);
            float crossBits = pow(max(0.0, 1.0 - abs(c.x) / 0.07), 2.0) * pow(max(0.0, 1.0 - abs(c.y) / 0.45), 2.0)
                            + pow(max(0.0, 1.0 - abs(c.y) / 0.07), 2.0) * pow(max(0.0, 1.0 - abs(c.x) / 0.45), 2.0);
            float tcol = glyph * 0.9 + crossBits * 1.0;
            float a = tcol * (0.5 + (1.0 / float(mult)) * 1.0) * (1.0 - smoothstep(0.15, 0.48, abs(rawv - 0.5)));
            // 星点颜色：跟随 tint（Java 侧由 EchoesHue 循环色相给出）⇒ 与手持同时变色
            vec3 starTint = mix(vec3(0.85, 0.90, 1.0), normalize(tint.rgb + vec3(0.001)), 0.65);
            vec3 starColor = starTint;
            starColor *= 0.72 + 0.28 * sin(time * (0.8 + 0.4 * hash1(rand1 * 0.13)) + rand2);
            col += starColor * a * 1.35;
        }
    }

    // 非白色部分：保留原贴图但压暗（让白色的星空成为绝对主角）
    vec3 base = tex.rgb * 0.16;

    // 合成：白色区 = 星空，其余 = 压暗的原贴图
    vec3 outc = mix(base, col, whiteMask);

    // 顶点色与调制色照常参与（GUI 里这两者通常都是白，保留是为了一致性）
    outc *= vertexColor.rgb * ColorModulator.rgb;

    float a = tex.a * opacity * vertexColor.a;
    fragColor = vec4(outc, a);
}
