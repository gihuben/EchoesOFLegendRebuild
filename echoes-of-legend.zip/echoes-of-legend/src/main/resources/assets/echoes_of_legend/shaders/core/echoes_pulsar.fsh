#version 150

/*
 * ==========================================================================
 * echoes_pulsar.fsh —— 神器介绍界面「中子星 / 脉冲星」特效（2026-10-18）
 * ==========================================================================
 *
 * 【用户规格（逐条落地）】
 *  ① 去除旧 tooltip 的全部内容（标题 / 描述 / 漩涡 / ARTEMIS 贴图 / 涟漪）——
 *     本文件只负责渲染"新内容"，旧内容由 Java 侧不再调用。
 *  ② 中心 = 会转动的**脉冲星球体**：蓝色，表面有"几乎白色的蓝色能量光点"，
 *     立体、平滑、真实、**高速**旋转。旋转轴 = 屏幕竖直轴（Y），像地球自转，
 *     方向为逆时针（从球体正上方俯视）。⇒ 见 `<body>` 段。
 *  ③ 球体前方 = 立体剑模型（由 Java 侧用真实 BakedModel 渲染，不在本文件里）。
 *  ④ 球体**外围**一道反向旋转的环（土星环式）：绕**垂直于屏幕的轴**（Z）逆时针，
 *     蓝色荧光，**严格套在球体外、不接触球体**。⇒ 见 `<ring>` 段。
 *  ⑤ 环外再一个更大的**数字环**（同样不接触内环，与内环同向旋转），
 *     由蓝色 + 蓝白闪光点的立体罗马数字 I..XII（时钟顺序）组成，
 *     每个数字跟随内环 12 等分点之一转动；12 等分点是**假想点、不绘制**。
 *     ⇒ 见 `<roman>` 段。
 *
 * 【为什么全部塞进一个片元着色器】
 *  GUI 里用图元拼几何必然出现锯齿与接缝（旧版"巨大涟漪"就是这么死掉的）。
 *  走"一个 quad + GPU 逐像素解析计算"这条路：分辨率无限、抗锯齿免费、
 *  旋转是连续的（不是逐帧跳格），且三层图形天然严格同心、绝不互相穿插。
 *
 * 【坐标系（最容易搞错的地方）】
 *  gl_FragCoord 的原点在**左下角**，而 Java 侧传入的 center 已换算成同一套
 *  像素坐标（y 向上）⇒ 本文件里 `p = gl_FragCoord.xy - center` 的 **y 轴向上**，
 *  因此"数学逆时针" = 角度递增，与用户要求的逆时针一致，不需要再取反。
 *
 * 【混合】echoes_pulsar.json 指定 add / srcalpha / 1-srcalpha（标准 alpha 混合）。
 */

const float PI  = 3.14159265359;
const float TAU = 6.28318530718;

uniform float time;      // 动画时间（秒）
uniform vec2  center;    // 脉冲星球心（像素，y 向上）
uniform float radius;    // 脉冲星半径 R（像素）
uniform float opacity;   // 整体不透明度
uniform vec4  tint;      // 主色（蓝）
uniform vec3  spin;      // x = 球体自转角速度  y = 内环角速度  z = 数字环角速度

in vec4 vertexColor;
out vec4 fragColor;

/* ==========================================================================
 * 噪声：球面纹理必须用 **3D** 噪声
 * --------------------------------------------------------------------------
 * 若用 2D 噪声（把球面投影成 uv），球体自转时会出现明显的 uv 接缝（一条竖线），
 * 而且两极会极度拉伸。直接在球体本地空间采样 3D 噪声 ⇒ 任意自转角都连续无缝。
 * ==========================================================================*/
float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float hash31(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float vnoise3(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash31(i + vec3(0.0, 0.0, 0.0));
    float n100 = hash31(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash31(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash31(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash31(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash31(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash31(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash31(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
               mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}

float fbm3(vec3 p) {
    float s = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; ++i) {
        s += a * vnoise3(p);
        p *= 2.02;
        a *= 0.5;
    }
    return s;
}

/* 线段 SDF（罗马数字全部由 I / V / X 三种笔画组合而成，零贴图依赖） */
float sdSeg(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-6), 0.0, 1.0);
    return length(pa - ba * h);
}

/* 单字符 SDF。字符框：宽 0.30、高 1.00、中心在原点，y 向上。
 *   type 0 = I（竖笔）  1 = V（两笔斜向下汇于底）  2 = X（两笔交叉） */
float charSDF(vec2 q, int type) {
    float w = 0.047;
    if (type == 0) {
        return sdSeg(q, vec2(0.0, -0.50), vec2(0.0, 0.50)) - w;
    } else if (type == 1) {
        float a = sdSeg(q, vec2(-0.150, 0.50), vec2(0.0, -0.50));
        float b = sdSeg(q, vec2( 0.150, 0.50), vec2(0.0, -0.50));
        return min(a, b) - w;
    }
    float a = sdSeg(q, vec2(-0.150, 0.50), vec2( 0.150, -0.50));
    float b = sdSeg(q, vec2( 0.150, 0.50), vec2(-0.150, -0.50));
    return min(a, b) - w;
}

/* 罗马数字 1..12 的 SDF（q 已按数字高度归一化：数字高 = 1.0，中心在原点）。
 * 字符序列与时钟顺序严格一致：I II III IV V VI VII VIII IX X XI XII */
float romanSDF(vec2 q, int n) {
    int cnt = 1;
    int c0 = -1; int c1 = -1; int c2 = -1; int c3 = -1;
    if (n == 1)       { cnt = 1; c0 = 0; c1 = -1; c2 = -1; c3 = -1; }
    else if (n == 2)  { cnt = 2; c0 = 0; c1 =  0; c2 = -1; c3 = -1; }
    else if (n == 3)  { cnt = 3; c0 = 0; c1 =  0; c2 =  0; c3 = -1; }
    else if (n == 4)  { cnt = 2; c0 = 0; c1 =  1; c2 = -1; c3 = -1; }
    else if (n == 5)  { cnt = 1; c0 = 1; c1 = -1; c2 = -1; c3 = -1; }
    else if (n == 6)  { cnt = 2; c0 = 1; c1 =  0; c2 = -1; c3 = -1; }
    else if (n == 7)  { cnt = 3; c0 = 1; c1 =  0; c2 =  0; c3 = -1; }
    else if (n == 8)  { cnt = 4; c0 = 1; c1 =  0; c2 =  0; c3 =  0; }
    else if (n == 9)  { cnt = 2; c0 = 0; c1 =  2; c2 = -1; c3 = -1; }
    else if (n == 10) { cnt = 1; c0 = 2; c1 = -1; c2 = -1; c3 = -1; }
    else if (n == 11) { cnt = 2; c0 = 2; c1 =  0; c2 = -1; c3 = -1; }
    else              { cnt = 3; c0 = 2; c1 =  0; c2 =  0; c3 = -1; }

    const float CW = 0.30;   // 字符宽
    const float GAP = 0.065; // 字符间距
    float charStep = CW + GAP;   // 不能叫 step：GLSL 内建函数名
    float total = float(cnt) * CW + float(cnt - 1) * GAP;
    float x0 = -total * 0.5 + CW * 0.5;   // 第一个字符中心

    float d = 1e9;
    if (c0 >= 0) d = min(d, charSDF(q - vec2(x0, 0.0), c0));
    if (c1 >= 0) d = min(d, charSDF(q - vec2(x0 + charStep, 0.0), c1));
    if (c2 >= 0) d = min(d, charSDF(q - vec2(x0 + charStep * 2.0, 0.0), c2));
    if (c3 >= 0) d = min(d, charSDF(q - vec2(x0 + charStep * 3.0, 0.0), c3));
    return d;
}

void main(void) {
    float R = radius;   // 不能加 const：radius 是 uniform（非编译期常量）

    vec2  p   = gl_FragCoord.xy - center;   // 相对球心的像素偏移，y 向上
    float r   = length(p);                  // 到球心的距离
    float ang = atan(p.y, p.x);             // 极角

    vec3  col   = vec3(0.0);
    float alpha = 0.0;

    /* ======================================================================
     * <body> 脉冲星本体：半径 R 的球面
     * ----------------------------------------------------------------------
     * 解析球体：像素到球心的距离 r ⇒ 球面在该像素处的深度 z = sqrt(R^2 - r^2)，
     * 于是得到该像素对应的**单位法线** n = (p/R, z/R)。
     * 自转：把 n 绕屏幕竖直轴（Y）反向转 spin.x * time，
     *       得到"球体本地空间"的坐标 q，再在 q 上采样 3D 噪声
     *       ⇒ 球面特征随自转流动，且任意角度都无缝。
     * ======================================================================*/
    if (r <= R * 1.012) {
        float rr   = min(r / R, 1.0);
        float zz   = sqrt(max(0.0, 1.0 - rr * rr));
        vec3  nrm  = vec3(p / R, zz);        // 观察空间单位法线

        // 绕 Y 轴自转（逆时针：从 +Y 俯视时角度递增）
        float a  = time * spin.x;
        float ca = cos(a);
        float sa = sin(a);
        vec3  q  = vec3(ca * nrm.x + sa * nrm.z,
                        nrm.y,
                        -sa * nrm.x + ca * nrm.z);

        // 多层 3D 噪声：低层做"能量云"，高层做"细碎光点"
        float f1 = fbm3(q * 2.35);
        float f2 = fbm3(q * 6.70 + vec3(13.1, 7.7, 2.3));
        float f3 = fbm3(q * 13.5 + vec3(4.7, 19.3, 8.1));
        float field = f1 * 0.56 + f2 * 0.30 + f3 * 0.14;

        // "几乎白色的蓝色能量光点"：高对比阈值 ⇒ 稀疏、锐利、像超高能粒子斑
        float spots = smoothstep(0.54, 0.86, field);
        float fine  = smoothstep(0.74, 0.96, f3);
        // 光点自身的呼吸闪烁（高速、相位随位置变化 ⇒ 不会全场同闪）
        float pulse = 0.80 + 0.20 * sin(time * 9.0 + field * 47.0);

        // 颜色：深蓝底 → 中蓝云 → 近白蓝光点
        vec3 cDeep = tint.rgb * 0.16;
        vec3 cMid  = tint.rgb * 0.70;
        vec3 cHot  = mix(tint.rgb, vec3(1.0), 0.84);   // 几乎白色的蓝
        vec3 albedo = mix(cDeep, cMid, smoothstep(0.20, 0.66, field));
        albedo = mix(albedo, cHot, clamp(spots * 0.94 + fine * 0.46, 0.0, 1.0) * pulse);

        // 光照：左上前方的平行光 + 强边缘光（中子星的"发光轮廓"）
        vec3  L    = normalize(vec3(-0.45, 0.58, 0.68));
        float diff = max(dot(nrm, L), 0.0);
        float rim  = pow(1.0 - max(nrm.z, 0.0), 2.8);
        vec3  body = albedo * (0.30 + 0.82 * diff) + cHot * rim * 0.58;

        // 边缘抗锯齿（按像素距离柔化，避免硬圆边）
        float aa = 1.0 - smoothstep(R * 0.978, R * 1.012, r);   // 规范形式（edge0 < edge1）
        col   = body;
        alpha = aa;
    }

    /* ======================================================================
     * <ring> 内环：土星环式的蓝荧光环
     * ----------------------------------------------------------------------
     * 几何：中心半径 RC、半宽 RW。RC - RW = R * 1.084 > R ⇒
     *       环的内边缘**严格在球体之外**，绝不接触球体（用户硬性要求）。
     * 反向旋转：绕 Z 轴（垂直于屏幕）逆时针，角速度 = spin.y。
     *   因为环是中心对称的圆环，单靠几何看不出它在转 ⇒
     *   必须让**亮度/能量沿角向流动**（多层不同角频率的正弦叠加），
     *   这样才看得出"在逆时针转"。
     * "土星环质感"：再叠一层随半径变化的细密纹路（径向 grain）。
     * ======================================================================*/
    float RC = R * 1.180;   // 环中心半径
    float RW = R * 0.082;   // 环半宽
    float dr = abs(r - RC);
    if (dr < RW) {
        float t    = 1.0 - dr / RW;                 // 1 = 环中心，0 = 环边缘
        float band = pow(smoothstep(0.0, 1.0, t), 0.72);

        float ar = time * spin.y;                   // 逆时针（角度递增）
        float e1 = sin(ang *  3.0 + ar * 1.35);
        float e2 = sin(ang *  7.0 - ar * 2.10);
        float e3 = sin(ang * 15.0 + ar * 0.85);
        float e4 = sin(ang * 29.0 - ar * 3.40);
        float energy = clamp(0.46 + 0.26 * e1 + 0.16 * e2 + 0.08 * e3 + 0.04 * e4, 0.0, 1.0);

        // 径向上的细密纹路 ⇒ 有厚度的盘状质感（不是一条死线）
        float grain = 0.82
                    + 0.13 * sin(r * 1.15 - ar * 6.0)
                    + 0.05 * sin(r * 3.70 + ar * 2.0);

        // 内外边缘稍亮，形成"环"的立体截面感
        float rimBand = pow(smoothstep(0.0, 0.32, t) * (1.0 - smoothstep(0.58, 1.0, t)), 0.85);

        vec3 ringCol = mix(tint.rgb * 0.42,
                           mix(tint.rgb, vec3(1.0), 0.62),
                           clamp(energy * 0.90 + rimBand * 0.10, 0.0, 1.0));
        ringCol *= grain;

        float ringA = band * (0.56 + 0.44 * energy);

        // 球体与环不重叠（环在球外），此处直接合成即可
        col   = mix(col, ringCol, ringA);
        alpha = max(alpha, ringA);
    }

    /* ======================================================================
     * <roman> 数字环：12 个立体罗马数字，跟随内环的 12 等分点
     * ----------------------------------------------------------------------
     * 几何：中心半径 NC、数字高度 NH。NC - NH * 0.85 = R * 1.357 >
     *       内环外缘 RC + RW = R * 1.262 ⇒ **不接触内环**（用户硬性要求）。
     * 旋转：与内环**同向**（角速度同为 spin.z 的正方向 ⇒ 逆时针）。
     * 朝向：数字**保持直立**（只跟随位置公转，自身不随切向翻滚），
     *       否则转到下方时数字会倒过来 —— 时钟盘面的数字必须是正的。
     * 顺序：i = 0 放在正上方（12 点），顺时针依次 1..12 ⇒ 与时钟一致。
     *       【注意】屏幕 y 向上时，"时钟方向的顺时针"= 角度递减，
     *       所以这里用 `-float(i)`，与内环的逆时针视觉方向一致但排列成时钟序。
     * 立体 / 闪光：核心亮、外缘暗（假挤出体）+ 帧不变的高光点 + 稀疏蓝白闪斑。
     * ======================================================================*/
    float NC = R * 1.455;    // 数字中心半径
    float NH = R * 0.115;    // 数字高度（归一化后 = 1.0）
    if (abs(r - NC) < NH * 0.86) {
        float an = time * spin.z;                       // 与内环同向
        for (int i = 0; i < 12; ++i) {
            // i = 0 → 正上方（PI/2）；i 递增 → 时钟方向（角度递减）
            float ai = an + PI * 0.5 - float(i) * (TAU / 12.0);
            vec2  dir = vec2(cos(ai), sin(ai));
            vec2  lp  = p - dir * NC;
            vec2  q   = lp / NH;                        // 数字高度归一化，y 向上

            float d = romanSDF(q, i + 1);
            if (d < 0.135) {
                float core  = (1.0 - smoothstep(0.010, 0.068, d));   // 笔画芯
                float shell = (1.0 - smoothstep(0.062, 0.125, d));   // 笔画外轮廓

                // 固定方位的高光（左上），所有数字一致 ⇒ 统一的光源感
                vec2  hp   = vec2(-0.52, 0.46);
                float spec = (1.0 - smoothstep(0.0, 0.62, length(q - hp))) * core;

                // 每颗数字独立的呼吸节奏（不成片同闪）
                float tw = 0.72 + 0.28 * sin(time * (3.1 + float(i) * 0.37) + float(i) * 1.93);

                // 稀疏蓝白闪斑（在数字笔画内部随机点亮）
                float sp = pow(hash21(floor(q * 21.0) + float(i) * 7.31), 34.0);

                vec3 cEdge  = tint.rgb * 0.52;
                vec3 cCore  = mix(tint.rgb, vec3(1.0), 0.70);
                vec3 dCol   = mix(cEdge, cCore, core);
                dCol += vec3(1.00, 0.98, 1.00) * spec * 0.55;
                dCol += vec3(0.88, 0.95, 1.00) * sp * 2.10;
                dCol *= tw;

                float dA = shell * 0.97;
                col   = mix(col, dCol, dA);
                alpha = max(alpha, dA);
            }
        }
    }

    /* 整体透明倍率（vertexColor 让上层还能再调一层） */
    float a = clamp(alpha * opacity * vertexColor.a, 0.0, 1.0);
    if (a <= 0.0005) {
        discard;
    }
    fragColor = vec4(clamp(col * vertexColor.rgb, 0.0, 1.0), a);
}
