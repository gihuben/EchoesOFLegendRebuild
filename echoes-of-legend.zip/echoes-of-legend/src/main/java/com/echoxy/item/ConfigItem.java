package com.echoxy.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

/**
 * 配置界面物品（注册名 {@code configitem}，显示名「右键打开配置界面」）。
 *
 * <p>右键（对空 / 对方块两条入口都覆盖）⇒ 打开纯原生配置界面
 * （{@code ECHO_CONFIG_UI.DLL} 用 GDI+ 直接覆盖绘制在游戏画面上，见
 * {@code com.echoxy.client.EchoConfigUi}）。</p>
 *
 * <p>物品本身零特效、零 TOOLTIP、零简介：只做一件事——把原生界面叫出来。</p>
 */
public class ConfigItem extends Item {

    public ConfigItem() {
        super(new Item.Properties().stacksTo(1));
    }

    /** 无使用动画（无任何特效）。 */
    @Override
    public UseAnim getUseAnimation(final ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public int getUseDuration(final ItemStack stack) {
        return 72000;
    }

    /** 右键空气 / 非方块目标。 */
    @Override
    public InteractionResultHolder<ItemStack> use(final Level level, final Player player,
                                                  final InteractionHand hand) {
        openOnClient(level);
        return InteractionResultHolder.success(player.getItemInHand(hand));
    }

    /** 对方块右键（原版走这条）：同样打开界面。 */
    @Override
    public InteractionResult useOn(final UseOnContext context) {
        openOnClient(context.getLevel());
        return InteractionResult.SUCCESS;
    }

    /**
     * 只在客户端执行，且用 {@link DistExecutor} 延迟解析客户端类
     * ⇒ 专服环境加载本物品类时不会因为引用 {@code EchoConfigUi} 而报 NoClassDefFoundError。
     */
    private static void openOnClient(final Level level) {
        if (level == null || !level.isClientSide) {
            return;
        }
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> com.echoxy.client.EchoConfigUi.toggle());
    }
}
