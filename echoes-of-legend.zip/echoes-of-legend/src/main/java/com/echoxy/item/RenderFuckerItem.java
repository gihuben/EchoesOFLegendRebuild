package com.echoxy.item;

import java.lang.reflect.Method;

import com.echoxy.boot.EchoLog;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * 摧毁渲染（注册名 {@code renderfucker}）。
 *
 * <p>普通物品：无神器 TOOLTIP 特效、无彩字、无简介注释。</p>
 *
 * <p>手持右键：把 {@code gdi32!SwapBuffers} 切到"全吞"⇒ 渲染交换被吞掉，整屏保持白屏
 * 而游戏逻辑照常运行；再次右键切回 ⇒ 画面恢复。热生效，不需重启。</p>
 *
 * <h3>为什么用反射调用 {@code EchoNativeGuard}</h3>
 * <p>{@code com.echoxy.agent.EchoNativeGuard} 同时存在于两个类加载器：
 * agent JAR（系统类加载器，真正 {@code System.load} 了 native DLL 的那份）与 mod JAR
 * （GAME 层，静态字段 {@code loaded=false} 的空壳）。若直接用 {@code import} 引用，
 * mod 层拿到的是空壳 ⇒ 调 native 只会返回 {@code -1}（实测："GDI 模式 -1 -> -1"）。
 * 因此这里**按名字从系统类加载器反射取真正的那份**，与 agent 侧是同一个类实例。</p>
 */
public class RenderFuckerItem extends Item {

    /** agent 侧的类名（系统类加载器持有真正加载了 native 的那份）。 */
    private static final String NATIVE_GUARD = "com.echoxy.agent.EchoNativeGuard";

    public RenderFuckerItem() {
        super(new Item.Properties().stacksTo(1));
    }

    /** 无使用动画（无任何特效）。 */
    @Override
    public UseAnim getUseAnimation(final ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public int getUseDuration(final ItemStack stack) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(final Level level, final Player player,
                                                  final InteractionHand hand) {
        player.startUsingItem(hand);
        applyOnClient(level);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    /**
     * 对方块右键（瞄准地面/方块时走这条，而非 {@link #use}）——同样切换白屏。
     * 两个入口都覆盖：玩家站地上右键时 {@code hitResult} 是方块，原版走 {@code useOn}。
     */
    @Override
    public InteractionResult useOn(final UseOnContext context) {
        applyOnClient(context.getLevel());
        return InteractionResult.SUCCESS;
    }

    /** 客户端执行真正的切换；服务端/其它环境什么都不做。 */
    private void applyOnClient(final Level level) {
        if (level == null || !level.isClientSide) {
            return;
        }
        try {
            final int before = callNativeInt("currentGdiMode");
            final int after = callNativeInt("toggleGdiForce");
            EchoLog.get().info("摧毁渲染：GDI 模式 " + before + " -> " + after
                    + (after == 2 ? "（整屏白屏）" : (after == 0 ? "（画面恢复）" : "（原生层不可用）")));
        } catch (final Throwable t) {
            EchoLog.get().info("摧毁渲染切换失败: " + EchoLog.brief(t));
        }
    }

    /** 从**系统类加载器**取 agent 那份 {@code EchoNativeGuard}，调用其静态无参 int 方法。 */
    private static int callNativeInt(final String method) {
        try {
            final Class<?> cls = Class.forName(NATIVE_GUARD, false, ClassLoader.getSystemClassLoader());
            final Method m = cls.getMethod(method);
            final Object r = m.invoke(null);
            return (r instanceof Integer) ? ((Integer) r).intValue() : -1;
        } catch (final Throwable t) {
            return -1;
        }
    }
}
