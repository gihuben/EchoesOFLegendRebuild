package com.echoxy.item;

import java.util.List;
import java.util.function.Consumer;

import com.echoxy.boot.EchoConfig;
import com.echoxy.client.ArtifactItemExtensions;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/**
 * 回响物语 · 神器（参考实现的学习版）。
 *
 * <p>特性：</p>
 * <ul>
 *   <li>右键格挡：按住右键持续格挡（UseAnim.BLOCK，原版第三人称自动摆格挡姿势）；</li>
 *   <li>显示名与描述：全部走语言文件（lang/*.json），彩字特效由客户端渲染层接管；</li>
 *   <li>近乎无限的破坏速度 + 附魔光泽（isFoil）；</li>
 *   <li>客户端扩展：第一人称格挡姿态（{@link ArtifactItemExtensions}）。</li>
 * </ul>
 */
public class EchoArtifactItem extends Item {

    public EchoArtifactItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }

    /** 右键使用动作 = 格挡（第三人称由原版 HumanoidModel 自动摆 ArmPose.BLOCK）。 */
    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BLOCK;
    }

    /** 近乎无限长，直到玩家松开右键（原版松开即 stopUsingItem）。 */
    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!EchoConfig.get().getBoolean("神器格挡", true)) {
            return super.use(level, player, hand);
        }
        player.startUsingItem(hand);
        // 右键秒杀（服务端执行；潜行时跳过——潜行+右键用于关闭防御模式，避免误触清屏）
        if (!level.isClientSide && !player.isShiftKeyDown()) {
            try {
                com.echoxy.attack.EchoAttackHandler.onRightClick(player, level);
            } catch (Throwable ignored) {
                // 攻击失败不影响格挡
            }
        }
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public float getDestroySpeed(ItemStack stack, BlockState state) {
        return 32767.0F;
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public boolean isCorrectToolForDrops(BlockState state) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        for (int i = 0; i < 21; i++) {
            tooltip.add(Component.translatable("item.echoes_of_legend.artemis.description_" + i));
        }
    }

    /** 客户端扩展注册（第一人称格挡姿态）。 */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new ArtifactItemExtensions());
    }
}
