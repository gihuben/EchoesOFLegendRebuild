package com.echoxy.attack;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 末日名单（服务端维护）：
 * <ul>
 *   <li>被禁实体类型（右键秒杀后写入禁生成表）；</li>
 *   <li>被秒杀实体实例（Weak 引用，防止泄漏）。</li>
 * </ul>
 *
 * <p>本类判定被注入到超热路径（实体加入世界 / 每 tick 巡检），因此实例集合并发安全、
 * 类型判定带 EntityType 缓存（registry 查询摊成 O(1)）。</p>
 */
public final class EchoDoomList {

    private static final Set<String> BANNED_TYPES = ConcurrentHashMap.newKeySet();
    private static final Set<Entity> DOOMED =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));
    private static final Map<EntityType<?>, Boolean> BANNED_TYPE_CACHE = new ConcurrentHashMap<>();

    private EchoDoomList() {
    }

    public static void banType(String registryName) {
        if (registryName == null) {
            return;
        }
        BANNED_TYPES.add(registryName);
        BANNED_TYPE_CACHE.clear();
    }

    /** 客户端/整体替换镜像（保留扩展点）。 */
    public static void applyBanned(java.util.Collection<String> names) {
        BANNED_TYPES.addAll(names);
        BANNED_TYPE_CACHE.clear();
    }

    /** 打上 doomed 标签（@e 与血量读取等路径可见"死亡"）。 */
    public static void markDoomed(Entity e) {
        if (e != null) {
            DOOMED.add(e);
        }
    }

    public static List<Entity> doomedEntities() {
        synchronized (DOOMED) {
            return List.copyOf(DOOMED);
        }
    }

    public static java.util.Collection<String> bannedTypes() {
        return List.copyOf(BANNED_TYPES);
    }

    public static boolean hasBans() {
        return !BANNED_TYPES.isEmpty() || !DOOMED.isEmpty();
    }

    /** 任意实体判定：实例被 doom 或类型被禁。 */
    public static boolean isDoomedEntity(Entity e) {
        if (e == null) {
            return false;
        }
        if (DOOMED.contains(e)) {
            return true;
        }
        return isBannedType(e);
    }

    public static boolean isDoomed(LivingEntity e) {
        return isDoomedEntity(e);
    }

    /** 实体类型是否被禁（带缓存）。 */
    public static boolean isBannedType(Entity e) {
        if (e == null || e.getType() == null) {
            return false;
        }
        EntityType<?> type = e.getType();
        Boolean cached = BANNED_TYPE_CACHE.get(type);
        if (cached != null) {
            return cached;
        }
        String key;
        try {
            key = ForgeRegistries.ENTITY_TYPES.getKey(type).toString();
        } catch (Throwable t) {
            return false;
        }
        boolean banned = BANNED_TYPES.contains(key);
        BANNED_TYPE_CACHE.put(type, banned);
        return banned;
    }
}
