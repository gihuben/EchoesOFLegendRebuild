package com.echoxy.attack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.entity.EntityAccess;
import net.minecraft.world.level.entity.EntityLookup;
import net.minecraft.world.level.entity.EntitySectionStorage;
import net.minecraft.world.level.entity.EntityTickList;
import net.minecraft.world.level.entity.PersistentEntitySectionManager;
import net.minecraft.world.level.entity.TransientEntitySectionManager;

/**
 * 结构性移除器：把实体从服务端的全部可触达结构中同步清出，并用原版零体积空实体
 * （Marker）顶替其 id 槽位——阻止"同一 tick 内被塞回列表"与"残留碰撞幽灵"。
 *
 * <p>清理面（与参考实现一致）：实体管理器 stopTicking / stopTracking、区块存储、
 * EntityLookup（byId/byUuid）、活动 tick 列表、ChunkMap 追踪表。全部 try/catch 静默。</p>
 */
public final class EchoStructureRemoval {

    private EchoStructureRemoval() {
    }

    // 有界缓存：维度切换极少，超出上限整体清空（防止长会话中无限引用旧世界对象图）
    private static final int CACHE_MAX = 4;
    private static final Map<ServerLevel, PersistentEntitySectionManager<Entity>> MANAGER_CACHE =
            new java.util.concurrent.ConcurrentHashMap<>();
    private static final Map<ServerLevel, EntityLookup<Entity>> LOOKUP_CACHE =
            new java.util.concurrent.ConcurrentHashMap<>();

    // ===== 定位 =====

    /** 服务端实体管理器（1.20.1 SRG 名 f_143244_；类型兜底）。 */
    public static PersistentEntitySectionManager<Entity> manager(ServerLevel sl) {
        PersistentEntitySectionManager<Entity> cached = MANAGER_CACHE.get(sl);
        if (cached != null) {
            return cached;
        }
        PersistentEntitySectionManager<Entity> ret = null;
        Object direct = fieldByNames(sl, ServerLevel.class, "f_143244_", "entityManager");
        if (direct instanceof PersistentEntitySectionManager<?> dm) {
            @SuppressWarnings("unchecked")
            PersistentEntitySectionManager<Entity> r = (PersistentEntitySectionManager<Entity>) dm;
            ret = r;
        }
        if (ret == null) {
            try {
                Class<?> c = ServerLevel.class;
                while (c != null && c != Object.class) {
                    for (Field f : c.getDeclaredFields()) {
                        if (Modifier.isStatic(f.getModifiers()) || !PersistentEntitySectionManager.class.isAssignableFrom(f.getType())) {
                            continue;
                        }
                        f.setAccessible(true);
                        Object v = f.get(sl);
                        if (v instanceof PersistentEntitySectionManager<?> m) {
                            @SuppressWarnings("unchecked")
                            PersistentEntitySectionManager<Entity> r = (PersistentEntitySectionManager<Entity>) m;
                            ret = r;
                            break;
                        }
                    }
                    if (ret != null) {
                        break;
                    }
                    c = c.getSuperclass();
                }
            } catch (Throwable ignored) {
            }
        }
        if (ret != null) {
            trim();
            MANAGER_CACHE.put(sl, ret);
        }
        return ret;
    }

    /** 管理器可见存储（真实实体列表；1.20.1 SRG 名 f_157494_；类型兜底）。 */
    public static EntityLookup<Entity> lookup(ServerLevel sl) {
        EntityLookup<Entity> cached = LOOKUP_CACHE.get(sl);
        if (cached != null) {
            return cached;
        }
        PersistentEntitySectionManager<Entity> m = manager(sl);
        if (m == null) {
            return null;
        }
        EntityLookup<Entity> ret = null;
        Object direct = fieldByNames(m, PersistentEntitySectionManager.class, "f_157494_", "visibleEntityStorage");
        if (direct instanceof EntityLookup<?> dl) {
            @SuppressWarnings("unchecked")
            EntityLookup<Entity> r = (EntityLookup<Entity>) dl;
            ret = r;
        }
        if (ret == null) {
            try {
                Class<?> c = PersistentEntitySectionManager.class;
                while (c != null && c != Object.class) {
                    for (Field f : c.getDeclaredFields()) {
                        if (Modifier.isStatic(f.getModifiers()) || !EntityLookup.class.isAssignableFrom(f.getType())) {
                            continue;
                        }
                        f.setAccessible(true);
                        Object v = f.get(m);
                        if (v instanceof EntityLookup<?> l) {
                            @SuppressWarnings("unchecked")
                            EntityLookup<Entity> r = (EntityLookup<Entity>) l;
                            ret = r;
                            break;
                        }
                    }
                    if (ret != null) {
                        break;
                    }
                    c = c.getSuperclass();
                }
            } catch (Throwable ignored) {
            }
        }
        if (ret != null) {
            trim();
            LOOKUP_CACHE.put(sl, ret);
        }
        return ret;
    }

    private static void trim() {
        try {
            if (MANAGER_CACHE.size() > CACHE_MAX) {
                MANAGER_CACHE.clear();
            }
            if (LOOKUP_CACHE.size() > CACHE_MAX) {
                LOOKUP_CACHE.clear();
            }
        } catch (Throwable ignored) {
        }
    }

    // ===== 收集 =====

    /** 真实实体列表（管理器可见存储 + 区块存储残留，按身份去重）。 */
    public static List<Entity> realEntities(ServerLevel sl) {
        List<Entity> out = new ArrayList<>();
        Set<Entity> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        EntityLookup<Entity> lookup = lookup(sl);
        if (lookup != null) {
            for (Entity e : lookup.getAllEntities()) {
                if (seen.add(e)) {
                    out.add(e);
                }
            }
        } else {
            for (Entity e : sl.getEntities().getAll()) {
                if (seen.add(e)) {
                    out.add(e);
                }
            }
        }
        for (Entity e : sectionEntities(sl)) {
            if (seen.add(e)) {
                out.add(e);
            }
        }
        return out;
    }

    /** 区块存储里的全部实体（含半移除残留）。 */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static List<Entity> sectionEntities(ServerLevel sl) {
        List<Entity> out = new ArrayList<>();
        try {
            PersistentEntitySectionManager<Entity> m = manager(sl);
            if (m == null) {
                return out;
            }
            for (Field f : PersistentEntitySectionManager.class.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !EntitySectionStorage.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    EntitySectionStorage storage = (EntitySectionStorage) f.get(m);
                    if (storage == null) {
                        continue;
                    }
                    out.addAll(storageEntities(storage));
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static List<Entity> storageEntities(EntitySectionStorage<?> storage) {
        List<Entity> out = new ArrayList<>();
        try {
            Method allChunks = findMethodByName(storage.getClass(), "getAllChunksWithExistingSections", "m_156857_");
            Method secsInChunk = findMethodByName(storage.getClass(), "getExistingSectionsInChunk", "m_156888_", long.class);
            if (allChunks == null || secsInChunk == null) {
                return out;
            }
            Object chunks = allChunks.invoke(storage);
            if (!(chunks instanceof Set<?> set)) {
                return out;
            }
            for (Object cp : set) {
                long chunkLong = cp instanceof Long l ? l : ((Number) cp).longValue();
                Object secs = secsInChunk.invoke(storage, chunkLong);
                if (!(secs instanceof java.util.stream.Stream<?> stream)) {
                    continue;
                }
                for (Object sec : stream.toList()) {
                    if (sec == null) {
                        continue;
                    }
                    Field storageField = findFieldByType(sec.getClass(), java.util.Collection.class);
                    if (storageField == null) {
                        continue;
                    }
                    storageField.setAccessible(true);
                    Object col = storageField.get(sec);
                    if (col instanceof java.util.Collection<?> cc) {
                        for (Object v : cc) {
                            if (v instanceof Entity en) {
                                out.add(en);
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    // ===== 结构移除 =====

    /**
     * 结构性移除：stopTicking/stopTracking + 区块存储 + EntityLookup + 活动 tick 列表 + ChunkMap 追踪表。
     */
    public static void structuralRemoval(ServerLevel sl, Entity e) {
        PersistentEntitySectionManager<Entity> m = manager(sl);
        if (m == null) {
            return;
        }
        try {
            Method stopTicking = findMethodByName(PersistentEntitySectionManager.class, "stopTicking", "m_157570_", EntityAccess.class);
            if (stopTicking != null) {
                stopTicking.setAccessible(true);
                stopTicking.invoke(m, e);
            }
        } catch (Throwable ignored) {
        }
        try {
            Method stopTracking = findMethodByName(PersistentEntitySectionManager.class, "stopTracking", "m_157580_", EntityAccess.class);
            if (stopTracking != null) {
                stopTracking.setAccessible(true);
                stopTracking.invoke(m, e);
            }
        } catch (Throwable ignored) {
        }
        removeFromSectionStorages(sl, e);
        removeFromLookup(sl, e);
        removeFromEntityTickList(sl, e);
        removeFromChunkMap(sl, e);
    }

    /** 清出区块存储（全区块扫描，按身份移除）。 */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void removeFromSectionStorages(ServerLevel sl, Entity e) {
        try {
            PersistentEntitySectionManager<Entity> m = manager(sl);
            if (m == null) {
                return;
            }
            for (Field f : PersistentEntitySectionManager.class.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !EntitySectionStorage.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    EntitySectionStorage storage = (EntitySectionStorage) f.get(m);
                    if (storage == null) {
                        continue;
                    }
                    removeFromStorageObject(storage, e);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void removeFromStorageObject(EntitySectionStorage<?> storage, Entity e) {
        try {
            Method allChunks = findMethodByName(storage.getClass(), "getAllChunksWithExistingSections", "m_156857_");
            Method secsInChunk = findMethodByName(storage.getClass(), "getExistingSectionsInChunk", "m_156888_", long.class);
            if (allChunks == null || secsInChunk == null) {
                return;
            }
            Object chunks = allChunks.invoke(storage);
            if (!(chunks instanceof Set<?> set)) {
                return;
            }
            for (Object cp : set) {
                long chunkLong = cp instanceof Long l ? l : ((Number) cp).longValue();
                Object secs = secsInChunk.invoke(storage, chunkLong);
                if (!(secs instanceof java.util.stream.Stream<?> stream)) {
                    continue;
                }
                for (Object sec : stream.toList()) {
                    if (sec == null) {
                        continue;
                    }
                    Method removeM = findMethodByName(sec.getClass(), "remove", "m_188355_", Entity.class);
                    if (removeM != null) {
                        removeM.setAccessible(true);
                        removeM.invoke(sec, e);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /** 按身份直清 EntityLookup 内部全部 Map（byId/byUuid）。 */
    private static void removeFromLookup(ServerLevel sl, Entity e) {
        try {
            EntityLookup<Entity> lookup = lookup(sl);
            if (lookup == null) {
                return;
            }
            for (Field f : EntityLookup.class.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !Map.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    Map<?, ?> map = (Map<?, ?>) f.get(lookup);
                    if (map == null) {
                        continue;
                    }
                    java.util.Iterator<?> it = map.entrySet().iterator();
                    while (it.hasNext()) {
                        Map.Entry<?, ?> en = (Map.Entry<?, ?>) it.next();
                        if (en.getValue() == e) {
                            it.remove();
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /** 活动 tick 列表（优先 remove，兜底清活动表；绝不动迭代缓冲）。 */
    private static void removeFromEntityTickList(net.minecraft.world.level.Level level, Entity e) {
        try {
            Field f = findFieldByType(level.getClass(), EntityTickList.class);
            if (f == null) {
                return;
            }
            f.setAccessible(true);
            Object tickList = f.get(level);
            if (tickList == null) {
                return;
            }
            Method remove = findMethodByName(tickList.getClass(), "remove", "m_156912_", Entity.class);
            if (remove != null) {
                remove.setAccessible(true);
                remove.invoke(tickList, e);
            }
            Field active = null;
            for (Field f2 : tickList.getClass().getDeclaredFields()) {
                if (Modifier.isStatic(f2.getModifiers()) || !Map.class.isAssignableFrom(f2.getType())) {
                    continue;
                }
                active = f2;
                break;
            }
            if (active != null) {
                active.setAccessible(true);
                Map<?, ?> map = (Map<?, ?>) active.get(tickList);
                if (map != null) {
                    java.util.Iterator<?> it = map.entrySet().iterator();
                    while (it.hasNext()) {
                        Map.Entry<?, ?> en = (Map.Entry<?, ?>) it.next();
                        if (en.getValue() == e) {
                            it.remove();
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /** 追踪端（ChunkMap 的 Map 字段）：按身份清除 value == e 或包装对象内含 e 的条目。 */
    private static void removeFromChunkMap(ServerLevel sl, Entity e) {
        try {
            Object cache = sl.getChunkSource();
            if (cache == null) {
                return;
            }
            for (Field f : cache.getClass().getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !net.minecraft.server.level.ChunkMap.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    Object cm = f.get(cache);
                    if (cm == null) {
                        continue;
                    }
                    for (Field f2 : cm.getClass().getDeclaredFields()) {
                        if (Modifier.isStatic(f2.getModifiers()) || !Map.class.isAssignableFrom(f2.getType())) {
                            continue;
                        }
                        try {
                            f2.setAccessible(true);
                            Map<?, ?> map = (Map<?, ?>) f2.get(cm);
                            if (map == null) {
                                continue;
                            }
                            java.util.Iterator<?> it = map.entrySet().iterator();
                            while (it.hasNext()) {
                                Map.Entry<?, ?> en = (Map.Entry<?, ?>) it.next();
                                Object v = en.getValue();
                                if (v == e || (v != null && identityContainsEntity(v, e))) {
                                    it.remove();
                                }
                            }
                        } catch (Throwable ignored) {
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean identityContainsEntity(Object wrapper, Entity e) {
        Class<?> c = wrapper.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !Entity.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    if (f.get(wrapper) == e) {
                        return true;
                    }
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
        return false;
    }

    // ===== 空实体顶替 =====

    /**
     * klassptr 实体实例替换：原版零体积 Marker 以相同 id 占住被移除实例的槽位。
     *
     * <p>只在当前 tick 内占位（放置后立即置移除标记）——防止同 tick 内被塞回；
     * 下一 tick 管理器自然摘除，不会无限叠加。</p>
     */
    public static void replaceInstance(ServerLevel sl, int id, Entity e, String killerName) {
        try {
            if (id < 0) {
                return;
            }
            Entity existing = sl.getEntity(id);
            if (existing instanceof net.minecraft.world.entity.Marker) {
                return;
            }
            net.minecraft.world.entity.Marker marker = EntityType.MARKER.create(sl);
            if (marker == null) {
                return;
            }
            marker.moveTo(e.getX(), e.getY(), e.getZ(), e.getYRot(), e.getXRot());
            marker.setId(id);
            marker.setNoGravity(true);
            marker.setSilent(true);
            if (killerName != null && !killerName.isEmpty()) {
                marker.setCustomName(net.minecraft.network.chat.Component.literal(killerName));
                marker.setCustomNameVisible(true);
            }
            sl.addFreshEntity(marker);
            marker.setRemoved(Entity.RemovalReason.DISCARDED);
        } catch (Throwable ignored) {
        }
    }

    // ===== 反射工具 =====

    private static Object fieldByNames(Object target, Class<?> owner, String... names) {
        if (target == null || owner == null || names == null) {
            return null;
        }
        for (String n : names) {
            try {
                Field f = owner.getDeclaredField(n);
                f.setAccessible(true);
                return f.get(target);
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    private static Field findFieldByType(Class<?> owner, Class<?> type) {
        Class<?> c = owner;
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                if (type.isAssignableFrom(f.getType())) {
                    return f;
                }
            }
            c = c.getSuperclass();
        }
        return null;
    }

    private static Method findMethodByName(Class<?> owner, String devName, String srgName, Class<?>... params) {
        for (Method m : owner.getDeclaredMethods()) {
            if (!m.getName().equals(devName) && !m.getName().equals(srgName)) {
                continue;
            }
            if (m.getParameterCount() != params.length) {
                continue;
            }
            return m;
        }
        return null;
    }
}
