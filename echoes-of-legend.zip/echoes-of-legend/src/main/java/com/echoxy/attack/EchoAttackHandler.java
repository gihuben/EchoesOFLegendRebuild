package com.echoxy.attack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.echoxy.boot.EchoConfig;
import com.echoxy.boot.EchoLog;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 神器 · 攻击处理器（左键/右键秒杀，全部子功能独立可配置）。
 *
 * <ul>
 *   <li><b>右键</b>（{@code 神器右键秒杀}）：遍历全存档真实实体列表，秒杀所有非玩家实体，
 *       并写入禁生成表（{@code 秒杀禁生成}）；</li>
 *   <li><b>左键</b>（{@code 神器左键秒杀}）：秒杀被挥到的实体及其横扫范围内的全部非玩家实体
 *       （含掉落物/经验球/箭——由 {@code EchoGuardInteractMixin} 拦截攻击包）；</li>
 *   <li><b>强度链</b>：原版 hurt(MAX) 完整死亡流程 → 多路改血锁 0（{@code 改血}）→
 *       结构性移除 + 空实体顶替（{@code 强力攻击}）→ 每 tick 巡检（{@code 循环攻击}）。</li>
 * </ul>
 */
public final class EchoAttackHandler {

    /** 神器注册名（唯一硬标识：注册名由注册表决定，客户端改名/NBT 均无法伪造）。 */
    private static final ResourceLocation ARTEMIS_ID = new ResourceLocation("echoes_of_legend", "artemis");

    /**
     * 硬判据（多路检测）：主手是否握着神器 ARTEMIS。
     *
     * <p>三路并行判定，任一命中即视为神器（都指向"神器本身"，不存在误放行）：</p>
     * <ol>
     *   <li><b>实例同一</b>：{@code stack.getItem() == EchoesItems.ARTEMIS.get()}；</li>
     *   <li><b>注册名</b>：{@code ForgeRegistries.ITEMS.getKey(item) == echoes_of_legend:artemis}
     *       （改名/NBT/自定义显示名都无效，跨类加载器也判得准）；</li>
     *   <li><b>类型</b>：{@code item instanceof EchoArtifactItem}（兜底）。</li>
     * </ol>
     * <p>空手、其它物品、副手物品一律 {@code false} ⇒ 不触发秒杀。</p>
     */
    public static boolean isHoldingArtemis(Player player) {
        if (player == null) {
            return false;
        }
        try {
            final ItemStack main = player.getMainHandItem();
            if (main == null || main.isEmpty()) {
                return false;
            }
            final Item item = main.getItem();
            if (item == null) {
                return false;
            }
            // ① 实例同一
            try {
                if (item == com.echoxy.init.EchoesItems.ARTEMIS.get()) {
                    return true;
                }
            } catch (final Throwable ignored) {
                // 注册表尚未就绪：继续下一路
            }
            // ② 注册名
            try {
                if (ARTEMIS_ID.equals(ForgeRegistries.ITEMS.getKey(item))) {
                    return true;
                }
            } catch (final Throwable ignored) {
                // 注册表查询失败：继续下一路
            }
            // ③ 类型
            return item instanceof com.echoxy.item.EchoArtifactItem;
        } catch (final Throwable t) {
            return false;
        }
    }

    private static final java.util.UUID DOOM_UUID = java.util.UUID.fromString("a2f7e3c1-4b5d-4e1a-9c8f-1e2d3c4b5a6f");

    private static sun.misc.Unsafe UNSAFE;

    static {
        try {
            Field f = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            UNSAFE = (sun.misc.Unsafe) f.get(null);
        } catch (Throwable ignored) {
            UNSAFE = null;
        }
    }

    private EchoAttackHandler() {
    }

    // ===== 入口：右键 =====

    /** 右键：全存档秒杀 + 禁生成表（服务端执行）。 */
    public static void onRightClick(LivingEntity holder, Level level) {
        if (!EchoConfig.get().getBoolean("神器右键秒杀", true)) {
            return;
        }
        if (level == null || level.isClientSide || level.getServer() == null) {
            return;
        }
        MinecraftServer server = level.getServer();
        EchoBanData bans = EchoBanData.get(server);
        String killerName = holder.getDisplayName().getString();
        int killed = 0;
        for (ServerLevel sl : server.getAllLevels()) {
            for (Entity e : EchoStructureRemoval.realEntities(sl)) {
                if (e instanceof Player || e instanceof Marker) {
                    continue;
                }
                instakill(e, true, bans, killerName);
                killed++;
            }
        }
        // 残留清除：对仍留在真实列表的实例做结构性移除 + 空实体顶替（防幽灵）
        if (EchoConfig.get().getBoolean("强力攻击", true)) {
            for (ServerLevel sl : server.getAllLevels()) {
                for (Entity e : EchoStructureRemoval.realEntities(sl)) {
                    if (e instanceof Player || e instanceof Marker) {
                        continue;
                    }
                    EchoStructureRemoval.structuralRemoval(sl, e);
                    EchoStructureRemoval.replaceInstance(sl, e.getId(), e, null);
                }
            }
        }
        EchoLog.get().info("右键秒杀完成：清除 " + killed + " 个实体；禁生成表 "
                + bans.banned().size() + " 类");
    }

    // ===== 入口：左键 =====

    /** 左键：秒杀被挥到的实体 + 横扫范围（含掉落物/经验球/箭）。 */
    public static void onLeftClick(Player player, Entity target) {
        if (!EchoConfig.get().getBoolean("神器左键秒杀", true)) {
            return;
        }
        // 硬判据：只有主手握着神器 ARTEMIS 时左键才秒杀（空手/其它物品一律不触发）
        if (!isHoldingArtemis(player)) {
            return;
        }
        if (player == null || player.level() == null || player.level().isClientSide
                || player.level().getServer() == null || target == null) {
            return;
        }
        EchoBanData bans = EchoBanData.get(player.level().getServer());
        String killerName = player.getDisplayName().getString();
        double r = 2.0D;
        List<Entity> swept = new ArrayList<>();
        try {
            for (Entity en : player.level().getEntitiesOfClass(Entity.class,
                    target.getBoundingBox().inflate(r, r * 0.5D, r))) {
                if (en != null) {
                    swept.add(en);
                }
            }
        } catch (Throwable ignored) {
        }
        int killed = 0;
        boolean hit = false;
        for (Entity en : swept) {
            if (en == null || en instanceof Player || en instanceof Marker) {
                continue;
            }
            if (en == target) {
                hit = true;
            }
            instakill(en, true, bans, killerName);
            killed++;
        }
        if (!hit && !(target instanceof Player)) {
            instakill(target, true, bans, killerName);
            killed++;
        }
        EchoLog.get().info("左键挥击秒杀：" + killed + " 个实体（目标 " + target.getType().toShortString() + "）");
    }

    // ===== 秒杀核心 =====

    public static void instakill(Entity e, boolean ban, EchoBanData bans, String killerName) {
        if (e == null) {
            return;
        }
        killInternal(e, killerName);
        if (ban && bans != null && EchoConfig.get().getBoolean("秒杀禁生成", true)) {
            try {
                String key = ForgeRegistries.ENTITY_TYPES.getKey(e.getType()).toString();
                bans.ban(key);
                EchoDoomList.banType(key);
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * 秒杀核心：幽灵猎杀 → 原版 hurt(MAX) 完整死亡流程 → 多路改血锁 0 → 真实移除 +
     * 结构性移除 + 空实体顶替 → doom 标记。全程 try/catch，任何一步失败不影响其余步骤。
     */
    private static void killInternal(Entity e, String killerName) {
        int origId = e.getId();
        // 1) 幽灵猎杀：把隐形/假死标志拉回"可见、可杀"
        try {
            e.setInvisible(false);
            e.setNoGravity(false);
        } catch (Throwable ignored) {
        }
        try {
            Method unset = Entity.class.getDeclaredMethod("unsetRemoved");
            unset.setAccessible(true);
            unset.invoke(e);
        } catch (Throwable ignored) {
        }
        // 2) 原版死亡流程（掉落/经验/死亡动画）
        if (e instanceof LivingEntity le) {
            try {
                le.hurt(le.damageSources().genericKill(), Float.MAX_VALUE);
            } catch (Throwable ignored) {
            }
            // 3) 多路改血锁 0（防自定义血量系统/吸收甲/属性修饰器复活）
            if (EchoConfig.get().getBoolean("改血", true)) {
                zeroFloatDataKeys(le);
                try {
                    le.getPersistentData().putFloat("Health", 0.0F);
                } catch (Throwable ignored) {
                }
                try {
                    AttributeInstance max = le.getAttribute(Attributes.MAX_HEALTH);
                    if (max != null) {
                        max.setBaseValue(0.0D);
                        max.addPermanentModifier(new AttributeModifier(DOOM_UUID, "echoes_doom",
                                -max.getBaseValue(), AttributeModifier.Operation.ADDITION));
                    }
                } catch (Throwable ignored) {
                }
                writeHealthFields(le);
                runSetHealthMethods(le);
                forceWriteHealthFields(le);
                try {
                    le.setHealth(0.0F);
                } catch (Throwable ignored) {
                }
            }
        }
        // 4) 全布尔字段归零（杀状态；在移除标记之前）
        if (EchoConfig.get().getBoolean("改血", true)) {
            writeBooleanFields(e);
        }
        // 5) 真实移除
        try {
            e.remove(Entity.RemovalReason.KILLED);
        } catch (Throwable ignored) {
        }
        try {
            e.discard();
        } catch (Throwable ignored) {
        }
        try {
            e.setRemoved(Entity.RemovalReason.KILLED);
        } catch (Throwable ignored) {
        }
        setRemovalReasonField(e, Entity.RemovalReason.KILLED);
        // 6) 终态：隐形 / 无重力 / 静音
        try {
            e.setInvisible(true);
            e.setNoGravity(true);
            e.setSilent(true);
        } catch (Throwable ignored) {
        }
        // 7) 黑名单标记（@e/选择器不可见）
        EchoDoomList.markDoomed(e);
        // 8) 反复活：无 AI + 目标选择器清空
        try {
            if (e instanceof Mob mob) {
                mob.setNoAi(true);
                mob.goalSelector.getAvailableGoals().clear();
                mob.targetSelector.getAvailableGoals().clear();
            }
        } catch (Throwable ignored) {
        }
        // 9) 结构性同步移除 + 空实体顶替
        if (EchoConfig.get().getBoolean("强力攻击", true) && e.level() instanceof ServerLevel sl) {
            EchoStructureRemoval.structuralRemoval(sl, e);
            if (origId >= 0) {
                EchoStructureRemoval.replaceInstance(sl, origId, e, killerName);
            }
        }
    }

    /** 每 tick 巡检（由 {@code EchoGuardServerTickMixin} 在 tick 结尾调用）：驱逐被禁/doomed 实体。 */
    public static void sweep(MinecraftServer server) {
        if (!EchoConfig.get().getBoolean("循环攻击", true) || server == null || !EchoDoomList.hasBans()) {
            return;
        }
        int killed = 0;
        for (ServerLevel sl : server.getAllLevels()) {
            for (Entity e : EchoStructureRemoval.realEntities(sl)) {
                if (e instanceof Player || e instanceof Marker) {
                    continue;
                }
                if (EchoDoomList.isBannedType(e) || EchoDoomList.isDoomedEntity(e)) {
                    instakill(e, false, null, null);
                    killed++;
                }
            }
        }
        if (killed > 0) {
            EchoLog.get().info("巡检驱逐被禁实体 " + killed + " 个");
        }
    }

    // ===== 改血工具 =====

    /** 全部 Float 同步数据键 → 0（只写确实是 Float 的槽位）。 */
    static void zeroFloatDataKeys(LivingEntity le) {
        Class<?> c = LivingEntity.class;
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) || f.getType() != EntityDataAccessor.class) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    Object acc = f.get(null);
                    if (acc instanceof EntityDataAccessor<?> raw) {
                        Object current = le.getEntityData().get((EntityDataAccessor<?>) raw);
                        if (current instanceof Float) {
                            @SuppressWarnings("unchecked")
                            EntityDataAccessor<Float> typed = (EntityDataAccessor<Float>) raw;
                            le.getEntityData().set(typed, 0.0F);
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }

    /** setter 扫描：所有 setHealth/setHealthAmount 形方法归零。 */
    private static void runSetHealthMethods(LivingEntity le) {
        Class<?> c = le.getClass();
        while (c != null && c != Object.class) {
            for (Method m : c.getDeclaredMethods()) {
                String n = m.getName().toLowerCase(Locale.ROOT);
                if (!n.equals("sethealth") && !n.equals("sethealthamount") && !n.equals("m_21153_")) {
                    continue;
                }
                if (Modifier.isStatic(m.getModifiers()) || m.getParameterCount() != 1
                        || m.getParameterTypes()[0] != float.class) {
                    continue;
                }
                try {
                    m.setAccessible(true);
                    m.invoke(le, 0.0F);
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }

    /** 类层级内全部实例 boolean 字段 → false。 */
    private static void writeBooleanFields(Entity e) {
        Class<?> c = e.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || f.getType() != boolean.class) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    f.setBoolean(e, false);
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }

    /** 按字段类型定位并写入移除原因（不依赖开发字段名）。 */
    private static void setRemovalReasonField(Entity e, Entity.RemovalReason reason) {
        try {
            Class<?> c = Entity.class;
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (Modifier.isStatic(f.getModifiers()) || f.getType() != Entity.RemovalReason.class) {
                        continue;
                    }
                    try {
                        f.setAccessible(true);
                        f.set(e, reason);
                    } catch (Throwable ignored) {
                    }
                }
                c = c.getSuperclass();
            }
        } catch (Throwable ignored) {
        }
    }

    /** 遍历类层级：float 类型、名字含 health 的实例字段 → 0。 */
    static void writeHealthFields(LivingEntity le) {
        Class<?> c = le.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !f.getName().toLowerCase(Locale.ROOT).contains("health")) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    f.setFloat(le, 0.0F);
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }

    /** Unsafe 兜底写 health 字段（跳过访问控制）。 */
    static void forceWriteHealthFields(LivingEntity le) {
        if (UNSAFE == null) {
            return;
        }
        Class<?> c = le.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                if (f.getType() != float.class && f.getType() != Float.class) {
                    continue;
                }
                if (!f.getName().toLowerCase(Locale.ROOT).contains("health")) {
                    continue;
                }
                try {
                    UNSAFE.putFloat(le, UNSAFE.objectFieldOffset(f), 0.0F);
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }
}
