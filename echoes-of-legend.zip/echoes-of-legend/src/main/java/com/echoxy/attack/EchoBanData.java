package com.echoxy.attack;

import java.util.HashSet;
import java.util.Set;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * 禁生成表：随存档持久化保存的实体注册名黑名单。
 *
 * <p>被右键秒杀的实体注册名写入此表；之后任何该实体的生成/加入世界都会被拦截
 * （由 {@code EchoGuardEntityGateMixin} 实现）。</p>
 */
public final class EchoBanData extends SavedData {

    private static final String NAME = "echoes_banned_entities";

    private final Set<String> banned = new HashSet<>();

    public EchoBanData() {
    }

    public static EchoBanData load(CompoundTag tag) {
        EchoBanData data = new EchoBanData();
        ListTag list = tag.getList("banned", Tag.TAG_STRING);
        for (Tag t : list) {
            data.banned.add(t.getAsString());
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (String s : banned) {
            list.add(StringTag.valueOf(s));
        }
        tag.put("banned", list);
        return tag;
    }

    public static EchoBanData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(EchoBanData::load, EchoBanData::new, NAME);
    }

    public boolean isBanned(String registryName) {
        return banned.contains(registryName);
    }

    public void ban(String registryName) {
        if (registryName != null && banned.add(registryName)) {
            setDirty();
        }
    }

    public Set<String> banned() {
        return banned;
    }
}
