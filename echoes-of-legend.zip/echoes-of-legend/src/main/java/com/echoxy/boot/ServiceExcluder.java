package com.echoxy.boot;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.zip.ZipFile;

/**
 * 服务提供者共存：让「既是框架服务提供者、又带 mods.toml」的 jar 以 MOD 身份注册，
 * 同时把它从服务层的模块图里摘掉，避免两个模块导出同一个包而触发
 * {@code java.lang.module.ResolutionException}。
 *
 * <h2>为什么需要两步</h2>
 * <p>Forge 的流程里同一个 jar 可能被登记两次：</p>
 * <ol>
 *   <li>服务发现（{@code ServiceLoader} 看到它提供了框架服务）→ 把它作为模块放进
 *       <b>服务层</b>，模块名由 jar 文件名推导；</li>
 *   <li>mod 目录扫描 → 若它也有 {@code mods.toml}，再把它作为模块放进
 *       <b>游戏层</b>，模块名取自 modId。</li>
 * </ol>
 * <p>两层各有一个模块，且都导出同一个包；JPMS 不允许两个模块把同一个包导出给
 * 同一个读取者，于是在构建游戏层的模块图时抛 ResolutionException。</p>
 *
 * <p>因此正确的做法是成对的两步，缺一不可：</p>
 * <ul>
 *   <li><b>第一步</b>：把它从「服务提供者排除表」里摘掉，否则它根本进不了 mod 发现；</li>
 *   <li><b>第二步</b>：把它从服务层的 {@code Configuration} 里摘掉，否则第一步之后
 *       两个模块仍然并存，照样冲突。</li>
 * </ul>
 *
 * <h2>怎么做到「不点名」</h2>
 * <ul>
 *   <li>不读任何具体类名/字段名来判断目标：用
 *       {@code module.getResourceAsStream("META-INF/mods.toml")} 判定「这个模块带不带 mod 描述」，
 *       这是 mod 的文件布局事实，不是谁的私有名字；</li>
 *   <li>改 {@code Configuration} 时按 <b>字段类型</b>定位（{@code Map} / {@code Set}），
 *       不依赖内部字段名。</li>
 * </ul>
 *
 * <h2>时序</h2>
 * <pre>
 *   1. 服务发现早期  candidates() → 排除表被填满
 *   2. 服务发现中期  服务层模块图构建完成
 *   3. IWP {@code <clinit>}  ← 本类在这里（全流程最早的可控点）
 *   4. ITS 枚举 / onLoad
 *   5. 构建游戏层模块图  ← 冲突就发生在这里；本类已在第 3 步消除隐患
 *   6. mod 目录扫描
 * </pre>
 *
 * <h2>稳定性</h2>
 * 全部步骤独立 try/catch(Throwable)，任何失败只写证据并继续；
 * 修改集合时先复制再替换，避免直接改动正在被读的集合。
 */
public final class ServiceExcluder {
    private ServiceExcluder() {
    }

    /** 承载「服务提供者排除表」的类（Forge 的公开内部结构）。 */
    private static final String TABLE_CLASS = "net.minecraftforge.fml.loading.ModDirTransformerDiscoverer";
    /** 排除表字段名。 */
    private static final String TABLE_FIELD = "found";
    /** mod 描述文件的固定路径（mod 布局事实）。 */
    private static final String MODS_TOML = "META-INF/mods.toml";

    /**
     * 执行共存处理（幂等；失败只降级）。
     *
     * <h2>为什么不再回滚</h2>
     * <p>旧实现把「第二步没摘到就回滚第一步」当成安全阀。实测证明那条策略是错的：
     * 第二步只在「该模块已经在某个已建好的层里」时才能摘到，而 ModLauncher 的
     * 层构建是<b>分阶段</b>的（BOOT → SERVICE → PLUGIN → GAME）。早期调用
     * （IWP {@code <clinit>}、ITS {@code initialize}）时 PLUGIN 层可能还没建，
     * 于是必然「摘不到」⇒ 回滚 ⇒ 第一次成功的机会被自己的安全阀吃掉了，
     * 后面再也没机会。正确做法是<b>每一步各自幂等、各自尽力</b>：
     * 排除表的释放一旦做成就是最终状态（mod 能被扫描到），模块图的摘除
     * 由后面的时机（{@code completeScan}、C 层钩子）继续推进。</p>
     *
     * <h2>为什么多时机重复调用是安全的</h2>
     * <ul>
     *   <li>{@code releaseFromTable}：第二次调用时表里已无「带 mods.toml」条目，
     *       自然返回 0，不会误摘别人；</li>
     *   <li>{@code stripFromServiceLayer}：已摘掉的模块不再出现在
     *       {@code Configuration.modules()} 里，也不会被重复计数。</li>
     * </ul>
     *
     * @param tag 证据标记（只用于区分调用来源）
     */
    public static void arm(final String tag) {
        if (!EchoConfig.get().getBoolean("共存", true)) {
            Evidence.write("service-excluder disabled-by-config tag=" + tag);
            return;
        }
        try {
            final List<?> table = locateTable(tag);
            int released = 0;
            if (table != null) {
                released = releaseFromTable(table, tag).size();
            }
            // ────────────────────────────────────────────────────────────
            // ★ 前置条件（不是回滚，是「不许只摘不补」）
            //
            //   表里只要还剩「带 mods.toml」的条目，就说明那个 jar 仍会被
            //   ModsFolderLocator 过滤掉 —— 它不会被当 mod 扫进游戏层。
            //   此刻若摘它的模块图，等于把它从服务层删掉又没有在游戏层补上：
            //   它自己的类再无来源，下一次 Class.forName 就是
            //   NoClassDefFoundError。
            //
            //   所以「摘模块图」的充分条件是「表已干净」。表干净有两种来路：
            //     · 本来就没有带 mods.toml 的服务提供者（无需共存）；
            //     · 本方（或对手自己）已经把它摘出去了 —— jar 会被扫描到。
            //   两种情况下摘模块图都是「有补」的，安全。
            // ────────────────────────────────────────────────────────────
            final int remaining = countModsTomlEntries(table);
            if (remaining > 0) {
                Evidence.write("service-excluder skip-strip remaining=" + remaining
                        + " released=" + released + " tag=" + tag);
                return;
            }
            if (!EchoConfig.get().getBoolean("共存", true)) {
                Evidence.write("service-excluder second-step-disabled tag=" + tag);
                return;
            }
            final int stripped = stripFromServiceLayer(tag);
            Evidence.write("service-excluder arm released=" + released
                    + " stripped=" + stripped + " tag=" + tag);
        } catch (final Throwable t) {
            Evidence.write("service-excluder-err " + Evidence.brief(t) + " tag=" + tag);
        }
    }

    /** 数一数排除表里还剩多少条「带 mods.toml」的条目（= 仍会被过滤掉的 mod）。 */
    private static int countModsTomlEntries(final List<?> table) {
        if (table == null || table.isEmpty()) {
            return 0;
        }
        int n = 0;
        synchronized (table) {
            for (final Object entry : new ArrayList<>(table)) {
                try {
                    if (entryHasModsToml(entry)) {
                        n++;
                    }
                } catch (final Throwable ignored) {
                    // 单条失败不计
                }
            }
        }
        return n;
    }

    /**
     * C 层钩子入口：只做第一步（解除排除表），绝不碰模块图。
     *
     * <p>由服务发现早期各服务席位（IWP/ITS 的 clinit/ctor）调用。这一步在当前时机
     * 是零风险的：</p>
     * <ol>
     *   <li>它只删 {@code List} 里的元素，不产生新的模块、不改 {@code Configuration}，
     *       因此不可能触发 {@code ResolutionException}；</li>
     *   <li>此时 ModLauncher 的服务发现已走到枚举阶段 —— 排除表（由
     *       {@code ModDirTransformerDiscoverer} 在扫描 mods 目录时填满）已就位。</li>
     * </ol>
     *
     * <p>幂等：多次命中只会让第二次起变成空操作。</p>
     *
     * @return 真正从排除表里摘出的条目数（0 = 这一枪没打中）
     */
    public static int armFromNative() {
        if (!EchoConfig.get().getBoolean("共存", true)) {
            return 0;
        }
        try {
            final List<?> table = locateTable("c-layer");
            if (table == null) {
                return 0;
            }
            final int released = releaseFromTable(table, "c-layer").size();
            if (released > 0) {
                Evidence.write("service-excluder c-layer released=" + released);
            }
            return released;
        } catch (final Throwable t) {
            Evidence.write("service-excluder-err " + Evidence.brief(t) + " tag=c-layer");
            return 0;
        }
    }

    // ------------------------------------------------------------------
    // 第一步：从排除表里摘掉「带 mods.toml」的条目
    // ------------------------------------------------------------------

    /**
     * 定位排除表。
     *
     * <h2>为什么必须用「类字面量」而不是 {@code Class.forName}</h2>
     * <p>类字面量的解析走 JVM 的常量池解析：{@code defining loader} + <b>本模块的
     * reads 图</b>。本方模块是自动模块（{@code Automatic-Module-Name}），自动模块
     * 读一切，于是解析成功。</p>
     *
     * <p>而 {@code Class.forName(name, false, loader)} 没有调用者上下文，直接落到
     * {@code ModuleClassLoader.loadClass}：它只查「自己这个模块的包」，同层的
     * {@code fmlloader} 模块的类查不到，抛 {@code ClassNotFoundException}。</p>
     *
     * <h2>为什么必须用 Unsafe 读字段</h2>
     * <p>{@code found} 是 {@code fmlloader} 模块里的 {@code private static final} 字段。
     * 跨模块 {@code setAccessible} 会抛 {@code InaccessibleObjectException}（本方不能也不该
     * 要求 {@code --add-opens}）。{@code Unsafe.staticFieldBase/staticFieldOffset} 绕过访问检查。</p>
     */
    private static List<?> locateTable(final String tag) throws Exception {
        final Field field = net.minecraftforge.fml.loading.ModDirTransformerDiscoverer.class
                .getDeclaredField(TABLE_FIELD);
        final Object value;
        final sun.misc.Unsafe u = unsafe();
        if (u != null) {
            value = u.getObject(u.staticFieldBase(field), u.staticFieldOffset(field));
        } else {
            if (!field.trySetAccessible()) {
                field.setAccessible(true);
            }
            value = field.get(null);
        }
        if (!(value instanceof List)) {
            Evidence.write("service-excluder field-not-list tag=" + tag);
            return null;
        }
        return (List<?>) value;
    }

    /**
     * 遍历排除表，把「同 jar 里带 mods.toml」的条目摘出来。
     *
     * @return 被摘出的条目（供第二步使用）
     */
    private static List<Object> releaseFromTable(final List<?> table, final String tag) {
        final List<Object> released = new ArrayList<>();
        if (table.isEmpty()) {
            Evidence.write("service-excluder table-empty tag=" + tag);
            return released;
        }
        final int before = table.size();
        synchronized (table) {
            final List<Object> snapshot = new ArrayList<>(table);
            for (final Object entry : snapshot) {
                try {
                    if (entryHasModsToml(entry)) {
                        released.add(entry);
                    }
                } catch (final Throwable ignored) {
                    // 单条判定失败不影响其它
                }
            }
            for (final Object entry : released) {
                table.remove(entry);
            }
        }
        Evidence.write("service-excluder table=" + before + " released=" + released.size() + " tag=" + tag);
        return released;
    }

    /** 判定一条排除表条目所指向的 jar 是否带 {@code META-INF/mods.toml}。 */
    private static boolean entryHasModsToml(final Object entry) {
        final Path jar = firstPathOf(entry);
        if (jar == null) {
            return false;
        }
        try (ZipFile zip = new ZipFile(jar.toFile())) {
            return zip.getEntry(MODS_TOML) != null;
        } catch (final Throwable ignored) {
            return false;
        }
    }

    /** 用反射从 {@code NamedPath.paths()} 取第一个路径（不依赖其类型名）。 */
    private static Path firstPathOf(final Object entry) {
        if (entry == null) {
            return null;
        }
        try {
            final java.lang.reflect.Method m = entry.getClass().getMethod("paths");
            final Object v = m.invoke(entry);
            if (v instanceof Path[]) {
                final Path[] arr = (Path[]) v;
                return arr.length > 0 ? arr[0] : null;
            }
            if (v instanceof Collection) {
                for (final Object o : (Collection<?>) v) {
                    if (o instanceof Path) {
                        return (Path) o;
                    }
                }
            }
        } catch (final Throwable ignored) {
            // 结构变化即放弃该条目
        }
        return null;
    }

    // ------------------------------------------------------------------
    // 第二步：把「带 mods.toml」的模块从服务层的 Configuration 里摘掉
    // ------------------------------------------------------------------

    /**
     * 遍历已建好的模块层，把带 mods.toml 的模块从各自层的 {@code Configuration} 中移除。
     *
     * <p>只处理「已存在的层的 Configuration」；游戏层此时尚未构建，
     * 所以不会误伤正常的 mod 模块。</p>
     *
     * @return 真正被摘掉的模块数量（0 表示这一步没生效）
     */
    private static int stripFromServiceLayer(final String tag) {
        int stripped = 0;
        try {
            final Object mgrObj = locateLayerManager();
            if (!(mgrObj instanceof cpw.mods.modlauncher.api.IModuleLayerManager)) {
                Evidence.write("service-excluder layer-manager-missing tag=" + tag);
                return 0;
            }
            final cpw.mods.modlauncher.api.IModuleLayerManager mgr =
                    (cpw.mods.modlauncher.api.IModuleLayerManager) mgrObj;
            for (final cpw.mods.modlauncher.api.IModuleLayerManager.Layer layerType
                    : cpw.mods.modlauncher.api.IModuleLayerManager.Layer.values()) {
                try {
                    final java.util.Optional<java.lang.ModuleLayer> opt = mgr.getLayer(layerType);
                    if (opt == null || !opt.isPresent()) {
                        continue;
                    }
                    stripped += stripOneLayer(opt.get(), layerType.name(), tag);
                } catch (final Throwable ignored) {
                    // 该层尚未构建：ModLauncher 实现会抛空指针，跳过
                }
            }
            Evidence.write("service-excluder stripped=" + stripped + " tag=" + tag);
        } catch (final Throwable t) {
            Evidence.write("service-excluder strip-err " + Evidence.brief(t) + " tag=" + tag);
        }
        return stripped;
    }

    /** 定位 {@code IModuleLayerManager} 实现实例（主路径 + 冗余路径）。 */
    private static Object locateLayerManager() {
        try {
            final Class<?> launcherCls = locateClass("cpw.mods.modlauncher.Launcher");
            if (launcherCls == null) {
                Evidence.write("service-excluder launcher-not-visible");
                return null;
            }
            final Field instF = launcherCls.getDeclaredField("INSTANCE");
            instF.setAccessible(true);
            final Object launcher = instF.get(null);
            if (launcher == null) {
                Evidence.write("service-excluder launcher-null");
                return null;
            }
            // 主路径：模块层处理器是 Launcher 的直接字段
            try {
                final Field f = launcherCls.getDeclaredField("moduleLayerHandler");
                f.setAccessible(true);
                final Object v = f.get(launcher);
                if (v instanceof cpw.mods.modlauncher.api.IModuleLayerManager) {
                    Evidence.write("service-excluder layer-manager via direct field");
                    return v;
                }
            } catch (final Throwable ignored) {
                // 走冗余路径
            }
            // 冗余路径：经由服务处理器再找模块层处理器（按类型匹配）
            try {
                final Field tshF = launcherCls.getDeclaredField("transformationServicesHandler");
                tshF.setAccessible(true);
                final Object tsh = tshF.get(launcher);
                if (tsh != null) {
                    for (final Field f : tsh.getClass().getDeclaredFields()) {
                        if (cpw.mods.modlauncher.api.IModuleLayerManager.class
                                .isAssignableFrom(f.getType())) {
                            f.setAccessible(true);
                            final Object v = f.get(tsh);
                            if (v instanceof cpw.mods.modlauncher.api.IModuleLayerManager) {
                                Evidence.write("service-excluder layer-manager via service handler");
                                return v;
                            }
                        }
                    }
                }
            } catch (final Throwable ignored) {
                // 两条路都失败
            }
        } catch (final Throwable t) {
            Evidence.write("service-excluder locate-mgr-err " + Evidence.brief(t));
        }
        return null;
    }

    /** 用多路类加载器定位类（与排除表定位同一套策略）。 */
    private static Class<?> locateClass(final String name) {
        final ClassLoader[] loaders = {
                Thread.currentThread().getContextClassLoader(),
                ServiceExcluder.class.getClassLoader(),
                ClassLoader.getSystemClassLoader(),
                ClassLoader.getPlatformClassLoader(),
        };
        for (final ClassLoader cl : loaders) {
            if (cl == null) {
                continue;
            }
            try {
                final Class<?> c = Class.forName(name, false, cl);
                if (c != null) {
                    return c;
                }
            } catch (final Throwable ignored) {
                // 下一个加载器
            }
        }
        return null;
    }

    /**
     * 从单个层的 {@code Configuration} 里移除「带 mods.toml」的模块。
     *
     * <p>遍历来源换成 <b>官方 API</b>：{@code Configuration.modules()} 返回
     * {@code Set<ResolvedModule>}，每个 {@code ResolvedModule} 又能通过
     * {@code reference().location()} 拿到所属 jar 的 URI。
     * 这样既能回答「模块到底在不在这一层」，又能直接读 jar 判断 mods.toml，
     * 完全绕开模块资源封装的问题。</p>
     */
    private static int stripOneLayer(final Object layer, final String layerName, final String tag) {
        int stripped = 0;
        try {
            final java.lang.reflect.Method configM = layer.getClass().getMethod("configuration");
            final Object configObj = configM.invoke(layer);
            if (!(configObj instanceof java.lang.module.Configuration)) {
                Evidence.write("service-excluder layer=" + layerName + " config-unavailable tag=" + tag);
                return 0;
            }
            final java.lang.module.Configuration config = (java.lang.module.Configuration) configObj;
            final Set<java.lang.module.ResolvedModule> modules = config.modules();
            Evidence.write("service-excluder layer=" + layerName + " modules=" + modules.size() + " tag=" + tag);

            for (final java.lang.module.ResolvedModule rm : modules) {
                try {
                    // JDK 17 的 ResolvedModule 没有 module()，要从层里按名字反查
                    java.lang.Module module = null;
                    try {
                        final java.lang.reflect.Method findM =
                                layer.getClass().getMethod("findModule", String.class);
                        final Object optObj = findM.invoke(layer, rm.name());
                        if (optObj instanceof Optional) {
                            final Object m = ((Optional<?>) optObj).orElse(null);
                            if (m instanceof java.lang.Module) {
                                module = (java.lang.Module) m;
                            }
                        }
                    } catch (final Throwable ignored) {
                        // 拿不到 Module 也没关系，方案①②仍可独立工作
                    }
                    if (!resolvedModuleHasModsToml(rm, module, layerName, tag)) {
                        continue;
                    }
                    if (removeResolvedModuleFromConfig(config, rm)) {
                        stripped++;
                        Evidence.write("service-excluder stripped-module layer=" + layerName + " tag=" + tag);
                    }
                } catch (final Throwable ignored) {
                    // 单个模块失败不影响其它
                }
            }
        } catch (final Throwable t) {
            Evidence.write("service-excluder layer=" + layerName + " err=" + Evidence.brief(t) + " tag=" + tag);
        }
        return stripped;
    }

    /**
     * 判断一个已解析模块是否「带 mod 描述」。三套手段依次尝试，任一成立即可。
     *
     * <ol>
     *   <li><b>官方位置</b>：{@code reference().location()} 拿 jar URI，直接读 zip 找
     *       {@code META-INF/mods.toml}（最可靠，不受资源封装影响）；</li>
     *   <li><b>模块资源</b>：{@code module.getResourceAsStream("META-INF/mods.toml")}；</li>
     *   <li><b>类加载器映射</b>：从该模块的类加载器里按类型找 {@code Map}，
     *       用模块名反查对应的 jar 路径（作为最后兜底）。</li>
     * </ol>
     */
    private static boolean resolvedModuleHasModsToml(final java.lang.module.ResolvedModule rm,
                                                     final java.lang.Module module,
                                                     final String layerName, final String tag) {
        // ① 官方位置 → 直接读 jar
        try {
            final Optional<java.net.URI> loc = rm.reference().location();
            if (loc != null && loc.isPresent()) {
                final Path jar = Paths.get(loc.get());
                if (jarHasModsToml(jar)) {
                    Evidence.write("service-excluder candidate[uri] layer=" + layerName + " tag=" + tag);
                    return true;
                }
            }
        } catch (final Throwable ignored) {
            // 继续下一方案
        }
        // ② 模块资源
        try {
            if (module != null) {
                final java.io.InputStream s = module.getResourceAsStream(MODS_TOML);
                if (s != null) {
                    s.close();
                    Evidence.write("service-excluder candidate[res] layer=" + layerName + " tag=" + tag);
                    return true;
                }
            }
        } catch (final Throwable ignored) {
            // 继续下一方案
        }
        // ③ 类加载器映射（最后兜底）
        try {
            final Path jar = jarPathFromLoader(rm, module, tag);
            if (jar != null && jarHasModsToml(jar)) {
                Evidence.write("service-excluder candidate[cl] layer=" + layerName + " tag=" + tag);
                return true;
            }
        } catch (final Throwable ignored) {
            // 三套都失败
        }
        return false;
    }

    /** 读 jar 判断有没有 {@code META-INF/mods.toml}。 */
    private static boolean jarHasModsToml(final Path jar) {
        try (ZipFile zip = new ZipFile(jar.toFile())) {
            return zip.getEntry(MODS_TOML) != null;
        } catch (final Throwable ignored) {
            return false;
        }
    }

    /**
     * 从模块的类加载器里反查 jar 路径（兜底手段）。
     *
     * <p>模块加载器内部通常持有一张「模块名 → 模块定义（含 jar 路径）」的 Map。
     * 这里按<b>类型</b>找 Map、按模块名取值，再反射取其中的路径字段，
     * 不依赖任何具体字段名。</p>
     */
    private static Path jarPathFromLoader(final java.lang.module.ResolvedModule rm,
                                          final java.lang.Module module, final String tag) {
        try {
            if (module == null) {
                return null;
            }
            final ClassLoader cl = module.getClassLoader();
            if (cl == null) {
                return null;
            }
            final String modName = module.getName();
            for (final Field f : cl.getClass().getDeclaredFields()) {
                if (!Map.class.isAssignableFrom(f.getType())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    final Object v = f.get(cl);
                    if (!(v instanceof Map)) {
                        continue;
                    }
                    final Object entry = ((Map<?, ?>) v).get(modName);
                    if (entry == null) {
                        continue;
                    }
                    // 在条目里按类型找 Path / URI 字段
                    for (final Field ef : entry.getClass().getDeclaredFields()) {
                        if (ef.getType() == Path.class) {
                            ef.setAccessible(true);
                            final Object p = ef.get(entry);
                            if (p instanceof Path) {
                                return (Path) p;
                            }
                        } else if (ef.getType() == java.net.URI.class) {
                            ef.setAccessible(true);
                            final Object u = ef.get(entry);
                            if (u instanceof java.net.URI) {
                                return Paths.get((java.net.URI) u);
                            }
                        }
                    }
                } catch (final Throwable ignored) {
                    // 下一个字段
                }
            }
        } catch (final Throwable ignored) {
            // 兜底也失败
        }
        return null;
    }

    /**
     * 从 {@code Configuration} 的内部集合里移除指定已解析模块。
     *
     * <p><b>为什么必须走 Unsafe</b>：{@code java.lang.module.Configuration} 属于
     * {@code java.base} 模块，它的内部字段是私有的。对 {@code java.base} 的私有字段
     * 调用 {@code setAccessible(true)} 会被模块系统直接拒绝
     * （{@code InaccessibleObjectException}），而本程序没有也**不应该**要求
     * {@code --add-opens}。因此这里改用 {@code sun.misc.Unsafe} 按对象偏移读写：
     * 它绕过访问检查，也不需要打开模块。</p>
     *
     * <p>按<b>字段值的运行时类型</b>判断：{@code Map}（名→解析模块）与
     * {@code Set}（全部解析模块）。先复制、再整体替换，绝不直接改动正在被读的集合。</p>
     */
    private static boolean removeResolvedModuleFromConfig(final java.lang.module.Configuration config,
                                                          final java.lang.module.ResolvedModule target) {
        final String targetName = target.name();
        boolean removed = false;
        final sun.misc.Unsafe u = unsafe();
        for (final Field f : config.getClass().getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) {
                continue;
            }
            try {
                final Object v = readField(config, f, u);
                // ------------------------------------------------------------
                // ① 名字表：Map<String, ResolvedModule>  —— 键是 String
                //
                //    ★★★ 这一处是整件事的关键 ★★★
                //
                //    只改「依赖图」是无效的：GAME 层构建时，Resolver 会拿
                //    **父层的 Configuration** 建立一个「父模块视图」，那个视图
                //    正是从 nameToModule（名字表）与 modules（模块集）读出来的。
                //    名字表里还留着本模块，父层视图里就还有它；于是
                //    checkExportSuppliers 看到「父层的它也导出了这个包」⇒
                //    ResolutionException 照旧。改依赖图只是改了一份没人再读的
                //    快照，问题原地不动。
                //
                //    反过来，把名字表与模块集都摘掉，父层视图里就没有它了，
                //    Resolver 也就无从重复统计。
                //
                //    为什么不改依赖图：依赖图（键是 ResolvedModule）在
                //    Configuration 构造完成后只服务 graph() 这个只读访问器，
                //    Resolver 不再回读它；动它反而可能让读取方看到
                //    「模块集里有、依赖图里没有」的不一致形态。保持原样最安全。
                // ------------------------------------------------------------
                if (v instanceof Map) {
                    final Map<?, ?> map = (Map<?, ?>) v;
                    if (!keysAreStrings(map)) {
                        continue; // 依赖图：保持不变
                    }
                    if (!map.containsKey(targetName)) {
                        continue;
                    }
                    final Map<Object, Object> copy = new java.util.LinkedHashMap<>(map);
                    copy.remove(targetName);
                    writeField(config, f, copy, u);
                    removed = true;
                    continue;
                }
                // ------------------------------------------------------------
                // ② 模块集：Set<ResolvedModule>
                // ------------------------------------------------------------
                if (v instanceof Set) {
                    final Set<?> set = (Set<?>) v;
                    Set<Object> copy = null;
                    for (final Object item : set) {
                        if (isSameResolved(item, target)) {
                            if (copy == null) {
                                copy = new HashSet<>(set);
                            }
                            copy.remove(item);
                        }
                    }
                    if (copy != null) {
                        writeField(config, f, copy, u);
                        removed = true;
                    }
                }
            } catch (final Throwable ignored) {
                // 单个字段失败继续
            }
        }
        return removed;
    }

    /** 判断一张 Map 的键是否全是 {@code String}（= 名字表，而不是依赖图）。 */
    private static boolean keysAreStrings(final Map<?, ?> map) {
        for (final Object k : map.keySet()) {
            if (!(k instanceof String)) {
                return false;
            }
        }
        return true;
    }

    /** 读实例字段（{@code java.base} 的私有 final 字段走 Unsafe）。 */
    private static Object readField(final Object target, final Field f, final sun.misc.Unsafe u)
            throws Exception {
        if (u != null) {
            return u.getObject(target, u.objectFieldOffset(f));
        }
        if (!f.trySetAccessible()) {
            f.setAccessible(true);
        }
        return f.get(target);
    }

    /** 写实例字段（{@code java.base} 的私有 final 字段走 Unsafe）。 */
    private static void writeField(final Object target, final Field f, final Object value,
            final sun.misc.Unsafe u) throws Exception {
        if (u != null) {
            u.putObject(target, u.objectFieldOffset(f), value);
            return;
        }
        if (!f.trySetAccessible()) {
            f.setAccessible(true);
        }
        f.set(target, value);
    }

    /** 两个已解析模块是否指向同一个对象（或同一模块名）。 */
    private static boolean isSameResolved(final Object candidate, final Object target) {
        if (candidate == null || target == null) {
            return false;
        }
        if (candidate == target) {
            return true;
        }
        try {
            final java.lang.reflect.Method m = candidate.getClass().getMethod("name");
            final Object a = m.invoke(candidate);
            final java.lang.reflect.Method t = target.getClass().getMethod("name");
            final Object b = t.invoke(target);
            return a != null && a.equals(b);
        } catch (final Throwable ignored) {
            return false;
        }
    }

    private static boolean unsafeResolved;
    private static sun.misc.Unsafe unsafeCache;

    private static sun.misc.Unsafe unsafe() {
        if (!unsafeResolved) {
            unsafeResolved = true;
            try {
                final Class<?> c = Class.forName("sun.misc.Unsafe");
                final Field f = c.getDeclaredField("theUnsafe");
                f.setAccessible(true);
                unsafeCache = (sun.misc.Unsafe) f.get(null);
            } catch (final Throwable ignored) {
                unsafeCache = null;
            }
        }
        return unsafeCache;
    }
}
