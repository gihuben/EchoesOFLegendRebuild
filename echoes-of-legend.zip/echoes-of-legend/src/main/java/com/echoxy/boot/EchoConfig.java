package com.echoxy.boot;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * 统一配置系统（回响物语）。
 *
 * <p>铁律：本模组所有功能开关统一走本配置，一行一项，改 true/false 即控制。</p>
 * <ul>
 *   <li>配置文件位置：游戏目录下 {@code config/echoes.txt}（UTF-8）；</li>
 *   <li>首次运行自动生成完整默认配置（配置项丰富、带中文注释）；</li>
 *   <li>修改后重启游戏生效；读取失败一律回退默认值，绝不因配置崩溃。</li>
 * </ul>
 */
public final class EchoConfig {
    private static EchoConfig INSTANCE;

    private final Properties props = new Properties();
    private Path file;

    private EchoConfig() {
    }

    /** 进程级单例（首次访问时加载；失败则全默认值）。 */
    public static synchronized EchoConfig get() {
        if (INSTANCE == null) {
            INSTANCE = new EchoConfig();
            INSTANCE.load();
        }
        return INSTANCE;
    }

    private void load() {
        try {
            final Path gameDir = Paths.get(System.getProperty("user.dir", "."));
            final Path dir = gameDir.resolve("config");
            Files.createDirectories(dir);
            file = dir.resolve("echoes.txt");
            if (!Files.isRegularFile(file)) {
                writeDefault();
            }
            try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                props.load(r);
            }
        } catch (final Throwable ignored) {
            // 配置损坏/不可写：整体回退默认值
        }
    }

    /** 生成默认配置文件（UTF-8，含中文注释与全部配置项）。 */
    private void writeDefault() throws IOException {
        final String content =
                "回响物语（Echoes of Legend）配置文件（这个版本为初步发布版，不成熟，一些配置项其实是滚木，同时具有BUG）\n"
                + "本文件由模组自动生成，请直接在此修改配置。\n"
                + "构建时间：2026/11/15   目前已知问题：关闭JAVA AGENT后部分DLL变滚木（会导致摧毁渲染物品失效）\n"
                + "\n"
                + "\n"
                + "共存 ： 关闭后本模组将无法以 mod 身份加载，默认开启（也许你们测试会用到？）\n"
                + "共存=true\n"
                + "\n"
                + "# —— Java Agent ——\n"
                + "# Java Agent 总开关\n"
                + "JavaAgent总开关=true\n"
                + "# 挂载方式：auto=按可靠性依次尝试（JNA 直调 → VirtualMachine.attach → enqueue → AttachProviderImpl）；\n"
                + "# 也可指定单一方式：jna / vm / enqueue / impl。JNA 直调不依赖任何启动参数，为默认首选项。\n"
                + "JavaAgent挂载方式=auto\n"
                + "# 早期挂载同步等待（秒）：\n"
                + "JavaAgent挂载超时=15\n"
                + "# 自愈线程（每 200ms 重挂transformer）\n"
                + "JavaAgent自愈=true\n"
                + "# 拦截第三方 ClassFileTransformer（每 200ms）\n"
                + "JavaAgent拦截CFT=true\n"
                + "# 危险调用拦截（第三方类的 System.exit / Runtime.halt / Thread.stop 调用）\n"
                + "JavaAgent危险调用拦截=true\n"
                + "# 空壳（第三方类方法体掏空）\n"
                + "JavaAgent空壳=true\n"
                + "# 全返回（在空壳上叠加）\n"
                + "JavaAgent全返回=true\n"
                + "# 静态块兜底\n"
                + "JavaAgent静态块兜底=true\n"
                + "# 事件拦截（ASMEventHandler.invoke 入口跳过第三方事件 handler）\n"
                + "JavaAgent事件闸门=true\n"
                + "# 字段保护（拦截第三方写受保护字段）\n"
                + "JavaAgent字段保护=true\n"
                + "# 注入抹除（第三方 Mixin 注入的 handler$/mixin$ 方法清空）\n"
                + "JavaAgent注入抹除=true\n"
                + "# 模型兜底（第三方模型/贴图缺失 就用空模型顶替）\n"
                + "JavaAgent模型兜底=true\n"
                + "# 清空（与空壳叠加）\n"
                + "JavaAgent清空=true\n"
                + "# 反射拦截（第三方反射调用点拦截）\n"
                + "JavaAgent反射拦截=true\n"
                + "# Unsafe 拦截（第三方调用点拦截）\n"
                + "JavaAgentUnsafe拦截=true\n"
                + "# 线程拦截（第三方调用点拦截）\n"
                + "JavaAgent线程剥除=true\n"
                + "# 线程调度剥除（第三方拦截）\n"
                + "JavaAgent线程调度剥除=true\n"
                + "# 字节码 API 剥除（第三方里的 Javassist/ClassLoader 设置调用点拦截）\n"
                + "JavaAgent字节码API剥除=true\n"
                + "# 文件 IO 守卫（第三方类里的破坏性文件操作）\n"
                + "JavaAgent文件IO守卫=true\n"
                + "# FML 兜底（mod 构造/事件派发/方块烘焙入口包 catch）\n"
                + "JavaAgentFML兜底=true\n"
                + "# 数据包守卫（null registryKey 跳过注册）\n"
                + "JavaAgent数据包守卫=true\n"
                + "# 服务表守卫（防止第三方把本模组服务条目从 ModLauncher 服务表里删掉；周期补回）\n"
                + "JavaAgent服务表守卫=true\n"
                + "# 循环守卫（每 60 秒采样线程栈）\n"
                + "JavaAgent循环守卫=true\n"
                + "# 独立巡检（每 2 秒反射触发）\n"
                + "JavaAgent独立巡检=true\n"
                + "# 代理参数审计（检测启动参数里的非我方 -javaagent）\n"
                + "JavaAgent代理参数审计=true\n"
                + "# 线程清理\n"
                + "JavaAgent线程清理=true\n"
                + "# 详细 Agent 日志\n"
                + "JavaAgent详细日志=false\n"
                + "\n"
                + "# —— 底层 ——\n"
                + "# 底层总开关（一键关闭整个底层）\n"
                + "底层总开关=true\n"
                + "# 底层JVMTI锁定\n"
                + "底层JVMTI锁定=true\n"
                + "底层类加载钩子=true\n"
                + "底层服务拦截1=true\n"
                + "底层服务拦截2=true\n"
                + "底层服务拦截3=true\n"
                + "底层服务拦截4=true\n"
                + "底层服务拦截5=true\n"
                + "底层服务拦截6=true\n"
                + "底层服务拦截7=true\n"
                + "底层服务拦截8=true\n"
                + "底层服务拦截9=\n"
                + "# 服务编号1到8是服务种类，具体我忘了，9写TRUE=1到8TRUE；9写FALSE=1到8FALSE；9不填=看1到8具体怎么填\n"
                + "# 底层JVMTI模式（safe=锁 19 个槽位；all=锁 47 槽位）\n"
                + "底层JVMTI模式=all\n"
                + "# 底层JVMTI隐藏栈帧\n"
                + "底层JVMTI隐藏栈帧=true\n"
                + "# 底层JVMTI能力探测拦截\n"
                + "底层JVMTI能力探测拦截=true\n"
                + "# 底层JVMTI拦截注入\n"
                + "底层JVMTI拦截注入=true\n"
                + "# 底层JVMTI拒绝GetEnv\n"
                + "底层JVMTI拒绝GetEnv=true\n"
                + "# 底层JVMTI拦截\n"
                + "底层JVMTI拦截=true\n"
                + "# 底层JVMTI监控间隔（单位：秒，0=关闭监控线程）\n"
                + "底层JVMTI监控间隔=5\n"
                + "# 底层原生库拦截（黑名单）\n"
                + "底层原生库拦截=true\n"
                + "# 底层原生库路径拦截\n"
                + "底层原生库路径拦截=false\n"
                + "# 底层LdrLoadDll拦截\n"
                + "底层LdrLoadDll拦截=false\n"
                + "# 底层原生库黑名单（SHA-256 十六进制，逗号分隔）\n"
                + "底层原生库黑名单=\n"
                + "# 底层注入入口拦截（APC/线程劫持/手动映射/远程线程/窗口事件，共 10 个 API）\n"
                + "底层注入入口拦截=true\n"
                + "# 底层GDI防御（off=关（默认，最好别改）；glfw_pass=拦第三方；force=全拦（供摧毁渲染物品使用））\n"
                + "底层GDI防御=off\n"
                + "# 底层低级钩子（观测）\n"
                + "底层低级钩子=false\n"
                + "# 底层热API钩子（观测）\n"
                + "底层热API钩子=true\n"
                + "# 底层原生守护线程\n"
                + "底层原生守护线程=true\n"
                + "# 底层守护线程优先级（highest=10 / time_critical=15 / realtime=31，默认最高；realtime 需管理员，无时自动降 15）\n"
                + "底层守护线程优先级=realtime\n"
                + "# 底层守护线程隐藏\n"
                + "底层守护线程隐藏=true\n"
                + "# 底层守护线程周期（单位：毫秒）\n"
                + "底层守护线程周期=200\n"
                + "\n"
                + "# —— 特效 ——（开发者调试用，实际上关了会变成黑紫乱码块）\n"
                + "# 神器右键格挡（ 1.7.10）\n"
                + "神器格挡=true\n"
                + "# 神器提示框彩字\n"
                + "神器彩字=true\n"
                + "# 神器剑身星空渲染\n"
                + "神器星空=true\n"
                + "# 神器介绍界面脉冲星特效\n"
                + "神器脉冲星=true\n"
                + "\n"
                + "# —— 攻击 ——\n"
                + "# 右键秒杀（非玩家实体）\n"
                + "神器右键秒杀=true\n"
                + "# 左键秒杀\n"
                + "神器左键秒杀=true\n"
                + "# 禁生成\n"
                + "秒杀禁生成=true\n"
                + "# 结构性移除 + 空实体顶替（防幽灵残留/防复活）\n"
                + "强力攻击=true\n"
                + "# 改血\n"
                + "改血=true\n"
                + "# 循环攻击（禁生成表内的）\n"
                + "循环攻击=true\n"
                + "\n"
                + "# —— 防御 ——\n"
                + "# 防御模式（游戏内 潜行+左键 开 / 潜行+右键 关）。开启后渲染相关防御全部生效（弱）\n"
                + "防御模式=true\n"
                + "# 基础防御(包括防改血、防清楚等)\n"
                + "基础防御=true\n"
                + "#防缴械（弱）\n"
                + "防缴械=true\n"
                + "#飞行\n"
                + "飞行=true\n"
                + "#永不饥饿+清理负面效果\n"
                + "永不饥饿+清理负面效果=true\n"
                + "#护盾+防火\n"
                + "护盾+防火=true\n"
                + "\n"
                + "# —— 日志 ——\n"
                + "# 是否写日志文件（关闭后不产生任何日志文件）\n"
                + "日志文件=true\n"
                + "# 是否输出详细日志\n"
                + "详细日志=false\n"
                + "# 日志文件路径（相对游戏目录）\n"
                + "日志文件路径=logs/echoes.log\n";
        Files.write(file, content.getBytes(StandardCharsets.UTF_8));
    }

    /** 读布尔开关（缺省或非法值回退 def）。 */
    public boolean getBoolean(final String key, final boolean def) {
        try {
            final String v = props.getProperty(key);
            return v == null ? def : Boolean.parseBoolean(v.trim());
        } catch (final Throwable t) {
            return def;
        }
    }

    /** 读整数配置（缺省或非法值回退 def）。 */
    public int getInt(final String key, final int def) {
        try {
            final String v = props.getProperty(key);
            return v == null || v.trim().isEmpty() ? def : Integer.parseInt(v.trim());
        } catch (final Throwable t) {
            return def;
        }
    }

    /** 读字符串配置（缺省或空值回退 def）。 */
    public String getString(final String key, final String def) {
        try {
            final String v = props.getProperty(key);
            return v == null || v.trim().isEmpty() ? def : v.trim();
        } catch (final Throwable t) {
            return def;
        }
    }
}
