package com.echoxy.boot;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 * 统一日志（回响物语）。
 *
 * <p>纪律：不搞「一个功能一个日志」的洪水。</p>
 * <ul>
 *   <li>{@link #info} —— 汇总日志，整个启动过程只有<b>几条</b>（点火完成、共存完成等）；</li>
 *   <li>{@link #fine} —— 详细日志，默认关闭，仅当配置 {@code 详细日志=true} 时输出；</li>
 *   <li>所有日志写入同一个文件（配置 {@code 日志文件路径}，默认 {@code logs/echoes.log}）。</li>
 * </ul>
 */
public final class EchoLog {
    private static EchoLog INSTANCE;

    private final Path file;
    private final boolean enabled;
    private final boolean verbose;

    private EchoLog(final Path file, final boolean enabled, final boolean verbose) {
        this.file = file;
        this.enabled = enabled;
        this.verbose = verbose;
    }

    /** 进程级单例（首次访问时按配置初始化）。 */
    public static synchronized EchoLog get() {
        if (INSTANCE == null) {
            final EchoConfig cfg = EchoConfig.get();
            final Path gameDir = Paths.get(System.getProperty("user.dir", "."));
            final String rel = cfg.getString("日志文件路径", "logs/echoes.log");
            final Path target = gameDir.resolve(rel);
            INSTANCE = new EchoLog(target,
                    cfg.getBoolean("日志文件", true),
                    cfg.getBoolean("详细日志", false));
        }
        return INSTANCE;
    }

    /** 汇总日志：每次启动只写几条关键行。 */
    public synchronized void info(final String msg) {
        append("INFO", msg);
    }

    /** 详细日志：默认关闭，仅 详细日志=true 时写。 */
    public synchronized void fine(final String msg) {
        if (verbose) {
            append("FINE", msg);
        }
    }

    /** 异常摘要（一行）。 */
    public static String brief(final Throwable t) {
        if (t == null) {
            return "null";
        }
        return t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
    }

    private void append(final String level, final String msg) {
        if (!enabled || file == null) {
            return;
        }
        try {
            Files.createDirectories(file.getParent());
            Files.write(file,
                    (java.time.LocalDateTime.now() + " [" + level + "] " + msg + System.lineSeparator())
                            .getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);
        } catch (final Throwable ignored) {
            // 日志写入失败不影响任何逻辑
        }
    }
}
