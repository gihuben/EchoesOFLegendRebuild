package com.echoxy.boot;

/**
 * 回响物语点火器（进程级幂等闸防重入）。
 *
 * <p>IWP 与 ITS 两个服务席位各自触发点火：</p>
 * <ul>
 *   <li>客户端：ImmediateWindowProvider 的 {@code <clinit>} / 构造器；</li>
 *   <li>服务端：ImmediateWindowHandler 不枚举窗口，由 ITransformationService 的
 *       {@code <clinit>} / 构造器 / {@code initialize} 覆盖。</li>
 * </ul>
 *
 * <p>点火在启动链上只做一件事——服务提供者共存的<b>第一步</b>（解除排除表），
 * 保证本 jar 能被 Forge 当 mod 扫描到。第二步（摘除重复模块）由
 * {@code EchoTransformService.completeScan} 在安全时机执行。</p>
 *
 * <p>纪律：全程只打<b>一条</b>汇总日志（点火完成/失败）；详细过程走 FINE 通道。</p>
 */
public final class EchoesBoot {
    private EchoesBoot() {
    }

    private static final String ARMED_PROP = "com.echoxy.boot.ignited";

    /** 点火入口（幂等：本进程已武装则直接返回；受配置 {@code 共存} 控制）。 */
    public static void ignite(final String tag) {
        try {
            if (!EchoConfig.get().getBoolean("共存", true)) {
                return;
            }
            final long pid = ProcessHandle.current().pid();
            final String prev = System.getProperty(ARMED_PROP);
            if (prev != null && prev.startsWith(pid + ",")) {
                return;
            }
            System.setProperty(ARMED_PROP, pid + "," + System.currentTimeMillis());

            final long t0 = System.currentTimeMillis();
            // 共存第一步：解除排除表（只删表元素，不碰模块图，安全且幂等）。
            final int released = ServiceExcluder.armFromNative();
            // Java Agent 早期自挂载（用户裁决：在 IWP 的 <clinit> 就 attach）。
            // 幂等 + 配置总闸 + 失败静默降级（后台线程 + 超时等待，绝不拖死启动）。
            try {
                com.echoxy.agent.EchoEarlyAttach.ensure();
            } catch (final Throwable agentErr) {
                EchoLog.get().fine("agent 早期挂载异常（已忽略）: " + EchoLog.brief(agentErr));
            }
            EchoLog.get().info("点火完成 tag=" + tag + " 共存释放=" + released
                    + " 用时=" + (System.currentTimeMillis() - t0) + "ms");
        } catch (final Throwable t) {
            // 不许崩：点火失败不影响宿主框架启动
            EchoLog.get().info("点火失败 tag=" + tag + " " + EchoLog.brief(t));
        }
    }
}
