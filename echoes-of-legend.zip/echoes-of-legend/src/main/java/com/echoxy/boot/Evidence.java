package com.echoxy.boot;

/**
 * 证据写入器（保留给内部共存逻辑使用）。
 *
 * <p>转发到统一日志的详细通道：默认不输出，仅配置 {@code 详细日志=true} 时记录。</p>
 */
public final class Evidence {
    private Evidence() {
    }

    /** 追加一行证据（走统一日志的 FINE 通道）。 */
    public static void write(final String line) {
        try {
            EchoLog.get().fine(line);
        } catch (final Throwable ignored) {
            // 证据写入失败不影响任何逻辑
        }
    }

    /** 异常摘要（一行）。 */
    public static String brief(final Throwable t) {
        return EchoLog.brief(t);
    }
}
