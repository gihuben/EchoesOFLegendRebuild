package com.echoxy.client;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.network.chat.Component;

/**
 * 蓝紫渐变 + 波浪浮动的彩色字体渲染器（神器彩字）。
 *
 * <p>逐字符调用原版公开 API {@link Font#drawInBatch} 渲染：</p>
 * <ul>
 *   <li>每个字符独立渲染，颜色在蓝（#3D7BFF）与紫（#B45CF0）之间随时间与横向位置
 *       平滑渐变，并携带整体 alpha；</li>
 *   <li>每个字符的 y 坐标按正弦波起伏 ⇒ 整体像波浪一样上下浮动；</li>
 *   <li>阴影由 drawInBatch 的 shadow 参数提供（原版阴影逻辑）。</li>
 * </ul>
 */
public final class GradientWaveText {

    private GradientWaveText() {
    }

    /** 文本宽度（与 render 同一逐字符口径；用于居中排版）。 */
    public static float width(String text, boolean bold) {
        if (text == null || text.isEmpty()) {
            return 0.0F;
        }
        Font font = Minecraft.getInstance().font;
        float w = 0.0F;
        for (int i = 0; i < text.length(); i++) {
            w += font.width(styleOf(String.valueOf(text.charAt(i)), bold));
        }
        return w;
    }

    /** 无缩放渲染。 */
    public static void render(String text, float x, float y, float time, PoseStack pose, MultiBufferSource buffer,
            int light, float alpha) {
        render(text, x, y, 1.0F, time, pose, buffer, light, alpha, false);
    }

    /** 缩放渲染（大标题用；缩放从 (x, y) 起算）。 */
    public static void render(String text, float x, float y, float scale, float time, PoseStack pose,
            MultiBufferSource buffer, int light, float alpha, boolean bold) {
        if (text == null || text.isEmpty()) {
            return;
        }
        int a = (int) (alpha * 255.0F);
        if (a <= 0) {
            return;
        }
        if (a > 255) {
            a = 255;
        }
        Font font = Minecraft.getInstance().font;
        float s = scale > 0.0F ? scale : 1.0F;
        pose.pushPose();
        try {
            pose.translate(x, y, 0.0F);
            pose.scale(s, s, 1.0F);
            float cx = 0.0F;
            int len = text.length();
            for (int i = 0; i < len; i++) {
                char ch = text.charAt(i);
                float t = len <= 1 ? 0.0F : (float) i / (len - 1);
                // 波浪：字符索引为相位、时间为传播速度
                float amp = bold ? 0.6F : 1.4F;
                float wave = (float) Math.sin(i * 0.55 + time * 2.2) * amp;
                int argb = (a << 24) | gradientColor(t, time);
                Component comp = styleOf(String.valueOf(ch), bold);
                font.drawInBatch(comp, cx, wave, argb, true, pose.last().pose(), buffer,
                        Font.DisplayMode.NORMAL, 0, light);
                cx += font.width(comp);
            }
        } finally {
            pose.popPose();
        }
    }

    private static Component styleOf(String s, boolean bold) {
        Component c = Component.literal(s);
        if (bold) {
            c = c.copy().withStyle(ChatFormatting.BOLD);
        }
        return c;
    }

    /** 蓝 #3D7BFF -> 紫 #B45CF0 的平滑渐变（时间摆动 + 横向相位过渡）。 */
    private static int gradientColor(float t, float time) {
        float phase = (float) (Math.sin(time * 0.55 + t * 2.1) * 0.5 + 0.5);
        int r = (int) (61 + (180 - 61) * phase);
        int g = (int) (123 + (92 - 123) * phase);
        int b = (int) (255 + (240 - 255) * phase);
        return (r << 16) | (g << 8) | b;
    }
}
