package com.echoxy.client;

import com.echoxy.EchoesOfLegendMod;

import net.minecraft.client.Minecraft;

import org.lwjgl.glfw.GLFW;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 配置界面的每帧呈现 + 鼠标状态同步（纯 Forge 官方事件，不 hook 任何系统函数）。
 *
 * <h3>为什么用 {@link RenderGuiEvent.Post}</h3>
 * <ul>
 *   <li>它在 <b>swap 之前</b>、GL 上下文 current ⇒ 我们画进后缓冲的内容与游戏画面
 *       <b>同帧同次交换</b>上屏，物理上不可能闪；</li>
 *   <li>只由 MC 提供"调用时机"，界面绘制 100% 在 {@code ECHO_CONFIG_UI.DLL} 里用 GL 完成；</li>
 *   <li>不需要 hook {@code wglSwapBuffers} ⇒ 绕开转发桩/rel32/trampoline 那一整类崩溃源。</li>
 * </ul>
 *
 * <h3>鼠标指针</h3>
 * <p>直接复用原版打开 GUI 的机制：{@code MouseHandler.releaseMouse()}（显示指针）/
 * {@code grabMouse()}（重新锁定）。这样不论界面是被「保存并关闭」「取消」「Esc」还是
 * 点面板外关闭的（后三者发生在 DLL 内部），下一帧都会被这里同步回正确状态。</p>
 */
@Mod.EventBusSubscriber(modid = EchoesOfLegendMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE,
        value = Dist.CLIENT)
public final class EchoConfigUiEvents {

    /** 上一帧的打开状态（null = 还没同步过）。 */
    private static Boolean lastOpen = null;

    private EchoConfigUiEvents() {
    }

    /** GUI 渲染完成（swap 之前）：同步鼠标 + 把原生界面贴到后缓冲。 */
    @SubscribeEvent
    public static void onRenderGuiPost(final RenderGuiEvent.Post event) {
        try {
            final Minecraft mc = Minecraft.getInstance();
            final boolean open = EchoConfigUi.isOpen();
            if (lastOpen == null || lastOpen.booleanValue() != open) {
                lastOpen = Boolean.valueOf(open);
                if (open) {
                    // 原版打开 GUI 的做法：释放锁定 ⇒ 指针显示
                    mc.mouseHandler.releaseMouse();
                    // 【必须兜底】releaseMouse() 内部条件是 `if (mouseGrabbed)`：
                    // 若之前某次 grabMouse 未生效（窗口失焦等）⇒ mouseGrabbed 已是 false
                    // ⇒ releaseMouse 变成空操作，光标再也不会被切回可见（实测的"之后不显示光标"）。
                    // 所以这里无条件把 GLFW 光标模式设成可见，绕开 MC 的内部状态。
                    final long win = mc.getWindow().getWindow();
                    GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
                } else if (mc.screen == null) {
                    // 只有回到游戏画面时才重新锁定（避免和暂停菜单等抢夺）
                    mc.mouseHandler.grabMouse();
                }
            }
            EchoConfigUi.present();
        } catch (final Throwable ignored) {
            // fail-open：渲染事件里绝不外抛
        }
    }
}
