package com.echoxy.client;

import java.util.ArrayList;
import java.util.List;

import com.echoxy.boot.EchoConfig;
import com.echoxy.boot.EchoLog;
import com.echoxy.item.EchoArtifactItem;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/**
 * 神器提示框自绘渲染器（彩字 + 脉冲星）。
 *
 * <p>不依赖 Forge 事件总线：由 {@code EchoGuardTooltipMixin} 在原版提示框各入口
 * 接管——只要目标物品是神器，就取消原版渲染并全程自绘（名字行 + 介绍行渐变波浪彩字，
 * 中心叠加脉冲星）；其他物品一步不碰，走原版路径。</p>
 */
public final class ArtifactTooltipRenderer {

    private static final String NAME_KEY = "item.echoes_of_legend.artemis";

    private ArtifactTooltipRenderer() {
    }

    /** 是否神器（提供后续扩展点）。 */
    public static boolean isArtifact(Item item) {
        return item instanceof EchoArtifactItem;
    }

    private static boolean enabled() {
        return EchoConfig.get().getBoolean("神器彩字", true)
                || EchoConfig.get().getBoolean("神器脉冲星", true);
    }

    /** 物品入口：返回 true ⇒ 调用方取消原版渲染。 */
    public static boolean tryRender(ItemStack stack, GuiGraphics graphics, int mouseX, int mouseY) {
        if (stack == null || stack.isEmpty() || !isArtifact(stack.getItem()) || !enabled()) {
            return false;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            render(buildLines(stack, mc), stack, graphics, mc);
            return true;
        } catch (Throwable t) {
            EchoLog.get().fine("神器提示框自绘失败，回退原版渲染: " + t);
            return false;
        }
    }

    /** 组件入口：只有组件列表、没有 ItemStack（第三方直接构造组件时按名字行识别）。 */
    public static boolean tryRenderComponents(List<Component> components, GuiGraphics graphics, int mouseX, int mouseY) {
        if (!enabled() || !isArtifactLines(components)) {
            return false;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            render(components, null, graphics, mc);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 组件列表识别：首几行的翻译键或已翻译显示名命中神器名。 */
    private static boolean isArtifactLines(List<Component> components) {
        if (components == null || components.isEmpty()) {
            return false;
        }
        int limit = Math.min(components.size(), 6);
        for (int i = 0; i < limit; i++) {
            Component c = components.get(i);
            if (c == null) {
                continue;
            }
            if (c.getContents() instanceof TranslatableContents tc && NAME_KEY.equals(tc.getKey())) {
                return true;
            }
            if (Component.translatable(NAME_KEY).getString().equals(c.getString())) {
                return true;
            }
        }
        return false;
    }

    /** 纯原版路径生成文本行（getTooltipLines 失败时用名字 + appendHoverText 重建）。 */
    private static List<Component> buildLines(ItemStack stack, Minecraft mc) {
        List<Component> lines = new ArrayList<>();
        try {
            lines.addAll(stack.getTooltipLines(mc.player, TooltipFlag.NORMAL));
        } catch (Throwable ignored) {
            lines.add(stack.getHoverName());
            try {
                stack.getItem().appendHoverText(stack, mc.level, lines, TooltipFlag.NORMAL);
            } catch (Throwable ignored2) {
                // 只降级
            }
        }
        return lines;
    }

    private static void render(List<Component> lines, ItemStack stack, GuiGraphics graphics, Minecraft mc) {
        float time = timeSeconds(mc);
        float cx = graphics.guiWidth() / 2.0F;
        float cy = graphics.guiHeight() / 2.0F;

        // 中心脉冲星（球 + 环 + 数字环 + 立体星空剑）——提示框不再有任何文字
        if (stack != null && EchoConfig.get().getBoolean("神器脉冲星", true)) {
            PoseStack pose = graphics.pose();
            pose.pushPose();
            try {
                pose.translate(0.0, 0.0, 350.0);
                EchoesPulsarRenderer.render(graphics, cx, cy, 140.0F * (2.0F / 3.0F), time, stack);
            } finally {
                pose.popPose();
            }
        }
    }

    /** 动画时间（秒）：优先用玩家 tick（与世界同拍），拿不到就用系统毫秒。 */
    private static float timeSeconds(Minecraft mc) {
        try {
            if (mc.player != null) {
                return (mc.player.tickCount + mc.getFrameTime()) / 20.0F;
            }
        } catch (Throwable ignored) {
        }
        return (System.currentTimeMillis() % 3_600_000L) / 1000.0F;
    }
}
