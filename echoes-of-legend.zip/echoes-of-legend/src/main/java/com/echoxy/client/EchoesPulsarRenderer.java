package com.echoxy.client;

import java.io.IOException;

import com.echoxy.boot.EchoConfig;
import com.echoxy.boot.EchoLog;
import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.RegisterShadersEvent;
import org.joml.Matrix4f;

/**
 * 神器 · 中子星（脉冲星）介绍界面渲染器。
 *
 * <p>全部由 GPU 逐像素解析计算（一个 quad + 片元着色器），没有图元拼几何的锯齿与接缝：</p>
 * <ol>
 *   <li>中心脉冲星球体：蓝色、表面能量光点、高速自转（屏幕竖直轴）；</li>
 *   <li>球体外围反向旋转的土星环（严格套在球外、不接触球体）；</li>
 *   <li>环外更大的数字环：立体罗马数字 I..XII（时钟顺序），与内环同向、不接触内环；</li>
 *   <li>球体前方：立体星空剑（真实 BakedModel + 星空着色器，随屏幕竖直轴自转）。</li>
 * </ol>
 *
 * <p>三层几何的半径区间互不重叠 ⇒ 结构上不可能互相穿插（不依赖浮点巧合）。</p>
 */
public final class EchoesPulsarRenderer {

    private static final ResourceLocation SHADER_PULSAR = new ResourceLocation("echoes_of_legend", "echoes_pulsar");
    private static final ResourceLocation SHADER_SWORD = new ResourceLocation("echoes_of_legend", "echoes_sword_gui");

    private static ShaderInstance shader;
    private static ShaderInstance swordShader;
    private static RenderType pulsarRenderType;
    private static RenderType swordRenderType;
    private static volatile boolean disabled = false;

    // 可调参数
    private static final float TINT_R = 0.30F, TINT_G = 0.60F, TINT_B = 1.00F;
    private static final float SPIN_BODY = 1.60F;   // rad/s，约 3.9 秒一圈
    private static final float SPIN_RING = -0.85F;  // 负号 = 与球体反向
    private static final float SPIN_NUMS = -0.55F;  // 与内环同向
    private static final float SPIN_SWORD_DEG = 45.0F;
    private static final float OPACITY = 1.0F;
    private static final float QUAD_EXTENT = 1.65F;
    private static final float Z_SWORD = 2460.0F;

    private EchoesPulsarRenderer() {
    }

    /** RenderStateShard 的常用状态常量在 1.20.1 为 protected，通过子类暴露。 */
    private static final class RS extends RenderStateShard {
        private RS() {
            super("echoes_of_legend_pulsar", () -> {
            }, () -> {
            });
        }

        private static final TransparencyStateShard TRANSLUCENT = TRANSLUCENT_TRANSPARENCY;
        private static final DepthTestStateShard LEQUAL = LEQUAL_DEPTH_TEST;
        private static final WriteMaskStateShard COLOR = COLOR_WRITE;
        private static final CullStateShard NO_CULL_STATE = NO_CULL;
    }

    /** 在 RegisterShadersEvent 中加载两个着色器（脉冲星 + 剑）。 */
    public static void registerShader(RegisterShadersEvent event) {
        if (!EchoConfig.get().getBoolean("神器脉冲星", true)) {
            return;
        }
        try {
            ShaderInstance instance = new ShaderInstance(event.getResourceProvider(), SHADER_PULSAR,
                    DefaultVertexFormat.BLOCK);
            event.registerShader(instance, s -> shader = s);
            shader = instance;
        } catch (IOException e) {
            EchoLog.get().info("脉冲星着色器加载失败: " + e.getMessage());
        }
        try {
            ShaderInstance instance = new ShaderInstance(event.getResourceProvider(), SHADER_SWORD,
                    DefaultVertexFormat.BLOCK);
            event.registerShader(instance, s -> swordShader = s);
            swordShader = instance;
        } catch (IOException e) {
            EchoLog.get().info("星空剑着色器加载失败: " + e.getMessage());
        }
    }

    private static RenderType getPulsarRenderType() {
        if (pulsarRenderType == null && shader != null) {
            pulsarRenderType = RenderType.create("echoes_of_legend_pulsar", DefaultVertexFormat.BLOCK,
                    VertexFormat.Mode.QUADS, 256, false, false,
                    RenderType.CompositeState.builder()
                            .setShaderState(new RenderStateShard.ShaderStateShard(() -> shader))
                            .setTextureState(new RenderStateShard.TextureStateShard(TextureAtlas.LOCATION_BLOCKS, false, false))
                            .setTransparencyState(RS.TRANSLUCENT)
                            .setDepthTestState(RS.LEQUAL)
                            .setWriteMaskState(RS.COLOR)
                            .setCullState(RS.NO_CULL_STATE)
                            .createCompositeState(false));
        }
        return pulsarRenderType;
    }

    /** 剑的 RenderType：必须指向物品图集（BakedModel 的 UV 在该图集内）。 */
    private static RenderType getSwordRenderType() {
        if (swordRenderType == null && swordShader != null) {
            swordRenderType = RenderType.create("echoes_of_legend_sword_gui", DefaultVertexFormat.BLOCK,
                    VertexFormat.Mode.QUADS, 256, false, false,
                    RenderType.CompositeState.builder()
                            .setShaderState(new RenderStateShard.ShaderStateShard(() -> swordShader))
                            .setTextureState(new RenderStateShard.TextureStateShard(TextureAtlas.LOCATION_BLOCKS, false, false))
                            .setTransparencyState(RS.TRANSLUCENT)
                            .setDepthTestState(RS.LEQUAL)
                            .setWriteMaskState(RS.COLOR)
                            .setCullState(RS.NO_CULL_STATE)
                            .createCompositeState(false));
        }
        return swordRenderType;
    }

    /**
     * 绘制整颗中子星（球体 + 内环 + 数字环），再叠上球体前方的立体星空剑。
     *
     * @param centerX 球心 GUI x（左上角原点）
     * @param centerY 球心 GUI y
     * @param radius  脉冲星半径 R（GUI 单位）
     * @param time    动画时间（秒）
     * @param stack   要渲染的剑（可为 null ⇒ 只画星体）
     */
    public static void render(GuiGraphics graphics, float centerX, float centerY, float radius, float time,
            ItemStack stack) {
        if (disabled || graphics == null || !EchoConfig.get().getBoolean("神器脉冲星", true)) {
            return;
        }
        renderPulsar(graphics, centerX, centerY, radius, time);
        renderSword(graphics, stack, centerX, centerY, radius * 2.0F, time);
    }

    /** 星体部分：球 + 内环 + 数字环（一个 quad，全部在片元里解析计算）。 */
    private static void renderPulsar(GuiGraphics graphics, float centerX, float centerY, float radius, float time) {
        if (shader == null) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.getWindow() == null) {
                return;
            }
            int fbH = mc.getWindow().getHeight();
            double gsRaw = mc.getWindow().getGuiScale();
            float gs = gsRaw > 0.0 ? (float) gsRaw : 1.0F;
            // GUI 单位 -> 像素；y 轴换算成 GL 的左下角原点
            float cxPix = centerX * gs;
            float cyPix = (float) fbH - centerY * gs;
            float rPix = Math.max(1.0F, radius * gs);

            setUniform(shader, "time", time);
            setVec2(shader, "center", cxPix, cyPix);
            setUniform(shader, "radius", rPix);
            setUniform(shader, "opacity", OPACITY);
            setVec4(shader, "tint", TINT_R, TINT_G, TINT_B, 1.0F);
            setVec3(shader, "spin", SPIN_BODY, SPIN_RING, SPIN_NUMS);

            RenderType rt = getPulsarRenderType();
            if (rt == null) {
                return;
            }
            VertexConsumer vc = graphics.bufferSource().getBuffer(rt);
            Matrix4f m = graphics.pose().last().pose();
            float ext = radius * QUAD_EXTENT;
            quadVertex(vc, m, centerX - ext, centerY + ext);
            quadVertex(vc, m, centerX + ext, centerY + ext);
            quadVertex(vc, m, centerX + ext, centerY - ext);
            quadVertex(vc, m, centerX - ext, centerY - ext);
        } catch (Throwable t) {
            // GUI 里抛异常会崩游戏 —— 一律吞掉并停用
            disabled = true;
            shader = null;
            EchoLog.get().info("脉冲星绘制失败，特效已停用: " + t);
        }
    }

    /** 球体前方的立体星空剑（真 BakedModel + 3D 光照 + 星空着色器）。 */
    private static void renderSword(GuiGraphics graphics, ItemStack stack, float cx, float cy, float diameter,
            float time) {
        if (stack == null || stack.isEmpty() || swordShader == null) {
            return;
        }
        RenderType rt = getSwordRenderType();
        if (rt == null) {
            return;
        }
        boolean lit3d = false;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.level == null || mc.player == null) {
                return;
            }
            ItemRenderer itemRenderer = mc.getItemRenderer();
            BakedModel model = itemRenderer.getModel(stack, mc.level, mc.player, 0);
            if (model == null) {
                return;
            }
            setUniform(swordShader, "time", time);
            setUniform(swordShader, "opacity", OPACITY);
            // 剑的星空颜色与手持完全同源（同一取色函数 + 同一速率）
            float hue = EchoesHue.cycleHue(time, EchoesHue.COSMIC_SPEED);
            float[] hueRgb = EchoesHue.rgbFloats(EchoesHue.hueToRgb(hue));
            setVec4(swordShader, "tint", hueRgb[0], hueRgb[1], hueRgb[2], 1.0F);

            PoseStack ps = new PoseStack();
            ps.last().pose().set(graphics.pose().last().pose());
            ps.last().normal().set(graphics.pose().last().normal());
            ps.translate(cx, cy, Z_SWORD);
            ps.scale(diameter, -diameter, diameter);
            ps.mulPose(Axis.YP.rotationDegrees(time * SPIN_SWORD_DEG));
            // 复现 ItemRenderer.render 的两步模型变换
            model = ForgeHooksClient.handleCameraTransforms(ps, model, ItemDisplayContext.FIXED, false);
            ps.translate(-0.5F, -0.5F, -0.5F);

            // 3D 物品光照（必须成对 setupFor3DItems / setupForFlatItems）
            Lighting.setupFor3DItems();
            lit3d = true;

            MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
            VertexConsumer vc = buf.getBuffer(rt);
            itemRenderer.renderModelLists(model, stack, 0xF000F0, OverlayTexture.NO_OVERLAY, ps, vc);
            buf.endBatch(rt);
        } catch (Throwable t) {
            EchoLog.get().info("星空剑绘制失败（已跳过）: " + t);
        } finally {
            if (lit3d) {
                try {
                    Lighting.setupForFlatItems();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private static void quadVertex(VertexConsumer vc, Matrix4f m, float x, float y) {
        vc.vertex(m, x, y, 0.0F).color(255, 255, 255, 255).uv(0.0F, 0.0F).uv2(0xF000F0)
                .normal(0.0F, 0.0F, 1.0F).endVertex();
    }

    private static void setUniform(ShaderInstance s, String name, float value) {
        try {
            com.mojang.blaze3d.shaders.Uniform u = s.getUniform(name);
            if (u != null) {
                u.set(value);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void setVec2(ShaderInstance s, String name, float a, float b) {
        try {
            com.mojang.blaze3d.shaders.Uniform u = s.getUniform(name);
            if (u != null) {
                u.set(a, b);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void setVec3(ShaderInstance s, String name, float a, float b, float c) {
        try {
            com.mojang.blaze3d.shaders.Uniform u = s.getUniform(name);
            if (u != null) {
                u.set(a, b, c);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void setVec4(ShaderInstance s, String name, float a, float b, float c, float d) {
        try {
            com.mojang.blaze3d.shaders.Uniform u = s.getUniform(name);
            if (u != null) {
                u.set(a, b, c, d);
            }
        } catch (Throwable ignored) {
        }
    }
}
