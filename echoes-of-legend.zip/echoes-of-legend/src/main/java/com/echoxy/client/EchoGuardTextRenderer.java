package com.echoxy.client;

import com.echoxy.boot.EchoConfig;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;

/**
 * 彩字文本接管（快捷栏上方的物品名 / 创造模式选项卡名字）。
 *
 * <p>由 {@code EchoGuardTextMixin} 在 {@code GuiGraphics.drawString(Component)} 的 HEAD 调用：
 * 命中神器名或我方选项卡标题 ⇒ 取消原版白字，改用 {@link GradientWaveText} 渐变波浪彩字；
 * 其余文本一步不碰。</p>
 */
public final class EchoGuardTextRenderer {

    private static final String ARTIFACT_KEY = "item.echoes_of_legend.artemis";
    private static final String TAB_KEY = "itemGroup.example_tab";

    private EchoGuardTextRenderer() {
    }

    /** 返回 true ⇒ 调用方取消原版绘制（并按原版返回字宽）。 */
    public static boolean tryRenderText(GuiGraphics graphics, Font font, Component text, int x, int y) {
        if (!EchoConfig.get().getBoolean("神器彩字", true) || text == null) {
            return false;
        }
        boolean hit = false;
        if (text.getContents() instanceof TranslatableContents tc) {
            hit = ARTIFACT_KEY.equals(tc.getKey()) || TAB_KEY.equals(tc.getKey());
        }
        if (!hit) {
            String s = text.getString();
            hit = Component.translatable(ARTIFACT_KEY).getString().equals(s)
                    || Component.translatable(TAB_KEY).getString().equals(s);
        }
        if (!hit) {
            return false;
        }
        String s = ChatFormatting.stripFormatting(text.getString());
        if (s == null || s.isEmpty()) {
            return false;
        }
        float time = timeSeconds();
        GradientWaveText.render(s, x, y, time, graphics.pose(), graphics.bufferSource(), 15728880, 1.0F);
        return true;
    }

    private static float timeSeconds() {
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.player != null) {
            return (mc.player.tickCount + mc.getFrameTime()) / 20.0F;
        }
        return (System.currentTimeMillis() % 3_600_000L) / 1000.0F;
    }
}
