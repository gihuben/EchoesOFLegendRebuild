package com.echoxy.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.echoxy.boot.EchoConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.RegisterShadersEvent;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * 神器 · 剑身星空渲染器（程序化自绘，非 PNG）。
 *
 * <p>星空由片元着色器 {@code artemis_cosmic.fsh} 在 GPU 上程序化生成：
 * 16 层视差星点 + 星云 + 星尘，以剑自身贴图的 alpha/白色区域作为蒙版——
 * 星空只出现在剑的形状内，天然对齐、不会被剑遮挡。</p>
 *
 * <p>绘制路径：{@code ItemRendererMixin} 在物品模型渲染时收集剑的渲染快照，
 * 帧末（{@code RenderTickEvent.END}）或手部渲染返回时统一用同一套四边形
 * + 星空着色器再画一遍，永远位于剑之上。</p>
 */
public final class ArtemisCosmicRenderer {

    private static final ResourceLocation SHADER_LOCATION = new ResourceLocation("echoes_of_legend", "artemis_cosmic");

    private static ShaderInstance shader;
    private static RenderType cosmicRenderType;
    /** 着色器失败后一次性停用（防止每帧重复异常）。 */
    private static volatile boolean disabled = false;
    private static volatile boolean collectLogged = false;
    private static volatile boolean pendingLogged = false;

    /** 帧内收集的剑渲染数据（帧末统一绘制）。 */
    private static final List<PendingCosmic> PENDING = new ArrayList<>();

    private record PendingCosmic(ItemStack stack, Matrix4f pose, Matrix3f normal,
            Matrix4f modelView, Matrix4f proj, int light, int overlay) {
    }

    /** 整体透明度。 */
    private static final float OPACITY = 0.85F;

    private ArtemisCosmicRenderer() {
    }

    /** RenderStateShard 的常用状态常量在 1.20.1 为 protected，通过子类暴露。 */
    private static final class RS extends RenderStateShard {
        private RS() {
            super("echoes_of_legend_cosmic", () -> {
            }, () -> {
            });
        }

        private static final TransparencyStateShard TRANSLUCENT = TRANSLUCENT_TRANSPARENCY;
        private static final DepthTestStateShard LEQUAL = LEQUAL_DEPTH_TEST;
        private static final WriteMaskStateShard COLOR = COLOR_WRITE;
        private static final CullStateShard NO_CULL_STATE = NO_CULL;
    }

    /** 在 RegisterShadersEvent 中加载星空着色器。 */
    public static void registerShader(RegisterShadersEvent event) {
        if (!EchoConfig.get().getBoolean("神器星空", true)) {
            return;
        }
        try {
            ShaderInstance instance = new ShaderInstance(event.getResourceProvider(), SHADER_LOCATION,
                    DefaultVertexFormat.BLOCK);
            event.registerShader(instance, s -> shader = s);
            shader = instance;
            com.echoxy.boot.EchoLog.get().info("星空着色器已加载");
        } catch (IOException e) {
            com.echoxy.boot.EchoLog.get().info("星空着色器加载失败: " + e.getMessage());
        }
    }

    /** 星空 RenderType（Sampler0 = 物品图集；剑贴图白色区决定星空覆盖区）。 */
    @Nullable
    public static RenderType getCosmicRenderType() {
        if (cosmicRenderType == null && shader != null) {
            cosmicRenderType = RenderType.create("echoes_of_legend_cosmic", DefaultVertexFormat.BLOCK,
                    VertexFormat.Mode.QUADS, 256, false, false,
                    RenderType.CompositeState.builder()
                            .setShaderState(new RenderStateShard.ShaderStateShard(() -> shader))
                            .setTextureState(new RenderStateShard.TextureStateShard(TextureAtlas.LOCATION_BLOCKS, false, false))
                            .setTransparencyState(RS.TRANSLUCENT)
                            .setDepthTestState(RS.LEQUAL)
                            .setWriteMaskState(RS.COLOR)
                            .setCullState(RS.NO_CULL_STATE)
                            .createCompositeState(false));
        }
        return cosmicRenderType;
    }

    /** 每帧更新 uniform（时间 / 相机 yaw/pitch / 主色）。 */
    public static void updateUniforms(float partialTick) {
        if (shader == null || disabled) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            long gameTime = mc.level != null ? mc.level.getGameTime() : 0L;
            float time = (gameTime % 24000L) + partialTick;
            Camera cam = mc.gameRenderer.getMainCamera();
            float yaw = (float) Math.toRadians(cam.getYRot());
            float pitch = (float) Math.toRadians(cam.getXRot());
            setUniform("time", time);
            setUniform("yaw", yaw);
            setUniform("pitch", pitch);
            // 主色由统一取色函数按循环色相算（与彩字同源 ⇒ 同时变色）
            int hueRgb = EchoesHue.hueToRgb(EchoesHue.cycleHue(time / 20.0F, EchoesHue.COSMIC_SPEED));
            float[] rgb = EchoesHue.rgbFloats(hueRgb);
            setVec4("cosmicColor0", rgb[0], rgb[1], rgb[2], 1.0F);
        } catch (Throwable ignored) {
            // uniform 更新失败静默（下一帧再试）
        }
    }

    /** 收集一次剑的渲染快照（含当时的全局矩阵）。 */
    public static void collect(ItemStack stack, PoseStack pose, int light, int overlay) {
        if (shader == null || stack.isEmpty() || disabled) {
            return;
        }
        if (!collectLogged) {
            collectLogged = true;
            com.echoxy.boot.EchoLog.get().info("星空收集首次触发");
        }
        try {
            PENDING.add(new PendingCosmic(stack,
                    new Matrix4f(pose.last().pose()),
                    new Matrix3f(pose.last().normal()),
                    new Matrix4f(RenderSystem.getModelViewMatrix()),
                    new Matrix4f(RenderSystem.getProjectionMatrix()),
                    light, overlay));
        } catch (Throwable ignored) {
        }
    }

    /** 帧末统一绘制（星空用剑自身四边形绘制在剑之上）。 */
    public static void renderPending() {
        if (PENDING.isEmpty() || disabled || !EchoConfig.get().getBoolean("神器星空", true)) {
            return;
        }
        if (!pendingLogged) {
            pendingLogged = true;
            com.echoxy.boot.EchoLog.get().info("星空绘制首次触发 count=" + PENDING.size());
        }
        try {
            RenderType cosmic = getCosmicRenderType();
            Minecraft mc = Minecraft.getInstance();
            if (cosmic == null || mc.level == null || mc.player == null) {
                PENDING.clear();
                return;
            }
            MultiBufferSource.BufferSource immediate = mc.renderBuffers().bufferSource();
            ItemRenderer itemRenderer = mc.getItemRenderer();
            for (PendingCosmic p : PENDING) {
                BakedModel model = itemRenderer.getModel(p.stack(), mc.level, mc.player, 0);
                PoseStack ps = new PoseStack();
                ps.last().pose().set(p.pose());
                ps.last().normal().set(p.normal());

                Matrix4f curModelView = RenderSystem.getModelViewMatrix();
                Matrix4f curProj = RenderSystem.getProjectionMatrix();
                boolean needSwap = !curModelView.equals(p.modelView()) || !curProj.equals(p.proj());
                Matrix4f keepModelView = needSwap ? new Matrix4f(curModelView) : null;
                Matrix4f keepProj = needSwap ? new Matrix4f(curProj) : null;
                if (needSwap) {
                    curModelView.set(p.modelView());
                    curProj.set(p.proj());
                }
                try {
                    itemRenderer.renderModelLists(model, p.stack(), p.light(), p.overlay(), ps,
                            immediate.getBuffer(cosmic));
                    immediate.endBatch(cosmic);
                } finally {
                    if (needSwap) {
                        curModelView.set(keepModelView);
                        curProj.set(keepProj);
                    }
                }
            }
        } catch (Throwable ignored) {
            // 星空绘制失败不影响任何渲染
        } finally {
            PENDING.clear();
        }
    }

    private static void setUniform(String name, float value) {
        try {
            com.mojang.blaze3d.shaders.Uniform u = shader.getUniform(name);
            if (u != null) {
                u.set(value);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void setVec4(String name, float a, float b, float c, float d) {
        try {
            com.mojang.blaze3d.shaders.Uniform u = shader.getUniform(name);
            if (u != null) {
                u.set(a, b, c, d);
            }
        } catch (Throwable ignored) {
        }
    }
}
