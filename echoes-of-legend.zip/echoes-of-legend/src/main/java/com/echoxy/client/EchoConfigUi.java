package com.echoxy.client;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import com.echoxy.boot.EchoConfig;

/**
 * 纯原生配置界面（ECHO_CONFIG_UI.DLL）的 Java 侧入口。
 *
 * <h3>为什么要独立加载、不依赖"底层"开关</h3>
 * <p>用户裁决：配置文件全关时底层 DLL（guard / jvmti）都不加载，所以本 DLL 由
 * <b>mod 侧直接 {@code System.load}</b> 注入，与任何底层开关无关。</p>
 *
 * <h3>职责</h3>
 * <ul>
 *   <li>把 jar 里的 {@code assets/echoes_native/ECHO_CONFIG_UI.DLL} 释放到
 *       {@code <gameDir>/echoes-native/}（长度比对，禁止复用旧件）；</li>
 *   <li>{@code System.load} 后即可调 JNI：界面打开 / 关闭 / 查询状态；</li>
 *   <li>界面本体（GDI+ 玻璃、胶囊开关、级联动画、降采样高斯模糊、滚动）全部在 DLL 里，
 *       绘制挂在自己的 {@code wglSwapBuffers} hook 上，覆盖在游戏画面上。</li>
 * </ul>
 *
 * <h3>铁律</h3>
 * <p>fail-open：任何一步失败只降级（返回 false / 不打开），绝不抛给调用方、绝不崩游戏。</p>
 */
public final class EchoConfigUi {

    private EchoConfigUi() {
    }

    /** DLL 文件名（与 build.gradle 产物一致）。 */
    private static final String DLL_NAME = "ECHO_CONFIG_UI.DLL";

    /** jar 内资源路径。 */
    private static final String DLL_ASSET = "/assets/echoes_native/" + DLL_NAME;

    /**
     * MinHook.x64.dll：本 DLL 的内部 hook 依赖（ECHO_CONFIG_UI.DLL 用它的 trampoline 做
     * RIP 重定位）。配置全关时 guard/jvmti 不会释放它 ⇒ 这里一并释放，保证自包含。
     */
    private static final String MINHOOK_NAME = "MinHook.x64.dll";

    private static final String MINHOOK_ASSET = "/assets/" + MINHOOK_NAME;

    private static volatile boolean loaded = false;
    private static volatile String state = "未加载";

    // ---- JNI（由 ECHO_CONFIG_UI.DLL 导出）----
    private static native int show0(String configPath);

    private static native void hide0();

    private static native int isOpen0();

    private static native int status0();

    /** 每帧把界面贴到后缓冲（由 Forge 的 RenderGuiEvent.Post 调用）。 */
    private static native int present0();

    /** 诊断串（只写状态，不含路径细节）。 */
    public static String state() {
        return state;
    }

    /** 是否已成功加载 DLL。 */
    public static boolean isLoaded() {
        return loaded;
    }

    /**
     * 打开配置界面（右键物品调用）。幂等：已打开则不动。
     *
     * @return 1=已请求显示，0=失败（fail-open）
     */
    public static int open() {
        try {
            if (!ensureLoaded()) {
                return 0;
            }
            // 确保配置文件已存在（首次运行由 EchoConfig 生成完整默认配置）
            final String path = configPath();
            try {
                EchoConfig.get();
            } catch (final Throwable ignored) {
                // 生成失败也继续：DLL 会显示空列表而不是崩溃
            }
            final int r = show0(path);
            state = r == 1 ? "已打开" : "打开失败(0)";
            return r;
        } catch (final Throwable t) {
            state = "打开异常: " + t.getClass().getSimpleName();
            return 0;
        }
    }

    /** 关闭配置界面（未打开时为空操作）。 */
    public static void hide() {
        try {
            if (loaded) {
                hide0();
                state = "已关闭";
            }
        } catch (final Throwable ignored) {
            // fail-open
        }
    }

    /** 切换（打开 ⇄ 关闭）：物品右键用这个。 */
    public static void toggle() {
        try {
            if (!ensureLoaded()) {
                return;
            }
            if (isOpen()) {
                hide();
            } else {
                open();
            }
        } catch (final Throwable ignored) {
            // fail-open
        }
    }

    /** 界面当前是否打开。 */
    public static boolean isOpen() {
        try {
            return loaded && isOpen0() != 0;
        } catch (final Throwable t) {
            return false;
        }
    }

    /**
     * 每帧调用（Forge {@code RenderGuiEvent.Post}）：让 DLL 用 GL 把界面贴到后缓冲。
     *
     * <p>为什么由事件驱动而不是 hook：事件在 swap 之前、GL 上下文 current，
     * 与游戏画面同帧上屏 ⇒ 不闪；完全不碰系统函数 ⇒ 无转发桩 / rel32 / trampoline 风险。</p>
     *
     * <p>未加载/未打开时为空操作（DLL 内部同样有 g_open 判断），每帧一次 JNI 开销可忽略。</p>
     */
    public static void present() {
        try {
            if (loaded) {
                present0();
            }
        } catch (final Throwable ignored) {
            // fail-open：绝不让渲染事件抛异常
        }
    }

    /** 原生侧状态位（诊断）：1=已 hook 换帧，2=界面打开，4=GDI+ 就绪，8=已子类化窗口。 */
    public static int nativeStatus() {
        try {
            return loaded ? status0() : -1;
        } catch (final Throwable t) {
            return -1;
        }
    }

    // ------------------------------------------------------------------
    // 内部
    // ------------------------------------------------------------------

    /** 幂等加载：释放 DLL → System.load（失败即降级）。 */
    private static synchronized boolean ensureLoaded() {
        if (loaded) {
            return true;
        }
        try {
            if (!System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT).contains("win")) {
                state = "非 Windows 跳过";
                return false;
            }
            final Path nativeDir = gameDir().resolve("echoes-native");
            final Path dst = nativeDir.resolve(DLL_NAME);
            if (!extract(DLL_ASSET, dst)) {
                state = "释放失败";
                return false;
            }
            // 先放好 MinHook（本 DLL 落补丁要用它的 trampoline），失败也只是降级为"不 hook"
            extract(MINHOOK_ASSET, nativeDir.resolve(MINHOOK_NAME));
            System.load(dst.toAbsolutePath().toString());
            loaded = true;
            state = "已加载";
            return true;
        } catch (final Throwable t) {
            state = "加载失败: " + t.getClass().getSimpleName();
            return false;
        }
    }

    /** 从 jar 资源释放到目标路径（长度比对；内容一致则复用）。 */
    private static boolean extract(final String asset, final Path dst) {
        try (InputStream in = EchoConfigUi.class.getResourceAsStream(asset)) {
            if (in == null) {
                // 资源没打包进 jar ⇒ 若磁盘上已有旧件仍可尝试加载
                return Files.isRegularFile(dst);
            }
            final byte[] bytes = in.readAllBytes();
            if (bytes.length < 4096) {
                return false;
            }
            if (Files.isRegularFile(dst) && Files.size(dst) == bytes.length) {
                return true;
            }
            Files.createDirectories(dst.getParent());
            final Path tmp = dst.resolveSibling(dst.getFileName().toString() + ".tmp");
            Files.write(tmp, bytes);
            Files.move(tmp, dst, StandardCopyOption.REPLACE_EXISTING);
            return Files.isRegularFile(dst);
        } catch (final Throwable t) {
            return Files.isRegularFile(dst);
        }
    }

    /** 游戏目录（{@code user.dir}，与 EchoConfig 一致）。 */
    private static Path gameDir() {
        return Path.of(System.getProperty("user.dir", "."));
    }

    /** 配置文件绝对路径：{@code <gameDir>/config/echoes.txt}。 */
    public static String configPath() {
        return gameDir().resolve("config").resolve("echoes.txt").toAbsolutePath().toString();
    }
}
