package com.echoxy.client;

/**
 * 统一取色来源：神器彩字 / 剑身星空 / 提示框特效共用同一个 HSV 取色函数。
 *
 * <p>三方都走这里 ⇒ 颜色节奏天然同步（色相来源同一，只是各自的速率/偏移不同）。</p>
 */
public final class EchoesHue {

    private EchoesHue() {
    }

    /** 涟漪节奏：整周约 8.33 秒。 */
    public static final float RIPPLE_SPEED = 0.12F;

    /** 星空/彩字节奏：整周约 14 秒。 */
    public static final float COSMIC_SPEED = 1.0F / 14.0F;

    /** 循环色相（整周 ≈ 8.33s）。 */
    public static float cycleHue(float seconds) {
        return cycleHue(seconds, RIPPLE_SPEED);
    }

    /** 自定义速率的循环色相；{@code speed} 为"每秒走过的色相比例"。 */
    public static float cycleHue(float seconds, float speed) {
        return fract(seconds * speed);
    }

    public static float fract(float v) {
        if (v != v) { // NaN 保护
            return 0.0F;
        }
        return v - (float) Math.floor(v);
    }

    /** HSV(hue) -> RGB，饱和度/亮度固定为 1（鲜艳）。 */
    public static int hueToRgb(float hue) {
        return hueToRgb(hue, 1.0F, 1.0F);
    }

    /** HSV -> RGB（h 任意实数自动取小数部分，s/v 夹到 0..1）。 */
    public static int hueToRgb(float hue, float s, float v) {
        float ss = clamp01(s);
        float vv = clamp01(v);
        float h = fract(hue) * 6.0F;
        int i = (int) Math.floor(h);
        float f = h - i;
        float p = vv * (1.0F - ss);
        float q = vv * (1.0F - ss * f);
        float t = vv * (1.0F - ss * (1.0F - f));
        float r;
        float g;
        float b;
        switch (i % 6) {
            case 0: r = vv; g = t; b = p; break;
            case 1: r = q; g = vv; b = p; break;
            case 2: r = p; g = vv; b = t; break;
            case 3: r = p; g = q; b = vv; break;
            case 4: r = t; g = p; b = vv; break;
            default: r = vv; g = p; b = q; break;
        }
        return (c255(r) << 16) | (c255(g) << 8) | c255(b);
    }

    /** 给 uniform 用的 0..1 三分量。 */
    public static float[] rgbFloats(int rgb) {
        return new float[] { ((rgb >> 16) & 255) / 255.0F, ((rgb >> 8) & 255) / 255.0F, (rgb & 255) / 255.0F };
    }

    private static float clamp01(float f) {
        if (f != f) {
            return 1.0F;
        }
        return f < 0.0F ? 0.0F : (f > 1.0F ? 1.0F : f);
    }

    private static int c255(float f) {
        int i = (int) (clamp01(f) * 255.0F);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }
}
