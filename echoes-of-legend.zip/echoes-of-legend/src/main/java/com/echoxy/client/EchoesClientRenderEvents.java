package com.echoxy.client;

import com.echoxy.EchoesOfLegendMod;
import com.echoxy.defense.EchoClientDefense;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 客户端渲染/逻辑帧事件：
 * <ul>
 *   <li>渲染帧开始：更新星空着色器 uniform；</li>
 *   <li>渲染帧结束：绘制收集到的剑身星空；</li>
 *   <li>逻辑 tick 结束：防御模式开关轮询（潜行+左键开 / 潜行+右键关）、护盾计时、死亡 GUI 兜底清除。</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = EchoesOfLegendMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class EchoesClientRenderEvents {

    private EchoesClientRenderEvents() {
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            ArtemisCosmicRenderer.updateUniforms(event.renderTickTime);
        } else {
            ArtemisCosmicRenderer.renderPending();
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            try {
                EchoClientDefense.tick();
            } catch (Throwable ignored) {
                // 防御 tick 异常不得影响客户端
            }
        }
    }

    /**
     * 防御模式：拦截一切界面打开（含 ESC 菜单/物品栏/第三方 GUI）——
     * 在打开瞬间取消，界面不会出现（而非"闪一下再被清掉"）。关闭界面（null）放行。
     */
    @SubscribeEvent
    public static void onScreenOpening(net.minecraftforge.client.event.ScreenEvent.Opening event) {
        try {
            if (EchoClientDefense.defenseModeActive() && event.getScreen() != null) {
                event.setCanceled(true);
            }
        } catch (Throwable ignored) {
            // 拦截异常不得影响客户端
        }
    }
}
