package com.echoxy.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/**
 * 神器 · 第一人称格挡姿态（Forge 官方 IClientItemExtensions）。
 *
 * <p>{@code applyForgeHandTransform} 在第一人称手持渲染管线内被调用（手臂渲染之后、
 * 默认手持变换之前）：格挡时应用复刻 1.7.10 的格挡姿态变换并返回 true，
 * 跳过默认的手持变换与 UseAnim 分支——剑横挡在面前、手臂保持正常渲染。</p>
 */
public final class ArtifactItemExtensions implements IClientItemExtensions {

    @Override
    public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm, ItemStack stack,
            float partialTick, float swingProgress, float equipProgress) {
        if (!(stack.getItem() instanceof com.echoxy.item.EchoArtifactItem)) {
            return false;
        }
        if (!player.isUsingItem() || player.getUseItemRemainingTicks() <= 0) {
            return false;
        }
        float f = arm == HumanoidArm.RIGHT ? 1.0F : -1.0F;
        // 手持基础位置
        pose.translate(f * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
        // 格挡位移
        pose.translate(f * -0.14142136F, 0.08F, 0.14142136F);
        // 格挡旋转（复刻 1.7.10 剑格挡姿态）
        pose.mulPose(Axis.XP.rotationDegrees(-102.25F));
        pose.mulPose(Axis.YP.rotationDegrees(f * 13.365F));
        pose.mulPose(Axis.ZP.rotationDegrees(f * 78.05F));
        return true;
    }
}
