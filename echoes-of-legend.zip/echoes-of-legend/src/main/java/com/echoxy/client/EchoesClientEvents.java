package com.echoxy.client;

import com.echoxy.EchoesOfLegendMod;
import com.echoxy.boot.EchoConfig;
import com.echoxy.boot.EchoLog;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 客户端 Mod 总线事件：特效着色器注册（彩字 / 星空 / 脉冲星共用同一时机）。 */
@Mod.EventBusSubscriber(modid = EchoesOfLegendMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EchoesClientEvents {

    private EchoesClientEvents() {
    }

    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        EchoLog.get().info("着色器注册事件触发");
        if (!EchoConfig.get().getBoolean("神器星空", true)
                && !EchoConfig.get().getBoolean("神器脉冲星", true)) {
            return;
        }
        ArtemisCosmicRenderer.registerShader(event);
        EchoesPulsarRenderer.registerShader(event);
    }
}
