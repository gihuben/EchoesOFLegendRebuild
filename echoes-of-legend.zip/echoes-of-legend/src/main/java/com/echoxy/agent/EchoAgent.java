package com.echoxy.agent;

import java.lang.instrument.Instrumentation;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;

/**
 * 回响物语 Java Agent 入口（纯 JDK，零 MC/Forge 依赖）。
 *
 * <p>本类及其依赖（{@link EchoGuardTransformer}）会被打包进运行期生成的
 * {@code echoes-agent.jar}，由<b>系统类加载器</b>装载 —— 因此这里<b>禁止</b>引用任何
 * Minecraft / Forge / 本模组游戏侧类，否则 agent 装载即 NoClassDefFoundError。</p>
 *
 * <h2>两条挂载通道</h2>
 * <ul>
 *   <li>{@code agentmain} —— 运行期 attach（IWP {@code <clinit>} 的 JNA 直调，
 *       见 {@link EchoEarlyAttach}）；</li>
 *   <li>{@code premain} —— 若将来通过 {@code -javaagent} 启动则走这条（更早、更干净）。</li>
 * </ul>
 *
 * <h2>职责</h2>
 * <ul>
 *   <li>持有 {@link Instrumentation} 句柄并对外暴露；</li>
 *   <li>安装字节码卫兵（危险调用剥除 + 断筋清理第三方变换器 + 自愈重挂）；</li>
 *   <li>可选：按栈判定清理第三方恶意后台线程。</li>
 * </ul>
 *
 * <p>所有开关通过系统属性传入（由游戏侧在挂载前设置，见 {@link EchoEarlyAttach}），
 * agent 层不读取配置文件 —— 避免跨类加载器引用游戏侧类。</p>
 */
public final class EchoAgent {

    private static volatile Instrumentation instrumentation;
    private static volatile boolean installed;
    private static volatile boolean defenseStarted;
    /** 上一轮的线程数（"线程创建"事件源：数值变化即触发清理）。 */
    private static volatile int lastThreadCount = -1;
    /** 根线程组缓存。 */
    private static volatile ThreadGroup rootGroup;

    /** 开关（默认开；游戏侧挂载前用系统属性覆盖）。 */
    private static volatile boolean selfHeal = true;
    private static volatile boolean purge = true;
    private static volatile boolean dangerStrip = true;
    private static volatile boolean shell = true;
    private static volatile boolean allReturn = true;
    private static volatile boolean clinitCatch = true;
    private static volatile boolean eventGate = true;
    private static volatile boolean fieldProtect = true;
    private static volatile boolean mixinStrip = true;
    private static volatile boolean modelFallback = true;
    private static volatile boolean serviceGuard = true;
    private static volatile boolean loopGuard = true;
    private static volatile boolean independentSweepEnabled = true;
    private static volatile boolean argAudit = true;
    private static volatile boolean threadClean = true;
    private static volatile boolean verbose;

    private EchoAgent() {
    }

    /** {@code -javaagent} 启动通道（main 之前执行，最早时机）。 */
    public static void premain(final String args, final Instrumentation inst) {
        if (inst == null) {
            return;
        }
        // 非游戏 JVM 守卫：防止 JAVA_TOOL_OPTIONS 把本 agent 带进 Gradle/IDE 等进程
        try {
            final String cmd = System.getProperty("sun.java.command", "");
            final String lower = cmd == null ? "" : cmd.toLowerCase();
            if (!lower.contains("forgeclient") && !lower.contains("bootstraplauncher")) {
                return;
            }
        } catch (final Throwable ignored) {
            // 判不出就当游戏 JVM 处理（本 agent 只会被显式注入）
        }
        instrumentation = inst;
        readFlags();
        install(instrumentation);
        auditAgentArgs();
        startDefense();
        logInfo("premain 已安装（危险调用剥除=" + dangerStrip + " 软空壳=" + shell + " 全返回="
                + allReturn + " 断筋=" + purge + " 自愈=" + selfHeal + " 线程清理=" + threadClean + "）");
    }

    /** 运行期 attach 通道（IWP {@code <clinit>} 的 JNA 直调 / VirtualMachine.attach）。 */
    public static void agentmain(final String args, final Instrumentation inst) {
        if (inst == null) {
            return;
        }
        instrumentation = inst;
        readFlags();
        install(instrumentation);
        startDefense();
        logInfo("agentmain 已安装（危险调用剥除=" + dangerStrip + " 软空壳=" + shell + " 全返回="
                + allReturn + " 断筋=" + purge + " 自愈=" + selfHeal + " 线程清理=" + threadClean + "）");
    }

    /** 供游戏侧反射取句柄（失败返回 null）。 */
    public static Instrumentation inst() {
        return instrumentation;
    }

    // ==================== 安装 ====================

    /** 安装变换器（幂等；agentmain 与 completeAttach 可能各调一次）。 */
    public static void install(final Instrumentation inst) {
        if (install(inst, false)) {
            logInfo("字节码卫兵已安装");
        }
    }

    /** 返回本次是否真的完成了安装（此前已装返回 false）。 */
    private static boolean install(final Instrumentation inst, final boolean force) {
        if (inst == null) {
            return false;
        }
        if (installed && !force) {
            return false;
        }
        installed = true;
        try {
            EchoGuardTransformer.configure(dangerStrip, shell, allReturn, clinitCatch, eventGate,
                    fieldProtect, mixinStrip, modelFallback, verbose);
            EchoGuardTransformer.install(inst);
            // 底层：JVMTI 函数表锁定（原生层；敌方 agent 的底层通道一律假成功）
            try {
                EchoJvmtiLockdown.ensure();
            } catch (final Throwable ignored) {
                // fail-open：原生层装配失败只降级，不影响 Java 层防御
            }
            // 底层：原生守卫（库加载拦截 / 渲染观测 / 句柄兜底 / 隐藏最高优先级守护线程）
            try {
                EchoNativeGuard.ensure();
            } catch (final Throwable ignored) {
                // fail-open
            }
            return true;
        } catch (final Throwable t) {
            logWarn("变换器安装失败（字节码改写不可用）: " + brief(t));
            return false;
        }
    }

    // ==================== 自愈线程 ====================

    /**
     * 自愈线程（幂等启动）：每 200ms 重挂我方变换器（防第三方摘除）+
     * 每 200ms 断筋清扫（物理摘除第三方 ClassFileTransformer）+ 服务表守卫 +
     * 每约 5 秒线程清理 + 每 2 秒独立巡检 + 每 60 秒循环守卫采样。
     */
    private static void startDefense() {
        if (defenseStarted) {
            return;
        }
        defenseStarted = true;
        if (!selfHeal && !purge && !threadClean) {
            logInfo("自愈/断筋/线程清理全部关闭（配置），防御线程不启动");
            return;
        }
        final Thread t = new Thread(() -> {
            int tick = 0;
            // 服务表守卫：先尝试 capture（早期可能表未建好，失败后每轮重试）
            if (serviceGuard) {
                try {
                    EchoServiceGuard.capture();
                } catch (final Throwable ignored) {
                    // 幂等重试
                }
            }
            while (true) {
                final Instrumentation ins = instrumentation;
                if (ins != null) {
                    if (selfHeal) {
                        try {
                            // 首 tick 立即重挂：attach 一完成就夺回链尾，堵住第三方"attach 后立刻摘除"的窗口
                            ins.removeTransformer(EchoGuardTransformer.instance());
                            ins.addTransformer(EchoGuardTransformer.instance(), true);
                        } catch (final Throwable ignored) {
                            // 单次失败不影响下一轮
                        }
                    }
                    if (purge) {
                        try {
                            EchoGuardTransformer.purgeForeignTransformers(ins);
                        } catch (final Throwable ignored) {
                        }
                    }
                    if (serviceGuard) {
                        try {
                            EchoServiceGuard.reassert();
                        } catch (final Throwable ignored) {
                        }
                    }
                    // 底层：JVMTI 锁完整性重断言（内部 1s 限流；敌方还原槽位 → 立即修回）
                    try {
                        EchoJvmtiLockdown.reassert();
                    } catch (final Throwable ignored) {
                    }
                    if (threadClean) {
                        // 线程清理：事件驱动 + 1s 兜底（用户裁决：不按高频轮询）。
                        // 事件源 = 线程数变化（ThreadGroup.activeCount 微秒级、无全局安全点）：
                        // 新线程一出现就立即清理；无变化时每 1s（5×200ms）只做一次兜底。
                        final int now = activeThreadCount();
                        if (now != lastThreadCount || (tick % 5) == 0) {
                            lastThreadCount = now;
                            try {
                                cleanEnemyThreads();
                            } catch (final Throwable ignored) {
                            }
                        }
                    }
                    if (loopGuard && (tick % 300 == 0)) {
                        try {
                            EchoLoopGuard.sampleOnce(false);
                        } catch (final Throwable ignored) {
                        }
                    }
                    if (independentSweepEnabled && (tick % 10 == 0)) {
                        try {
                            independentSweep();
                        } catch (final Throwable ignored) {
                        }
                    }
                }
                ++tick;
                try {
                    Thread.sleep(200L);
                } catch (final InterruptedException e) {
                    return;
                }
            }
        }, "echoes-agent-defense");
        t.setDaemon(true);
        t.start();
    }

    /**
     * 独立巡检（学习自样板 independentSweep）：周期反射触发游戏侧禁生成实体巡检——
     * 完全不依赖 Forge 事件总线与字节码钩子（事件总线被关/钩子被剥时仍生效）。
     * 经游戏线程的上下文类加载器解析游戏类（绕开 agent/系统类加载器隔离）。
     */
    private static void independentSweep() {
        try {
            final ClassLoader gameCl = findGameClassLoader();
            if (gameCl == null) {
                return;
            }
            final Thread cur = Thread.currentThread();
            final ClassLoader oldTccl = cur.getContextClassLoader();
            final boolean swapped = oldTccl != gameCl;
            if (swapped) {
                try {
                    cur.setContextClassLoader(gameCl);
                } catch (final Throwable ignored) {
                    // ignore
                }
            }
            try {
                final Class<?> hooks = Class.forName("net.minecraftforge.server.ServerLifecycleHooks",
                        true, gameCl);
                final Object server = hooks.getMethod("getCurrentServer").invoke(null);
                if (server == null) {
                    return;
                }
                final Class<?> ah = Class.forName("com.echoxy.attack.EchoAttackHandler", true, gameCl);
                final java.lang.reflect.Method sweep = ah.getMethod("sweepBanned",
                        Class.forName("net.minecraft.server.MinecraftServer", true, gameCl));
                final Object finalServer = server;
                final Runnable task = () -> {
                    try {
                        sweep.invoke(null, finalServer);
                    } catch (final Throwable ignored) {
                        // ignore
                    }
                };
                server.getClass().getMethod("execute", Runnable.class).invoke(server, task);
            } finally {
                if (swapped) {
                    try {
                        cur.setContextClassLoader(oldTccl);
                    } catch (final Throwable ignored) {
                        // ignore
                    }
                }
            }
        } catch (final Throwable ignored) {
            // 游戏未就绪/反射失败：静默跳过
        }
    }

    /** 从游戏主线程拿上下文类加载器（游戏类的正确加载器）。 */
    private static ClassLoader findGameClassLoader() {
        for (final Thread th : Thread.getAllStackTraces().keySet()) {
            final String n = th.getName();
            if (n == null) {
                continue;
            }
            if (n.equals("main") || n.contains("Server thread") || n.contains("Render thread")) {
                final ClassLoader cl = th.getContextClassLoader();
                if (cl != null) {
                    return cl;
                }
            }
        }
        return null;
    }

    /** 代理参数审计（学习自样板 ArtemisAgentArgAudit 的 Java 侧判据）：premain 期检查
     * {@code -javaagent} 参数里是否有非我方 agent（记录，不阻断）。 */
    private static volatile boolean argAudited;

    private static void auditAgentArgs() {
        if (argAudited) {
            return;
        }
        argAudited = true;
        try {
            final java.util.List<String> args =
                    java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments();
            if (!argAudit || args == null) {
                return;
            }
            int foreign = 0;
            final StringBuilder sb = new StringBuilder();
            for (final String a : args) {
                if (a == null || !a.startsWith("-javaagent:")) {
                    continue;
                }
                final String path = a.substring("-javaagent:".length()).toLowerCase(java.util.Locale.ROOT);
                if (path.contains("echoes")) {
                    continue; // 我方 agent（-javaagent 通道，目前不启用）
                }
                foreign++;
                sb.append(path.contains("=") ? path.substring(0, path.indexOf('=')) : path).append(' ');
            }
            if (foreign > 0) {
                logWarn("代理参数审计：检测到 " + foreign + " 个非我方 -javaagent（" + sb + "）——未阻断，仅记录");
            }
        } catch (final Throwable ignored) {
            // 审计失败不影响主流程
        }
    }

    // ==================== 第三方线程清理 ====================

    /**
     * 清理第三方恶意后台线程。
     *
     * <p>判定规则（与样板一致，防误杀）：</p>
     * <ol>
     *   <li>线程名命中框架白名单（Render/Server/main/Netty/Worker…）——不动；</li>
     *   <li>栈里出现 MC/Forge/ModLauncher/Mojang 帧 —— 说明该线程正在执行框架代码，不动；</li>
     *   <li>其余栈里出现非白名单帧（第三方类）——判定为敌方线程， interrupt + stop。</li>
     * </ol>
     */
    @SuppressWarnings({"deprecation", "removal"})
    private static void cleanEnemyThreads() {
        try {
            final Thread current = Thread.currentThread();
            final ThreadGroup g = rootThreadGroup();
            if (g == null) {
                return;
            }
            final Thread[] buf = new Thread[Math.max(64, g.activeCount() * 2 + 16)];
            final int n = g.enumerate(buf, true);
            for (int i = 0; i < n; i++) {
                final Thread th = buf[i];
                if (th == null || th == current || !th.isAlive()) {
                    continue;
                }
                String name = null;
                try {
                    name = th.getName();
                } catch (final Throwable ignored) {
                    continue;
                }
                if (name == null || isFrameworkThreadName(name)) {
                    continue;
                }
                StackTraceElement[] stack;
                try {
                    stack = th.getStackTrace();
                } catch (final Throwable ignored) {
                    continue;
                }
                if (stack.length == 0 || !isEnemyStack(stack)) {
                    continue;
                }
                // 竞态兜底：判定与处置之间线程可能已切到框架代码 —— 处置前重取一次栈再判
                try {
                    final StackTraceElement[] now = th.getStackTrace();
                    if (now != null && now.length > 0 && !isEnemyStack(now)) {
                        continue;
                    }
                } catch (final Throwable ignored) {
                    // 重取失败按原判定处理
                }
                try {
                    th.interrupt();
                } catch (final Throwable ignored) {
                }
                try {
                    th.stop();
                } catch (final Throwable ignored) {
                }
                logInfo("已清理第三方线程：" + name + "（daemon=" + th.isDaemon() + "）");
            }
        } catch (final Throwable ignored) {
            // 诊断/处置失败不影响主流程
        }
    }

    /** 线程数（ThreadGroup.activeCount）——"线程创建"的廉价事件源（微秒级，无安全点）。 */
    private static int activeThreadCount() {
        try {
            final ThreadGroup g = rootThreadGroup();
            return g == null ? -1 : g.activeCount();
        } catch (final Throwable t) {
            return -1;
        }
    }

    /** 根线程组（缓存；ThreadGroup 遍历入口）。 */
    private static ThreadGroup rootThreadGroup() {
        try {
            final ThreadGroup cached = rootGroup;
            if (cached != null) {
                return cached;
            }
            ThreadGroup g = Thread.currentThread().getThreadGroup();
            while (g != null && g.getParent() != null) {
                g = g.getParent();
            }
            rootGroup = g;
            return g;
        } catch (final Throwable t) {
            return null;
        }
    }

    private static boolean isFrameworkThreadName(final String name) {
        return name.contains("Render") || name.contains("Server") || name.contains("main")
                || name.contains("Reference Handler") || name.contains("Finalizer")
                || name.contains("Signal Dispatcher") || name.contains("Common-Cleaner")
                || name.contains("Notification Thread") || name.contains("Attach Listener")
                || name.contains("Worker") || name.contains("worker")
                || name.contains("ForkJoinPool") || name.contains("CommonPool")
                || name.contains("modloading") || name.contains("Netty")
                || name.contains("echoes-agent-defense");
    }

    /**
     * 敌方线程栈判定。
     *
     * <p>先看有没有框架帧（有 ⇒ 不是敌方线程，哪怕正路过第三方代码）；
     * 再看有没有"非白名单类"帧（有 ⇒ 敌方线程）。</p>
     */
    private static boolean isEnemyStack(final StackTraceElement[] stack) {
        for (final StackTraceElement frame : stack) {
            final String cls = frame == null ? null : frame.getClassName();
            if (cls == null) {
                continue;
            }
            if (cls.startsWith("net.minecraft.") || cls.startsWith("net.minecraftforge.")
                    || cls.startsWith("cpw.mods.") || cls.startsWith("com.mojang.")) {
                return false;
            }
        }
        for (final StackTraceElement frame : stack) {
            final String cls = frame == null ? null : frame.getClassName();
            if (cls == null || isWhitelistedClass(cls)) {
                continue;
            }
            return true;
        }
        return false;
    }

    /** 栈判定白名单（JDK / 框架 / 已知库 / 我方类）。 */
    private static boolean isWhitelistedClass(final String cls) {
        final String[] prefixes = {
                "com.echoxy.", "java.", "javax.", "jdk.", "sun.", "com.sun.",
                "net.minecraft.", "net.minecraftforge.", "com.mojang.", "cpw.mods.",
                "org.spongepowered.", "org.objectweb.", "org.slf4j.", "org.apache.",
                "org.lwjgl.", "org.joml.", "com.google.", "io.netty.", "it.unimi.",
                "kotlin.", "scala.", "net.java.dev.jna.", "com.llamalad7."
        };
        for (final String p : prefixes) {
            if (cls.startsWith(p)) {
                return true;
            }
        }
        return false;
    }

    // ==================== 开关与日志 ====================

    /** 读系统属性开关（缺省即默认值）。 */
    private static void readFlags() {
        selfHeal = readBool("echoxy.agent.selfheal", true);
        purge = readBool("echoxy.agent.purge", true);
        dangerStrip = readBool("echoxy.agent.danger", true);
        shell = readBool("echoxy.agent.shell", true);
        allReturn = readBool("echoxy.agent.allreturn", true);
        clinitCatch = readBool("echoxy.agent.clinitcatch", true);
        eventGate = readBool("echoxy.agent.eventgate", true);
        fieldProtect = readBool("echoxy.agent.fieldprotect", true);
        mixinStrip = readBool("echoxy.agent.mixinstrip", true);
        modelFallback = readBool("echoxy.agent.modelfallback", true);
        serviceGuard = readBool("echoxy.agent.serviceguard", true);
        loopGuard = readBool("echoxy.agent.loopguard", true);
        independentSweepEnabled = readBool("echoxy.agent.sweep", true);
        argAudit = readBool("echoxy.agent.argaudit", true);
        threadClean = readBool("echoxy.agent.threadclean", true);
        verbose = readBool("echoxy.agent.verbose", false);
    }

    private static boolean readBool(final String key, final boolean def) {
        try {
            final String v = System.getProperty(key);
            return v == null ? def : Boolean.parseBoolean(v.trim());
        } catch (final Throwable t) {
            return def;
        }
    }

    /** 汇总日志：写入统一日志文件（路径由游戏侧以系统属性传入）；无路径时退回 stdout。 */
    private static void logInfo(final String msg) {
        report("INFO " + msg, false);
    }

    private static void logWarn(final String msg) {
        report("WARN " + msg, true);
    }

    /** 供同包（EchoGuardTransformer）写统一日志（同一文件，保持"日志不要乱"纪律）。 */
    static void logExternal(final String line, final boolean forceStdout) {
        report(line, forceStdout);
    }

    private static void report(final String msg, final boolean forceStdout) {
        try {
            final String path = System.getProperty("echoxy.agent.logfile");
            if (path != null && !path.isEmpty()) {
                final Path p = Paths.get(path);
                final Path parent = p.getParent();
                if (parent != null) {
                    Files.createDirectories(parent);
                }
                Files.write(p,
                        (java.time.LocalDateTime.now() + " [AGENT] " + msg + System.lineSeparator())
                                .getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                return;
            }
            if (forceStdout) {
                System.out.println("[Echoes Agent] " + msg);
            }
        } catch (final Throwable ignored) {
            // 日志失败不影响任何逻辑
        }
    }

    /** 异常一行摘要（agent 层无 EchoLog，自带实现）。 */
    private static String brief(final Throwable t) {
        if (t == null) {
            return "null";
        }
        return t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
    }
}
