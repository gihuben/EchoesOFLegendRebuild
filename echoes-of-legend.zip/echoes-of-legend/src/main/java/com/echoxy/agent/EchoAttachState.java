package com.echoxy.agent;

/**
 * Agent 挂载状态的跨层传递（纯 JDK）。
 *
 * <p>为什么用系统属性而不是静态字段：agent JAR 由<b>系统类加载器</b>装载，
 * 而本模组侧（IWP/ITS 服务层）是另一个类加载器 —— 同一个类在两个加载器里
 * 是两份 Class，静态字段不共享。系统属性是全进程共享的，因此作为唯一权威状态源。</p>
 *
 * <p>写入方：agent 侧（{@code EchoEarlyAttach.completeAttach}）与游戏侧（本类静态方法）；
 * 读取方：任何需要判断"agent 是否已挂载"的代码。</p>
 */
public final class EchoAttachState {
    private EchoAttachState() {
    }

    /** agent 已挂载（布尔，true=已挂载）。 */
    private static final String PROP_ATTACHED = "echoxy.agent.attached";

    /** 是否已挂载（读系统属性，跨类加载器可见）。 */
    public static boolean isAgentAttached() {
        try {
            return "true".equalsIgnoreCase(System.getProperty(PROP_ATTACHED));
        } catch (final Throwable t) {
            return false;
        }
    }

    /** 置位挂载状态（系统属性，跨类加载器共享）。 */
    public static void setAgentAttached(final boolean attached) {
        try {
            System.setProperty(PROP_ATTACHED, String.valueOf(attached));
        } catch (final Throwable ignored) {
            // 属性写入失败不影响主流程
        }
    }
}
