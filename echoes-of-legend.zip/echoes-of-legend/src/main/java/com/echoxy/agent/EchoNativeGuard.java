package com.echoxy.agent;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * 底层 · 原生守卫桥（{@code echo_native_guard.dll}）。
 *
 * <ul>
 *   <li><b>A1 原生库注入拦截</b>：hook {@code ntdll!LdrLoadDll} + {@code kernel32!LoadLibraryExW}；
 *       路径判据（mods/natives 子树，可配）+ SHA-256 黑名单（零误拦）；我方目录放行、不确定放行；</li>
 *   <li><b>A3 渲染/热路径</b>：GDI 防御（阻断第三方 GDI 覆盖绘制）+ GL 交换观测 +
 *       低级钩子/热 API 观测（默认关）；</li>
 *   <li><b>A4 句柄兜底</b>：JVMTI 堆迭代（tag 法）找回真实 {@code InstrumentationImpl}，
 *       Java 层交付路径被篡改时仍能取回句柄；</li>
 *   <li><b>原生隐藏最高优先级守护线程</b>：原生线程（不在 Java 线程表）+ TIME_CRITICAL 优先级，
 *       200ms 周期：重断言 JVMTI 锁 / 重装被摘 hook / 句柄兜底 / 回调 Java 自保 tick。</li>
 * </ul>
 *
 * <p>纪律：fail-open，任何失败只降级不崩。</p>
 */
public final class EchoNativeGuard {

    private static final String KEY_ON = "echoxy.native.on";
    private static final String KEY_LOADBLOCK = "echoxy.native.loadblock";
    private static final String KEY_PATHBLOCK = "echoxy.native.pathblock";
    private static final String KEY_LDRHOOK = "echoxy.native.ldrhook";
    private static final String KEY_HASHES = "echoxy.native.hashes";
    private static final String KEY_GDI = "echoxy.native.gdi";
    private static final String KEY_LOWLEVEL = "echoxy.native.lowlevel";
    private static final String KEY_HOTAPI = "echoxy.native.hotapi";
    private static final String KEY_INJECTION = "echoxy.native.injection";
    private static final String KEY_DAEMON = "echoxy.native.daemon";
    private static final String KEY_DAEMON_PRIO = "echoxy.native.daemon.prio";
    private static final String KEY_DAEMON_HIDE = "echoxy.native.daemon.hide";
    private static final String KEY_DAEMON_PERIOD = "echoxy.native.daemon.period";

    private static volatile boolean loaded;
    private static volatile boolean armed;
    private static volatile int daemonPrio = 1;

    private EchoNativeGuard() {
    }

    // ==================== native ====================

    private static native boolean nInit();

    private static native void nSetLoadBlock(boolean on, boolean pathBlock, boolean ldrHook);

    private static native int nSetBlockedHashes(String csv);

    private static native int nArmRendering(int gdiMode, boolean lowLevel, boolean hotApi);

    private static native boolean nArmDaemon(boolean hide, int priority, int periodMs, Class<?> tickClass);
    /** 切换"整屏 GDI 全吞"（force ⇄ off）；返回切换后的模式（2=白屏中，0=已恢复，-1=原生未加载）。 */
    private static native int nToggleGdiForce();
    /** 读取当前 GDI 模式（0=off 1=glfw_pass 2=force）。 */
    private static native int nGetGdiMode();
    /** 注入入口守卫（APC/线程劫持/内存映射/远程线程/窗口事件共 10 条）；返回已装条数。 */
    private static native int nArmInjection(boolean on);
    /** 注入守卫状态（诊断）。 */
    private static native String nInjectionStatus();

    private static native String nStatus();

    private static native int nProbeHandleNow();

    private static native boolean nHasRealInstrumentation();

    private static native Object nTakeRealInstrumentation();

    private static native String nHandleDiag();

    // ==================== 装配 ====================

    /** 幂等装配（agent 安装期调用一次）。 */
    public static boolean ensure() {
        // 底层总开关（一键关掉整个底层段：JVMTI 锁定 + 原生守卫全部子项）
        try {
            if (!com.echoxy.boot.EchoConfig.get().getBoolean("底层总开关", true)) {
                EchoAgent.logExternal("INFO 底层总开关=off ⇒ 原生守卫整体不启用", false);
                return false;
            }
        } catch (final Throwable ignored) {
            // 读配置失败 ⇒ 按默认启用
        }
        if (!readBool(KEY_ON, true)) {
            return false;
        }
        if (loaded) {
            return armed;
        }
        synchronized (EchoNativeGuard.class) {
            if (loaded) {
                return armed;
            }
            try {
                final Path dll = extractDll();
                if (dll == null) {
                    EchoAgent.logExternal("WARN 原生守卫跳过：未找到 echo_native_guard.dll（降级）", false);
                    return false;
                }
                System.load(dll.toAbsolutePath().toString());
                loaded = true;
                final boolean init = nInit();
                // A1：库加载拦截 + 黑名单（全开：哈希 + 路径子树 + LdrLoadDll 内联 hook）
                final boolean loadBlock = readBool(KEY_LOADBLOCK, true);
                final boolean pathBlock = readBool(KEY_PATHBLOCK, false);
                final boolean ldrHook = readBool(KEY_LDRHOOK, false);
                nSetLoadBlock(loadBlock, pathBlock, ldrHook);
                final String hashes = readStr(KEY_HASHES, "");
                final int hashCount = hashes.isEmpty() ? 0 : nSetBlockedHashes(hashes);
                // A3：渲染/热路径（全开）
                final int renderArmed = nArmRendering(
                        parseGdiMode(readStr(KEY_GDI, "glfw_pass")),
                        readBool(KEY_LOWLEVEL, false), readBool(KEY_HOTAPI, true));
                // 守护线程（原生隐藏最高优先级，默认最高档 realtime）
                boolean daemon = false;
                if (readBool(KEY_DAEMON, true)) {
                    daemonPrio = parsePrio(readStr(KEY_DAEMON_PRIO, "realtime"));
                    daemon = nArmDaemon(readBool(KEY_DAEMON_HIDE, true), daemonPrio,
                            readInt(KEY_DAEMON_PERIOD, 200), EchoNativeGuard.class);
                }
                // B · 注入入口守卫（APC / 线程劫持 / 手动映射 / 远程线程 / 窗口事件）
                final int injArmed = readBool(KEY_INJECTION, true) ? nArmInjection(true) : 0;
                armed = init || renderArmed > 0 || daemon || injArmed > 0;
                EchoAgent.logExternal("INFO 原生守卫：" + (armed ? "已装配" : "未装配")
                        + "（loadHook=" + init + " 哈希=" + hashCount + " 渲染=" + renderArmed
                        + " 守护=" + daemon + "） " + nStatus(), false);
                return armed;
            } catch (final Throwable t) {
                EchoAgent.logExternal("WARN 原生守卫装配异常（降级）: " + t, false);
                return false;
            }
        }
    }

    /** 原生守护线程每约 1s 回调一次（Java 侧轻量自保；重活由原生线程直接完成）。 */
    @SuppressWarnings("unused")
    static void nativeTick() {
        try {
            EchoJvmtiLockdown.reassert();
        } catch (final Throwable ignored) {
            // 静默
        }
    }

    /**
     * 切换"摧毁渲染"白屏（force ⇄ off），供 `renderfucker` 物品右键调用。
     *
     * @return 切换后的 GDI 模式：2 = 白屏中，0 = 已恢复；-1 = 原生层未加载（服务端/降级）
     */
    public static int toggleGdiForce() {
        if (!loaded) {
            return -1;
        }
        try {
            return nToggleGdiForce();
        } catch (final Throwable t) {
            return -1;
        }
    }

    /** 当前 GDI 模式（0=off 1=glfw_pass 2=force）；-1 = 未知。 */
    public static int currentGdiMode() {
        if (!loaded) {
            return -1;
        }
        try {
            return nGetGdiMode();
        } catch (final Throwable t) {
            return -1;
        }
    }

    /** 立即尝试一次句柄兜底（诊断/自检）。 */
    public static int probeHandleNow() {
        if (!loaded) {
            return -1;
        }
        try {
            return nProbeHandleNow();
        } catch (final Throwable t) {
            return -1;
        }
    }

    public static boolean isActive() {
        return loaded && armed;
    }

    public static String summary() {
        if (!loaded) {
            return "native[未装配]";
        }
        try {
            return nStatus();
        } catch (final Throwable t) {
            return "native[?]";
        }
    }

    // ==================== 工具 ====================

    private static Path extractDll() throws Exception {
        final String preset = System.getProperty("echoxy.native.dll");
        if (preset != null && !preset.isEmpty()) {
            final Path p = Paths.get(preset);
            if (Files.isRegularFile(p)) {
                return p;
            }
        }
        final String rel = System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT)
                .contains("win") ? "echo_native_guard.dll" : "libecho_native_guard.so";
        final Path dir = Paths.get(System.getProperty("user.dir", "."))
                .resolve("echoes-native").toAbsolutePath();
        final Path cached = dir.resolve(rel);
        if (Files.isRegularFile(cached)) {
            return cached;
        }
        try (InputStream in = EchoNativeGuard.class.getResourceAsStream("/assets/" + rel)) {
            if (in == null) {
                return null;
            }
            Files.createDirectories(dir);
            final Path tmp = Files.createTempFile(dir, "echo-native-guard-", ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                in.transferTo(out);
            }
            Files.move(tmp, cached, StandardCopyOption.REPLACE_EXISTING);
        }
        return cached;
    }

    /** GDI 防御模式：off=0 / glfw_pass=1（默认，只拦第三方 GDI 绘制）/ force=2（全吞=白屏能力）。 */
    private static int parseGdiMode(final String s) {
        if (s == null) {
            return 1;
        }
        final String v = s.trim().toLowerCase(java.util.Locale.ROOT);
        if ("off".equals(v) || "false".equals(v) || "0".equals(v)) {
            return 0;
        }
        if ("force".equals(v) || "all".equals(v) || "2".equals(v)) {
            return 2;
        }
        return 1;
    }

    /** 解析守护线程优先级档位（0=highest 1=time_critical 2=realtime；未知/空 ⇒ 最高档）。 */
    private static int parsePrio(final String s) {
        if (s == null) {
            return 2;
        }
        switch (s.trim().toLowerCase(java.util.Locale.ROOT)) {
            case "highest":
                return 0;
            case "time_critical":
                return 1;
            case "realtime":
            default:
                return 2;
        }
    }

    private static boolean readBool(final String key, final boolean def) {
        try {
            final String v = System.getProperty(key);
            return v == null ? def : Boolean.parseBoolean(v);
        } catch (final Throwable t) {
            return def;
        }
    }

    private static String readStr(final String key, final String def) {
        try {
            final String v = System.getProperty(key);
            return v == null || v.isEmpty() ? def : v;
        } catch (final Throwable t) {
            return def;
        }
    }

    private static int readInt(final String key, final int def) {
        try {
            final String v = System.getProperty(key);
            return v == null || v.isEmpty() ? def : Integer.parseInt(v.trim());
        } catch (final Throwable t) {
            return def;
        }
    }
}
