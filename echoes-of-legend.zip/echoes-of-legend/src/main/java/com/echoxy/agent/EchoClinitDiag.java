package com.echoxy.agent;

import java.util.concurrent.atomic.AtomicLong;

/**
 * {@code <clinit>} 兜底诊断（学习自样板 ArtemisGateDiag.noteClinitThrowable）。
 *
 * <p>由注入在第三方类 {@code <clinit>} 的 catch 体里调用：把被吞掉的静态初始化异常捞出来
 * （只记类名与异常摘要，写统一日志；诊断器内部吞掉一切异常，绝不让它成为新的抛出点）。</p>
 *
 * <p>纯 JDK —— 会被第三方类（自动模块，读一切）按名引用；也随 agent JAR 自包含。</p>
 */
public final class EchoClinitDiag {

    private EchoClinitDiag() {
    }

    private static final AtomicLong COUNT = new AtomicLong();

    public static void noteClinitThrowable(final String className, final Throwable t) {
        try {
            final long n = COUNT.incrementAndGet();
            if (n <= 50 || n % 100 == 0) {
                EchoAgent.logExternal("WARN <clinit> 兜底吞异常 #" + n + " " + className
                        + " ：" + (t == null ? "null" : t.getClass().getSimpleName()
                        + ": " + String.valueOf(t.getMessage())), false);
            }
        } catch (final Throwable ignored) {
            // 诊断器绝不外抛
        }
    }
}
