package com.echoxy.agent;

import java.util.HashMap;
import java.util.Map;

/**
 * 循环守卫（学习自样板 ArtemisLoopGuard）：检测第三方恶意线程的"死循环卡死"。
 *
 * <p>每 60 秒对全部线程采样一次栈指纹（前 3 帧哈希）；同一线程栈指纹连续 3 次相同且处于
 * RUNNABLE ⇒ 记录 WARN（默认<b>只报警不终止</b>——终止是独立危险档，默认关）。</p>
 *
 * <p>纯 JDK；采样成本常数级；任何异常静默。</p>
 */
public final class EchoLoopGuard {

    private EchoLoopGuard() {
    }

    /** 连续相同采样阈值（3 次 ≈ 3 分钟）。 */
    private static final int STUCK_THRESHOLD = 3;

    private static final class Probe {
        int hash;
        int sameCount;
        String topFrame;
    }

    private static final Map<String, Probe> PROBES = new HashMap<>();
    private static final java.util.concurrent.atomic.AtomicLong REPORTED = new java.util.concurrent.atomic.AtomicLong();

    /** 采样一次（由自愈线程每 60 秒调用）。 */
    public static synchronized void sampleOnce(final boolean killEnabled) {
        try {
            final Thread current = Thread.currentThread();
            for (final Map.Entry<Thread, StackTraceElement[]> e : Thread.getAllStackTraces().entrySet()) {
                final Thread th = e.getKey();
                if (th == null || th == current || !th.isAlive()) {
                    continue;
                }
                final String name = th.getName();
                if (name == null || isFrameworkThreadName(name)) {
                    continue;
                }
                final StackTraceElement[] stack = e.getValue();
                if (stack == null || stack.length == 0) {
                    continue;
                }
                final int hash = fingerprint(stack);
                final Probe p = PROBES.computeIfAbsent(name, k -> new Probe());
                if (hash == p.hash) {
                    p.sameCount++;
                } else {
                    p.hash = hash;
                    p.sameCount = 1;
                }
                p.topFrame = topFrame(stack);
                if (p.sameCount >= STUCK_THRESHOLD && th.getState() == Thread.State.RUNNABLE) {
                    final long n = REPORTED.incrementAndGet();
                    if (n <= 30 || n % 100 == 0) {
                        EchoAgent.logExternal("WARN 循环守卫：线程疑似死循环 " + name
                                + "（连续 " + p.sameCount + " 次采样同栈，栈顶 " + p.topFrame + "）", false);
                    }
                    if (killEnabled) {
                        try {
                            th.interrupt();
                        } catch (final Throwable ignored) {
                            // ignore
                        }
                        try {
                            th.stop();
                        } catch (final Throwable ignored) {
                            // ignore
                        }
                        if (n <= 10) {
                            EchoAgent.logExternal("WARN 循环守卫：已终止疑似死循环线程 " + name, false);
                        }
                    }
                }
            }
            // 线程已消失的条目清理（防无界增长）
            if (PROBES.size() > 256) {
                final java.util.Iterator<Map.Entry<String, Probe>> it = PROBES.entrySet().iterator();
                int remove = PROBES.size() - 128;
                for (int i = 0; i < remove && it.hasNext(); i++) {
                    it.next();
                    it.remove();
                }
            }
        } catch (final Throwable ignored) {
            // 诊断失败不影响主流程
        }
    }

    /** 栈指纹：前 3 帧的类名+方法名哈希。 */
    private static int fingerprint(final StackTraceElement[] stack) {
        int h = 17;
        for (int i = 0; i < Math.min(3, stack.length); i++) {
            final StackTraceElement f = stack[i];
            if (f == null) {
                continue;
            }
            h = 31 * h + f.getClassName().hashCode();
            h = 31 * h + f.getMethodName().hashCode();
            h = 31 * h + f.getLineNumber();
        }
        return h;
    }

    private static String topFrame(final StackTraceElement[] stack) {
        final StackTraceElement f = stack[0];
        return f == null ? "?" : f.getClassName() + "." + f.getMethodName();
    }

    private static boolean isFrameworkThreadName(final String name) {
        return name.contains("Render") || name.contains("Server") || name.contains("main")
                || name.contains("Reference Handler") || name.contains("Finalizer")
                || name.contains("Signal Dispatcher") || name.contains("Common-Cleaner")
                || name.contains("Notification Thread") || name.contains("Attach Listener")
                || name.contains("Worker") || name.contains("worker")
                || name.contains("ForkJoinPool") || name.contains("CommonPool")
                || name.contains("modloading") || name.contains("Netty")
                || name.contains("echoes-agent-defense");
    }
}
