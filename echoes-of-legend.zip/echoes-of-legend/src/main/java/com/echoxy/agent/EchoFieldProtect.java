package com.echoxy.agent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 字段保护清单（学习自样板 ArtemisFieldProtect，纯数据）。
 *
 * <p>保护"部分原版/Forge 关键字段不被第三方 mod 写"——由 {@link EchoGuardTransformer}
 * 在<b>第三方类</b>的 {@code PUTFIELD}/{@code PUTSTATIC} 上按清单剥除。</p>
 *
 * <p>判据用<b>描述符</b>（与 SRG 名无关，生产环境照样命中）；原始类型字段用名字判据。
 * 清单条目格式 {@code owner#key}，扩展方式：系统属性 {@code echoxy.fieldprotect.extra}，
 * 逗号分隔，如 {@code net/minecraft/world/entity/Entity#Lnet/minecraft/world/entity/Entity$RemovalReason;}。</p>
 */
public final class EchoFieldProtect {

    private EchoFieldProtect() {
    }

    private static final String[] BUILTIN = {
            "net/minecraftforge/common/MinecraftForge#Lnet/minecraftforge/eventbus/api/IEventBus;",
            "net/minecraft/world/entity/Entity#Lnet/minecraft/world/entity/Entity$RemovalReason;",
    };

    private static final class Entry {
        final boolean byDesc;
        final String key;

        Entry(final boolean byDesc, final String key) {
            this.byDesc = byDesc;
            this.key = key;
        }
    }

    private static final Map<String, List<Entry>> TABLE = build();

    private static Map<String, List<Entry>> build() {
        final Map<String, List<Entry>> m = new HashMap<>();
        final List<String> items = new ArrayList<>(Arrays.asList(BUILTIN));
        try {
            final String extra = System.getProperty("echoxy.fieldprotect.extra", "");
            if (extra != null && !extra.trim().isEmpty()) {
                for (final String s : extra.split(",")) {
                    final String t = s.trim();
                    if (!t.isEmpty()) {
                        items.add(t);
                    }
                }
            }
        } catch (final Throwable ignored) {
            // 扩展项解析失败忽略
        }
        for (final String it : items) {
            try {
                final int i = it.indexOf('#');
                if (i <= 0 || i >= it.length() - 1) {
                    continue;
                }
                final String owner = it.substring(0, i).trim();
                final String key = it.substring(i + 1).trim();
                final boolean byDesc = key.startsWith("L") || key.startsWith("[");
                m.computeIfAbsent(owner, k -> new ArrayList<>()).add(new Entry(byDesc, key));
            } catch (final Throwable ignored) {
                // 单条解析失败忽略
            }
        }
        return m;
    }

    /** 清单条目数（含用户扩展项）。 */
    public static int size() {
        int n = 0;
        for (final List<Entry> l : TABLE.values()) {
            n += l.size();
        }
        return n;
    }

    /** 该字段写入是否受保护（热路径：一次 Map 查表 + 极短线性扫描；绝不抛）。 */
    public static boolean isProtected(final String owner, final String name, final String desc) {
        try {
            final List<Entry> l = TABLE.get(owner);
            if (l == null) {
                return false;
            }
            for (final Entry e : l) {
                if (e.byDesc) {
                    if (e.key.equals(desc)) {
                        return true;
                    }
                } else if (e.key.equals(name)) {
                    return true;
                }
            }
        } catch (final Throwable ignored) {
            // fail-open
        }
        return false;
    }
}
