package com.echoxy.agent;

import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 服务表守卫（学习自样板 ArtemisServiceGuard）：防止第三方把本模组的
 * {@code ITransformationService} 条目从 ModLauncher 的 {@code serviceLookup} 表里删掉
 * （删掉 = 我方服务再也收不到任何生命周期回调 = 被架空）。
 *
 * <p>策略（对齐样板）：</p>
 * <ol>
 *   <li>早期 {@link #capture()} 抓住 handler 与我方条目（表未建好时留空，后续自动补）；</li>
 *   <li>周期 {@link #reassert()}：<b>补回我方条目</b>；第三方条目（CodeSource 在 mods 目录且非我方 jar）
 *       剔除；框架条目（fml/mixin/forge/modlauncher/securejar）绝不误删；判不出来的一律保留。</li>
 * </ol>
 * <p>纯 JDK + 反射；任何失败只返回 0，绝不抛。</p>
 */
public final class EchoServiceGuard {

    private EchoServiceGuard() {
    }

    /** 我方服务名（{@code EchoTransformService.name()}）。 */
    private static final String OUR_KEY = "echoes_early";

    /** 框架保留关键词（小写匹配 key）：命中即保留，绝不误删。 */
    private static final String[] FRAMEWORK_KEY_HINTS = { "fml", "mixin", "forge", "modlauncher", "securejar" };

    private static volatile Object handler;
    private static volatile long lookupOffset = -1L;
    private static volatile Object unsafeCache;
    private static volatile long serviceFieldOffset = -1L;
    private static volatile Object ourDecorator;
    private static volatile boolean captured;
    private static volatile boolean diagnosed;

    /** 抓取 ModLauncher 侧句柄与我方条目（幂等；表未建好时允许重试）。 */
    public static boolean capture() {
        if (captured) {
            refreshMine();
            return true;
        }
        try {
            final Object un = unsafe();
            if (un == null) {
                return false;
            }
            final Class<?> launcherCls = Class.forName("cpw.mods.modlauncher.Launcher");
            final Object launcher = launcherCls.getField("INSTANCE").get(null);
            if (launcher == null) {
                return false;
            }
            final Field hf = launcherCls.getDeclaredField("transformationServicesHandler");
            final long hOff = offsetOf(un, hf);
            if (hOff < 0) {
                return false;
            }
            final Object h = getObj(un, launcher, hOff);
            if (h == null) {
                return false;
            }
            Field lf = null;
            for (final Field f : h.getClass().getDeclaredFields()) {
                if (Map.class.isAssignableFrom(f.getType())) {
                    lf = f;
                    break;
                }
            }
            if (lf == null) {
                return false;
            }
            final long lOff = offsetOf(un, lf);
            if (lOff < 0) {
                return false;
            }
            final Object cur = getObj(un, h, lOff);
            if (cur instanceof Map) {
                final Object mine = ((Map<?, ?>) cur).get(OUR_KEY);
                if (mine != null) {
                    ourDecorator = mine;
                }
            }
            // decorator.service 字段偏移（判身份用；从表里任一实例就地解析）
            if (cur instanceof Map && !((Map<?, ?>) cur).isEmpty()) {
                for (final Object v : ((Map<?, ?>) cur).values()) {
                    if (v != null) {
                        final Field sf = v.getClass().getDeclaredField("service");
                        final long svcOff = offsetOf(un, sf);
                        if (svcOff >= 0) {
                            serviceFieldOffset = svcOff;
                        }
                        break;
                    }
                }
            }
            handler = h;
            lookupOffset = lOff;
            unsafeCache = un;
            captured = true;
            reassert();
            return true;
        } catch (final Throwable t) {
            return false;
        }
    }

    /** 补抓我方条目（serviceLookup 可能刚建好）。 */
    private static void refreshMine() {
        if (ourDecorator != null && serviceFieldOffset >= 0) {
            return;
        }
        try {
            final Object un = unsafeCache;
            final Object h = handler;
            if (un == null || h == null || lookupOffset < 0) {
                return;
            }
            final Object cur = getObj(un, h, lookupOffset);
            if (!(cur instanceof Map)) {
                return;
            }
            final Object mine = ((Map<?, ?>) cur).get(OUR_KEY);
            if (mine != null) {
                ourDecorator = mine;
                reassert();
            }
            if (serviceFieldOffset < 0 && !((Map<?, ?>) cur).isEmpty()) {
                for (final Object v : ((Map<?, ?>) cur).values()) {
                    if (v != null) {
                        final long off = offsetOf(un, v.getClass().getDeclaredField("service"));
                        if (off >= 0) {
                            serviceFieldOffset = off;
                        }
                        break;
                    }
                }
            }
        } catch (final Throwable ignored) {
            // 幂等重试
        }
    }

    /**
     * 重断言：补回我方条目 + 剔除第三方条目（整表替换写回，兼容对手写的不可变 map）。
     *
     * @return 本次净变更数（0 = 无需改动，零副作用）
     */
    public static int reassert() {
        if (!captured) {
            return 0;
        }
        try {
            final Object un = unsafeCache;
            final Object h = handler;
            if (un == null || h == null || lookupOffset < 0) {
                return 0;
            }
            final Object curObj = getObj(un, h, lookupOffset);
            if (!(curObj instanceof Map)) {
                return 0;
            }
            final Map<?, ?> cur = (Map<?, ?>) curObj;
            final Map<String, Object> keep = new LinkedHashMap<>();
            final Map<String, Object> others = new LinkedHashMap<>();
            int removed = 0;
            boolean sawMine = false;
            for (final Map.Entry<?, ?> e : cur.entrySet()) {
                final Object k = e.getKey();
                if (k == null) {
                    return 0; // 表结构异常：整表不动
                }
                final String key = String.valueOf(k);
                final Object v = e.getValue();
                if (OUR_KEY.equals(key)) {
                    sawMine = true;
                    ourDecorator = v;
                    continue; // 稍后置顶，不按原顺序放
                }
                if (isFrameworkKey(key)) {
                    others.put(key, v);
                    continue;
                }
                if (isThirdPartyDecorator(un, v)) {
                    removed++;
                    continue;
                }
                others.put(key, v);
            }
            // G4 · 置顶：我方条目固定放首位（服务目录按顺序取可用提供者 ⇒ 第三方抢不到先手）
            boolean needReorder = false;
            if (ourDecorator != null) {
                final java.util.Iterator<?> it = cur.keySet().iterator();
                if (it.hasNext() && !OUR_KEY.equals(String.valueOf(it.next()))) {
                    needReorder = true;
                }
                keep.put(OUR_KEY, ourDecorator);
            }
            keep.putAll(others);
            boolean addedMine = !sawMine && ourDecorator != null;
            if (removed == 0 && !addedMine && !needReorder) {
                return 0;
            }
            putObj(un, h, lookupOffset, keep);
            fence(un);
            if (!diagnosed) {
                diagnosed = true;
                EchoAgent.logExternal("INFO 服务表守卫：条目=" + cur.size() + " 我方在表=" + sawMine
                        + " 本轮剔除第三方=" + removed + " 置顶=" + needReorder, false);
            }
            return removed + (addedMine ? 1 : 0);
        } catch (final Throwable t) {
            return 0;
        }
    }

    private static boolean isFrameworkKey(final String key) {
        final String lower = key.toLowerCase(java.util.Locale.ROOT);
        for (final String hint : FRAMEWORK_KEY_HINTS) {
            if (lower.contains(hint)) {
                return true;
            }
        }
        return false;
    }

    /** 是否"确定是第三方"：取 decorator.service → CodeSource 位于 mods 目录且非我方 jar。 */
    private static boolean isThirdPartyDecorator(final Object un, final Object decorator) {
        try {
            if (decorator == null || serviceFieldOffset < 0) {
                return false;
            }
            final Object svc = getObj(un, decorator, serviceFieldOffset);
            if (svc == null) {
                return false;
            }
            final Class<?> sc = svc.getClass();
            final String n = sc.getName();
            if (n.startsWith("com.echoxy.")) {
                return false; // 我方类（防御改名自伤）
            }
            String src = null;
            try {
                final java.security.ProtectionDomain pd = sc.getProtectionDomain();
                if (pd != null && pd.getCodeSource() != null && pd.getCodeSource().getLocation() != null) {
                    src = pd.getCodeSource().getLocation().getPath();
                }
            } catch (final Throwable ignored) {
                // CodeSource 拿不到 → fail-safe 保留
            }
            if (src == null || src.isEmpty()) {
                return false;
            }
            final String lower = src.toLowerCase(java.util.Locale.ROOT).replace('\\', '/');
            if (lower.contains("echoes_of_legend")) {
                return false;
            }
            String mods = System.getProperty("user.dir", ".") + "/mods";
            mods = mods.toLowerCase(java.util.Locale.ROOT).replace('\\', '/');
            if (!mods.endsWith("/")) {
                mods += "/";
            }
            return lower.startsWith(mods);
        } catch (final Throwable t) {
            return false; // fail-safe
        }
    }

    // ==================== 反射 / Unsafe 原语 ====================

    private static Object unsafe() {
        try {
            final Class<?> uc = Class.forName("sun.misc.Unsafe");
            final Field f = uc.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            return f.get(null);
        } catch (final Throwable t) {
            return null;
        }
    }

    private static long offsetOf(final Object un, final Field f) {
        try {
            final Object r = un.getClass().getMethod("objectFieldOffset", Field.class).invoke(un, f);
            return r instanceof Long ? (Long) r : -1L;
        } catch (final Throwable t) {
            return -1L;
        }
    }

    private static Object getObj(final Object un, final Object target, final long off) {
        try {
            return un.getClass().getMethod("getObject", Object.class, long.class).invoke(un, target, off);
        } catch (final Throwable t) {
            return null;
        }
    }

    private static void putObj(final Object un, final Object target, final long off, final Object val) {
        try {
            un.getClass().getMethod("putObject", Object.class, long.class, Object.class)
                    .invoke(un, target, off, val);
        } catch (final Throwable ignored) {
            // 写失败不影响主流程
        }
    }

    private static void fence(final Object un) {
        try {
            un.getClass().getMethod("storeFence").invoke(un);
        } catch (final Throwable ignored) {
            // ignore
        }
    }
}
