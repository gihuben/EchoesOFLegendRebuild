package com.echoxy.agent;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * 回响物语字节码卫兵（agent JAR 内，系统类加载器装载）。
 *
 * <h2>功能（全部只对"第三方类"生效，白名单内的 JDK/MC/Forge/已知库/我方类一律放行）</h2>
 * <ol>
 *   <li><b>危险调用中和</b>：移除第三方类里的
 *       {@code System.exit(int)} / {@code Runtime.halt(int)} / {@code Thread.stop} 自爆调用；</li>
 *   <li><b>软空壳</b>（soft shell）：把第三方类的实例方法体替换为**安全默认返回**
 *       （String→空串、集合→空集合、数组→零长、数值→0、对象→null），
 *       类结构照常合法、注册照常工作，但第三方行为被掏空；
 *       保留 {@code <init>}/{@code <clinit>}/注册供应商/纯计算助手；native 方法去 ACC_NATIVE 后给默认返回；
 *       实体数据契约方法转发 super（父类构造期虚调用安全）；"武装类"连静态初始化与静态方法一起掏空；</li>
 *   <li><b>全返回</b>（ALLRETURN，报告式）：在软空壳结果上叠加 —— 覆写父类/接口的方法改为
 *       {@code invokespecial super.方法(args)}（父类构造期虚调用安全）；独立 void 方法直接 return；
 *       独立非 void 方法不动（注册供应商不向注册表流入 null）；</li>
 *   <li><b>断筋战术</b>：{@link #purgeForeignTransformers(Instrumentation)} 周期物理摘除第三方
 *       {@link ClassFileTransformer}。</li>
 * </ol>
 *
 * <p>ASM 类由 {@code EchoEarlyAttach} 在生成 agent JAR 时从运行期 ASM 包中读取并自包含；
 * 若 ASM 打包失败，{@link #install(Instrumentation)} 会检测并降级（只保留断筋）。</p>
 *
 * <p>所有开关由系统属性传入（{@code echoxy.agent.*}，游戏侧在挂载前设置），agent 层不引用游戏侧类。</p>
 */
public final class EchoGuardTransformer implements ClassFileTransformer {

    private static final EchoGuardTransformer INSTANCE = new EchoGuardTransformer();

    /** 危险调用中和开关。 */
    private static volatile boolean dangerEnabled = true;
    /** 软空壳开关。 */
    private static volatile boolean shellEnabled = true;
    /** 全返回开关。 */
    private static volatile boolean allReturnEnabled = true;
    /** 全清空式 purge 开关（第三方类 void/基本类型方法体清空；补齐"对齐样板 purge"通道）。 */
    private static volatile boolean purgeEnabled = true;
    /** 第三方 {@code <clinit>} 包 catch 开关（静态初始化崩被吞）。 */
    private static volatile boolean clinitCatchEnabled = true;
    /** 事件闸门开关（ASMEventHandler 跳过第三方 handler）。 */
    private static volatile boolean eventGateEnabled = true;

    /**
     * 事件闸门第一方前缀（命中 ⇒ handler 照常执行；不命中 ⇒ 第三方 ⇒ 跳过）。
     * 与样板 FIRST_PARTY 清单同源，另加我方包 {@code com.echoxy.}；比较对象是 handler 实例的类名
     * （lambda/匿名类的类名以订阅方法定义类为前缀），故全部用"点号"形态。
     */
    private static final String[] FIRST_PARTY_PREFIXES = {
            "net.minecraft.", "net.minecraftforge.", "net.neoforged.", "com.mojang.", "cpw.mods.",
            "org.spongepowered.", "com.echoxy.", "java.", "javax.", "jdk.", "sun.", "com.sun.",
            "com.google.", "org.apache.", "io.netty.", "it.unimi.", "org.objectweb.",
            "com.llamalad7.", "org.lwjgl.", "org.slf4j."
    };

    /**
     * 注册/生命周期事件的判定标记（事件闸门对命中者<b>一律放行</b>）。
     *
     * <p>这些事件里的第三方 handler 是"游戏必需的注册动作"（实体属性登记、生成规则、创造标签构建、
     * 数据包注册、mod 生命周期等）。若一并跳过，实体/物品根本没登记，表现就是
     * {@code Entity xxx has no attributes} → {@code /summon} 报"无法召唤实体"（实测日志实证）。</p>
     *
     * <p>判定发生在 {@code ASMEventHandler.readable}（{@code "ASM: <类> <方法>(<参数类型>)V"}）上，
     * 用字符串包含匹配；全部是框架事件名，不点名任何 MOD（铁律⑤）。</p>
     */
    private static final String[] REGISTRATION_EVENT_MARKS = {
            "Register",                       // RegisterEvent / *RegisterEvent / RegisterCommandsEvent …
            "EntityAttributeCreationEvent",   // 实体属性登记（缺了 ⇒ 构造实体 NPE ⇒ 无法召唤）
            "EntityAttributeModificationEvent",
            "BuildCreativeModeTabContentsEvent", // 创造标签内容构建
            "SetupEvent",                     // FMLCommonSetupEvent / FMLClientSetupEvent
            "DataPackRegistryEvent",
            "InterModEnqueueEvent", "InterModProcessEvent",
            "EntityRenderersEvent"            // 客户端渲染器注册（实体可见性）
    };
    /** 字段保护开关（第三方写受保护字段 → 剥除）。 */
    private static volatile boolean fieldProtectEnabled = true;
    /** Mixin 处理器抹除开关（原版类 handler$/mixin$ 引用第三方 → 清空）。 */
    private static volatile boolean mixinStripEnabled = true;
    /** 模型缺层兜底开关（bakeLayer/getChild 缺件 → 空模型）。 */
    private static volatile boolean modelFallbackEnabled = true;
    /** 反射调用剥除开关。 */
    private static volatile boolean reflectStripEnabled = true;
    /** Unsafe/VarHandle/defineClass 调用剥除开关（常开通道）。 */
    private static volatile boolean unsafeStripEnabled = true;
    /** 线程创建/调度剥除开关（Thread/Timer/Executors/Process/Runtime.exec）。 */
    private static volatile boolean threadStripEnabled = true;
    /** 线程调度/进程/关机钩子剥除开关（常开通道）。 */
    private static volatile boolean threadCallStripEnabled = true;
    /** 字节码 API 剥除开关（Javassist/ClassLoader 设置）。 */
    private static volatile boolean bytecodeApiStripEnabled = true;
    /** 文件 IO 守卫开关（破坏性文件操作剥除）。 */
    private static volatile boolean fileIoGuardEnabled = true;
    /** FML 兜底开关（mod 构造/事件派发异常被吞，FML 不判 ERROR）。 */
    private static volatile boolean fmlSinkEnabled = true;
    /** 数据包空 key 守卫开关（null registryKey 跳过注册）。 */
    private static volatile boolean datapackGuardEnabled = true;
    /** 详细日志开关。 */
    private static volatile boolean verbose;

    /** 统计（只写数量，日志不刷屏）。 */
    private static final AtomicLong shellCount = new AtomicLong();
    private static final AtomicLong allReturnCount = new AtomicLong();
    private static final AtomicLong purgeCount = new AtomicLong();
    private static final AtomicLong dangerStripCount = new AtomicLong();

    /**
     * 官方/原版/Forge/启动器库白名单（穷举本地 libraries 目录 + JDK 运行时）：
     * JDK 运行时库、MC 本体、Forge/ModLauncher/Mixin/ASM、以及启动器 classpath 上的全部库
     * （joptsimple / night-config / oshi / nashorn / icu4j / lwjgl / joml / fastutil / netty /
     *   guava / log4j / jna / antlr / jline / typetools / maven-artifact / fernflower …）。
     */
    private static final String[] THIRD_PARTY_ALLOW_PREFIXES = {
            "java/", "javax/", "jdk/", "sun/", "com/sun/",
            "net/minecraft/", "net/minecraftforge/", "com/mojang/", "cpw/mods/",
            "org/spongepowered/", "org/objectweb/", "org/lwjgl/", "org/slf4j/",
            "org/apache/", "com/google/", "io/netty/", "it/unimi/",
            "com/llamalad7/", "net/java/dev/jna/", "com/echoxy/",
            // 启动器 classpath 上的库（本地 libraries 穷举）
            "joptsimple/", "org/openjdk/nashorn/", "jdk/nashorn/",
            "org/jetbrains/", "org/intellij/", "com/ibm/icu/", "com/ibm/",
            "org/joml/", "com/electronwill/", "oshi/", "com/github/oshi/",
            "org/antlr/", "org/jline/", "net/jodah/", "org/newsclub/",
            "net/jpountz/", "org/mvel/", "org/checkerframework/", "org/ow2/",
            // 运行时生成类（nashorn 脚本 / 隐藏类 / lambda）
            "jdk/nashorn/internal/", "org/openjdk/nashorn/internal/"
    };

    /** 实体数据契约签名（开发名 + SRG 名，学习自样板 DATA_CONTRACT_SIGS）。 */
    private static final String[] ENTITY_DATA_CONTRACT = {
            "defineSynchedData()V", "m_8097_()V",
            "readAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V", "m_7378_(Lnet/minecraft/nbt/CompoundTag;)V",
            "addAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V", "m_7380_(Lnet/minecraft/nbt/CompoundTag;)V"
    };

    /** 实体可杀性链（学习自样板 KILLABLE_NAMES）：保留原体，防止打不死卡关。 */
    private static final java.util.Set<String> KILLABLE_NAMES = java.util.Set.of(
            "hurt", "actuallyHurt", "die", "kill", "remove", "setRemoved", "discard",
            "setHealth", "getHealth", "heal");

    /** 实体可杀性链（SRG 名，学习自样板 KILLABLE_SRG）。 */
    private static final java.util.Set<String> KILLABLE_SRG = java.util.Set.of(
            "m_6469_", "m_6475_", "m_6667_", "m_6074_", "m_142687_", "m_142467_", "m_146870_",
            "m_21153_", "m_21223_", "m_5634_");

    /**
     * 实体生成 API（方法体<b>直接调用</b>即视为"召唤入口"，三个改写阶段一律保留原体）。
     * 判据是<b>字节码行为</b>（调用了哪个框架方法），与 MOD 名/类名/包名无关——
     * 换任何第三方召唤物都同样生效（铁律⑤：不能针对）。
     */
    private static final java.util.Set<String> ENTITY_SPAWN_NAMES = java.util.Set.of(
            "addFreshEntity", "m_7967_", "m_262496_", "m_20615_");

    /**
     * 物品交互入口（玩家主动使用物品）。召唤类物品的 {@code use} 只调用第三方方法、
     * 体内不含 {@link #ENTITY_SPAWN_NAMES}，必须单独豁免——否则"覆写 → call super"
     * 会把它的召唤体换成父类空实现。同样是框架通用入口名，不点名。
     */
    private static final java.util.Set<String> ITEM_USE_NAMES = java.util.Set.of(
            "use", "useOn", "m_7203_", "m_6222_");

    /** 方法体是否直接生成实体（{@code Level.addFreshEntity} / {@code EntityType.spawn|create}）。 */
    private static boolean containsEntitySpawnCall(final MethodNode m) {
        if (m.instructions == null) {
            return false;
        }
        for (AbstractInsnNode in = m.instructions.getFirst(); in != null; in = in.getNext()) {
            if (in instanceof MethodInsnNode) {
                final MethodInsnNode mi = (MethodInsnNode) in;
                if (mi.owner == null || !ENTITY_SPAWN_NAMES.contains(mi.name)) {
                    continue;
                }
                if (mi.owner.startsWith("net/minecraft/world/level/")
                        || mi.owner.startsWith("net/minecraft/server/level/")
                        || mi.owner.startsWith("net/minecraft/world/entity/")) {
                    return true;
                }
            }
        }
        return false;
    }

    /** 是否物品交互入口（{@code use}/{@code useOn}，含 SRG 名；lambda 不算）。 */
    private static boolean isItemUseEntry(final MethodNode m) {
        return m.name != null && !m.name.startsWith("lambda$") && ITEM_USE_NAMES.contains(m.name);
    }

    /** 纯计算助手放行的 owner 前缀（只做字符串/数字运算，无攻防面）。 */
    private static final String[] PURE_COMPUTE_OWNERS = {
            "java/lang/String", "java/lang/Math", "java/lang/Integer", "java/lang/Long",
            "java/lang/Short", "java/lang/Byte", "java/lang/Character", "java/lang/Boolean",
            "java/lang/StringBuilder", "java/lang/StringBuffer", "java/lang/Object",
            "java/util/Base64", "java/nio/charset/"
    };

    /**
     * 注册框架 owner 前缀（学习自样板 REGISTRY_PREFIXES 完整清单）：命中即视为"注册形态"，
     * 方法体保留——属性注册/物品/方块/创造标签构建/粒子与颜色注册/实体渲染器注册等。
     */
    private static final String[] REGISTRY_PREFIXES = {
            "net/minecraftforge/registries/", "net/minecraftforge/fml/javafmlmod/",
            "net/minecraftforge/eventbus/api/IEventBus", "net/minecraft/core/registries/",
            "net/minecraft/core/Registry", "net/minecraftforge/client/event/EntityRenderersEvent",
            "net/minecraftforge/client/event/RegisterParticleProvidersEvent",
            "net/minecraftforge/client/event/RegisterColorHandlersEvent",
            "net/minecraft/client/renderer/entity/EntityRendererProvider",
            "net/minecraft/client/model/geom/", "net/minecraftforge/event/entity/EntityAttributeCreationEvent",
            "net/minecraftforge/event/entity/SpawnPlacementRegisterEvent",
            "net/minecraft/world/entity/ai/attributes/AttributeSupplier",
            "net/minecraft/world/entity/SpawnPlacements",
            "net/minecraftforge/event/RegisterCommandsEvent",
            "net/minecraft/world/item/CreativeModeTab",
            "net/minecraftforge/event/BuildCreativeModeTabContentsEvent"
    };

    private EchoGuardTransformer() {
    }

    /** 单例（自愈线程重挂用）。 */
    public static EchoGuardTransformer instance() {
        return INSTANCE;
    }

    /** 配置（由 {@code EchoAgent} 在 install 前调用；参数来自系统属性）。 */
    public static void configure(final boolean danger, final boolean shell, final boolean allReturn,
            final boolean clinitCatch, final boolean eventGate, final boolean fieldProtect,
            final boolean mixinStrip, final boolean modelFallback, final boolean isVerbose) {
        dangerEnabled = danger;
        shellEnabled = shell;
        allReturnEnabled = allReturn;
        clinitCatchEnabled = clinitCatch;
        eventGateEnabled = eventGate;
        fieldProtectEnabled = fieldProtect;
        mixinStripEnabled = mixinStrip;
        modelFallbackEnabled = modelFallback;
        verbose = isVerbose;
    }

    /** 从系统属性读 P1 通道开关（install 时一次；purge/剥除类）。 */
    public static void configureSecurity() {
        purgeEnabled = readSystemBool("echoxy.agent.fullpurge", true);
        reflectStripEnabled = readSystemBool("echoxy.agent.reflectstrip", true);
        unsafeStripEnabled = readSystemBool("echoxy.agent.unsafestrip", true);
        threadStripEnabled = readSystemBool("echoxy.agent.threadstrip", true);
        threadCallStripEnabled = readSystemBool("echoxy.agent.threadcallstrip", true);
        bytecodeApiStripEnabled = readSystemBool("echoxy.agent.bytecodeapistrip", true);
        fileIoGuardEnabled = readSystemBool("echoxy.agent.fileioguard", true);
        fmlSinkEnabled = readSystemBool("echoxy.agent.fmlsink", true);
        datapackGuardEnabled = readSystemBool("echoxy.agent.datapackguard", true);
    }

    private static boolean readSystemBool(final String key, final boolean def) {
        try {
            final String v = System.getProperty(key);
            return v == null ? def : Boolean.parseBoolean(v.trim());
        } catch (final Throwable t) {
            return def;
        }
    }

    /** 安装变换器（幂等）。 */
    public static synchronized void install(final Instrumentation inst) {
        if (inst == null) {
            return;
        }
        configureSecurity();
        if (!asmReady()) {
            logInfo("字节码改写不可用（ASM 未随 agent JAR 打包），仅保留断筋机制");
            dangerEnabled = false;
            shellEnabled = false;
            allReturnEnabled = false;
            purgeEnabled = false;
        }
        try {
            inst.addTransformer(INSTANCE, true);
        } catch (final Throwable t) {
            logWarn("addTransformer 失败: " + t);
        }
    }

    /** 当前 ASM 是否可用（agent 类加载器内）。 */
    private static boolean asmReady() {
        try {
            Class.forName("org.objectweb.asm.ClassReader", false,
                    EchoGuardTransformer.class.getClassLoader());
            Class.forName("org.objectweb.asm.tree.ClassNode", false,
                    EchoGuardTransformer.class.getClassLoader());
            return true;
        } catch (final Throwable t) {
            return false;
        }
    }

    // ==================== 变换主流程 ====================

    @Override
    public byte[] transform(final ClassLoader loader, final String className,
            final Class<?> classBeingRedefined, final ProtectionDomain protectionDomain,
            final byte[] classfileBuffer) {
        if (classfileBuffer == null || className == null) {
            return null;
        }
        try {
            // 【服务拦截】ModLauncher 服务漏斗 + IWP 装载点（仅在"底层服务拦截"数字 > 0 时启用）
            if ("cpw/mods/modlauncher/util/ServiceLoaderUtils".equals(className)
                    || "net/minecraftforge/fml/loading/ImmediateWindowHandler".equals(className)) {
                final byte[] svc = interceptServiceRegistration(className, classfileBuffer, loader);
                if (svc != null) {
                    return svc;
                }
            }
            if (isThirdParty(className)) {
                if (!dangerEnabled && !shellEnabled && !allReturnEnabled && !fieldProtectEnabled) {
                    return null;
                }
                return handleThirdParty(className, classfileBuffer, loader);
            }
            if (!clinitCatchEnabled && !eventGateEnabled && !fieldProtectEnabled
                    && !mixinStripEnabled && !modelFallbackEnabled) {
                return null;
            }
            return handleVanillaClass(className, classfileBuffer, loader);
        } catch (final Throwable t) {
            // 变换失败绝不让类加载失败：返回 null = 原样放行
            if (verbose) {
                logWarn("变换失败（原样放行）" + className + ": " + t);
            }
            return null;
        }
    }

    // ==================== 服务拦截（学习自样板 ArtemisGuardTransformer.interceptServiceRegistration） ====================
    /**
     * 在 ModLauncher 的服务漏斗与 IWP 装载点插入 {@link EchoServiceFilter}：
     * <ul>
     *   <li>{@code ServiceLoaderUtils.streamWithErrorHandling}：{@code ServiceLoader.stream()} 之后
     *       紧接 {@code filterProviders(Stream)} ⇒ 第三方提供者在 {@code p.get()}（实例化）之前被丢弃；</li>
     *   <li>{@code ImmediateWindowHandler}：把 {@code ServiceLoader.iterator()} 换成
     *       {@code filterIwp(ServiceLoader)}（接收者留在栈上，栈形状不变）。</li>
     * </ul>
     * <p>只在「底层服务拦截」数字 &gt; 0 时生效；钩子类在该加载器不可见、或方法形状不匹配时
     * 一律返回 null（原样放行，fail-open）。</p>
     */
    private static byte[] interceptServiceRegistration(final String className, final byte[] buf,
            final ClassLoader loader) {
        try {
            if (com.echoxy.boot.EchoConfig.get().getInt("底层服务拦截", 0) <= 0) {
                return null;
            }
            // 钩子类必须在该加载器可见，否则注入会在运行时 NoClassDefFoundError
            try {
                Class.forName("com.echoxy.agent.EchoServiceFilter", false, loader);
            } catch (final Throwable t) {
                return null;
            }
            final boolean isUtils = "cpw/mods/modlauncher/util/ServiceLoaderUtils".equals(className);
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            int touched = 0;
            for (final MethodNode m : cn.methods) {
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                if (isUtils) {
                    if (!"streamWithErrorHandling".equals(m.name)) {
                        continue;
                    }
                    for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                        if (insn instanceof MethodInsnNode) {
                            final MethodInsnNode min = (MethodInsnNode) insn;
                            if ("java/util/ServiceLoader".equals(min.owner) && "stream".equals(min.name)
                                    && "()Ljava/util/stream/Stream;".equals(min.desc)) {
                                m.instructions.insert(min, new MethodInsnNode(Opcodes.INVOKESTATIC,
                                        "com/echoxy/agent/EchoServiceFilter", "filterProviders",
                                        "(Ljava/util/stream/Stream;)Ljava/util/stream/Stream;", false));
                                touched++;
                                break;
                            }
                        }
                    }
                } else {
                    for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                        if (insn instanceof MethodInsnNode) {
                            final MethodInsnNode min = (MethodInsnNode) insn;
                            if ("java/util/ServiceLoader".equals(min.owner) && "iterator".equals(min.name)
                                    && "()Ljava/util/Iterator;".equals(min.desc)) {
                                m.instructions.set(min, new MethodInsnNode(Opcodes.INVOKESTATIC,
                                        "com/echoxy/agent/EchoServiceFilter", "filterIwp",
                                        "(Ljava/util/ServiceLoader;)Ljava/util/Iterator;", false));
                                touched++;
                            }
                        }
                    }
                }
            }
            if (touched == 0) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, 0);   // 栈形状不变 ⇒ 保留原帧
            cn.accept(cw);
            if (verbose) {
                logWarn("服务拦截：已注入实例化前过滤器 " + className + "（" + touched + " 处）");
            }
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;                                    // 任何失败 ⇒ 原样放行
        }
    }
    /** 第三方类处理：软空壳 → 危险调用中和 → 全返回 → 字段保护。 */
    private static byte[] handleThirdParty(final String className, final byte[] buf,
            final ClassLoader loader) {
        byte[] out = buf;
        boolean touched = false;
        if (shellEnabled) {
            final byte[] s = softShell(out, loader);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (dangerEnabled) {
            final byte[] s = stripDangerousCalls(out);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        // 全方法清空式 purge（学习自样板 purgeEnemyMethods；放在全返回之前 —— 样板顺序 purge → blankClass）
        if (purgeEnabled) {
            final byte[] s = purgeEnemyMethods(out, loader);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (allReturnEnabled) {
            final byte[] s = allReturn(out, loader);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        // P1 剥除通道（学习自样板：弹参数+默认值，第三方类专用）
        if (reflectStripEnabled) {
            final byte[] s = stripCalls("反射剥除", out, EchoGuardTransformer::isReflectCall);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (unsafeStripEnabled) {
            final byte[] s = stripCalls("Unsafe剥除", out, EchoGuardTransformer::isUnsafeChannelCall);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (threadStripEnabled) {
            final byte[] s = stripCalls("线程剥除", out, EchoGuardTransformer::isThreadCall);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (threadCallStripEnabled) {
            final byte[] s = stripCalls("线程调度剥除", out, EchoGuardTransformer::isThreadChannelCall);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (bytecodeApiStripEnabled) {
            final byte[] s = stripCalls("字节码API剥除", out,
                    m -> isJavassistMutation(m) || isClassLoaderMutation(m));
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (fileIoGuardEnabled) {
            final byte[] s = stripCalls("文件IO剥除", out, EchoGuardTransformer::isDestructiveFileOp);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (fieldProtectEnabled) {
            final byte[] s = protectFieldWrites(out);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        return touched ? out : null;
    }

    /**
     * 白名单类处理（原版/Forge/库）：不做软空壳，只做"崩溃点拦截 / 闸门"——
     * 模型缺层兜底、事件闸门、第三方 Mixin 处理器抹除、ObjectHolder 容错。
     */
    private static byte[] handleVanillaClass(final String className, final byte[] buf,
            final ClassLoader loader) {
        byte[] out = buf;
        boolean touched = false;
        if (modelFallbackEnabled) {
            if ("net/minecraft/client/model/geom/EntityModelSet".equals(className)) {
                final byte[] s = modelSetFallback(out);
                if (s != null) {
                    out = s;
                    touched = true;
                }
            } else if ("net/minecraft/client/model/geom/ModelPart".equals(className)) {
                final byte[] s = modelPartChildGuard(out);
                if (s != null) {
                    out = s;
                    touched = true;
                }
            }
        }
        if (eventGateEnabled && className.startsWith("net/minecraftforge/eventbus/ASMEventHandler")) {
            final byte[] s = installEventGate(out);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (mixinStripEnabled && isVanillaOrForge(className)
                && (bytesContain(out, "handler$") || bytesContain(out, "mixin$"))) {
            final byte[] s = stripEnemyInjections(className, out, loader);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (className.startsWith("net/minecraftforge/registries/RegistryObject")) {
            final byte[] s = swallowRegistryHolderErrors(className, out, loader);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        if (fmlSinkEnabled) {
            final boolean fmlTarget = "net/minecraftforge/fml/ModContainer".equals(className)
                    || "net/minecraftforge/fml/ModLoader".equals(className)
                    || "net/minecraftforge/fml/javafmlmod/FMLModContainer".equals(className)
                    || "net/minecraftforge/registries/GameData$BlockCallbacks".equals(className);
            if (fmlTarget) {
                final byte[] s = fmlSink(className, out);
                if (s != null) {
                    out = s;
                    touched = true;
                }
            }
        }
        if (datapackGuardEnabled
                && "net/minecraftforge/registries/DataPackRegistryEvent$NewRegistry".equals(className)) {
            final byte[] s = datapackNullKeyGuard(out);
            if (s != null) {
                out = s;
                touched = true;
            }
        }
        return touched ? out : null;
    }

    /**
     * FML 兜底（学习自样板 forgeSink）：给 FML 的 mod 构造 / 事件派发 / 方块烘焙入口包
     * catch(Throwable)——第三方 mod 在这些阶段崩，不再变成 ModLoadingException 把整局拉崩。
     * <b>不注入任何我方类引用</b>（fmlcore/forge 是显式模块，不读我方模块）。
     */
    private static byte[] fmlSink(final String className, final byte[] buf) {
        try {
            final boolean isModCtor = "net/minecraftforge/fml/ModContainer".equals(className);
            final boolean isEventDispatch = "net/minecraftforge/fml/ModLoader".equals(className);
            final boolean isAcceptEvent = "net/minecraftforge/fml/javafmlmod/FMLModContainer".equals(className);
            final boolean isBlockBake = "net/minecraftforge/registries/GameData$BlockCallbacks".equals(className);
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            boolean changed = false;
            for (final MethodNode m : cn.methods) {
                if (m.name == null || m.desc == null || !m.desc.endsWith(")V")) {
                    continue;
                }
                final boolean hit = (isModCtor && m.name.startsWith("lambda$buildTransitionHandler$"))
                        || (isEventDispatch && m.name.startsWith("lambda$postEvent"))
                        || (isAcceptEvent && "acceptEvent".equals(m.name))
                        || (isBlockBake && "onBake".equals(m.name));
                if (!hit) {
                    continue;
                }
                if (wrapVoidWithCatch(m, null, false)) {
                    changed = true;
                }
            }
            if (!changed) {
                return null;
            }
            final ClassWriter cw = newFrameWriter(cr, EchoGuardTransformer.class.getClassLoader());
            cn.accept(cw);
            logVerbose("FML 兜底已注入 " + className);
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /**
     * 数据包空 key 守卫（学习自样板 datapackNullKeyGuard）：{@code dataPackRegistry(ResourceKey, Codec, Codec)}
     * 入口插 {@code if (key == null) return;}——对抗性 mod 静态初始化崩后留下 null 注册表，开世界不再
     * "null key in entry" 崩。判空之外一字不改。
     */
    private static byte[] datapackNullKeyGuard(final byte[] buf) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            boolean changed = false;
            final String targetDesc = "(Lnet/minecraft/resources/ResourceKey;"
                    + "Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/Codec;)V";
            for (final MethodNode m : cn.methods) {
                if (!"dataPackRegistry".equals(m.name) || !targetDesc.equals(m.desc)) {
                    continue;
                }
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                // 幂等：首两条已是我们插的 ALOAD 1; IFNONNULL ⇒ 跳过
                final AbstractInsnNode f0 = m.instructions.getFirst();
                if (f0 instanceof VarInsnNode && f0.getOpcode() == Opcodes.ALOAD
                        && ((VarInsnNode) f0).var == 1) {
                    final AbstractInsnNode f1 = f0.getNext();
                    if (f1 instanceof org.objectweb.asm.tree.JumpInsnNode
                            && f1.getOpcode() == Opcodes.IFNONNULL) {
                        continue;
                    }
                }
                final org.objectweb.asm.tree.LabelNode cont = new org.objectweb.asm.tree.LabelNode();
                final InsnList pre = new InsnList();
                pre.add(new VarInsnNode(Opcodes.ALOAD, 1));
                pre.add(new org.objectweb.asm.tree.JumpInsnNode(Opcodes.IFNONNULL, cont));
                pre.add(new FieldInsnNode(Opcodes.GETSTATIC, "java/lang/System", "out",
                        "Ljava/io/PrintStream;"));
                pre.add(new LdcInsnNode("[Echoes][DATAPACK-SKIP] datapack registryKey==null ⇒ 已跳过注册"));
                pre.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream",
                        "println", "(Ljava/lang/String;)V", false));
                pre.add(new InsnNode(Opcodes.RETURN));
                pre.add(cont);
                m.instructions.insert(pre);
                changed = true;
            }
            if (!changed) {
                return null;
            }
            final ClassWriter cw = newFrameWriter(cr, EchoGuardTransformer.class.getClassLoader());
            cn.accept(cw);
            logInfo("数据包空 key 守卫已注入（DataPackRegistryEvent$NewRegistry）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /** 原版/Forge 类判定（白名单类里的"崩溃点拦截"目标）。 */
    private static boolean isVanillaOrForge(final String internalName) {
        return internalName.startsWith("net/minecraft/") || internalName.startsWith("net/minecraftforge/")
                || internalName.startsWith("com/mojang/") || internalName.startsWith("cpw/mods/");
    }

    /** 方法体是否引用第三方类（学习自样板 methodRefersToEnemy）。 */
    private static boolean methodRefersToEnemy(final MethodNode m) {
        if (m.instructions == null) {
            return false;
        }
        for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            String owner = null;
            if (insn instanceof MethodInsnNode) {
                owner = ((MethodInsnNode) insn).owner;
            } else if (insn instanceof FieldInsnNode) {
                owner = ((FieldInsnNode) insn).owner;
            } else if (insn instanceof TypeInsnNode) {
                owner = ((TypeInsnNode) insn).desc;
            } else if (insn instanceof LdcInsnNode && ((LdcInsnNode) insn).cst instanceof Type) {
                owner = ((Type) ((LdcInsnNode) insn).cst).getInternalName();
            }
            if (owner != null && isThirdParty(owner)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 第三方 Mixin 处理器抹除（学习自样板 stripEnemyInjections）：原版/Forge 类里由第三方 Mixin
     * 生成的 {@code handler$}/{@code mixin$} 方法（方法体引用第三方类）→ 清空。
     * 我方自己的 Mixin 方法引用白名单类 → 不受影响。
     */
    private static byte[] stripEnemyInjections(final String className, final byte[] buf,
            final ClassLoader loader) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            boolean touched = false;
            int cleared = 0;
            for (final MethodNode m : cn.methods) {
                if ((m.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) {
                    continue;
                }
                if (!m.name.startsWith("handler$") && !m.name.startsWith("mixin$")) {
                    continue;
                }
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                if (!methodRefersToEnemy(m)) {
                    continue;
                }
                clearMethod(m);
                cleared++;
                touched = true;
                verboseMethod("抹除Mixin处理器", className, m, "引用第三方");
            }
            if (!touched) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            logVerbose("Mixin 处理器抹除 " + className + "（" + cleared + " 个方法）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /**
     * 事件闸门（学习自样板 installEventGate 的语义：只跳第三方 handler），
     * 但注入体改为 <b>零外部引用的内联字节码</b>。
     *
     * <p><b>为什么必须内联（实战血证）</b>：{@code ASMEventHandler} 属 Forge 的
     * <b>MC-BOOTSTRAP 模块层</b>（bootstraplauncher 装配），它的类加载器既看不到
     * agent JAR（系统类加载器），也看不到游戏层 mod JAR ⇒ 注入任何
     * {@code com/echoxy/agent/*} 调用都会在事件派发时 {@code NoClassDefFoundError}
     * （启动期 RegisterEvent 派发全部报错 → 游戏崩溃）。样板把这些辅助类放在 mod JAR
     * （GAME 层，与 minecraft/第三方同类加载器）里，故只在游戏层目标上引用；对
     * MC-BOOTSTRAP 层目标，唯一安全形态是"注入体自包含"。</p>
     *
     * <p>注入后的入口代码（仅用 {@code ASMEventHandler} 自己的 {@code handler} 字段 + JDK 方法）：</p>
     * <pre>
     *   Object h = this.handler;
     *   if (h == null) { 原体 }                       // 判不出 ⇒ 当第一方（不跳过）
     *   String n = h.getClass().getName();
     *   if (n.startsWith("net.minecraft.") || ...) { 原体 }   // 第一方 handler 照常
     *   else return;                                  // 第三方 handler ⇒ 跳过
     * </pre>
     *
     * <p>判据来源与样板等价：ASMEventHandler 的 {@code handler} 是 LambdaMetafactory
     * 生成的处理器实例，其类名以<b>订阅方法的定义类</b>为前缀（第三方 lambda ⇒ 第三方前缀），
     * 故前缀比对即可区分第一方/第三方，且不依赖任何外部类、反射或类加载器。</p>
     */
    private static byte[] installEventGate(final byte[] buf) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            // handler 字段（owner/desc 取实际类定义，避免跨版本硬编码漂移）
            String fieldDesc = null;
            for (final org.objectweb.asm.tree.FieldNode fd : cn.fields) {
                if ("handler".equals(fd.name) && (fd.access & Opcodes.ACC_STATIC) == 0) {
                    fieldDesc = fd.desc;
                    break;
                }
            }
            if (fieldDesc == null) {
                return null;
            }
            // readable 字段（"ASM: <类> <方法>(<参数类型>)V"）：用于识别"注册/生命周期事件"，缺失则退化为纯前缀判断
            String readableDesc = null;
            for (final org.objectweb.asm.tree.FieldNode fd : cn.fields) {
                if ("readable".equals(fd.name) && (fd.access & Opcodes.ACC_STATIC) == 0) {
                    readableDesc = fd.desc;
                    break;
                }
            }
            boolean injected = false;
            for (final MethodNode m : cn.methods) {
                if (!"invoke".equals(m.name) || m.desc == null) {
                    continue;
                }
                if (!m.desc.startsWith("(Lnet/minecraftforge/eventbus/api/Event;)")) {
                    continue;
                }
                if ((m.access & Opcodes.ACC_STATIC) != 0) {
                    continue; // 入口必须能读到 this.handler
                }
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                if (hasInlineEventGate(m)) {
                    continue; // 幂等：已注入（新版内联 / 旧版 EchoEventGate 调用）
                }
                final org.objectweb.asm.tree.LabelNode keep = new org.objectweb.asm.tree.LabelNode();
                final InsnList pre = new InsnList();
                // ===== ① 注册/生命周期事件的 handler 一律放行 =====
                // 这些事件里的 handler 是**游戏必需的注册动作**（实体属性登记、生成规则、创造标签构建、
                // 数据包注册、mod 生命周期…）。把第三方 handler 一并跳过会出现：
                //   Entity <modid>:<entity> has no attributes ⇒ EntityType.create 构造期 NPE
                //   ⇒ /summon 报"无法召唤实体"（实测日志实证）。
                // 判据用 ASMEventHandler.readable（= "ASM: <类> <方法>(<参数类型>)V" 的参数类型文本），
                // 与事件类名比对待；与 MOD 名无关（铁律⑤）。
                if (readableDesc != null) {
                    final org.objectweb.asm.tree.LabelNode notReg = new org.objectweb.asm.tree.LabelNode();
                    final org.objectweb.asm.tree.LabelNode afterReadable = new org.objectweb.asm.tree.LabelNode();
                    pre.add(new VarInsnNode(Opcodes.ALOAD, 0));
                    pre.add(new FieldInsnNode(Opcodes.GETFIELD, cn.name, "readable", readableDesc));
                    pre.add(new InsnNode(Opcodes.DUP));
                    pre.add(new org.objectweb.asm.tree.JumpInsnNode(Opcodes.IFNULL, afterReadable));
                    for (final String mark : REGISTRATION_EVENT_MARKS) {
                        pre.add(new InsnNode(Opcodes.DUP));            // [r, r]
                        pre.add(new LdcInsnNode(mark));
                        pre.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                                "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z", false));
                        pre.add(new org.objectweb.asm.tree.JumpInsnNode(Opcodes.IFNE, keep)); // [r]
                    }
                    pre.add(new InsnNode(Opcodes.POP));                         // 丢弃 readable
                    pre.add(new org.objectweb.asm.tree.JumpInsnNode(Opcodes.GOTO, notReg));
                    pre.add(afterReadable);
                    pre.add(new InsnNode(Opcodes.POP));                         // readable 为 null：丢弃
                    pre.add(notReg);
                }
                // ===== ② handler 类名前缀判断（第一方照常；第三方 ⇒ 跳过） =====
                pre.add(new VarInsnNode(Opcodes.ALOAD, 0));
                pre.add(new FieldInsnNode(Opcodes.GETFIELD, cn.name, "handler", fieldDesc));
                pre.add(new InsnNode(Opcodes.DUP));
                pre.add(new org.objectweb.asm.tree.JumpInsnNode(Opcodes.IFNULL, keep)); // null ⇒ 不跳过
                pre.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                        "java/lang/Object", "getClass", "()Ljava/lang/Class;", false));
                pre.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                        "java/lang/Class", "getName", "()Ljava/lang/String;", false));
                for (final String prefix : FIRST_PARTY_PREFIXES) {
                    pre.add(new InsnNode(Opcodes.DUP));            // [n, n]
                    pre.add(new LdcInsnNode(prefix));
                    pre.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                            "java/lang/String", "startsWith", "(Ljava/lang/String;)Z", false));
                    pre.add(new org.objectweb.asm.tree.JumpInsnNode(Opcodes.IFNE, keep)); // [n]
                }
                pre.add(new InsnNode(Opcodes.POP));   // 丢弃类名
                pre.add(new InsnNode(Opcodes.RETURN)); // 第三方 handler ⇒ 跳过
                pre.add(keep);
                pre.add(new InsnNode(Opcodes.POP));   // 第一方 ⇒ 丢弃类名，继续原体
                m.instructions.insert(pre);
                injected = true;
            }
            if (!injected) {
                return null;
            }
            final ClassWriter cw = newFrameWriter(cr, EchoGuardTransformer.class.getClassLoader());
            cn.accept(cw);
            logInfo("事件闸门已注入（ASMEventHandler.invoke：第三方 handler 跳过；注入体零外部引用）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /** 事件闸门幂等判定：方法入口是否已是本闸门（内联形态或历史 EchoEventGate 调用形态）。 */
    private static boolean hasInlineEventGate(final MethodNode m) {
        int seen = 0;
        for (AbstractInsnNode in = m.instructions.getFirst(); in != null && seen < 16; in = in.getNext(), seen++) {
            if (in instanceof MethodInsnNode) {
                final MethodInsnNode mi = (MethodInsnNode) in;
                if ("startsWith".equals(mi.name) && "java/lang/String".equals(mi.owner)) {
                    return true;
                }
                if ("shouldSkip".equals(mi.name) && mi.owner != null && mi.owner.contains("EchoEventGate")) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 模型缺层兜底（学习自样板 modelSetFallback）：{@code EntityModelSet.bakeLayer} 缺层抛异常
     * → 包 catch(IllegalArgumentException)，catch 体返回空模型（{@code EchoModelFallback.emptyModelWithParts()}）。
     */
    private static byte[] modelSetFallback(final byte[] buf) {
        return wrapModelMethod(buf, "EchoModelFallback", "bakeLayer", "m_171103_",
                "java/lang/IllegalArgumentException");
    }

    /** 模型部件缺件兜底（学习自样板 modelPartChildGuard）：{@code ModelPart.getChild} 缺件 → 空部件。 */
    private static byte[] modelPartChildGuard(final byte[] buf) {
        return wrapModelMethod(buf, "EchoModelFallback", "getChild", "m_171324_",
                "java/util/NoSuchElementException");
    }

    /** 通用：给指定方法包一层 catch(异常类型) → catch 体返回空模型（模板方法）。 */
    private static byte[] wrapModelMethod(final byte[] buf, final String helperOwner, final String ...names) {
        try {
            final String exceptionType = names[2];
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            boolean changed = false;
            for (final MethodNode m : cn.methods) {
                if (m.name == null || m.desc == null || m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                if (!names[0].equals(m.name) && !names[1].equals(m.name)) {
                    continue;
                }
                if (!m.desc.endsWith("Lnet/minecraft/client/model/geom/ModelPart;")) {
                    continue;
                }
                if (m.tryCatchBlocks == null) {
                    m.tryCatchBlocks = new ArrayList<>();
                }
                boolean already = false;
                for (final org.objectweb.asm.tree.TryCatchBlockNode t : m.tryCatchBlocks) {
                    if (exceptionType.equals(t.type)) {
                        already = true;
                    }
                }
                if (already) {
                    continue;
                }
                final org.objectweb.asm.tree.LabelNode start = new org.objectweb.asm.tree.LabelNode();
                final org.objectweb.asm.tree.LabelNode end = new org.objectweb.asm.tree.LabelNode();
                final org.objectweb.asm.tree.LabelNode handler = new org.objectweb.asm.tree.LabelNode();
                m.instructions.insert(start);
                m.instructions.add(end);
                m.instructions.add(handler);
                m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,
                        "com/echoxy/agent/" + helperOwner, "noteEmpty", "()V", false));
                m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,
                        "com/echoxy/agent/" + helperOwner, "emptyModelWithParts",
                        "()Lnet/minecraft/client/model/geom/ModelPart;", false));
                m.instructions.add(new InsnNode(Opcodes.ARETURN));
                m.tryCatchBlocks.add(new org.objectweb.asm.tree.TryCatchBlockNode(start, end, handler,
                        exceptionType));
                changed = true;
            }
            if (!changed) {
                return null;
            }
            final ClassWriter cw = newFrameWriter(cr, EchoGuardTransformer.class.getClassLoader());
            cn.accept(cw);
            logInfo("模型缺层兜底已注入（" + cn.name + "）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /**
     * ObjectHolder 容错（学习自样板 swallowRegistryHolderErrors）：第三方 registry 缺失时
     * {@code RegistryObject} 的 "Unable to find registry" throw → 改为静默返回。
     */
    private static byte[] swallowRegistryHolderErrors(final String className, final byte[] buf,
            final ClassLoader loader) {
        if (!className.startsWith("net/minecraftforge/registries/RegistryObject")) {
            return null;
        }
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            boolean touched = false;
            for (final MethodNode m : cn.methods) {
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                boolean hasRegistryError = false;
                for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    if (insn instanceof LdcInsnNode) {
                        final Object cst = ((LdcInsnNode) insn).cst;
                        if (cst instanceof String && ((String) cst).contains("Unable to find registry")) {
                            hasRegistryError = true;
                            break;
                        }
                    }
                }
                if (!hasRegistryError) {
                    continue;
                }
                AbstractInsnNode insn = m.instructions.getFirst();
                while (insn != null) {
                    final AbstractInsnNode next = insn.getNext();
                    if (insn.getOpcode() == Opcodes.ATHROW) {
                        m.instructions.insert(insn, defaultReturnInsns(m.desc));
                        m.instructions.remove(insn);
                        touched = true;
                    }
                    insn = next;
                }
            }
            if (!touched) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            logInfo("ObjectHolder 容错已注入（" + className + "）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /**
     * 字段保护（学习自样板 ArtemisFieldProtect）：第三方类对本清单字段的
     * {@code PUTFIELD}/{@code PUTSTATIC} → 剥除（值不落地）。
     */
    private static byte[] protectFieldWrites(final byte[] buf) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            boolean changed = false;
            for (final MethodNode m : cn.methods) {
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                AbstractInsnNode insn = m.instructions.getFirst();
                while (insn != null) {
                    final AbstractInsnNode next = insn.getNext();
                    if (insn instanceof FieldInsnNode) {
                        final FieldInsnNode fin = (FieldInsnNode) insn;
                        if ((fin.getOpcode() == Opcodes.PUTFIELD || fin.getOpcode() == Opcodes.PUTSTATIC)
                                && fin.owner != null && EchoFieldProtect.isProtected(fin.owner, fin.name, fin.desc)) {
                            m.instructions.insertBefore(insn, popForFieldWrite(fin));
                            m.instructions.remove(insn);
                            changed = true;
                            verboseMethod("字段保护剥除", cn.name, m, fin.owner + "." + fin.name);
                        }
                    }
                    insn = next;
                }
            }
            if (!changed) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            logInfo("字段保护已生效（" + cn.name + "）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /** 剥除字段写入时的栈平衡（PUTFIELD: [obj, value] → 弹 value 再弹 obj；PUTSTATIC: 只弹 value）。 */
    private static InsnList popForFieldWrite(final FieldInsnNode fin) {
        final InsnList il = new InsnList();
        final boolean wide = "J".equals(fin.desc) || "D".equals(fin.desc);
        il.add(new InsnNode(wide ? Opcodes.POP2 : Opcodes.POP));
        if (fin.getOpcode() == Opcodes.PUTFIELD) {
            il.add(new InsnNode(Opcodes.POP));
        }
        return il;
    }

    // ==================== 全方法清空式 purge（学习自样板 purgeEnemyMethods / purgeEntityBehavior） ====================

    /**
     * 全方法清空式 purge：第三方类里 void / 基本类型返回的方法体清空（对象/数组返回保留，
     * 序列化/注册/数据契约/可杀性链保留）——与软空壳叠加，进一步确保行为失效。
     */
    private static byte[] purgeEnemyMethods(final byte[] buf, final ClassLoader loader) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            if (cn.name == null || cn.name.contains("/__")) {
                return null;
            }
            final boolean entity = isEntityClass(cn);
            boolean touched = false;
            int cleared = 0;
            for (final MethodNode m : cn.methods) {
                if (m.name == null || m.desc == null) {
                    continue;
                }
                if (m.name.equals("<init>") || m.name.equals("<clinit>")) {
                    continue;
                }
                if ((m.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) {
                    continue;
                }
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                if (isAlreadyCleared(m)) {
                    continue; // 幂等：软空壳已清空
                }
                // 实体数据契约 → call super（父类构造期/存档期虚调用安全）
                if (isEntityDataContract(cn.superName, m.name, m.desc)) {
                    if (canSuperEntityDataContract(cn.superName)) {
                        replaceBody(m, superCallInsns(new SuperOwner(cn.superName, false), m, cn.version));
                        touched = true;
                    }
                    continue;
                }
                if (isDataSerializationMethod(m) || isRegistrationMethod(m)) {
                    continue; // 序列化/注册保留
                }
                if (containsEntitySpawnCall(m) || isItemUseEntry(m)) {
                    continue; // 召唤入口保留（清空全开也要能召唤实体）
                }
                if (entity && (KILLABLE_NAMES.contains(m.name) || KILLABLE_SRG.contains(m.name))) {
                    continue; // 可杀性链保留
                }
                final Type ret = Type.getReturnType(m.desc);
                if (ret.getSort() == Type.OBJECT || ret.getSort() == Type.ARRAY) {
                    continue; // 对象/数组返回保留（不崩铁律）
                }
                replaceBody(m, defaultReturnInsns(m.desc));
                touched = true;
                cleared++;
                verboseMethod("全清空", cn.name, m, "purge");
            }
            if (!touched) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            final long n = purgeCount.incrementAndGet();
            if (verbose) {
                logVerbose("全清空 " + cn.name + "（清空 " + cleared + " 个方法，累计类=" + n + "）");
            } else if (n == 1) {
                logInfo("全清空首次生效（后续命中只计数）");
            }
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /** 方法是否已被清空（首条真实指令即 return 族）——purge 幂等判据。 */
    private static boolean isAlreadyCleared(final MethodNode m) {
        try {
            for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                if (insn.getOpcode() < 0) {
                    continue; // 跳过标签/帧/行号
                }
                final int op = insn.getOpcode();
                return op == Opcodes.RETURN || op == Opcodes.IRETURN || op == Opcodes.LRETURN
                        || op == Opcodes.FRETURN || op == Opcodes.DRETURN || op == Opcodes.ARETURN;
            }
        } catch (final Throwable ignored) {
            // ignore
        }
        return false;
    }

    // ==================== P1 剥除：反射 / Unsafe / 线程 / 字节码 API / 文件 IO ====================

    /** 中和一次方法调用：弹参数 + 弹接收者 + 压默认返回值（学习自样板 neutralizeCall）。 */
    private static InsnList neutralizeCall(final MethodInsnNode min) {
        final InsnList out = new InsnList();
        final Type[] args = Type.getArgumentTypes(min.desc);
        for (int i = args.length - 1; i >= 0; i--) {
            out.add(new InsnNode(args[i].getSize() == 2 ? Opcodes.POP2 : Opcodes.POP));
        }
        if (min.getOpcode() != Opcodes.INVOKESTATIC) {
            out.add(new InsnNode(Opcodes.POP)); // 接收者
        }
        switch (Type.getReturnType(min.desc).getSort()) {
            case Type.BOOLEAN:
            case Type.BYTE:
            case Type.CHAR:
            case Type.SHORT:
            case Type.INT:
                out.add(new InsnNode(Opcodes.ICONST_0));
                break;
            case Type.LONG:
                out.add(new InsnNode(Opcodes.LCONST_0));
                break;
            case Type.FLOAT:
                out.add(new InsnNode(Opcodes.FCONST_0));
                break;
            case Type.DOUBLE:
                out.add(new InsnNode(Opcodes.DCONST_0));
                break;
            case Type.OBJECT:
            case Type.ARRAY:
                out.add(new InsnNode(Opcodes.ACONST_NULL));
                break;
            default:
                break;
        }
        return out;
    }

    /** 反射调用判定（学习自样板 isReflectCall）。 */
    private static boolean isReflectCall(final MethodInsnNode min) {
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null) {
            return false;
        }
        if (o.startsWith("sun/misc/Unsafe") || o.equals("jdk/internal/misc/Unsafe")) {
            return true;
        }
        if (o.equals("java/lang/Class")) {
            return n.equals("getDeclaredField") || n.equals("getField") || n.equals("getDeclaredMethod")
                    || n.equals("getMethod") || n.equals("getDeclaredConstructor") || n.equals("getConstructor")
                    || n.equals("forName") || n.equals("getDeclaredFields") || n.equals("getDeclaredMethods")
                    || n.equals("getDeclaredConstructors");
        }
        if (o.equals("java/lang/reflect/Field") || o.equals("java/lang/reflect/Method")
                || o.equals("java/lang/reflect/Constructor") || o.equals("java/lang/reflect/Array")) {
            return true;
        }
        if (o.equals("java/lang/invoke/MethodHandles") || o.startsWith("java/lang/invoke/MethodHandles$")) {
            return true;
        }
        if (o.equals("java/lang/invoke/MethodHandle") || o.startsWith("java/lang/invoke/MethodHandle")) {
            return true;
        }
        if (o.equals("java/lang/ClassLoader")) {
            return n.startsWith("defineClass");
        }
        return o.equals("sun/reflect/ReflectionFactory") || o.equals("jdk/internal/reflect/ReflectionFactory");
    }

    /** Unsafe/VarHandle/特权块/defineClass 调用判定（学习自样板 isUnsafeChannelCall）。 */
    private static boolean isUnsafeChannelCall(final MethodInsnNode min) {
        if (isReflectCall(min)) {
            return true;
        }
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null) {
            return false;
        }
        if (o.equals("java/lang/invoke/VarHandle") || o.startsWith("java/lang/invoke/VarHandle$")) {
            return true;
        }
        if (o.equals("java/lang/invoke/MethodHandles$Lookup")) {
            return n.startsWith("find") || n.equals("defineClass") || n.equals("defineHiddenClass")
                    || n.equals("accessClass") || n.equals("unreflect") || n.equals("revealDirect");
        }
        if (o.equals("java/security/AccessController") && n.equals("doPrivileged")) {
            return true;
        }
        return o.equals("java/lang/ClassLoader") && n.startsWith("defineClass");
    }

    /** 线程创建/调度判定（学习自样板 isThreadCall）。 */
    private static boolean isThreadCall(final MethodInsnNode min) {
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null) {
            return false;
        }
        if (o.equals("java/lang/Thread")) {
            return n.equals("start") || n.equals("stop") || n.equals("suspend") || n.equals("resume")
                    || n.equals("interrupt") || n.equals("setDaemon") || n.equals("join") || n.equals("destroy")
                    || n.equals("startVirtualThread") || n.equals("ofVirtual") || n.equals("ofPlatform")
                    || n.equals("setContextClassLoader")
                    || n.equals("setUncaughtExceptionHandler") || n.equals("setDefaultUncaughtExceptionHandler");
        }
        if (o.equals("java/util/concurrent/Executors")) {
            return n.equals("newSingleThreadExecutor") || n.equals("newFixedThreadPool")
                    || n.equals("newCachedThreadPool") || n.equals("newScheduledThreadPool")
                    || n.equals("newSingleThreadScheduledExecutor") || n.equals("newVirtualThreadPerTaskExecutor")
                    || n.equals("newThreadPerTaskExecutor") || n.equals("callable") || n.equals("privilegedThreadFactory");
        }
        if (o.equals("java/util/concurrent/ForkJoinPool")) {
            return n.equals("commonPool");
        }
        if (o.equals("java/util/Timer")) {
            return n.equals("schedule") || n.equals("scheduleAtFixedRate");
        }
        if (o.equals("java/lang/Runtime")) {
            return n.equals("exec") || n.equals("addShutdownHook") || n.equals("removeShutdownHook");
        }
        return o.equals("java/lang/ProcessBuilder") && n.equals("start");
    }

    /** 线程调度/进程/关机钩子判定（学习自样板 isThreadChannelCall）。 */
    private static boolean isThreadChannelCall(final MethodInsnNode min) {
        if (isThreadCall(min)) {
            return true;
        }
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null) {
            return false;
        }
        if (o.equals("java/util/concurrent/ForkJoinPool")) {
            return n.equals("execute") || n.equals("submit") || n.equals("invoke");
        }
        if (o.equals("java/util/concurrent/ExecutorService") || o.equals("java/util/concurrent/Executor")) {
            return n.equals("submit") || n.equals("execute") || n.equals("invokeAll") || n.equals("invokeAny");
        }
        if (o.equals("java/util/concurrent/ScheduledExecutorService")) {
            return n.startsWith("schedule");
        }
        if (o.equals("java/util/concurrent/CompletableFuture")) {
            return n.endsWith("Async");
        }
        if (o.equals("java/lang/Thread")) {
            return n.equals("setUncaughtExceptionHandler") || n.equals("setDefaultUncaughtExceptionHandler")
                    || n.equals("setContextClassLoader") || n.equals("startVirtualThread");
        }
        if (o.equals("java/lang/ThreadGroup")) {
            return n.equals("uncaughtException");
        }
        if (o.equals("java/lang/Runtime")) {
            return n.equals("halt");
        }
        if (o.equals("java/lang/Process")) {
            return n.equals("destroy");
        }
        return o.equals("java/lang/ProcessHandle") && (n.equals("destroy") || n.equals("destroyForcibly"));
    }

    /** Javassist 结构变异判定（学习自样板 isJavassistMutation）。 */
    private static boolean isJavassistMutation(final MethodInsnNode min) {
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null || !o.startsWith("javassist/")) {
            return false;
        }
        if (n.equals("setBody") || n.equals("insertBefore") || n.equals("insertAfter")
                || n.equals("insertAt") || n.equals("addLocalVariable") || n.equals("addCatch")
                || n.equals("addParameter") || n.equals("setModifiers") || n.equals("setGenericSignature")) {
            return true;
        }
        if (n.equals("removeMethod") || n.equals("removeField") || n.equals("detach")
                || n.equals("defrost") || n.equals("freeze") || n.equals("prune") || n.equals("stopPruning")
                || n.equals("setName") || n.equals("setSuperclass") || n.equals("setInterfaces")
                || n.equals("setModifiers")) {
            return true;
        }
        return n.equals("appendClassPath") || n.equals("insertClassPath") || n.equals("removeClassPath")
                || n.equals("clearImportedPackages") || n.equals("childFirst") || n.equals("makePackage");
    }

    /** ClassLoader/安全管理器 设置类判定（学习自样板 isClassLoaderMutation）。 */
    private static boolean isClassLoaderMutation(final MethodInsnNode min) {
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null) {
            return false;
        }
        if (o.equals("java/lang/System")) {
            return n.equals("setSecurityManager") || n.equals("setSecurityManager0");
        }
        return o.equals("java/lang/ClassLoader")
                && (n.equals("setDefaultAssertionStatus") || n.equals("setPackageAssertionStatus")
                || n.equals("setClassAssertionStatus") || n.equals("clearAssertionStatus"));
    }

    /** 破坏性文件操作判定（学习自样板 isDestructiveFileOp）。 */
    private static boolean isDestructiveFileOp(final MethodInsnNode min) {
        final String o = min.owner;
        final String n = min.name;
        if (o == null || n == null) {
            return false;
        }
        if (o.equals("java/nio/file/Files")) {
            return n.equals("delete") || n.equals("deleteIfExists");
        }
        if (o.equals("java/io/File")) {
            return n.equals("deleteOnExit") || n.equals("delete") || n.equals("mkdir") || n.equals("mkdirs")
                    || n.equals("createNewFile") || n.equals("renameTo") || n.equals("setWritable")
                    || n.equals("setReadable") || n.equals("setExecutable") || n.equals("setReadOnly")
                    || n.equals("setLastModified");
        }
        if (o.equals("java/nio/channels/FileChannel")) {
            return n.equals("write") || n.equals("force");
        }
        if (o.equals("java/io/RandomAccessFile")) {
            return n.equals("write") || n.equals("setLength");
        }
        return (o.equals("java/io/FileOutputStream") || o.equals("java/io/FileWriter")) && n.equals("write");
    }

    /** 通用剥除：对第三方类的方法体调用点按判定剥除（学习自样板"弹参数+默认值"模板）。 */
    private static byte[] stripCalls(final String bufLabel, final byte[] buf, final java.util.function.Predicate<MethodInsnNode> p) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            int removed = 0;
            for (final MethodNode m : cn.methods) {
                if (m.instructions == null || m.instructions.size() == 0) {
                    continue;
                }
                AbstractInsnNode insn = m.instructions.getFirst();
                while (insn != null) {
                    final AbstractInsnNode next = insn.getNext();
                    if (insn instanceof MethodInsnNode) {
                        final MethodInsnNode min = (MethodInsnNode) insn;
                        if (p.test(min)) {
                            m.instructions.insertBefore(insn, neutralizeCall(min));
                            m.instructions.remove(insn);
                            removed++;
                        }
                    }
                    insn = next;
                }
            }
            if (removed == 0) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            logVerbose(bufLabel + " " + cn.name + "（剥除 " + removed + " 处调用）");
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    // ==================== 第三方类判定（穷举官方 jar 白名单） ====================

    /**
     * 第三方类判定（学习自样板："官方/原版/Forge 的 jar 穷举白名单"）。
     *
     * <p>判定顺序：</p>
     * <ol>
     *   <li>类名前缀白名单（JDK/MC/Forge/ModLauncher/Mixin/ASM 等）→ 放行（快速路径）；</li>
     *   <li>扫描启动 classpath + module path 里**全部官方 jar**，建立官方类集合；命中 → 放行
     *       （libraries 里的所有库：joptsimple/night-config/oshi/guava/netty/log4j/lwjgl/… 全部穷举，
     *       绝不误伤）；</li>
     *   <li>其余 = 来自 mods 目录的第三方 mod 类（或动态生成、不在官方集合里的类）→ 处理。</li>
     * </ol>
     *
     * <p>为什么必须穷举：早期版本只按前缀白名单，把 BOOT 层启动库（joptsimple）误判为第三方
     * 并掏空，导致启动即 NPE（2026-11-08 08:58 实测）。</p>
     */
    private static boolean isThirdParty(final String internalName) {
        for (final String p : THIRD_PARTY_ALLOW_PREFIXES) {
            if (internalName.startsWith(p)) {
                return false; // 快速路径：JDK/MC/Forge/已知库/我方
            }
        }
        ensureOfficialMap();
        if (OFFICIAL.contains(internalName)) {
            return false; // 官方/原版/Forge/libraries 类（穷举白名单）
        }
        return true; // 其余：第三方 mod / 动态类
    }

    // ==================== 官方类集合（穷举启动 classpath + module path 里全部 jar） ====================

    /** 官方类内部名集合（懒加载一次；来自启动 classpath + module path 的全部 jar）。 */
    private static final Set<String> OFFICIAL = ConcurrentHashMap.newKeySet();
    private static volatile boolean officialMapBuilt;

    /**
     * 扫描启动 classpath（{@code java.class.path}）与 module path（{@code jdk.module.path}）
     * 里的全部 jar，把所有类名收进 {@link #OFFICIAL}。
     *
     * <p>这是"白名单穷举官方/原版/Forge 的 jar"：libraries 目录里的每一个依赖（joptsimple、
     * night-config、oshi、guava、netty、log4j、lwjgl、joml、fastutil、asm、mixin、modlauncher、
     * eventbus、forgespi、…）与 MC 本体 jar 都在这两条路径里 ⇒ 一次扫描全部纳入白名单。</p>
     *
     * <p>第三方 mod 的 jar 不在 classpath/module path（由 ModLauncher 从 mods 目录装入）
     * ⇒ 它们的类自然不在集合里 ⇒ 判定为第三方。扫描失败（任何异常）⇒ 集合为空 ⇒
     * 全部放行（fail-open，绝不把启动库误伤）。</p>
     */
    private static synchronized void ensureOfficialMap() {
        if (officialMapBuilt) {
            return;
        }
        officialMapBuilt = true;
        try {
            final List<java.io.File> jars = new ArrayList<>();
            collectJars(System.getProperty("java.class.path", ""), jars);
            collectJars(System.getProperty("jdk.module.path", ""), jars);
            for (final java.io.File jar : jars) {
                try (java.util.jar.JarFile jf = new java.util.jar.JarFile(jar)) {
                    final java.util.Enumeration<java.util.jar.JarEntry> en = jf.entries();
                    while (en.hasMoreElements()) {
                        final String n = en.nextElement().getName();
                        if (n.endsWith(".class") && !n.startsWith("META-INF/")) {
                            OFFICIAL.add(n.substring(0, n.length() - 6));
                        }
                    }
                } catch (final Throwable ignored) {
                    // 单个 jar 读取失败跳过（不影响其它 jar）
                }
            }
        } catch (final Throwable ignored) {
            // 扫描失败 ⇒ OFFICIAL 为空 ⇒ 全部放行（fail-open）
        }
    }

    /** 收集路径串（分号/冒号分隔）里的 jar 文件。 */
    private static void collectJars(final String paths, final List<java.io.File> out) {
        if (paths == null || paths.isEmpty()) {
            return;
        }
        for (final String s : paths.split(java.util.regex.Pattern.quote(java.io.File.pathSeparator))) {
            final String t = s.trim();
            if (t.toLowerCase().endsWith(".jar")) {
                out.add(new java.io.File(t));
            }
        }
    }

    // ==================== 软空壳（soft shell） ====================

    /**
     * 软空壳：类级处理（学习自样板 ShellLoadGate.softBlank 与 purgeEnemyMethods 的最终形态）。
     *
     * <p>规则（按样板战场教训逐条落实）：</p>
     * <ol>
     *   <li>{@code <init>}：绝对保留、绝不包 catch（JVMS：覆盖 uninitializedThis 的异常处理器验证必败）；</li>
     *   <li>{@code <clinit>}：保留原体（注册与字段初始化都在这里）；"武装类"才连它一起掏空；</li>
     *   <li>abstract：跳过；native：去 ACC_NATIVE + 默认返回（永不 UnsatisfiedLinkError）；</li>
     *   <li>实体数据契约：转发 super（父类构造期/存档期虚调用安全，否则实体召唤即崩）；</li>
     *   <li>实例方法：<b>void / 基本类型返回 → 默认返回；对象 / 数组返回 → 保留原体</b>
     *       —— 样板铁律：对象返回值清成 null 会流进原版契约（实测 ItemStack.getTooltipLines
     *       对 getAttributeModifiers() 直接 .isEmpty() ⇒ NPE 崩溃）；</li>
     *   <li>静态方法：引用注册框架的类保留（注册保护）、纯计算助手保留、元素类的原版/Forge
     *       契约方法保留；"武装类"一并掏空；其余掏空；</li>
     *   <li>类名含 {@code /__}：事件总线生成的类，整体豁免（注册方法必须能被调用）。</li>
     * </ol>
     *
     * <p>任何异常返回 null = 原样放行（fail-open，绝不把非法字节交给 JVM）。</p>
     */
    private static byte[] softShell(final byte[] buf, final ClassLoader loader) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            if (cn.name == null || cn.name.contains("/__")) {
                return null;
            }
            // 类是否引用注册框架（静态方法因此保留，防注册向注册表流入 null）
            final boolean refsRegistration = refsRegistration(buf);
            // "武装类"：装载原生库 / 取 Instrumentation / 接触 JVMTI / 声明 native / 自爆原语
            final boolean arming = looksLikeArmingClass(cn);
            // 元素类（物品/方块/实体/创造标签的第三方子类）：其静态契约方法保留
            final boolean element = isElementClass(cn, loader);
            // 实体类（可杀性链保留）与渲染类（清空易致客户端并发修改崩溃 → 豁免）
            final boolean entity = isEntityClass(cn);
            final boolean render = isRenderClass(cn);
            boolean changed = false;
            boolean needFrames = false;
            int blanked = 0;
            for (final MethodNode m : cn.methods) {
                if (m.name == null || m.desc == null) {
                    continue;
                }
                if (m.name.equals("<init>")) {
                    continue; // 绝对保留
                }
                if ((m.access & Opcodes.ACC_ABSTRACT) != 0) {
                    continue;
                }
                if (m.name.equals("<clinit>")) {
                    if (arming) {
                        clearMethod(m);
                        changed = true;
                        verboseMethod("软空壳掏空", cn.name, m, "武装类静态初始化");
                    } else if (clinitCatchEnabled) {
                        // 学习自样板 wrapVoidWithCatch：给第三方 <clinit> 包 catch(Throwable)
                        // —— 静态初始化崩被吞掉 ⇒ 类照常完成初始化 ⇒ FML 不判 ERROR。
                        if (wrapVoidWithCatch(m, cn.name, true)) {
                            needFrames = true;
                            changed = true;
                            verboseMethod("软空壳包catch", cn.name, m, "<clinit>兜底");
                        }
                    }
                    continue; // 非武装类：保留静态初始化（注册/字段）
                }
                if ((m.access & Opcodes.ACC_NATIVE) != 0) {
                    m.access &= ~Opcodes.ACC_NATIVE;
                    replaceBody(m, defaultReturnInsns(m.desc));
                    changed = true;
                    blanked++;
                    verboseMethod("软空壳掏空", cn.name, m, "native→空实现");
                    continue;
                }
                // 实体数据契约（学习自样板 keepDataContractMethod 两态）：
                // 可 call super → 转发父类；父类恰为 Entity（abstract 无实现）→ 保留原体
                if (isEntityDataContract(cn.superName, m.name, m.desc)) {
                    if (canSuperEntityDataContract(cn.superName)) {
                        replaceBody(m, superCallInsns(new SuperOwner(cn.superName, false), m, cn.version));
                        changed = true;
                        verboseMethod("软空壳call-super", cn.name, m, "实体数据契约");
                    } else {
                        verboseMethod("软空壳保留", cn.name, m, "实体数据契约(无super可调)");
                    }
                    continue;
                }
                // ===== 样板 softBlank 的保护链（静态/实例方法共用，按序判定） =====
                if (arming) {
                    // 武装类整类惰性化，但"召唤入口"仍放行：只认字节码行为（见 ENTITY_SPAWN_NAMES），
                    // 否则第三方武装类里的召唤实现会被一并掏空 ⇒ 召唤物永远出不来（用户实测需求）。
                    if (containsEntitySpawnCall(m)) {
                        verboseMethod("软空壳保留", cn.name, m, "武装类召唤入口");
                    } else {
                        clearMethod(m);
                        changed = true;
                        blanked++;
                        verboseMethod("软空壳掏空", cn.name, m, "武装类");
                    }
                    continue;
                }
                // 对齐样板 softBlank 的静态方法判据（不是"静态全保留"）：
                // ① 注册供应商工厂（返回 Supplier 的 static 方法）→ 保留原体（否则元素对象造不出来）；
                // ② 元素类/注册类的 static 方法，返回原版/Forge 类型 → 保留原体
                //    （典型 = createAttributes() 返回 AttributeSupplier$Builder：清空成 null ⇒
                //      属性从未登记 ⇒ /summon 报"无法召唤实体"；样板现场实证）。
                if ((m.access & Opcodes.ACC_STATIC) != 0) {
                    if (refsRegistration
                            && "(Ljava/lang/Class;)Ljava/util/function/Supplier;".equals(m.desc)) {
                        verboseMethod("软空壳保留", cn.name, m, "注册供应商工厂");
                        continue;
                    }
                    if ((element || refsRegistration) && returnsVanillaOrForgeType(m)) {
                        verboseMethod("软空壳保留", cn.name, m, "元素类静态契约");
                        continue;
                    }
                }
                // 召唤入口（方法体直接生成实体 / 物品 use）：保留原体，否则召唤物出不来。
                if (containsEntitySpawnCall(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "实体生成入口");
                    continue;
                }
                if (isItemUseEntry(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "物品交互入口");
                    continue;
                }
                if (refsRegistration && m.name.startsWith("lambda$")) {
                    verboseMethod("软空壳保留", cn.name, m, "注册lambda");
                    continue; // 注册供应商 lambda：保留原体（否则注册值变 null → 崩）
                }
                if (referencesRegistryFramework(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "引用注册框架");
                    continue; // 方法体碰注册框架（属性/物品/方块/TAB 构建）：保留原体
                }
                if (isStringNoArgPublic(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "name()-类");
                    continue; // 服务 name() 等：必须非 null
                }
                if (returnsCollectionLike(m.desc)) {
                    if (element) {
                        // 元素类集合族返回 → 空集合（契约安全；敌方属性加成被拦）
                        replaceBody(m, defaultReturnInsns(m.desc));
                        changed = true;
                        blanked++;
                        verboseMethod("软空壳空集合", cn.name, m, "元素类集合族");
                    } else {
                        verboseMethod("软空壳保留", cn.name, m, "集合族返回");
                    }
                    continue;
                }
                if (returnsVanillaOrForgeType(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "原版/Forge返回");
                    continue; // 返回原版/Forge 类型：原版契约假定非 null → 保留原体
                }
                if (isDataSerializationMethod(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "序列化");
                    continue; // 序列化契约：保留原体
                }
                if (isPureComputeHelper(m)) {
                    verboseMethod("软空壳保留", cn.name, m, "纯计算助手");
                    continue; // 纯计算助手：保留原体（名字/字符串生成器）
                }
                if (render) {
                    verboseMethod("软空壳保留", cn.name, m, "渲染类");
                    continue; // 渲染类豁免（样板 purge 教训：清空渲染方法易致并发修改崩溃）
                }
                if (entity && (KILLABLE_NAMES.contains(m.name) || KILLABLE_SRG.contains(m.name))) {
                    verboseMethod("软空壳保留", cn.name, m, "可杀性链");
                    continue; // 实体可杀性链保留（防止打不死卡关）
                }
                // 其余：方法体 → 安全默认返回（void / 基本类型 / 第三方自有对象）
                // getter 形态（get*/is* 无参、返回第三方对象类型）→ 返回"哑实例"而不是 null
                // （学习自样板 ArtemisDummy：避免第三方自己的 getConfig().xxx 直接 NPE）
                if (isGetterLike(m.name) && "()".equals(m.desc.substring(0, 2))) {
                    final Type ret = Type.getReturnType(m.desc);
                    if (ret.getSort() == Type.OBJECT && isThirdParty(ret.getInternalName())) {
                        final InsnList il = new InsnList();
                        il.add(new LdcInsnNode(ret));
                        il.add(new MethodInsnNode(Opcodes.INVOKESTATIC,
                                "com/echoxy/agent/EchoDummy", "dummyFor",
                                "(Ljava/lang/Class;)Ljava/lang/Object;", false));
                        il.add(new TypeInsnNode(Opcodes.CHECKCAST, ret.getInternalName()));
                        il.add(new InsnNode(Opcodes.ARETURN));
                        replaceBody(m, il);
                        changed = true;
                        blanked++;
                        verboseMethod("软空壳哑实例", cn.name, m, "getter 返回第三方对象");
                        continue;
                    }
                }
                replaceBody(m, defaultReturnInsns(m.desc));
                changed = true;
                blanked++;
                verboseMethod("软空壳掏空", cn.name, m, "默认");
            }
            if (!changed) {
                return null;
            }
            final ClassWriter cw = needFrames ? newFrameWriter(cr, loader) : new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            final long n = shellCount.incrementAndGet();
            if (verbose) {
                logVerbose("软空壳 " + cn.name + "（掏空 " + blanked + " 个方法，武装类=" + arming
                        + "，注册类=" + refsRegistration + "，元素类=" + element
                        + "，实体类=" + entity + "，渲染类=" + render
                        + "，重算帧=" + needFrames + "，累计类=" + n + "）");
            } else if (n == 1) {
                logInfo("软空壳首次生效（后续命中只计数）");
            }
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /** 类是否引用注册框架（学习自样板 REGISTRY_OWNERS + refsRegistration 判定）。 */
    private static boolean refsRegistration(final byte[] buf) {
        return bytesContain(buf, "net/minecraftforge/registries/DeferredRegister")
                || bytesContain(buf, "net/minecraftforge/registries/RegisterEvent")
                || bytesContain(buf, "net/minecraftforge/registries/GameData")
                || bytesContain(buf, "net/minecraftforge/registries/ForgeRegistries")
                || bytesContain(buf, "net/minecraft/core/Registry")
                || bytesContain(buf, "net/minecraftforge/event/EntityAttributeCreationEvent")
                || bytesContain(buf, "net/minecraft/world/item/CreativeModeTab")
                || bytesContain(buf, "net/minecraftforge/event/BuildCreativeModeTabContentsEvent");
    }

    /** 方法是否引用注册框架（学习自样板 referencesRegistryFramework；软空壳静态方法豁免）。 */
    private static boolean referencesRegistryFramework(final MethodNode m) {
        if (m.desc != null) {
            for (final String p : REGISTRY_PREFIXES) {
                if (m.desc.contains(p)) {
                    return true;
                }
            }
        }
        if (m.instructions == null) {
            return false;
        }
        for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            final String owner = instructionOwner(insn);
            if (owner != null && isRegRef(owner)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 是否"注册形态方法"（学习自样板 isRegistrationMethod）：签名/方法体引用注册框架 ⇒
     * 全返回时不清空（属性注册、物品/方块注册、创造标签构建必须存活）。
     * {@code RegistryObject} 是运行时访问器，不算注册动作。
     */
    private static boolean isRegistrationMethod(final MethodNode m) {
        if (m.desc != null) {
            for (final String p : REGISTRY_PREFIXES) {
                if (m.desc.contains(p)) {
                    return true;
                }
            }
        }
        if (m.instructions == null) {
            return false;
        }
        for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            final String owner = instructionOwner(insn);
            if (owner == null || "net/minecraftforge/registries/RegistryObject".equals(owner)) {
                continue;
            }
            if (isRegRef(owner)) {
                return true;
            }
        }
        return false;
    }

    /** 指令引用的 owner（方法/字段/类型/常量类型），无则 null。 */
    private static String instructionOwner(final AbstractInsnNode insn) {
        if (insn instanceof MethodInsnNode) {
            return ((MethodInsnNode) insn).owner;
        }
        if (insn instanceof FieldInsnNode) {
            return ((FieldInsnNode) insn).owner;
        }
        if (insn instanceof TypeInsnNode) {
            return ((TypeInsnNode) insn).desc;
        }
        if (insn instanceof LdcInsnNode && ((LdcInsnNode) insn).cst instanceof Type) {
            return ((Type) ((LdcInsnNode) insn).cst).getInternalName();
        }
        return null;
    }

    /** owner 是否命中注册框架前缀。 */
    private static boolean isRegRef(final String internalName) {
        for (final String p : REGISTRY_PREFIXES) {
            if (internalName.startsWith(p)) {
                return true;
            }
        }
        return false;
    }

    /** 序列化契约方法（NBT / 同步数据 / 网络包读写）——清空会让实体存档/召唤崩溃。 */
    private static boolean isDataSerializationMethod(final MethodNode m) {
        if (m.desc == null) {
            return false;
        }
        return m.desc.contains("net/minecraft/network/syncher/")
                || m.desc.contains("net/minecraft/nbt/")
                || m.desc.contains("FriendlyByteBuf");
    }

    /** 无参返回 String 的 public 方法（服务 name() 等）——清空会致框架 NPE。 */
    private static boolean isStringNoArgPublic(final MethodNode m) {
        return "()Ljava/lang/String;".equals(m.desc) && (m.access & Opcodes.ACC_PUBLIC) != 0;
    }

    /** getter 形态（get* / is* 无参）：哑实例兜底的目标（学习自样板 isGetterLike）。 */
    private static boolean isGetterLike(final String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }
        return (name.startsWith("get") && name.length() > 3)
                || (name.startsWith("is") && name.length() > 2);
    }

    /** 返回集合族（List/Set/Map/Collection/Iterable/Guava Multimap 等）——原版契约假定非 null。 */
    private static boolean returnsCollectionLike(final String desc) {
        final Type ret = Type.getReturnType(desc);
        if (ret.getSort() != Type.OBJECT) {
            return false;
        }
        final String internal = ret.getInternalName();
        switch (internal) {
            case "java/util/List":
            case "java/util/Collection":
            case "java/util/Set":
            case "java/util/Map":
            case "java/util/Iterable":
            case "java/util/Iterator":
            case "com/google/common/collect/Multimap":
            case "com/google/common/collect/ImmutableMultimap":
            case "com/google/common/collect/ListMultimap":
            case "com/google/common/collect/SetMultimap":
            case "com/google/common/collect/ImmutableList":
            case "com/google/common/collect/ImmutableSet":
            case "com/google/common/collect/ImmutableMap":
                return true;
            default:
                return false;
        }
    }

    /** 元素类判定（物品/方块/实体/创造标签的第三方子类）：沿父类链**读字节**（不触发类加载）。 */
    private static boolean isElementClass(final ClassNode cn, final ClassLoader loader) {
        final String[] bases = {
                "net/minecraft/world/item/Item", "net/minecraft/world/level/block/Block",
                "net/minecraft/world/entity/Entity", "net/minecraft/world/entity/LivingEntity",
                "net/minecraft/world/entity/Mob", "net/minecraft/world/entity/Monster",
                "net/minecraft/world/item/CreativeModeTab"
        };
        ClassNode node = cn;
        int depth = 0;
        while (node != null && depth++ < 12) {
            final String sup = node.superName;
            if (sup == null) {
                return false;
            }
            for (final String b : bases) {
                if (b.equals(sup)) {
                    return true;
                }
            }
            node = readClassNode(sup, loader);
        }
        return false;
    }

    /** 返回类型是否为原版/Forge 类型（元素类静态契约保留判定；void/基本类型不算契约）。 */
    private static boolean returnsVanillaOrForgeType(final MethodNode m) {
        final Type ret = Type.getReturnType(m.desc);
        if (ret.getSort() != Type.OBJECT && ret.getSort() != Type.ARRAY) {
            return true;
        }
        final String internal = ret.getSort() == Type.ARRAY
                ? ret.getElementType().getInternalName() : ret.getInternalName();
        return internal.startsWith("net/minecraft/") || internal.startsWith("net/minecraftforge/");
    }

    /** 方法体整体替换为指定指令（清空异常表/局部变量表；无跳转 ⇒ COMPUTE_MAXS 足够）。 */
    private static void replaceBody(final MethodNode m, final InsnList body) {
        m.instructions = body;
        m.tryCatchBlocks = null;
        m.localVariables = null;
        m.maxStack = 0;
        m.maxLocals = 0;
    }

    // ==================== 栈帧重算（字节级求公共父类，零类加载） ====================

    /** COMPUTE_FRAMES 写入器（供需要插入跳转/异常处理器的变换使用）。 */
    private static ClassWriter newFrameWriter(final ClassReader cr, final ClassLoader loader) {
        return new EchoFrameWriter(cr, loader);
    }

    /** 命名静态内部类（不用匿名类：agent JAR 清单必须能显式包含内部类，匿名类会漏）。 */
    private static final class EchoFrameWriter extends ClassWriter {
        private final ClassLoader loader;

        private EchoFrameWriter(final ClassReader cr, final ClassLoader loader) {
            super(cr, ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
            this.loader = loader;
        }

        @Override
        protected String getCommonSuperClass(final String type1, final String type2) {
            try {
                return resolveCommonSuper(loader, type1, type2);
            } catch (final Throwable t) {
                return "java/lang/Object";
            }
        }
    }

    private static String resolveCommonSuper(final ClassLoader loader, final String type1,
            final String type2) {
        if (type1.equals(type2)) {
            return type1;
        }
        try {
            return resolveCommonSuperBytecode(loader, type1, type2);
        } catch (final Throwable t) {
            return "java/lang/Object";
        }
    }

    /** 字节码级公共父类解析（ASM getCommonSuperClass 同款语义，全程 readClassNode 不触发类加载）。 */
    private static String resolveCommonSuperBytecode(final ClassLoader loader, final String type1,
            final String type2) {
        if (type1.startsWith("[") || type2.startsWith("[")) {
            if (type1.equals(type2)) {
                return type1;
            }
            if (type1.startsWith("[") && type2.startsWith("[")) {
                final String e1 = type1.substring(1);
                final String e2 = type2.substring(1);
                if (isPrimitiveDesc(e1) || isPrimitiveDesc(e2)) {
                    return "java/lang/Object";
                }
                final String n1 = stripClassDesc(e1);
                final String n2 = stripClassDesc(e2);
                final String ce = resolveCommonSuperBytecode(loader, n1, n2);
                if (ce == null) {
                    return "java/lang/Object";
                }
                if (ce.equals(n1)) {
                    return type1;
                }
                if (ce.equals(n2)) {
                    return type2;
                }
                if (ce.equals("java/lang/Object")) {
                    return "[java/lang/Object";
                }
                return "[" + ce;
            }
            return "java/lang/Object";
        }
        if (type1.equals("java/lang/Object") || type2.equals("java/lang/Object")) {
            return "java/lang/Object";
        }
        if (isAssignableFrom(loader, type1, type2)) {
            return type1;
        }
        if (isAssignableFrom(loader, type2, type1)) {
            return type2;
        }
        if (isInterfaceNode(loader, type1) || isInterfaceNode(loader, type2)) {
            return "java/lang/Object";
        }
        String cur = type1;
        while (true) {
            final ClassNode n = readClassNode(cur, loader);
            if (n == null || n.superName == null) {
                return "java/lang/Object";
            }
            cur = n.superName;
            if (isAssignableFrom(loader, cur, type2)) {
                return cur;
            }
        }
    }

    private static boolean isPrimitiveDesc(final String s) {
        return s.length() == 1 && "BCDFIJSZV".indexOf(s.charAt(0)) >= 0;
    }

    private static String stripClassDesc(final String s) {
        if (s.length() >= 2 && s.charAt(0) == 'L' && s.endsWith(";")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    /** 字节码级赋值判定（superType 是否 superType ⟸ subType）。 */
    private static boolean isAssignableFrom(final ClassLoader loader, final String superType,
            final String subType) {
        if (superType.equals(subType) || superType.equals("java/lang/Object")) {
            return true;
        }
        final boolean sa = superType.startsWith("[");
        final boolean sb = subType.startsWith("[");
        if (sa || sb) {
            if (!sa || !sb) {
                return false;
            }
            final String se = stripClassDesc(superType.substring(1));
            final String su = stripClassDesc(subType.substring(1));
            if (isPrimitiveDesc(se) || isPrimitiveDesc(su)) {
                return se.equals(su);
            }
            return isAssignableFrom(loader, se, su);
        }
        String cur = subType;
        while (cur != null) {
            if (cur.equals(superType)) {
                return true;
            }
            final ClassNode n = readClassNode(cur, loader);
            if (n == null) {
                return false;
            }
            if (n.interfaces != null) {
                for (final String itf : n.interfaces) {
                    if (isAssignableFrom(loader, superType, itf)) {
                        return true;
                    }
                }
            }
            cur = n.superName;
        }
        return false;
    }

    private static boolean isInterfaceNode(final ClassLoader loader, final String type) {
        final ClassNode n = readClassNode(type, loader);
        return n != null && (n.access & Opcodes.ACC_INTERFACE) != 0;
    }

    /**
     * 给 void 方法包一层 {@code try { 原体 } catch (Throwable t) { [note;] return; }}（学习自样板 wrapVoidWithCatch）。
     *
     * <p>铁律：{@code <init>} 永不参与（覆盖 super() 的处理器验证必败）；
     * 只处理 void 方法；幂等（首指令起已被我方 Throwable 处理器覆盖 ⇒ 跳过）。</p>
     *
     * @param withDiag 是否注入诊断调用（{@code EchoClinitDiag}）——fmlcore 等显式模块不读我方模块，
     *                 对其注入我方类引用会 IllegalAccessError ⇒ 传 false 只包 catch
     * @return true = 已插入 try-catch（调用方须改用会重算帧的写入器）
     */
    private static boolean wrapVoidWithCatch(final MethodNode mn, final String className, final boolean withDiag) {
        try {
            if (mn == null || mn.instructions == null || mn.instructions.size() == 0) {
                return false;
            }
            int real = 0;
            for (AbstractInsnNode in = mn.instructions.getFirst(); in != null; in = in.getNext()) {
                if (in.getOpcode() >= 0 && ++real > 1) {
                    break;
                }
            }
            if (real <= 1) {
                return false; // 空方法/已掏空：包 catch 无意义
            }
            if ("<init>".equals(mn.name)) {
                return false; // 构造器永不参与
            }
            if (Type.getReturnType(mn.desc).getSort() != Type.VOID) {
                return false;
            }
            if (mn.tryCatchBlocks == null) {
                mn.tryCatchBlocks = new ArrayList<>();
            }
            final AbstractInsnNode firstInsn = mn.instructions.getFirst();
            for (final org.objectweb.asm.tree.TryCatchBlockNode t : mn.tryCatchBlocks) {
                if ("java/lang/Throwable".equals(t.type) && t.start == firstInsn) {
                    return false; // 幂等：这一层就是我们自己包的
                }
            }
            final org.objectweb.asm.tree.LabelNode start = new org.objectweb.asm.tree.LabelNode();
            final org.objectweb.asm.tree.LabelNode end = new org.objectweb.asm.tree.LabelNode();
            final org.objectweb.asm.tree.LabelNode handler = new org.objectweb.asm.tree.LabelNode();
            mn.instructions.insert(start);
            mn.instructions.add(end);
            mn.instructions.add(handler);
            if (withDiag && className != null && !className.isEmpty()) {
                // 诊断：把被吞异常捞出来（栈顶正好是 Throwable ⇒ LDC+SWAP = (String, Throwable) 顺序）
                mn.instructions.add(new LdcInsnNode(className));
                mn.instructions.add(new InsnNode(Opcodes.SWAP));
                mn.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,
                        "com/echoxy/agent/EchoClinitDiag", "noteClinitThrowable",
                        "(Ljava/lang/String;Ljava/lang/Throwable;)V", false));
            }
            mn.instructions.add(new InsnNode(Opcodes.RETURN));
            mn.tryCatchBlocks.add(new org.objectweb.asm.tree.TryCatchBlockNode(start, end, handler,
                    "java/lang/Throwable"));
            return true;
        } catch (final Throwable t) {
            return false; // fail-safe：包不上就保持历史行为
        }
    }


    /** 方法体清空为默认返回。 */
    private static void clearMethod(final MethodNode m) {
        replaceBody(m, defaultReturnInsns(m.desc));
    }

    /** 默认返回指令（安全默认值，学习自样板教训表：String→空串、集合→空集合、数组→零长）。 */
    static InsnList defaultReturnInsns(final String desc) {
        final InsnList il = new InsnList();
        final Type ret = Type.getReturnType(desc);
        switch (ret.getSort()) {
            case Type.VOID:
                il.add(new InsnNode(Opcodes.RETURN));
                break;
            case Type.BOOLEAN:
            case Type.BYTE:
            case Type.CHAR:
            case Type.SHORT:
            case Type.INT:
                il.add(new InsnNode(Opcodes.ICONST_0));
                il.add(new InsnNode(Opcodes.IRETURN));
                break;
            case Type.LONG:
                il.add(new InsnNode(Opcodes.LCONST_0));
                il.add(new InsnNode(Opcodes.LRETURN));
                break;
            case Type.FLOAT:
                il.add(new InsnNode(Opcodes.FCONST_0));
                il.add(new InsnNode(Opcodes.FRETURN));
                break;
            case Type.DOUBLE:
                il.add(new InsnNode(Opcodes.DCONST_0));
                il.add(new InsnNode(Opcodes.DRETURN));
                break;
            case Type.ARRAY: {
                // 一维基本类型数组 → 零长数组（枚举 values()→null 会让 for-each NPE）；其余 → null
                final Type elem = ret.getElementType();
                if (ret.getDimensions() == 1 && elem.getSort() >= Type.BOOLEAN && elem.getSort() <= Type.DOUBLE) {
                    il.add(new InsnNode(Opcodes.ICONST_0));
                    il.add(new IntInsnNode(Opcodes.NEWARRAY, primitiveArrayCode(elem.getSort())));
                } else {
                    il.add(new InsnNode(Opcodes.ACONST_NULL));
                }
                il.add(new InsnNode(Opcodes.ARETURN));
                break;
            }
            case Type.OBJECT: {
                final String internal = ret.getInternalName();
                if ("java/lang/String".equals(internal)) {
                    // String 契约几乎不允许 null（且方法体清空后不再抛异常）→ 返回空串
                    il.add(new LdcInsnNode(""));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("java/util/List".equals(internal) || "java/util/Collection".equals(internal)
                        || "java/lang/Iterable".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/util/Collections",
                            "emptyList", "()Ljava/util/List;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("java/util/Set".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/util/Collections",
                            "emptySet", "()Ljava/util/Set;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("java/util/Map".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/util/Collections",
                            "emptyMap", "()Ljava/util/Map;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("com/google/common/collect/Multimap".equals(internal)
                        || "com/google/common/collect/ImmutableMultimap".equals(internal)) {
                    // 样板教训：Multimap 返回 null 会让原版 ItemStack.getTooltipLines 直接 NPE
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/google/common/collect/ImmutableMultimap",
                            "of", "()Lcom/google/common/collect/ImmutableMultimap;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("com/google/common/collect/ListMultimap".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/google/common/collect/ImmutableListMultimap",
                            "of", "()Lcom/google/common/collect/ImmutableListMultimap;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("com/google/common/collect/SetMultimap".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/google/common/collect/ImmutableSetMultimap",
                            "of", "()Lcom/google/common/collect/ImmutableSetMultimap;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("com/google/common/collect/ImmutableList".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/google/common/collect/ImmutableList",
                            "of", "()Lcom/google/common/collect/ImmutableList;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("com/google/common/collect/ImmutableSet".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/google/common/collect/ImmutableSet",
                            "of", "()Lcom/google/common/collect/ImmutableSet;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else if ("com/google/common/collect/ImmutableMap".equals(internal)) {
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/google/common/collect/ImmutableMap",
                            "of", "()Lcom/google/common/collect/ImmutableMap;", false));
                    il.add(new InsnNode(Opcodes.ARETURN));
                } else {
                    il.add(new InsnNode(Opcodes.ACONST_NULL));
                    il.add(new InsnNode(Opcodes.ARETURN));
                }
                break;
            }
            default:
                il.add(new InsnNode(Opcodes.ACONST_NULL));
                il.add(new InsnNode(Opcodes.ARETURN));
                break;
        }
        return il;
    }

    /** NEWARRAY 的数组类型码。 */
    private static int primitiveArrayCode(final int sort) {
        switch (sort) {
            case Type.BOOLEAN:
                return Opcodes.T_BOOLEAN;
            case Type.CHAR:
                return Opcodes.T_CHAR;
            case Type.FLOAT:
                return Opcodes.T_FLOAT;
            case Type.DOUBLE:
                return Opcodes.T_DOUBLE;
            case Type.BYTE:
                return Opcodes.T_BYTE;
            case Type.SHORT:
                return Opcodes.T_SHORT;
            default:
                return Opcodes.T_INT;
        }
    }

    /**
     * 实体数据契约判定（学习自样板 DATA_CONTRACT_SIGS + canSuper）：
     * 父类在 {@code net/minecraft/world/entity/} 之下且签名命中 ⇒ 契约方法。
     * 处理分两态：{@link #canSuperEntityDataContract} 为真 → call super；否则 → 保留原体。
     */
    private static boolean isEntityDataContract(final String superName, final String name, final String desc) {
        if (superName == null || !superName.startsWith("net/minecraft/world/entity/")) {
            return false;
        }
        final String sig = name + desc;
        for (final String s : ENTITY_DATA_CONTRACT) {
            if (s.equals(sig)) {
                return true;
            }
        }
        return false;
    }

    /** 是否可 call super（父类恰为 Entity 时那三条是 abstract，改写会 AbstractMethodError）。 */
    private static boolean canSuperEntityDataContract(final String superName) {
        return superName != null && superName.startsWith("net/minecraft/world/entity/")
                && !"net/minecraft/world/entity/Entity".equals(superName);
    }

    /** 实体类判定（学习自样板 isEntityClass）：父类在 world/entity 下，或包路径含 entity/entities 且非渲染类。 */
    private static boolean isEntityClass(final ClassNode cn) {
        if (cn.superName != null && cn.superName.startsWith("net/minecraft/world/entity/")) {
            return true;
        }
        final String n = cn.name.toLowerCase(java.util.Locale.ROOT);
        return (n.contains("/entity/") || n.contains("/entities/")) && !isRenderClass(cn);
    }

    /** 渲染类判定（学习自样板 isRenderClass）：渲染器/模型/GUI 子类——清空其方法易致客户端并发修改崩溃。 */
    private static boolean isRenderClass(final ClassNode cn) {
        return cn.superName != null
                && (cn.superName.startsWith("net/minecraft/client/renderer/")
                || cn.superName.startsWith("net/minecraft/client/model/")
                || cn.superName.startsWith("net/minecraft/client/gui/"));
    }

    /**
     * "武装类"判定（学习自样板 looksLikeArmingClass）：声明 native / 装载原生库 / 取 Instrumentation /
     * 接触 JVMTI / 自爆原语 / 相关字符串常量。
     */
    private static boolean looksLikeArmingClass(final ClassNode cn) {
        if (cn.methods == null) {
            return false;
        }
        for (final MethodNode m : cn.methods) {
            if ((m.access & Opcodes.ACC_NATIVE) != 0) {
                return true;
            }
            if (m.instructions == null) {
                continue;
            }
            for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                if (insn instanceof MethodInsnNode) {
                    final MethodInsnNode mi = (MethodInsnNode) insn;
                    if (mi.owner == null || mi.name == null) {
                        continue;
                    }
                    if (("java/lang/System".equals(mi.owner) || "java/lang/Runtime".equals(mi.owner)
                            || "java/lang/ClassLoader".equals(mi.owner))
                            && ("load".equals(mi.name) || "loadLibrary".equals(mi.name)
                            || "load0".equals(mi.name))) {
                        return true;
                    }
                    if ("java/lang/System".equals(mi.owner) && "exit".equals(mi.name)) {
                        return true;
                    }
                    if ("java/lang/Runtime".equals(mi.owner)
                            && ("halt".equals(mi.name) || "exit".equals(mi.name))) {
                        return true;
                    }
                    if ("sun/misc/Unsafe".equals(mi.owner) || "jdk/internal/misc/Unsafe".equals(mi.owner)) {
                        return true;
                    }
                    if (mi.owner.startsWith("java/lang/instrument/")
                            || mi.owner.startsWith("com/sun/tools/attach/")
                            || mi.owner.startsWith("sun/tools/attach/")
                            || mi.owner.toLowerCase().contains("jvmti")) {
                        return true;
                    }
                } else if (insn instanceof LdcInsnNode) {
                    final Object cst = ((LdcInsnNode) insn).cst;
                    if (cst instanceof String) {
                        final String t = ((String) cst).toLowerCase();
                        if (t.contains("java.lang.instrument") || t.contains("java/lang/instrument")
                                || t.contains("instrumentationimpl") || t.contains("transformermanager")
                                || t.contains("tools.attach") || t.contains("tools/attach")
                                || t.contains("jvmti") || t.contains("retransformclasses")
                                || t.contains("redefineclasses")) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * 纯计算助手判定（简化版）：static + 返回 String/基本类型 + 参数只有 String/基本类型 +
     * 方法体只碰纯计算 owner —— 这类方法只做字符串/数字运算，放行以保住"名字生成器"。
     */
    private static boolean isPureComputeHelper(final MethodNode m) {
        if ((m.access & Opcodes.ACC_STATIC) == 0) {
            return false;
        }
        if (m.instructions == null || m.instructions.size() == 0) {
            return false;
        }
        final Type ret = Type.getReturnType(m.desc);
        if (!isPureComputeType(ret, true)) {
            return false;
        }
        for (final Type arg : Type.getArgumentTypes(m.desc)) {
            if (!isPureComputeType(arg, false)) {
                return false;
            }
        }
        for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            String owner = null;
            if (insn instanceof MethodInsnNode) {
                owner = ((MethodInsnNode) insn).owner;
            } else if (insn instanceof FieldInsnNode) {
                owner = ((FieldInsnNode) insn).owner;
            } else if (insn instanceof TypeInsnNode) {
                owner = ((TypeInsnNode) insn).desc;
            }
            if (owner != null && !isPureComputeOwner(owner)) {
                return false;
            }
        }
        return true;
    }

    /** 纯计算类型判定：String / 基本类型（返回允许 void）。 */
    private static boolean isPureComputeType(final Type t, final boolean allowVoid) {
        if (t.getSort() == Type.VOID) {
            return allowVoid;
        }
        if (t.getSort() >= Type.BOOLEAN && t.getSort() <= Type.DOUBLE) {
            return true;
        }
        return t.getSort() == Type.OBJECT && "java/lang/String".equals(t.getInternalName());
    }

    private static boolean isPureComputeOwner(final String owner) {
        for (final String p : PURE_COMPUTE_OWNERS) {
            if (owner.startsWith(p)) {
                return true;
            }
        }
        return false;
    }

    /** 字节里是否含某 ASCII 串（常量池扫描，不需要解析）。 */
    private static boolean bytesContain(final byte[] data, final String ascii) {
        if (data == null || ascii == null || ascii.isEmpty()) {
            return false;
        }
        final byte[] needle = ascii.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1);
        outer:
        for (int i = 0; i <= data.length - needle.length; i++) {
            for (int j = 0; j < needle.length; j++) {
                if (data[i + j] != needle[j]) {
                    continue outer;
                }
            }
            return true;
        }
        return false;
    }

    /** 方法级详细日志（仅详细模式；记录每个方法的处置，便于与样板逐条核对）。 */
    private static void verboseMethod(final String action, final String className, final MethodNode m,
            final String reason) {
        if (verbose) {
            logVerbose(action + " " + className + "." + m.name + m.desc + "（" + reason + "）");
        }
    }

    // ==================== 全返回（ALLRETURN，报告式） ====================

    /**
     * 全返回：在软空壳结果上叠加（学习自样板 blankClass aggressive 模式）。
     *
     * <p>对每个非构造/非抽象/非 native 方法：</p>
     * <ol>
     *   <li>实体数据契约 → {@code super.方法(args)}（与软空壳一致）；</li>
     *   <li>覆写父类具体方法（可见、非抽象）或实现接口 default 方法 → {@code invokespecial super.方法(args)}；</li>
     *   <li>独立 void 方法 → 直接 return；</li>
     *   <li>独立非 void 方法 → 不动（注册供应商/序列化契约，不向注册表流入 null）；</li>
     *   <li>事件总线生成类（含 {@code /__}）→ 整体豁免。</li>
     * </ol>
     * <p>父类/接口的方法是否存在通过**读字节码**判定（不触发类加载，避免转换期死锁）。</p>
     */
    private static byte[] allReturn(final byte[] buf, final ClassLoader loader) {
        try {
            final ClassReader cr = new ClassReader(buf);
            final ClassNode cn = new ClassNode();
            cr.accept(cn, 0);
            if (cn.name == null || cn.name.contains("/__")) {
                return null;
            }
            boolean changed = false;
            int wrapped = 0;
            for (final MethodNode m : cn.methods) {
                if (m.name == null || m.desc == null) {
                    continue;
                }
                if (m.name.equals("<init>") || m.name.equals("<clinit>")) {
                    continue;
                }
                if ((m.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) {
                    continue;
                }
                if (m.instructions == null) {
                    continue;
                }
                // 召唤入口（方法体直接生成实体 / 物品 use）：保留原体 —— 全返回开启时
                // 也不能把"召唤"改成 call super（否则任何第三方召唤物都出不来）。
                if (containsEntitySpawnCall(m) || isItemUseEntry(m)) {
                    verboseMethod("全返回保留", cn.name, m, "召唤入口");
                    continue;
                }
                // 实体数据契约：转发父类
                if (isEntityDataContract(cn.superName, m.name, m.desc)) {
                    replaceBody(m, superCallInsns(new SuperOwner(cn.superName, false), m, cn.version));
                    changed = true;
                    verboseMethod("全返回call-super", cn.name, m, "实体数据契约");
                    continue;
                }
                final boolean isStatic = (m.access & Opcodes.ACC_STATIC) != 0;
                SuperOwner owner = null;
                if (!isStatic) {
                    owner = findSuperOwner(cn, m, loader);
                    // JVMS：接口 default 方法调用必须是当前类的直接父接口；间接父接口 → 非法（VerifyError）
                    if (owner != null && owner.isInterface()
                            && (cn.interfaces == null || !cn.interfaces.contains(owner.owner()))) {
                        owner = null;
                    }
                }
                if (owner != null) {
                    replaceBody(m, superCallInsns(owner, m, cn.version));
                    changed = true;
                    wrapped++;
                    verboseMethod("全返回call-super", cn.name, m, "覆写→" + owner.owner());
                    continue;
                }
                final Type ret = Type.getReturnType(m.desc);
                if (ret.getSort() != Type.VOID) {
                    verboseMethod("全返回保留", cn.name, m, "独立非void");
                    continue; // 独立非 void：不动（注册供应商不受影响，无 null 流入注册表）
                }
                if (isRegistrationMethod(m)) {
                    verboseMethod("全返回保留", cn.name, m, "注册方法");
                    continue; // 注册形态方法豁免（属性/物品/方块/创造标签注册不被拦截）
                }
                replaceBody(m, defaultReturnInsns(m.desc));
                changed = true;
                wrapped++;
                verboseMethod("全返回掏空", cn.name, m, "独立void");
            }
            if (!changed) {
                return null;
            }
            final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            final long n = allReturnCount.incrementAndGet();
            if (verbose) {
                logVerbose("全返回 " + cn.name + "（处理 " + wrapped + " 个方法，累计类=" + n + "）");
            } else if (n == 1) {
                logInfo("全返回首次生效（后续命中只计数）");
            }
            return cw.toByteArray();
        } catch (final Throwable t) {
            return null;
        }
    }

    /** 父实现记录（类或接口 default）。 */
    private static final class SuperOwner {
        private final String owner;
        private final boolean isInterface;

        private SuperOwner(final String owner, final boolean isInterface) {
            this.owner = owner;
            this.isInterface = isInterface;
        }

        private String owner() {
            return owner;
        }

        private boolean isInterface() {
            return isInterface;
        }
    }

    /**
     * 找"可委托的父实现"：沿父类链读字节找同名同描述符方法（具体且可见 → 父类；
     * 抽象/不可见 → null）；链上找不到时查接口 default 方法。
     */
    private static SuperOwner findSuperOwner(final ClassNode cn, final MethodNode mn, final ClassLoader loader) {
        ClassNode node = cn;
        while (true) {
            final String sup = node.superName;
            if (sup == null) {
                return null; // 到 Object
            }
            final ClassNode parent = readClassNode(sup, loader);
            if (parent == null) {
                return null;
            }
            final MethodNode pm = findMethod(parent, mn.name, mn.desc);
            if (pm != null) {
                if ((pm.access & Opcodes.ACC_ABSTRACT) != 0) {
                    return null; // 抽象 → 无具体实现可委托
                }
                if (isVisibleOverride(pm.access, parent.name, node.name)) {
                    return new SuperOwner(sup, false);
                }
                return null; // 不可见 → 非覆写
            }
            final String itf = findInterfaceDefault(node, mn, loader);
            if (itf != null) {
                return new SuperOwner(itf, true);
            }
            node = parent;
        }
    }

    /** 接口 default 方法查找（递归；跳过 abstract/static/private 接口方法）。 */
    private static String findInterfaceDefault(final ClassNode node, final MethodNode mn, final ClassLoader loader) {
        if (node.interfaces == null) {
            return null;
        }
        for (final String itf : node.interfaces) {
            final ClassNode in = readClassNode(itf, loader);
            if (in == null) {
                continue;
            }
            final MethodNode im = findMethod(in, mn.name, mn.desc);
            if (im != null) {
                if ((im.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_STATIC | Opcodes.ACC_PRIVATE)) == 0) {
                    return itf;
                }
                continue;
            }
            final String deep = findInterfaceDefault(in, mn, loader);
            if (deep != null) {
                return deep;
            }
        }
        return null;
    }

    private static MethodNode findMethod(final ClassNode node, final String name, final String desc) {
        if (node.methods == null) {
            return null;
        }
        for (final MethodNode m : node.methods) {
            if (m.name.equals(name) && m.desc.equals(desc)) {
                return m;
            }
        }
        return null;
    }

    /** 覆写可见性：public/protected 恒可见；包私有需同包；private 不可见。 */
    private static boolean isVisibleOverride(final int access, final String parentName, final String childName) {
        if ((access & (Opcodes.ACC_PUBLIC | Opcodes.ACC_PROTECTED)) != 0) {
            return true;
        }
        if ((access & Opcodes.ACC_PRIVATE) != 0) {
            return false;
        }
        final int p = parentName.lastIndexOf('/');
        final int c = childName.lastIndexOf('/');
        return p == c && (p < 0 || parentName.regionMatches(0, childName, 0, p));
    }

    /** 生成 {@code super.方法(args)} 指令（含返回；接口 default 用 itf=true）。 */
    private static InsnList superCallInsns(final SuperOwner owner, final MethodNode m, final int classVersion) {
        final InsnList il = new InsnList();
        int slot = 0;
        if ((m.access & Opcodes.ACC_STATIC) == 0) {
            il.add(new VarInsnNode(Opcodes.ALOAD, 0));
            slot = 1;
        }
        for (final Type arg : Type.getArgumentTypes(m.desc)) {
            il.add(new VarInsnNode(arg.getOpcode(Opcodes.ILOAD), slot));
            slot += arg.getSize();
        }
        final boolean isItf = owner.isInterface() && classVersion >= Opcodes.V1_8;
        il.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, owner.owner(), m.name, m.desc, isItf));
        il.add(new InsnNode(Type.getReturnType(m.desc).getOpcode(Opcodes.IRETURN)));
        return il;
    }

    // ==================== 类层级读取（不触发类加载） ====================

    private static final Map<String, ClassNode> HIERARCHY_CACHE = new ConcurrentHashMap<>();
    private static final int HIERARCHY_CACHE_MAX = 1000;
    /** 读取失败的哨兵（避免反复读不存在的类）。 */
    private static final ClassNode MISSING = new ClassNode();

    private static ClassNode readClassNode(final String internalName, final ClassLoader loader) {
        final ClassNode cached = HIERARCHY_CACHE.get(internalName);
        if (cached != null) {
            return cached == MISSING ? null : cached;
        }
        ClassNode node = null;
        try {
            byte[] bytes = null;
            if (loader != null) {
                try (java.io.InputStream in = loader.getResourceAsStream(internalName + ".class")) {
                    if (in != null) {
                        bytes = in.readAllBytes();
                    }
                }
            }
            if (bytes == null) {
                try (java.io.InputStream in = ClassLoader.getSystemResourceAsStream(internalName + ".class")) {
                    if (in != null) {
                        bytes = in.readAllBytes();
                    }
                }
            }
            if (bytes != null) {
                final ClassReader r = new ClassReader(bytes);
                node = new ClassNode();
                r.accept(node, ClassReader.SKIP_CODE);
            }
        } catch (final Throwable ignored) {
            node = null;
        }
        if (HIERARCHY_CACHE.size() > HIERARCHY_CACHE_MAX) {
            HIERARCHY_CACHE.clear();
        }
        HIERARCHY_CACHE.put(internalName, node == null ? MISSING : node);
        return node;
    }

    // ==================== 危险调用中和 ====================

    /** 中和危险调用（返回 null = 未改动）。 */
    private static byte[] stripDangerousCalls(final byte[] buf) {
        final ClassReader cr = new ClassReader(buf);
        final ClassNode cn = new ClassNode();
        cr.accept(cn, 0);
        boolean changed = false;
        for (final MethodNode method : cn.methods) {
            if (method.instructions == null || method.instructions.size() == 0) {
                continue;
            }
            AbstractInsnNode insn = method.instructions.getFirst();
            while (insn != null) {
                final AbstractInsnNode next = insn.getNext();
                if (insn instanceof MethodInsnNode) {
                    final MethodInsnNode min = (MethodInsnNode) insn;
                    if (isDangerousCall(min)) {
                        method.instructions.insertBefore(insn, popForCall(min));
                        method.instructions.remove(insn);
                        changed = true;
                        if (verbose) {
                            logVerbose("危险调用中和：" + cn.name + "." + method.name
                                    + " 调用=" + min.owner + "." + min.name);
                        }
                    }
                }
                insn = next;
            }
        }
        if (!changed) {
            return null;
        }
        final ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        final long n = dangerStripCount.incrementAndGet();
        if (n == 1) {
            logInfo("危险调用中和首次生效（后续命中只计数）");
        }
        return cw.toByteArray();
    }

    /** 危险调用判定（通用形态，不点名任何 mod）。 */
    private static boolean isDangerousCall(final MethodInsnNode min) {
        final String owner = min.owner;
        final String name = min.name;
        if ("java/lang/System".equals(owner) && "exit".equals(name)) {
            return true;
        }
        if ("java/lang/Runtime".equals(owner) && "halt".equals(name)) {
            return true;
        }
        return "java/lang/Thread".equals(owner) && "stop".equals(name);
    }

    /** 为被中和的调用生成"弹掉参数"的指令序列（保持栈平衡）。 */
    private static InsnList popForCall(final MethodInsnNode min) {
        final InsnList list = new InsnList();
        final List<Integer> pops = new ArrayList<>();
        parsePops(min.desc, pops);
        for (int i = pops.size() - 1; i >= 0; i--) {
            list.add(new InsnNode(pops.get(i) == 2 ? Opcodes.POP2 : Opcodes.POP));
        }
        if (min.getOpcode() != Opcodes.INVOKESTATIC) {
            list.add(new InsnNode(Opcodes.POP));
        }
        return list;
    }

    /** 解析方法描述符参数占用的栈槽（1 槽 = POP，2 槽 = POP2）。 */
    private static void parsePops(final String desc, final List<Integer> out) {
        if (desc == null || desc.isEmpty() || desc.charAt(0) != '(') {
            return;
        }
        int i = 1;
        while (i < desc.length() && desc.charAt(i) != ')') {
            final char c = desc.charAt(i);
            if (c == 'J' || c == 'D') {
                out.add(2);
                i++;
            } else if (c == 'L') {
                out.add(1);
                final int semi = desc.indexOf(';', i);
                i = semi < 0 ? desc.length() : semi + 1;
            } else if (c == '[') {
                out.add(1);
                i++;
                while (i < desc.length() && desc.charAt(i) == '[') {
                    i++;
                }
                if (i < desc.length() && desc.charAt(i) == 'L') {
                    final int semi = desc.indexOf(';', i);
                    i = semi < 0 ? desc.length() : semi + 1;
                } else {
                    i++;
                }
            } else {
                out.add(1);
                i++;
            }
        }
    }

    // ==================== 断筋战术 ====================

    /**
     * 物理摘除第三方 ClassFileTransformer（每 200ms 由自愈线程调用）。
     *
     * <p>{@code InstrumentationImpl.mTransformerManager} → {@code TransformerManager.mTransformerList}
     * → 逐个 {@code mTransformer} 判断；全部经 {@code sun.misc.Unsafe} 读取（JDK 17 模块封装下
     * 反射 setAccessible 会被拒）。第三方变换器一律 {@code inst.removeTransformer()}；我方/Forge/
     * Mixin/ModLauncher 保留。</p>
     */
    public static void purgeForeignTransformers(final Instrumentation inst) {
        try {
            final sun.misc.Unsafe unsafe = unsafe();
            if (unsafe == null) {
                return;
            }
            final Class<?> implClass = Class.forName("sun.instrument.InstrumentationImpl");
            final Field tmf = implClass.getDeclaredField("mTransformerManager");
            final Object manager = unsafe.getObject(inst, unsafe.objectFieldOffset(tmf));
            if (manager == null) {
                return;
            }
            final Class<?> tmClass = Class.forName("sun.instrument.TransformerManager");
            final Field listField = tmClass.getDeclaredField("mTransformerList");
            final Object[] infos = (Object[]) unsafe.getObject(manager,
                    unsafe.objectFieldOffset(listField));
            if (infos == null) {
                return;
            }
            int removed = 0;
            for (final Object info : infos) {
                try {
                    final Field tf = info.getClass().getDeclaredField("mTransformer");
                    final Object t = unsafe.getObject(info, unsafe.objectFieldOffset(tf));
                    if (!(t instanceof ClassFileTransformer)) {
                        continue;
                    }
                    final ClassFileTransformer cft = (ClassFileTransformer) t;
                    final String tName = cft.getClass().getName();
                    if (tName == null || tName.startsWith("com.echoxy.")) {
                        continue;
                    }
                    if (isForeignTransformer(cft)) {
                        inst.removeTransformer(cft);
                        removed++;
                    }
                } catch (final Throwable ignored) {
                    // 单条失败继续
                }
            }
            if (removed > 0) {
                logInfo("断筋：已物理摘除第三方变换器 " + removed + " 个");
            }
        } catch (final Throwable ignored) {
            // 周期清扫失败不影响主流程
        }
    }

    /** 第三方变换器判定：我方 / Forge-Mixin-ModLauncher 核心 / Bootstrap 加载保留。 */
    private static boolean isForeignTransformer(final ClassFileTransformer t) {
        final String name = t.getClass().getName();
        if (name == null) {
            return false;
        }
        if (name.startsWith("com.echoxy.")) {
            return false;
        }
        if (name.startsWith("cpw.mods.") || name.startsWith("net.minecraftforge.")
                || name.startsWith("org.spongepowered.") || name.startsWith("com.mojang.")) {
            return false;
        }
        final ClassLoader cl = t.getClass().getClassLoader();
        if (cl == null) {
            return false; // Bootstrap 加载（JDK 自带）
        }
        return !cl.getClass().getName().contains("LaunchClassLoader"); // dev 环境保留
    }

    private static sun.misc.Unsafe UNSAFE_CACHE;
    private static boolean unsafeResolved;

    private static sun.misc.Unsafe unsafe() {
        if (!unsafeResolved) {
            unsafeResolved = true;
            try {
                final Class<?> u = Class.forName("sun.misc.Unsafe");
                final Field f = u.getDeclaredField("theUnsafe");
                f.setAccessible(true);
                UNSAFE_CACHE = (sun.misc.Unsafe) f.get(null);
            } catch (final Throwable ignored) {
                UNSAFE_CACHE = null;
            }
        }
        return UNSAFE_CACHE;
    }

    // ==================== 日志（委托 EchoAgent） ====================

    private static void logInfo(final String msg) {
        EchoAgent.logExternal("INFO " + msg, false);
    }

    private static void logVerbose(final String msg) {
        if (verbose) {
            EchoAgent.logExternal("FINE " + msg, false);
        }
    }

    private static void logWarn(final String msg) {
        EchoAgent.logExternal("WARN " + msg, true);
    }
}
