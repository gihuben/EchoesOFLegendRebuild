package com.echoxy.agent;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;

/**
 * loadAgent0 直调通道的回调件（G1 · 学习自样板 ArtemisAgent0Callback）。
 *
 * <p>本类字节会被 {@link EchoEarlyAttach} 用 trusted Lookup + {@code ClassLoader.defineClass1}
 * <b>预埋进系统类加载器</b>（临时 agent JAR 只带 manifest），JVM 解析 {@code Agent-Class} 时
 * 命中预埋副本；agentmain 被调起后分两条路把句柄交回：</p>
 * <ol>
 *   <li><b>属性通道</b>（主）：{@code System.getProperties()} 是 JDK 单例、跨类加载器可见；</li>
 *   <li><b>反射回敲</b>（备）：{@code inst.getAllLoadedClasses()} 按名字找回主类后反射调
 *       {@code onInstrumentation0}——跨类加载器桥完全走反射，不依赖编译期引用。</li>
 * </ol>
 *
 * <p>纪律：纯 {@code java.*}；绝不向外抛（agentmain 抛异常会被 JVM 记为 attach 失败）。</p>
 */
public final class EchoAttach0Callback {

    /** 属性通道键（{@link EchoEarlyAttach} 轮询读取）。 */
    public static final String KEY = "echoxy.attach0.inst";

    private EchoAttach0Callback() {
    }

    /** manifest 里 {@code Agent-Class} 指向这里。 */
    public static void agentmain(final String agentArgs, final Instrumentation inst) {
        try {
            if (inst == null) {
                return;
            }
            try {
                System.getProperties().put(KEY, inst);
            } catch (final Throwable ignored) {
                // 属性通道失败：走反射回敲
            }
            Class<?> target = null;
            for (final Class<?> c : inst.getAllLoadedClasses()) {
                if (c != null && "com.echoxy.agent.EchoEarlyAttach".equals(c.getName())) {
                    target = c;
                    break;
                }
            }
            if (target != null) {
                final Method m = target.getMethod("onInstrumentation0", Instrumentation.class);
                m.invoke(null, inst);
            }
        } catch (final Throwable ignored) {
            // fail-open：主链按超时降级到其它挂载方式
        }
    }
}
