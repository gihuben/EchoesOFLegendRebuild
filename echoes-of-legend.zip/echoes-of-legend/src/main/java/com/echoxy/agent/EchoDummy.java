package com.echoxy.agent;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * 哑实例（学习自样板 ArtemisDummy，纯 JDK）。
 *
 * <p>被软空壳掏空的 <b>getter 形态</b>方法（无参、返回第三方对象类型）返回一个
 * "字段全默认值"的未初始化实例，而不是 {@code null}——避免第三方自己的代码
 * {@code getConfig().xxx} 直接 NPE 把整局拉崩（样板实测教训）。</p>
 *
 * <p>强度不受影响：方法体已被掏空 ⇒ 哑实例里所有字段都是默认值 ⇒ 拿不到对手任何真实状态；
 * 分配走 {@code Unsafe.allocateInstance} ⇒ <b>不执行任何构造器/静态块</b>（零副作用）。</p>
 */
public final class EchoDummy {

    private EchoDummy() {
    }

    private static Object unsafeCache;
    private static boolean unsafeResolved;

    /** 为给定类型分配一个"未初始化实例"（字段全默认值）；不可用时返回 null。 */
    public static Object dummyFor(final Class<?> type) {
        try {
            if (type == null) {
                return null;
            }
            if (type.isInterface() || type.isArray() || type.isPrimitive() || type.isEnum()) {
                return null;
            }
            if (Modifier.isAbstract(type.getModifiers())) {
                return null;
            }
            // 只对第三方类兜底：原版/库/JDK 的契约由默认返回值负责（空串/零长/空集合）
            final String n = type.getName();
            if (n.startsWith("java.") || n.startsWith("javax.") || n.startsWith("jdk.")
                    || n.startsWith("sun.") || n.startsWith("com.sun.") || n.startsWith("net.minecraft")
                    || n.startsWith("net.minecraftforge") || n.startsWith("cpw.mods")) {
                return null;
            }
            final Object u = unsafe();
            if (u == null) {
                return null;
            }
            return u.getClass().getMethod("allocateInstance", Class.class).invoke(u, type);
        } catch (final Throwable t) {
            return null; // fail-open：退回"返回 null"的历史行为
        }
    }

    /** 哑 Supplier（供"注册供应商工厂"改写使用；get() 给出哑元素实例）。 */
    public static java.util.function.Supplier<Object> supplierFor(final Class<?> c) {
        return () -> dummyFor(c);
    }

    private static synchronized Object unsafe() {
        if (unsafeResolved) {
            return unsafeCache;
        }
        unsafeResolved = true;
        try {
            final Class<?> uc = Class.forName("sun.misc.Unsafe");
            final Field f = uc.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            unsafeCache = f.get(null);
        } catch (final Throwable t) {
            unsafeCache = null;
        }
        return unsafeCache;
    }
}
