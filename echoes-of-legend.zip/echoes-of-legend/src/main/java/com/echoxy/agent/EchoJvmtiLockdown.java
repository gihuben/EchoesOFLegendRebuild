package com.echoxy.agent;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * 底层 · JVMTI 函数表锁定桥（原生 {@code echo_jvmti_lockdown.dll}）。
 *
 * <h2>为什么锁 JVMTI</h2>
 * <p>JVMTI 是"比 Instrumentation 更底层"的进程内接口。敌方 agent 拿到任意
 * {@code jvmtiEnv} 后即可：抢 {@code can_redefine_any_class}（solo 能力先到先得）、
 * {@code SetEventCallbacks} 注册自己的 ClassFileLoadHook 偷看/改写类字节、
 * {@code RetransformClasses/RedefineClasses} 改我方类、{@code AddModuleOpens} 给
 * java.base 开洞、{@code SuspendThread/StopThread} 停我方线程、
 * {@code SetLocal*} 系列改我方局部变量、{@code ForceEarlyReturn*} 系列改我方执行流……
 * 这些通道不经过 Java 层 Instrumentation 的可见面，Java 侧防御管不到。</p>
 *
 * <h2>本类做什么</h2>
 * <ol>
 *   <li>从 jar 的 {@code assets/echo_jvmti_lockdown.dll} 解到 {@code <gameDir>/echoes-native/}
 *       后 {@code System.load}（与 guard 同款装载纪律）；</li>
 *   <li>{@code nInit(本模组类加载器, "com/echoxy/")} 注入白名单锚点；</li>
 *   <li>按配置锁定：{@code safe}=19 个敏感槽位 / {@code all}=47 个（深锁）；</li>
 *   <li>周期 {@link #reassert()}：完整性自检，被敌方还原的槽位立即修回。</li>
 * </ol>
 *
 * <p>可信调用者（栈上有 {@code com.echoxy.*} 帧）一律转发给原函数 ⇒ 我方一切正常；
 * 敌方/未知调用者返回"假成功"（并配套：栈帧剔除、能力查询清零）。任何失败 fail-open，
 * 绝不拖累游戏启动。</p>
 */
public final class EchoJvmtiLockdown {

    private static final String KEY_ON = "echoxy.agent.jvmti.on";
    private static final String KEY_MODE = "echoxy.agent.jvmti.mode";
    private static final String KEY_STACKHIDE = "echoxy.agent.jvmti.stackhide";
    private static final String KEY_CAPHIDE = "echoxy.agent.jvmti.caphide";
    private static final String KEY_INJECT = "echoxy.agent.jvmti.inject";
    private static final String KEY_REFUSE_GETENV = "echoxy.agent.jvmti.refusegetenv";
    private static final String KEY_INVALIDATE = "echoxy.agent.jvmti.invalidate";
    private static final String KEY_MONITOR = "echoxy.agent.jvmti.monitor";

    private static volatile boolean loaded;
    private static volatile boolean locked;
    private static volatile boolean injectGuard;
    private static volatile String mode = "all";
    private static volatile long lastRecheck;
    private static volatile long restoredTotal;

    private EchoJvmtiLockdown() {
    }

    // ==================== native ====================

    private static native void nInit(ClassLoader loader, String pkg);
    /** ClassFileLoadHook（类字节入关口）：true=装成功。 */
    private static native boolean nEnableCflh();
    /** CFLH 状态（on=1 calls=N）。 */
    private static native String nCflhStatus();

    private static native void nSetRuntime(boolean stackHide, boolean capHide, boolean deepLock);

    private static native int nStatus();

    private static native int nDisableAll();

    private static native int nDisableSelective();

    private static native int nEnableAll();

    private static native int nRecheckIntegrity();

    private static native int nGuardProbe();

    private static native int nAnchorStatus();

    private static native long nStackHiddenFrames();

    private static native long nCapProbeHidden();

    private static native int nPid();

    private static native boolean nEnableInjectGuard(boolean refuseAttach, boolean refuseGetEnv,
            boolean invalidate, int monitorSec);

    private static native String nInjectGuardStatus();

    // ==================== 装配 ====================

    /**
     * 幂等装配（agent 安装期调用一次）。
     *
     * @return true = 已装配并锁定成功
     */
    public static boolean ensure() {
        try {
            if (!com.echoxy.boot.EchoConfig.get().getBoolean("底层总开关", true)) {
                return false;   // 底层总开关=off ⇒ JVMTI 锁定整体不启用
            }
        } catch (final Throwable ignored) {
            // 读配置失败 ⇒ 按默认启用
        }
        if (!readBool(KEY_ON, true)) {
            return false;
        }
        if (loaded) {
            return locked;
        }
        synchronized (EchoJvmtiLockdown.class) {
            if (loaded) {
                return locked;
            }
            try {
                final Path dll = extractDll();
                if (dll == null) {
                    EchoAgent.logExternal("WARN 底层JVMTI锁定跳过：未找到 echo_jvmti_lockdown.dll"
                            + "（jar 未打包或解出失败，降级）", false);
                    return false;
                }
                System.load(dll.toAbsolutePath().toString());
                loaded = true;
                // 白名单锚点：本类加载器（agent/系统类加载器）+ 我方包前缀
                nInit(EchoJvmtiLockdown.class.getClassLoader(), "com/echoxy/");
            // ClassFileLoadHook：类字节入关口（defineClass/JNI/retransform 全经过，含隐藏类/lambda）。
            // 必须在 Java 调用链内调用（栈上有 com/echoxy 帧），否则本库自己的 AddCapabilities
            // 代理会判成不可信而"假成功"。失败只降级，不影响其它能力。
            try {
                if (com.echoxy.boot.EchoConfig.get().getBoolean("底层类加载钩子", true)) {
                    final boolean cflh = nEnableCflh();
                    EchoAgent.logExternal("INFO 类加载钩子(CFLH)：" + (cflh ? "已启用" : "未启用")
                            + " " + nCflhStatus(), false);
                }
            } catch (final Throwable ignored) {
                // CFLH 是增强项：失败不抛出
            }
                final int anchor = nAnchorStatus();
                if (anchor != 0) {
                    return false; // 锚点未就绪 ⇒ 原生层会透明降级，但不主动锁
                }
                mode = readStr(KEY_MODE, "all");
                final boolean stackHide = readBool(KEY_STACKHIDE, true);
                final boolean capHide = readBool(KEY_CAPHIDE, true);
                nSetRuntime(stackHide, capHide, "all".equals(mode));
                final int rc = "all".equals(mode) ? nDisableAll() : nDisableSelective();
                locked = rc == 0;
                // 注入守卫：Agent_OnAttach hook + GetEnv hook + env 链监控
                try {
                    final boolean refuseAttach = readBool(KEY_INJECT, true);
                    final boolean refuseGetEnv = readBool(KEY_REFUSE_GETENV, true);
                    final boolean invalidate = readBool(KEY_INVALIDATE, true);
                    final int monitorSec = readInt(KEY_MONITOR, 5);
                    injectGuard = nEnableInjectGuard(refuseAttach, refuseGetEnv, invalidate, monitorSec);
                    EchoAgent.logExternal("INFO 底层JVMTI注入守卫：" + (injectGuard ? "已启用" : "未启用")
                            + "（拦attach=" + refuseAttach + " 拒GetEnv=" + refuseGetEnv
                            + " 使能失效=" + invalidate + " 监控=" + monitorSec + "s）"
                            + " " + nInjectGuardStatus(), false);
                } catch (final Throwable ignored) {
                    injectGuard = false;
                }
                if (locked) {
                    EchoAgent.logExternal("INFO 底层JVMTI锁定已生效（模式=" + mode
                            + " 槽位=" + nGuardProbe() + " 帧隐藏=" + stackHide
                            + " 能力屏蔽=" + capHide + "）", false);
                } else {
                    EchoAgent.logExternal("WARN 底层JVMTI锁定失败 rc=" + rc + "（降级，不拦截）", false);
                }
                return locked;
            } catch (final Throwable t) {
                EchoAgent.logExternal("WARN 底层JVMTI锁定装配异常（降级）: " + t, false);
                return false;
            }
        }
    }

    /**
     * 周期重断言（防御线程每轮调用；内部限流 1 秒一次）。
     * 敌方若把槽位还原/篡改，这里立即修回；任何异常静默。
     */
    public static void reassert() {
        if (!loaded) {
            return;
        }
        final long now = System.currentTimeMillis();
        if (now - lastRecheck < 1000L) {
            return;
        }
        lastRecheck = now;
        try {
            if (!locked) {
                // 之前失败过：重试装配
                locked = ensure();
                return;
            }
            final int s = nStatus();
            if ((s & 1) == 0) {
                // 锁定状态丢了 ⇒ 重锁
                locked = ("all".equals(mode) ? nDisableAll() : nDisableSelective()) == 0;
                return;
            }
            final int fixed = nRecheckIntegrity();
            if (fixed > 0) {
                restoredTotal += fixed;
                EchoAgent.logExternal("WARN 底层JVMTI 槽位被篡改/还原，已修回 " + fixed
                        + " 个（累计 " + restoredTotal + "）", false);
            }
        } catch (final Throwable ignored) {
            // 静默
        }
    }

    /** 是否已锁定生效。 */
    public static boolean isActive() {
        return loaded && locked;
    }

    /** 状态摘要（诊断用）。 */
    public static String summary() {
        if (!loaded) {
            return "jvmti[未装配]";
        }
        try {
            return "jvmti[locked=" + locked + " mode=" + mode
                    + " status=0x" + Integer.toHexString(nStatus())
                    + " slots=" + nGuardProbe()
                    + " hiddenFrames=" + nStackHiddenFrames()
                    + " capProbeHidden=" + nCapProbeHidden()
                    + " restored=" + restoredTotal + "]";
        } catch (final Throwable t) {
            return "jvmti[?]";
        }
    }

    /** 关闭锁定并卸载（诊断/回滚用）。 */
    public static boolean disable() {
        if (!loaded) {
            return true;
        }
        try {
            locked = nEnableAll() != 0;
            return true;
        } catch (final Throwable t) {
            return false;
        }
    }

    // ==================== 装载工具 ====================

    /**
     * 从 jar 的 assets 解出 DLL 到 {@code <gameDir>/echoes-native/}（固定目录，便于原生定位）。
     *
     * <p>本类由系统类加载器从 agent JAR 加载，**agent JAR 里没有 assets** ⇒ 资源解出由
     * mod 侧的 {@link EchoEarlyAttach} 预先完成并写入系统属性 {@code echoxy.agent.jvmti.dll}；
     * 这里优先消费该路径，找不到再尝试自身资源与固定目录。</p>
     */
    private static Path extractDll() throws Exception {
        // ① mod 侧已解出（首选）
        final String preset = System.getProperty("echoxy.agent.jvmti.dll");
        if (preset != null && !preset.isEmpty()) {
            final Path p = Paths.get(preset);
            if (Files.isRegularFile(p)) {
                return p;
            }
        }
        final String rel = System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT)
                .contains("win") ? "echo_jvmti_lockdown.dll" : "libecho_jvmti_lockdown.so";
        final Path dir = Paths.get(System.getProperty("user.dir", "."))
                .resolve("echoes-native").toAbsolutePath();
        // ② 固定目录已有
        final Path cached = dir.resolve(rel);
        if (Files.isRegularFile(cached)) {
            return cached;
        }
        // ③ 自身资源（若本类恰好在含 assets 的 jar 里）
        try (InputStream in = EchoJvmtiLockdown.class.getResourceAsStream("/assets/" + rel)) {
            if (in == null) {
                return null; // jar 未打包 DLL：降级
            }
            Files.createDirectories(dir);
            final Path tmp = Files.createTempFile(dir, "echo-jvmti-", ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                in.transferTo(out);
            }
            Files.move(tmp, cached, StandardCopyOption.REPLACE_EXISTING);
        }
        return cached;
    }

    private static boolean readBool(final String key, final boolean def) {
        try {
            final String v = System.getProperty(key);
            return v == null ? def : Boolean.parseBoolean(v);
        } catch (final Throwable t) {
            return def;
        }
    }

    private static int readInt(final String key, final int def) {
        try {
            final String v = System.getProperty(key);
            return v == null || v.isEmpty() ? def : Integer.parseInt(v.trim());
        } catch (final Throwable t) {
            return def;
        }
    }

    private static String readStr(final String key, final String def) {
        try {
            final String v = System.getProperty(key);
            return v == null || v.isEmpty() ? def : v;
        } catch (final Throwable t) {
            return def;
        }
    }
}
