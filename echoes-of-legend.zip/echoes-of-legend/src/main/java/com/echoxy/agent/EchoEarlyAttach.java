package com.echoxy.agent;

import java.io.File;
import java.io.InputStream;
import java.lang.instrument.Instrumentation;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import com.echoxy.boot.EchoConfig;

/**
 * 回响物语 Java Agent 早期自举（IWP {@code <clinit>} 点火位，纯 JDK）。
 *
 * <h2>为什么在 IWP 的 {@code <clinit>} 挂载</h2>
 * <p>ImmediateWindowProvider 的枚举是 ModLauncher 服务发现阶段最早的自定义类执行点
 * （早于 mod 扫描、早于第三方 coremod 注册变换器）。在此 self-attach 拿到
 * {@link Instrumentation}，才能在第三方 mod 的类<b>被加载之前</b>把防御布置好。</p>
 *
 * <h2>attach 手段（全部学习自两个样板，按可靠性排序，可配置）</h2>
 * <ol>
 *   <li><b>JNA 直调</b>（回响物语样板主路径）：{@code jvm.dll::JNI_GetCreatedJavaVMs}
 *       拿本进程 JavaVM*，再直调 {@code instrument.dll::Agent_OnAttach} ——
 *       完全绕开 Java attach API，不受 {@code jdk.attach} 模块解析/自我 attach 限制；</li>
 *   <li><b>VirtualMachine.attach</b>（主回退）：JDK 标准 attach API，
 *       需 {@code jdk.attach} 可解析 + {@code -Djdk.attach.allowAttachSelf=true}；</li>
 *   <li><b>enqueue 直发</b>（loadAgentWithEnqueue 方式）：经 {@code IMPL_LOOKUP}
 *       调 {@code sun.tools.attach.VirtualMachineImpl} 的 createPipe/generateStub/
 *       connectPipe/enqueue，直接向 attach 管道派发 load 命令，绕开 VirtualMachine 类；</li>
 *   <li><b>AttachProviderImpl</b>（loadAgentWithImpl 方式）：实例化
 *       {@code sun.tools.attach.AttachProviderImpl} 后调 attachVirtualMachine。</li>
 * </ol>
 * <p>另有 premain 通道（{@code -javaagent}，见 {@link EchoAgent#premain}）。
 * 配置 {@code JavaAgent挂载方式} 选 {@code auto}=按上述顺序逐个尝试，或指定单一方式。</p>
 *
 * <h2>agent JAR 自包含</h2>
 * <p>agent 类由系统类加载器装载，系统类路径上没有 ASM —— 故生成 agent JAR 时
 * 从运行期 ASM 包（启动器 module path / 依赖）读取类字节一并打包（学习自样板）。
 * 缺 ASM 时自动降级（只保留断筋/自愈/线程清理，不做字节码改写）。</p>
 *
 * <p>失败一律静默降级（写统一日志），绝不拖累游戏启动。挂载为后台线程 + 超时等待。</p>
 */
public final class EchoEarlyAttach {

    /** agent 入口类（打进 agent JAR 的清单必须与 {@link #AGENT_CLASSES} 一致）。 */
    private static final String AGENT_MAIN = "com.echoxy.agent.EchoAgent";
    /** agent JAR 必备类硬编码清单（生产 SecureJar 环境文件扫描拿不到，必须兜底）。
     *  <b>教训一</b>：清单必须包含 agent 类实际加载时要解析的全部内部类——漏一个（如匿名类
     *  {@code $1}、{@code $SuperOwner}）就会 NoClassDefFoundError ⇒ 变换器安装失败 ⇒ 拦截全失效。
     *  <b>教训二（类加载器可见性）</b>：agent JAR 由系统类加载器装载，而 Forge 的
     *  MC-BOOTSTRAP / PLUGIN / GAME 层类加载器并不都能委派到它 ⇒
     *  <ul>
     *    <li>被 <b>agent 自身 Java 代码</b>引用的类（变换器/守卫/服务表/循环守卫及其内部类）必须在本清单；</li>
     *    <li>只被 <b>注入进字节码</b>引用的辅助类（{@link EchoDummy}、{@link EchoClinitDiag}）
     *        必须<b>只留在 mod JAR</b>（GAME 层加载器可见），绝不能再打进 agent JAR；</li>
     *    <li>注入到 <b>MC-BOOTSTRAP 层</b>目标（{@code ASMEventHandler} 等）的代码一律自包含，
     *        零外部引用（见 {@code EchoGuardTransformer.installEventGate}）。</li>
     *  </ul> */
    private static final String[] AGENT_CLASSES = {
            "com.echoxy.agent.EchoAgent",
            "com.echoxy.agent.EchoAttach0Callback",
            "com.echoxy.agent.EchoJvmtiLockdown",
            "com.echoxy.agent.EchoNativeGuard",
            "com.echoxy.agent.EchoGuardTransformer",
            "com.echoxy.agent.EchoGuardTransformer$SuperOwner",
            "com.echoxy.agent.EchoGuardTransformer$EchoFrameWriter",
            "com.echoxy.agent.EchoFieldProtect",
            "com.echoxy.agent.EchoFieldProtect$Entry",
            "com.echoxy.agent.EchoServiceGuard",
            "com.echoxy.agent.EchoLoopGuard",
            "com.echoxy.agent.EchoLoopGuard$Probe"
    };

    /** 不进 agent JAR 的类：引用 MC 类的辅助类（系统类加载器加载它会 CNFE）。 */
    private static final String[] EXCLUDE = {
            "com.echoxy.agent.EchoEarlyAttach",
            "com.echoxy.agent.EchoAttachState",
            "com.echoxy.agent.EchoModelFallback"
    };

    private static final Object LOCK = new Object();
    private static volatile boolean attempted;

    private EchoEarlyAttach() {
    }

    /**
     * 幂等入口（IWP {@code <clinit>} / ITS {@code <clinit>} 都会调用；成功后永久跳过）。
     * 后台线程执行 attach，最多同步等待 {@code JavaAgent挂载超时} 秒，避免拖死启动。
     */
    public static void ensure() {
        final EchoConfig cfg = EchoConfig.get();
        if (!cfg.getBoolean("JavaAgent总开关", true)) {
            return;
        }
        if (EchoAttachState.isAgentAttached()) {
            return;
        }
        synchronized (LOCK) {
            if (EchoAttachState.isAgentAttached() || attempted) {
                return;
            }
            attempted = true;
            prepareAgentProperties(cfg);
            prepareNativeDll();
            final String mode = cfg.getString("JavaAgent挂载方式", "auto");
            final int timeoutSec = parseInt(cfg.getString("JavaAgent挂载超时", "15"), 15);
            final Thread t = new Thread(() -> {
                try {
                    report("早期挂载开始（方式=" + mode + "）");
                    attach(mode);
                    EchoAttachState.setAgentAttached(true);
                    report("早期挂载成功（方式=" + mode + "）");
                } catch (final Throwable th) {
                    report("早期挂载失败（" + mode + "）: " + brief(th));
                }
            }, "echoes-agent-attach");
            t.setDaemon(true);
            t.start();
            try {
                t.join(Math.max(1L, timeoutSec) * 1000L);
            } catch (final InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    /** 把游戏侧配置转成系统属性（agent 层类由系统类加载器装载，看不到 EchoConfig）。 */
    private static void prepareAgentProperties(final EchoConfig cfg) {
        try {
            System.setProperty("echoxy.agent.danger",
                    String.valueOf(cfg.getBoolean("JavaAgent危险调用拦截", true)));
            System.setProperty("echoxy.agent.purge",
                    String.valueOf(cfg.getBoolean("JavaAgent拦截CFT", true)));
            System.setProperty("echoxy.agent.selfheal",
                    String.valueOf(cfg.getBoolean("JavaAgent自愈", true)));
            System.setProperty("echoxy.agent.shell",
                    String.valueOf(cfg.getBoolean("JavaAgent空壳", true)));
            System.setProperty("echoxy.agent.allreturn",
                    String.valueOf(cfg.getBoolean("JavaAgent全返回", true)));
            System.setProperty("echoxy.agent.clinitcatch",
                    String.valueOf(cfg.getBoolean("JavaAgent静态块兜底", true)));
            System.setProperty("echoxy.agent.eventgate",
                    String.valueOf(cfg.getBoolean("JavaAgent事件闸门", true)));
            System.setProperty("echoxy.agent.fieldprotect",
                    String.valueOf(cfg.getBoolean("JavaAgent字段保护", true)));
            System.setProperty("echoxy.agent.mixinstrip",
                    String.valueOf(cfg.getBoolean("JavaAgent注入抹除", true)));
            System.setProperty("echoxy.agent.modelfallback",
                    String.valueOf(cfg.getBoolean("JavaAgent模型兜底", true)));
            System.setProperty("echoxy.agent.fullpurge",
                    String.valueOf(cfg.getBoolean("JavaAgent清空", true)));
            System.setProperty("echoxy.agent.reflectstrip",
                    String.valueOf(cfg.getBoolean("JavaAgent反射拦截", true)));
            System.setProperty("echoxy.agent.unsafestrip",
                    String.valueOf(cfg.getBoolean("JavaAgentUnsafe拦截", true)));
            System.setProperty("echoxy.agent.threadstrip",
                    String.valueOf(cfg.getBoolean("JavaAgent线程剥除", true)));
            System.setProperty("echoxy.agent.threadcallstrip",
                    String.valueOf(cfg.getBoolean("JavaAgent线程调度剥除", true)));
            System.setProperty("echoxy.agent.bytecodeapistrip",
                    String.valueOf(cfg.getBoolean("JavaAgent字节码API剥除", true)));
            System.setProperty("echoxy.agent.fileioguard",
                    String.valueOf(cfg.getBoolean("JavaAgent文件IO守卫", true)));
            System.setProperty("echoxy.agent.fmlsink",
                    String.valueOf(cfg.getBoolean("JavaAgentFML兜底", true)));
            System.setProperty("echoxy.agent.datapackguard",
                    String.valueOf(cfg.getBoolean("JavaAgent数据包守卫", true)));
            System.setProperty("echoxy.agent.serviceguard",
                    String.valueOf(cfg.getBoolean("JavaAgent服务表守卫", true)));
            System.setProperty("echoxy.agent.loopguard",
                    String.valueOf(cfg.getBoolean("JavaAgent循环守卫", true)));
            System.setProperty("echoxy.agent.sweep",
                    String.valueOf(cfg.getBoolean("JavaAgent独立巡检", true)));
            System.setProperty("echoxy.agent.argaudit",
                    String.valueOf(cfg.getBoolean("JavaAgent代理参数审计", true)));
            System.setProperty("echoxy.agent.threadclean",
                    String.valueOf(cfg.getBoolean("JavaAgent线程清理", true)));
            // —— 底层（JVMTI 函数表锁定）——
            System.setProperty("echoxy.agent.jvmti.on",
                    String.valueOf(cfg.getBoolean("底层JVMTI锁定", true)));
            System.setProperty("echoxy.agent.jvmti.mode", cfg.getString("底层JVMTI模式", "all"));
            System.setProperty("echoxy.agent.jvmti.stackhide",
                    String.valueOf(cfg.getBoolean("底层JVMTI隐藏栈帧", true)));
            System.setProperty("echoxy.agent.jvmti.caphide",
                    String.valueOf(cfg.getBoolean("底层JVMTI能力探测拦截", true)));
            System.setProperty("echoxy.agent.jvmti.inject",
                    String.valueOf(cfg.getBoolean("底层JVMTI拦截注入", true)));
            System.setProperty("echoxy.agent.jvmti.refusegetenv",
                    String.valueOf(cfg.getBoolean("底层JVMTI拒绝GetEnv", false)));
            System.setProperty("echoxy.agent.jvmti.invalidate",
                    String.valueOf(cfg.getBoolean("底层JVMTI拦截", false)));
            System.setProperty("echoxy.agent.jvmti.monitor",
                    String.valueOf(parseInt(cfg.getString("底层JVMTI监控间隔", "5"), 5)));
            // —— 底层（原生守卫：库加载拦截 / 渲染观测 / 句柄兜底 / 隐藏守护线程）——
            System.setProperty("echoxy.native.on",
                    String.valueOf(cfg.getBoolean("底层原生库拦截", true)));
            System.setProperty("echoxy.native.loadblock",
                    String.valueOf(cfg.getBoolean("底层原生库拦截", true)));
            System.setProperty("echoxy.native.pathblock",
                    String.valueOf(cfg.getBoolean("底层原生库路径拦截", false)));
            System.setProperty("echoxy.native.ldrhook",
                    String.valueOf(cfg.getBoolean("底层LdrLoadDll拦截", false)));
            System.setProperty("echoxy.native.hashes", cfg.getString("底层原生库黑名单", ""));
            System.setProperty("echoxy.native.gdi", cfg.getString("底层GDI防御", "glfw_pass"));
            System.setProperty("echoxy.native.lowlevel",
                    String.valueOf(cfg.getBoolean("底层低级钩子", false)));
            System.setProperty("echoxy.native.hotapi",
                    String.valueOf(cfg.getBoolean("底层热API钩子", false)));
            System.setProperty("echoxy.native.daemon",
                    String.valueOf(cfg.getBoolean("底层原生守护线程", true)));
            System.setProperty("echoxy.native.daemon.prio", cfg.getString("底层守护线程优先级", "time_critical"));
            System.setProperty("echoxy.native.daemon.hide",
                    String.valueOf(cfg.getBoolean("底层守护线程隐藏", false)));
            System.setProperty("echoxy.native.daemon.period",
                    String.valueOf(parseInt(cfg.getString("底层守护线程周期", "200"), 200)));
            System.setProperty("echoxy.agent.verbose",
                    String.valueOf(cfg.getBoolean("JavaAgent详细日志", false)));
            final Path gameDir = Paths.get(System.getProperty("user.dir", "."));
            final String rel = cfg.getString("日志文件路径", "logs/echoes.log");
            System.setProperty("echoxy.agent.logfile",
                    gameDir.resolve(rel).toAbsolutePath().toString());
        } catch (final Throwable ignored) {
            // 属性设置失败：agent 层用默认开关
        }
    }

    /**
     * 把 jar 内 assets 的原生 DLL 解到 {@code <gameDir>/echoes-native/}，并把绝对路径写入
     * 系统属性 {@code echoxy.agent.jvmti.dll}（供 agent 侧 {@link EchoJvmtiLockdown} 装载）。
     *
     * <p><b>为什么在 mod 侧解</b>：agent 类由系统类加载器从 agent JAR 加载，而 agent JAR 只带
     * 功能类（不打包 assets）⇒ agent 侧读不到 jar 资源；本类在 mod JAR 内，资源可读。
     * 这是"类可见性/资源可见性"分工的延伸（与事件闸门零引用同一族纪律）。</p>
     *
     * <p>纪律：任何失败静默（fail-open，原生防御缺席不影响游戏）。</p>
     */
    private static void prepareNativeDll() {
        final boolean win = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        final String[] names = win
                ? new String[] { "echo_jvmti_lockdown.dll", "echo_native_guard.dll", "MinHook.x64.dll" }
                : new String[] { "libecho_jvmti_lockdown.so" };
        try {
            final Path dir = Paths.get(System.getProperty("user.dir", "."))
                    .resolve("echoes-native").toAbsolutePath();
            Files.createDirectories(dir);
            for (final String rel : names) {
                try (InputStream in = EchoEarlyAttach.class.getResourceAsStream("/assets/" + rel)) {
                    if (in == null) {
                        continue; // 该 DLL 未打包：跳过（其余 DLL 照常）
                    }
                    final Path target = dir.resolve(rel);
                    final Path tmp = Files.createTempFile(dir, "echo-native-", ".tmp");
                    try (java.io.OutputStream out = Files.newOutputStream(tmp)) {
                        in.transferTo(out);
                    }
                    Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    if ("echo_jvmti_lockdown.dll".equals(rel)) {
                        System.setProperty("echoxy.agent.jvmti.dll", target.toString());
                    }
                    if ("echo_native_guard.dll".equals(rel)) {
                        System.setProperty("echoxy.native.dll", target.toString());
                    }
                }
            }
        } catch (final Throwable ignored) {
            // fail-open
        }
    }

    // ==================== 挂载核心 ====================

    /** 生成 agent JAR 并尝试挂载（按配置顺序）。 */
    private static void attach(final String mode) throws Throwable {
        final Path gameDir = Paths.get(System.getProperty("user.dir", "."));
        final Path jar = gameDir.resolve("echoes-agent.jar");
        writeAgentJar(jar);
        final int shipped = countAgentClasses(jar);
        report("agent JAR 已生成 " + jar.getFileName() + "（" + shipped + " 个类）");
        if (shipped < AGENT_CLASSES.length) {
            throw new IllegalStateException("agent JAR 类条目不足: " + shipped);
        }

        final List<String> order = attachOrder(mode);
        Throwable last = null;
        for (final String method : order) {
            try {
                switch (method) {
                    case "jna":
                        attachViaJna(jar);
                        break;
                    case "nativeagent":
                        attachViaNativeAgent(jar);
                        break;
                    case "loadagent0":
                        attachViaLoadAgent0(jar);
                        break;
                    case "vm":
                        attachViaVirtualMachine(jar);
                        break;
                    case "enqueue":
                        attachViaEnqueue(jar);
                        break;
                    case "impl":
                        attachViaAttachProvider(jar);
                        break;
                    default:
                        continue;
                }
                report("attach 成功（方式=" + method + "）");
                completeAttach();
                return;
            } catch (final Throwable th) {
                last = th;
                report("attach 失败（方式=" + method + "）: " + brief(th));
            }
        }
        throw (last != null ? last : new IllegalStateException("全部挂载方式均失败"));
    }

    /** 解析挂载方式为尝试顺序。 */
    private static List<String> attachOrder(final String mode) {
        final List<String> order = new ArrayList<>();
        switch (mode == null ? "" : mode.toLowerCase(Locale.ROOT)) {
            case "jna":
                order.add("jna");
                break;
            case "loadagent0":
                order.add("loadagent0");
                break;
            case "vm":
                order.add("vm");
                break;
            case "enqueue":
                order.add("enqueue");
                break;
            case "impl":
                order.add("impl");
                break;
            case "nativeagent":
                order.add("nativeagent");
                break;
            default: // auto：全部依次尝试
                order.add("jna");
                // 原生 agent 通道：合并到既有的"底层JVMTI锁定"（不新增配置项）。
                // 锁定关 ⇒ 不加本通道，行为与旧版完全一致。
                try {
                    if (com.echoxy.boot.EchoConfig.get().getBoolean("底层JVMTI锁定", true)) {
                        order.add("nativeagent");
                    }
                } catch (final Throwable ignored) {
                    order.add("nativeagent");
                }
                order.add("loadagent0");
                order.add("vm");
                order.add("enqueue");
                order.add("impl");
                break;
        }
        return order;
    }

    /** 本进程 PID。 */
    private static String currentPid() {
        try {
            return String.valueOf(ProcessHandle.current().pid());
        } catch (final Throwable ignored) {
            return "0";
        }
    }

    /**
     * JNA 直调：{@code JNI_GetCreatedJavaVMs} 拿 JavaVM*，再直调 {@code Agent_OnAttach}。
     * 这是最可靠的方式：不依赖 jdk.attach 模块、不受自我 attach 限制、无模块访问检查。
     */
    private static void attachViaJna(final Path jar) throws Throwable {
        final String javaHome = System.getProperty("java.home", "");
        final com.sun.jna.NativeLibrary jvmLib = com.sun.jna.NativeLibrary.getInstance(firstExisting(javaHome,
                "bin/server/jvm.dll", "bin/jvm.dll",
                "lib/server/libjvm.so", "lib/libjvm.so",
                "lib/server/libjvm.dylib", "lib/libjvm.dylib"));
        final com.sun.jna.Function getVMs = jvmLib.getFunction("JNI_GetCreatedJavaVMs");
        final com.sun.jna.Memory vmBuffer = new com.sun.jna.Memory(8L * com.sun.jna.Native.POINTER_SIZE);
        final com.sun.jna.ptr.IntByReference count = new com.sun.jna.ptr.IntByReference();
        final int rc = getVMs.invokeInt(new Object[] { vmBuffer, 8, count.getPointer() });
        if (rc != 0 || count.getValue() < 1) {
            throw new IllegalStateException("JNI_GetCreatedJavaVMs rc=" + rc + " nVMs=" + count.getValue());
        }
        final com.sun.jna.Pointer javaVM = vmBuffer.getPointer(0L);
        final com.sun.jna.NativeLibrary instLib = com.sun.jna.NativeLibrary.getInstance(firstExisting(javaHome,
                "bin/instrument.dll", "lib/libinstrument.so", "lib/libinstrument.dylib"));
        final com.sun.jna.Function agentOnAttach = instLib.getFunction("Agent_OnAttach");
        final int result = agentOnAttach.invokeInt(new Object[] {
                javaVM, jar.toAbsolutePath().toString(), com.sun.jna.Pointer.NULL });
        if (result != 0) {
            throw new IllegalStateException("Agent_OnAttach result=" + result);
        }
    }

    /**
     * NATIVE AGENT 直调：把**我们自己 DLL** 的 `Agent_OnAttach` 直接调起来
     * （不需要启动参数、不经 jdk.attach 模块、不依赖 JNI 符号）。
     *
     * <h3>【铁律·失败绝不削弱】</h3>
     * <ul>
     *   <li>本方法在 {@code auto} 顺序里排在 {@code jna} <b>之后</b>：主路径成功时它根本不执行；</li>
     *   <li>失败只抛异常，由 {@link #attach} 捕获后继续尝试下一种方式，<b>不中断挂载链</b>；</li>
     *   <li>失败时<b>不卸载</b>已加载的 DLL（卸载会让 JVM 持有悬空指针，反而更危险）；
     *       后续 {@code EchoJvmtiLockdown.ensure()} 的 {@code System.load} 走 {@code LoadLibrary}
     *       引用计数，<b>仍会成功</b> ⇒ JVMTI 函数表锁定的强度与加入本通道之前完全一致；</li>
     *   <li>因此：<b>原生 agent 通道是"加分项"，不是"必需项"</b>——拿不到就静默退回原有强度。</li>
     * </ul>
     *
     * <p>与 {@link #attachViaJna} 的区别：`jna` 调的是 `instrument.dll!Agent_OnAttach`
     * （Java agent JAR 的入口）；本方式调的是 `echo_jvmti_lockdown.dll!Agent_OnAttach`
     * （**原生 agent 入口**），能在更早的时刻把 JVMTI env 拿到手。</p>
     *
     * <p>失败只抛异常、由调用方继续尝试下一种方式 ⇒ 绝不吞没既有挂载链。</p>
     */
    private static void attachViaNativeAgent(final Path agentJar) throws Throwable {
        final String dllPath = System.getProperty("echoxy.agent.jvmti.dll", "");
        if (dllPath.isEmpty() || !java.nio.file.Files.isRegularFile(Paths.get(dllPath))) {
            throw new IllegalStateException("原生 agent DLL 未就绪: " + dllPath);
        }
        final String javaHome = System.getProperty("java.home", "");
        final com.sun.jna.NativeLibrary jvmLib = com.sun.jna.NativeLibrary.getInstance(firstExisting(javaHome,
                "bin/server/jvm.dll", "bin/jvm.dll",
                "lib/server/libjvm.so", "lib/libjvm.so",
                "lib/server/libjvm.dylib", "lib/libjvm.dylib"));
        final com.sun.jna.Function getVMs = jvmLib.getFunction("JNI_GetCreatedJavaVMs");
        final com.sun.jna.Memory vmBuffer = new com.sun.jna.Memory(8L * com.sun.jna.Native.POINTER_SIZE);
        final com.sun.jna.ptr.IntByReference count = new com.sun.jna.ptr.IntByReference();
        final int rc = getVMs.invokeInt(new Object[] { vmBuffer, 8, count.getPointer() });
        if (rc != 0 || count.getValue() < 1) {
            throw new IllegalStateException("JNI_GetCreatedJavaVMs rc=" + rc + " nVMs=" + count.getValue());
        }
        final com.sun.jna.Pointer javaVM = vmBuffer.getPointer(0L);
        final com.sun.jna.NativeLibrary our = com.sun.jna.NativeLibrary.getInstance(dllPath);
        final com.sun.jna.Function onAttach = our.getFunction("Agent_OnAttach");
        final int r = onAttach.invokeInt(new Object[] { javaVM,
                agentJar.toAbsolutePath().toString(), com.sun.jna.Pointer.NULL });
        if (r != 0) {
            throw new IllegalStateException("原生 Agent_OnAttach result=" + r);
        }
    }
    /** VirtualMachine.attach（JDK 标准 attach API）。 */
    private static void attachViaVirtualMachine(final Path jar) throws Throwable {
        final Class<?> vmClass = Class.forName("com.sun.tools.attach.VirtualMachine");
        final Object vm = vmClass.getMethod("attach", String.class).invoke(null, currentPid());
        try {
            vmClass.getMethod("loadAgent", String.class, String.class)
                    .invoke(vm, jar.toAbsolutePath().toString(), "");
        } finally {
            try {
                vmClass.getMethod("detach").invoke(vm);
            } catch (final Throwable ignored) {
                // detach 失败可忽略
            }
        }
    }

    /**
     * enqueue 直发（loadAgentWithEnqueue 方式）：绕开 VirtualMachine 类，
     * 用 {@code IMPL_LOOKUP} 直接调 {@code sun.tools.attach.VirtualMachineImpl} 的管道协议。
     */
    private static void attachViaEnqueue(final Path jar) throws Throwable {
        final MethodHandles.Lookup lookup = implLookup();
        if (lookup == null) {
            throw new IllegalStateException("IMPL_LOOKUP 不可用（需 --add-opens=java.base/java.lang.invoke=ALL-UNNAMED）");
        }
        final Class<?> implClass = Class.forName("sun.tools.attach.VirtualMachineImpl");
        final MethodHandle createPipe = lookup.findStatic(implClass, "createPipe",
                MethodType.methodType(long.class, String.class));
        final MethodHandle generateStub = lookup.findStatic(implClass, "generateStub",
                MethodType.methodType(byte[].class));
        final MethodHandle connectPipe = lookup.findStatic(implClass, "connectPipe",
                MethodType.methodType(void.class, long.class));
        final MethodHandle enqueue = lookup.findStatic(implClass, "enqueue",
                MethodType.methodType(void.class, long.class, byte[].class, String.class, String.class,
                        Object[].class));
        final String pipe = "\\\\.\\pipe\\javatool" + new Random().nextInt(Integer.MAX_VALUE);
        final long pipeId = (long) createPipe.invoke(pipe);
        final byte[] stub = (byte[]) generateStub.invoke();
        final String path = stripLeadingSlash(jar.toAbsolutePath().toString());
        // 直接向管道派发 load 命令（等价 VirtualMachine.loadAgent 的内部动作）
        enqueue.invoke((long) -1L, stub, "load", pipe, new Object[] { "instrument", "false", path });
        connectPipe.invoke(pipeId);
    }

    /** 通过 {@code sun.tools.attach.AttachProviderImpl} 实例 attach（loadAgentWithImpl 方式）。 */
    private static void attachViaAttachProvider(final Path jar) throws Throwable {
        final Class<?> providerClass = Class.forName("sun.tools.attach.AttachProviderImpl");
        final Object provider = providerClass.getConstructor().newInstance();
        final Method attachVm = providerClass.getDeclaredMethod("attachVirtualMachine", String.class);
        attachVm.setAccessible(true);
        final Object vm = attachVm.invoke(provider, currentPid());
        try {
            final Method loadAgent = vm.getClass().getMethod("loadAgent", String.class);
            loadAgent.invoke(vm, stripLeadingSlash(jar.toAbsolutePath().toString()));
        } finally {
            try {
                vm.getClass().getMethod("detach").invoke(vm);
            } catch (final Throwable ignored) {
                // detach 失败可忽略
            }
        }
    }

    /** 取 {@code MethodHandles.Lookup.IMPL_LOOKUP}（enqueue 通道用；需 add-opens）。 */
    private static MethodHandles.Lookup implLookup() {
        try {
            final Field f = MethodHandles.Lookup.class.getDeclaredField("IMPL_LOOKUP");
            f.setAccessible(true);
            return (MethodHandles.Lookup) f.get(null);
        } catch (final Throwable ignored) {
            return null;
        }
    }

    // ==================== G1 · loadAgent0 直调通道 ====================

    /**
     * loadAgent0 直调（G1 · 学习自样板 {@code ArtemisSelfAttach0}）：
     * 用已有的 {@code sun.instrument.InstrumentationImpl} 实例直调 {@code loadAgent0(jar)}，
     * 绕开 {@code Agent_OnAttach} 导出入口（外部封该导出时仍能加载 agent）。
     *
     * <p><b>前提</b>：本进程已有 Instrumentation 实例（premain 通道已给、或先前的 attach 成功）。
     * JDK 17 的 {@code InstrumentationImpl} 没有可捞实例的静态字段，纯 Java 无法凭空造出句柄
     * ⇒ 无实例时本方式必然失败并自动降级到后续方式（fail-open，不产生任何副作用）。</p>
     */
    private static void attachViaLoadAgent0(final Path jar) throws Throwable {
        final Object impl = findInstrumentationImpl();
        if (impl == null) {
            throw new IllegalStateException("loadAgent0 需要已有 InstrumentationImpl 实例（本进程尚无句柄）");
        }
        // ① 回调类字节预埋进系统类加载器（trusted Lookup + ClassLoader.defineClass1）
        predefineAttach0Callback(jar);
        // ② 只带 manifest 的临时 agent JAR（功能件全在预埋副本里）
        final Path a0 = jar.getParent().resolve("echoes-attach0.jar");
        writeManifestOnlyJar(a0, EchoAttach0Callback.class.getName());
        // ③ 反射直调 loadAgent0
        final Class<?> implClass = Class.forName("sun.instrument.InstrumentationImpl");
        final Method loadAgent0 = implClass.getDeclaredMethod("loadAgent0", String.class);
        loadAgent0.setAccessible(true);
        attach0Inst = null;
        try {
            System.getProperties().remove(EchoAttach0Callback.KEY);
        } catch (final Throwable ignored) {
            // 清理旧值失败可忽略
        }
        loadAgent0.invoke(impl, a0.toAbsolutePath().toString());
        // ④ 等回调回传句柄（属性通道 / 反射回敲，任一到即成功）
        final long deadline = System.currentTimeMillis() + 3000L;
        while (attach0Inst == null && System.getProperties().get(EchoAttach0Callback.KEY) == null
                && System.currentTimeMillis() < deadline) {
            Thread.sleep(10L);
        }
        if (attach0Inst == null && System.getProperties().get(EchoAttach0Callback.KEY) == null) {
            throw new IllegalStateException("loadAgent0 回调未回传句柄（超时）");
        }
        System.setProperty("echoxy.agent.selfAttach", "1");
    }

    /** loadAgent0 回调回传的句柄（{@link EchoAttach0Callback} 反射回敲时写入）。 */
    private static volatile Instrumentation attach0Inst;

    /** loadAgent0 回调入口（由预埋回调类反射调用）。 */
    public static void onInstrumentation0(final Instrumentation inst) {
        if (inst != null) {
            attach0Inst = inst;
        }
    }

    /** 找已有的 InstrumentationImpl 实例：① 已挂载句柄；② 静态字段扫描（样板同法）。 */
    private static Object findInstrumentationImpl() {
        try {
            final Instrumentation inst = EchoAgent.inst();
            if (inst != null) {
                return inst;
            }
        } catch (final Throwable ignored) {
            // 继续下一路
        }
        try {
            final Class<?> implClass = Class.forName("sun.instrument.InstrumentationImpl");
            for (final Field f : implClass.getDeclaredFields()) {
                if (!java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    final Object v = f.get(null);
                    if (v != null && implClass.isInstance(v)) {
                        return v;
                    }
                } catch (final Throwable ignored) {
                    // 逐字段降级
                }
            }
        } catch (final Throwable ignored) {
            // 类不可见：降级
        }
        return null;
    }

    /** 把回调类字节预埋进系统类加载器（已存在则跳过；不产生重复定义）。 */
    private static void predefineAttach0Callback(final Path agentJar) throws Throwable {
        final ClassLoader sys = ClassLoader.getSystemClassLoader();
        final String fqcn = EchoAttach0Callback.class.getName();
        try {
            Class.forName(fqcn, false, sys);
            return; // 已预埋（或系统搜索路径上已可见）
        } catch (final ClassNotFoundException notThere) {
            // 继续预埋
        }
        final byte[] cb = readJarEntry(agentJar, fqcn.replace('.', '/') + ".class");
        if (cb == null || cb.length < 64) {
            throw new IllegalStateException("agent JAR 缺回调类字节: " + fqcn);
        }
        final MethodHandles.Lookup lookup = trustedLookup();
        if (lookup == null) {
            throw new IllegalStateException("trusted Lookup 不可用");
        }
        final MethodHandle defineClass1 = lookup.findStatic(ClassLoader.class, "defineClass1",
                MethodType.methodType(Class.class, ClassLoader.class, String.class, byte[].class,
                        int.class, int.class, ProtectionDomain.class, String.class));
        defineClass1.invoke(sys, fqcn, cb, 0, cb.length, null, "EchoEarlyAttach");
    }

    /** trusted Lookup（ReflectionFactory 序列化构造器；不依赖 --add-opens）。 */
    private static MethodHandles.Lookup trustedLookup() {
        try {
            final java.lang.reflect.Constructor<?> raw = sun.reflect.ReflectionFactory.getReflectionFactory()
                    .newConstructorForSerialization(MethodHandles.Lookup.class,
                            MethodHandles.Lookup.class.getDeclaredConstructor(Class.class, Class.class, int.class));
            return (MethodHandles.Lookup) raw.newInstance(Object.class, null, -1);
        } catch (final Throwable ignored) {
            return null;
        }
    }

    /** 从 agent JAR 读条目字节（失败 ⇒ null）。 */
    private static byte[] readJarEntry(final Path jar, final String entry) {
        try (JarFile jf = new JarFile(jar.toFile())) {
            final JarEntry e = jf.getJarEntry(entry);
            if (e == null) {
                return null;
            }
            try (InputStream in = jf.getInputStream(e)) {
                return in.readAllBytes();
            }
        } catch (final Throwable ignored) {
            return null;
        }
    }

    /** 写"只带 manifest"的临时 agent JAR（loadAgent0 通道用）。 */
    private static void writeManifestOnlyJar(final Path path, final String agentClass) throws Exception {
        final Manifest mf = new Manifest();
        final Attributes a = mf.getMainAttributes();
        a.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        a.putValue("Agent-Class", agentClass);
        a.putValue("Can-Redefine-Classes", "true");
        a.putValue("Can-Retransform-Classes", "true");
        try (JarOutputStream jos = new JarOutputStream(Files.newOutputStream(path), mf)) {
            jos.flush();
        }
    }
    private static String stripLeadingSlash(final String s) {
        return s.startsWith("/") ? s.substring(1) : s;
    }

    /** 挂载成功后反射取句柄并确认安装（agentmain 已安装，这里幂等补位 + 置位跨层状态）。 */
    private static void completeAttach() throws Throwable {
        final Class<?> agent = Class.forName(AGENT_MAIN, true, ClassLoader.getSystemClassLoader());
        final Instrumentation inst = (Instrumentation) agent.getMethod("inst").invoke(null);
        if (inst == null) {
            throw new IllegalStateException("agent 已挂载但 Instrumentation 句柄为空");
        }
        System.setProperty("echoxy.agent.selfAttach", "1");
        // agentmain 里已 install + startDefense（幂等）；此处再调一次确保（例如 premain 通道无 agentmain）
        try {
            agent.getMethod("install", Instrumentation.class).invoke(null, inst);
        } catch (final Throwable t) {
            report("completeAttach install 异常（agentmain 已装，可忽略）: " + brief(t));
        }
    }

    // ==================== agent JAR 生成 ====================

    /** 生成 agent JAR（Manifest + agent 类 + 自包含 ASM）。 */
    private static void writeAgentJar(final Path path) throws Exception {
        final Manifest mf = new Manifest();
        final Attributes a = mf.getMainAttributes();
        a.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        a.putValue("Agent-Class", AGENT_MAIN);
        a.putValue("Premain-Class", AGENT_MAIN);
        a.putValue("Can-Redefine-Classes", "true");
        a.putValue("Can-Retransform-Classes", "true");
        final Set<String> toShip = collectAgentClasses();
        final Map<String, byte[]> asmBytes = collectAsmBytes();
        try (JarOutputStream jos = new JarOutputStream(Files.newOutputStream(path), mf)) {
            for (final String cls : toShip) {
                final String res = "/" + cls.replace('.', '/') + ".class";
                final InputStream in = EchoEarlyAttach.class.getResourceAsStream(res);
                if (in == null) {
                    // 必备类缺失必须显式失败：静默跳过会导致 premain/agentmain 引用缺失类崩溃
                    throw new IllegalStateException("agent JAR 缺类资源: " + res);
                }
                final byte[] bytes;
                try {
                    bytes = in.readAllBytes();
                } finally {
                    in.close();
                }
                jos.putNextEntry(new JarEntry(cls.replace('.', '/') + ".class"));
                jos.write(bytes);
                jos.closeEntry();
            }
            // ASM 类：agent 由系统类加载器装载，必须自包含
            for (final Map.Entry<String, byte[]> e : asmBytes.entrySet()) {
                jos.putNextEntry(new JarEntry(e.getKey().replace('.', '/') + ".class"));
                jos.write(e.getValue());
                jos.closeEntry();
            }
        }
    }

    /** 收集 agent 包内全部类：硬编码清单 + 文件扫描（dev 目录/普通 JAR），排除游戏侧类。 */
    private static Set<String> collectAgentClasses() {
        final LinkedHashSet<String> set = new LinkedHashSet<>();
        for (final String c : AGENT_CLASSES) {
            set.add(c);
        }
        // 文件扫描（dev 目录 / 普通 jar；生产 SecureJar 下静默跳过，靠硬编码清单兜底）
        try {
            final java.security.CodeSource cs = EchoEarlyAttach.class.getProtectionDomain().getCodeSource();
            if (cs != null && cs.getLocation() != null) {
                final File own = new File(cs.getLocation().toURI());
                if (own.isFile()) {
                    try (JarFile jf = new JarFile(own)) {
                        final Enumeration<JarEntry> en = jf.entries();
                        while (en.hasMoreElements()) {
                            final String n = en.nextElement().getName();
                            if (n.startsWith("com/echoxy/agent/") && n.endsWith(".class")) {
                                set.add(n.substring(0, n.length() - 6).replace('/', '.'));
                            }
                        }
                    }
                } else if (own.isDirectory()) {
                    final File pkg = new File(own, "com/echoxy/agent");
                    final File[] files = pkg.listFiles((d, name) -> name.endsWith(".class"));
                    if (files != null) {
                        for (final File f : files) {
                            set.add("com.echoxy.agent." + f.getName().substring(0, f.getName().length() - 6));
                        }
                    }
                }
            }
        } catch (final Throwable ignored) {
            // 扫描失败：硬编码清单仍可工作
        }
        // 排除游戏侧类（引用 MC 类，或只被注入字节码按名引用、由游戏层解析）
        for (final String ex : EXCLUDE) {
            set.remove(ex);
            set.removeIf(n -> n.startsWith(ex + "$"));
        }
        return set;
    }

    /** 收集 ASM 类字节（agent JAR 自包含；运行时从 ASM jar 读）。 */
    private static Map<String, byte[]> collectAsmBytes() {
        final Map<String, byte[]> map = new LinkedHashMap<>();
        final String[] anchors = {
                "org.objectweb.asm.ClassReader",
                "org.objectweb.asm.tree.ClassNode"
        };
        for (final String anchor : anchors) {
            try {
                final Class<?> c = Class.forName(anchor, false, EchoEarlyAttach.class.getClassLoader());
                final ProtectionDomain pd = c.getProtectionDomain();
                if (pd == null || pd.getCodeSource() == null || pd.getCodeSource().getLocation() == null) {
                    continue;
                }
                final File jar = new File(pd.getCodeSource().getLocation().toURI());
                if (!jar.isFile()) {
                    continue;
                }
                try (JarFile jf = new JarFile(jar)) {
                    final Enumeration<JarEntry> en = jf.entries();
                    while (en.hasMoreElements()) {
                        final JarEntry e = en.nextElement();
                        final String n = e.getName();
                        if (n.startsWith("org/objectweb/asm/") && n.endsWith(".class")) {
                            try (InputStream in = jf.getInputStream(e)) {
                                map.put(n.substring(0, n.length() - 6).replace('/', '.'),
                                        in.readAllBytes());
                            }
                        }
                    }
                }
            } catch (final Throwable ignored) {
                // 单个 anchor 失败继续
            }
        }
        return map;
    }

    /** 统计 agent JAR 类条目数（校验用）。 */
    private static int countAgentClasses(final Path path) {
        try (JarFile jf = new JarFile(path.toFile())) {
            int n = 0;
            final Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                if (en.nextElement().getName().endsWith(".class")) {
                    n++;
                }
            }
            return n;
        } catch (final Throwable ignored) {
            return -1;
        }
    }

    private static String firstExisting(final String javaHome, final String... relPaths) {
        for (final String rel : relPaths) {
            final File f = new File(javaHome, rel);
            if (f.isFile()) {
                return f.getAbsolutePath();
            }
        }
        return new File(javaHome, relPaths[0]).getAbsolutePath();
    }

    private static int parseInt(final String s, final int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (final Throwable t) {
            return def;
        }
    }

    // ==================== 日志 ====================

    /** 统一日志文件（路径由游戏侧以系统属性传入；IWP clinit 阶段已可用）。 */
    private static void report(final String msg) {
        try {
            final String path = System.getProperty("echoxy.agent.logfile");
            if (path == null || path.isEmpty()) {
                return;
            }
            final Path p = Paths.get(path);
            final Path parent = p.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.write(p,
                    (java.time.LocalDateTime.now() + " [AGENT] " + msg + System.lineSeparator())
                            .getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (final Throwable ignored) {
            // 日志失败不影响任何逻辑
        }
    }

    private static String brief(final Throwable t) {
        if (t == null) {
            return "null";
        }
        return t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
    }
}
