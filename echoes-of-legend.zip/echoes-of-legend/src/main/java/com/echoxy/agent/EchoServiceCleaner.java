package com.echoxy.agent;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.echoxy.boot.EchoLog;

/**
 * 服务清理（学习自样板 {@code ArtemisServiceCleaner}）：清理 ModLauncher 里
 * **已经注册**的第三方转换器与启动插件。
 *
 * <h3>为什么需要它（与 {@link EchoServiceFilter} 的分工）</h3>
 * <ul>
 *   <li>{@link EchoServiceFilter}：在服务提供者**实例化之前**筛掉 ⇒ 处理"还没注册的"；</li>
 *   <li>本类：服务已经注册进 ModLauncher 之后 ⇒ 处理"**已经进去的**"。</li>
 * </ul>
 * <p>两者互补。本类对应样板反编译实证的两个落点：</p>
 * <pre>
 *  · cpw.mods.modlauncher.Launcher.launchPluginHandler → plugins() 返回的 Map
 *  · cpw.mods.modlauncher.ClassTransformer.plugins（static Map）
 * </pre>
 *
 * <h3>白名单（只保留我方 + 框架）</h3>
 * <p>⚠️ 与 {@link EchoServiceFilter} 同一纪律：**只放行 {@code com.echoxy} 与框架**；
 * 绝不放行 {@code net.mcreator.*}（那是第三方 MCreator 模组的包名）。</p>
 *
 * <h3>纪律</h3>
 * <ul>
 *   <li>绝不抛：全程 try/catch，失败只写日志；</li>
 *   <li>只写数量：不写任何第三方名称；</li>
 *   <li>可配置：由「底层服务拦截」数字里对应位控制（不改就完全不动）；</li>
 *   <li>幂等：可反复调用，已清空的 Map 再清为 0。</li>
 * </ul>
 */
public final class EchoServiceCleaner {

    private EchoServiceCleaner() {
    }

    /** 插件名/类名白名单：只保留我方与框架。 */
    private static final String[] ALLOW = {
            "com.echoxy.",              // 我方
            "com.llamalad7.mixinextras.",
            "cpw.mods.",                // ModLauncher 本体
            "net.minecraftforge.",      // Forge
            "net.minecraft.",           // 原版
            "org.spongepowered.",       // Mixin
            "com.mojang.",
            "org.objectweb.",
            "mixin", "forge", "fml", "eventbus",
    };

    /** 已清理的条目数（诊断）。 */
    private static volatile int cleaned = 0;

    /** 该名字是否要保留（在白名单内）。 */
    private static boolean keep(final String name) {
        if (name == null || name.isEmpty()) {
            return true;                                // 取不到名字 ⇒ 保守保留
        }
        for (final String p : ALLOW) {
            if (name.startsWith(p)) {
                return true;
            }
        }
        // ModLauncher 内部按序生成的数字键 ⇒ 放行
        return name.matches("\\d+");
    }

    /**
     * 执行一轮清理（幂等）。
     *
     * @return 本次移除的条目数（0 = 没动或没东西可清）
     */
    public static int cleanOnce() {
        // ILaunchPluginService 对应序号 2；用与 EchoServiceFilter 完全一致的总开关语义
        if (!com.echoxy.agent.EchoServiceFilter.serviceTypeEnabledPublic(
                "cpw.mods.modlauncher.serviceapi.ILaunchPluginService")) {
            return 0;
        }
        int total = 0;
        try {
            // 落点 1：Launcher.launchPluginHandler.plugins()
            final Class<?> launcherCls = locateClass("cpw.mods.modlauncher.Launcher");
            if (launcherCls != null) {
                final Field f = launcherCls.getDeclaredField("launchPluginHandler");
                f.setAccessible(true);
                final Object lph = f.get(null);
                if (lph != null) {
                    try {
                        final Object plugins = lph.getClass().getMethod("plugins").invoke(lph);
                        total += scrubMap(plugins);
                    } catch (final Throwable ignored) {
                        // 结构变化：跳过该落点
                    }
                }
            }
        } catch (final Throwable ignored) {
            // 落点 1 失败不影响落点 2
        }
        try {
            // 落点 2：ClassTransformer.plugins（static Map）
            final Class<?> ct = locateClass("cpw.mods.modlauncher.ClassTransformer");
            if (ct != null) {
                final Field f = ct.getDeclaredField("plugins");
                f.setAccessible(true);
                total += scrubMap(f.get(null));
            }
        } catch (final Throwable ignored) {
            // 落点 2 失败不影响已有能力
        }
        if (total > 0) {
            cleaned += total;
            log("服务清理：已移除第三方转换/启动插件 " + total + " 个（累计 " + cleaned + "）");
        }
        return total;
    }

    /** 清理一张插件 Map：移除非白名单条目。返回移除数。 */
    @SuppressWarnings("unchecked")
    private static int scrubMap(final Object mapObj) {
        if (!(mapObj instanceof Map<?, ?>)) {
            return 0;
        }
        final Map<?, ?> map = (Map<?, ?>) mapObj;
        final List<Object> remove = new ArrayList<>();
        for (final Map.Entry<?, ?> e : map.entrySet()) {
            final Object k = e.getKey();
            final String key = String.valueOf(k);
            if (keep(key)) {
                continue;
            }
            // 类名也参与判定：插件 key 有时是序号，真实身份在 value 的类名里
            final String cls = e.getValue() == null ? "" : e.getValue().getClass().getName();
            if (keep(cls)) {
                continue;
            }
            remove.add(k);
        }
        for (final Object k : remove) {
            try {
                ((Map<Object, Object>) map).remove(k);
            } catch (final Throwable ignored) {
                // 单个移除失败继续
            }
        }
        return remove.size();
    }

    /** 多加载器定位类（早期阶段上下文加载器可能不是系统加载器）。 */
    private static Class<?> locateClass(final String name) {
        final ClassLoader[] loaders = {
                Thread.currentThread().getContextClassLoader(),
                EchoServiceCleaner.class.getClassLoader(),
                ClassLoader.getSystemClassLoader(),
        };
        for (final ClassLoader cl : loaders) {
            if (cl == null) {
                continue;
            }
            try {
                return Class.forName(name, false, cl);
            } catch (final Throwable ignored) {
                // 下一个
            }
        }
        return null;
    }

    /** 诊断：累计已清理数。 */
    public static int cleaned() {
        return cleaned;
    }

    private static void log(final String msg) {
        try {
            EchoLog.get().info(msg);
        } catch (final Throwable ignored) {
            // 日志失败不影响功能
        }
    }
}
