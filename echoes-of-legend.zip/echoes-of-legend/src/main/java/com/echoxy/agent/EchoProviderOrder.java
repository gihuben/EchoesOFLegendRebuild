package com.echoxy.agent;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * 服务目录置顶器（学习自样板 {@code ArtemisProviderOrder}）。
 *
 * <h3>作用</h3>
 * 把「我方服务提供者条目」强制挪到模块层服务目录列表的**第 0 位**，
 * 从而在 Forge 的 {@code ImmediateWindowHandler.load} 迭代中**最先**被实例化。
 *
 * <h3>为什么这是"确定"的，而不是碰运气</h3>
 * <pre>
 * ImmediateWindowHandler.load(ModuleLayer layer)
 *   → ServiceLoader.load(layer, ImmediateWindowProvider.class)
 *   → ServiceLoader$LayerLookupIterator.providers(layer)
 *        = LANG_ACCESS.getServicesCatalog(layer).findServices(serviceName)
 *   → ModuleLayer.getServicesCatalog() 懒建：for (Module m : nameToModule.values()) catalog.register(m)
 *   → ServicesCatalog.map = ConcurrentHashMap&lt;String, List&lt;ServiceProvider&gt;&gt;
 *     每个服务的列表是 CopyOnWriteArrayList ⇒ 顺序 = register 顺序 = 列表顺序
 * </pre>
 * <p>列表顺序就是唯一判据；`CopyOnWriteArrayList` 的内部快照数组 `array` 是普通字段，
 * 用 {@code Unsafe} 原地换成「我方在最前、其余保持相对次序」的新数组，即可把
 * "谁先被实例化"变成确定值。</p>
 *
 * <h3>为什么不依赖名字、不依赖 JVMTI、不点名</h3>
 * <ul>
 *   <li><b>不依赖名字</b>：模块名只决定初始桶号，置顶与名字无关 ⇒ 对手换名也照样被顶下去；</li>
 *   <li><b>不依赖 JVMTI</b>：纯 Java + Unsafe，对手的 JVMTI 清除影响不到；</li>
 *   <li><b>不点名</b>：只按"是不是我方模块名"筛选，日志只写列表长度与位次，不打印任何第三方名字。</li>
 * </ul>
 *
 * <h3>绝不崩</h3>
 * <p>全程 try/catch，任何失败只记一行计数并返回 0；不修改任何第三方对象的内容，只重排列表引用。</p>
 */
public final class EchoProviderOrder {

    /** 我方模块名（与 build.gradle 的 {@code Automatic-Module-Name} 一致）。 */
    private static final String OWN_MODULE = "artemis.early.ah";

    /** 我方早期通道类：只取 {@code getModule()}，initialize=false 避免触发我方 {@code <clinit>}。 */
    private static final String[] OWN_CLASSES = {
            "com.echoxy.service.EchoWindowProvider",
            "com.echoxy.service.EchoTransformService",
    };

    /** 需要置顶的服务（下标即日志编号，日志不打印这些字符串本身）。 */
    private static final String[] SERVICES = {
            "net.minecraftforge.fml.loading.ImmediateWindowProvider",       // svc1：窗口提供者（顺序 = 谁先武装）
            "cpw.mods.modlauncher.api.ITransformationService",              // svc2：转换服务
            "cpw.mods.modlauncher.serviceapi.ITransformerDiscoveryService", // svc3：发现服务
    };

    private static final Object LOCK = new Object();
    private static volatile int calls = 0;
    private static volatile Object unsafe;              // sun.misc.Unsafe
    private static volatile boolean unsafeTried = false;
    private static volatile int totalMoves = 0;
    private static volatile String lastDiag = "(未执行)";

    private EchoProviderOrder() {
    }

    /**
     * 执行置顶。可重复调用（幂等：已在第 0 位时只记日志、不做无意义写入）。
     *
     * @param tag 调用点标记（仅日志行首区分）
     * @return 本次真正移动的条目数
     */
    public static int enforce(final String tag) {
        synchronized (LOCK) {
            try {
                if (calls >= 16) {
                    return 0;
                }
                calls++;
                final Object u = unsafe();
                if (u == null) {
                    lastDiag = "Unsafe 不可用";
                    return 0;
                }
                final ModuleLayer layer = findLayer();
                if (layer == null) {
                    lastDiag = "无模块层";
                    return 0;
                }
                final Object catalog = getField(u, layer, "servicesCatalog");
                if (catalog == null) {
                    // 目录懒建：此刻还没人调过 getServicesCatalog()。不主动触发（会实例化对手），
                    // 留给下一个调用点（ITS 阶段之后必然已建）。
                    lastDiag = "目录未建";
                    return 0;
                }
                final Object mapObj = getField(u, catalog, "map");
                if (!(mapObj instanceof Map)) {
                    lastDiag = "目录结构异常";
                    return 0;
                }
                int moved = 0;
                for (int i = 0; i < SERVICES.length; i++) {
                    try {
                        final Object list = ((Map<?, ?>) mapObj).get(SERVICES[i]);
                        if (list == null) {
                            continue;
                        }
                        moved += moveToFront(u, list, "svc" + (i + 1), tag);
                    } catch (final Throwable ignored) {
                        // 单个服务失败继续
                    }
                }
                totalMoves += moved;
                lastDiag = "moved=" + moved + " total=" + totalMoves;
                return moved;
            } catch (final Throwable t) {
                lastDiag = "异常 " + t.getClass().getSimpleName();
                return 0;
            }
        }
    }

    /** 自检读数（只含计数）。 */
    public static String status() {
        return "order[calls=" + calls + " moved=" + totalMoves + " " + lastDiag + "]";
    }

    // ------------------------------------------------------------------ 内部

    private static int moveToFront(final Object u, final Object list, final String svcTag, final String tag) {
        final Object arrObj = getField(u, list, "array");
        if (!(arrObj instanceof Object[])) {
            return 0;
        }
        final Object[] arr = (Object[]) arrObj;
        if (arr.length == 0) {
            return 0;
        }
        int mine = -1;
        for (int i = 0; i < arr.length; i++) {
            if (isOurs(u, arr[i])) {
                mine = i;
                break;
            }
        }
        if (mine < 0) {
            return 0;                                   // 不在列表中（非早期通道阶段）
        }
        if (mine == 0) {
            return 0;                                   // 已是首位
        }
        final Object[] next = new Object[arr.length];
        next[0] = arr[mine];
        int k = 1;
        for (int i = 0; i < arr.length; i++) {
            if (i != mine) {
                next[k++] = arr[i];
            }
        }
        // 只换这一个数组引用：其余条目的对象与相对次序完全不动
        if (!setField(u, list, "array", next)) {
            return 0;
        }
        return 1;
    }

    private static boolean isOurs(final Object u, final Object serviceProvider) {
        try {
            final Object module = getField(u, serviceProvider, "module");
            if (module instanceof Module) {
                return OWN_MODULE.equals(((Module) module).getName());
            }
        } catch (final Throwable ignored) {
            // 取不到就认为不是
        }
        return false;
    }

    private static ModuleLayer findLayer() {
        final ClassLoader cl = EchoProviderOrder.class.getClassLoader();
        for (final String cn : OWN_CLASSES) {
            try {
                // initialize=false：只拿 Class/Module/Layer，绝不触发我方 <clinit>
                final Class<?> c = Class.forName(cn, false, cl);
                final Module m = c.getModule();
                if (m != null) {
                    final ModuleLayer l = m.getLayer();
                    if (l != null) {
                        return l;
                    }
                }
            } catch (final Throwable ignored) {
                // 下一个类
            }
        }
        return null;
    }

    private static Object unsafe() {
        if (!unsafeTried) {
            synchronized (LOCK) {
                if (!unsafeTried) {
                    try {
                        final Class<?> uc = Class.forName("sun.misc.Unsafe");
                        final Field f = uc.getDeclaredField("theUnsafe");
                        f.setAccessible(true);
                        unsafe = f.get(null);
                    } catch (final Throwable t) {
                        unsafe = null;
                    }
                    unsafeTried = true;
                }
            }
        }
        return unsafe;
    }

    private static Object getField(final Object u, final Object target, final String name) {
        try {
            final Field f = target.getClass().getDeclaredField(name);
            final java.lang.reflect.Method m = u.getClass().getMethod("objectFieldOffset", Field.class);
            final long off = ((Long) m.invoke(u, f)).longValue();
            final java.lang.reflect.Method g = u.getClass().getMethod("getObject", Object.class, long.class);
            return g.invoke(u, target, off);
        } catch (final Throwable t) {
            return null;
        }
    }

    private static boolean setField(final Object u, final Object target, final String name, final Object value) {
        try {
            final Field f = target.getClass().getDeclaredField(name);
            final java.lang.reflect.Method m = u.getClass().getMethod("objectFieldOffset", Field.class);
            final long off = ((Long) m.invoke(u, f)).longValue();
            final java.lang.reflect.Method s = u.getClass().getMethod("putObject",
                    Object.class, long.class, Object.class);
            s.invoke(u, target, off, value);
            return true;
        } catch (final Throwable t) {
            return false;
        }
    }
}
