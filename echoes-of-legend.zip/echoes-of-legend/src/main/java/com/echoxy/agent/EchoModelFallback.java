package com.echoxy.agent;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import net.minecraft.client.model.geom.ModelPart;

/**
 * 模型缺层兜底（学习自样板 ArtemisModelFallback）。
 *
 * <p>由注入在 {@code EntityModelSet.bakeLayer} 的 catch(IllegalArgumentException) 体、
 * 以及 {@code ModelPart.getChild} 的 catch(NoSuchElementException) 体里调用——
 * 返回<b>空模型</b>而不是抛异常（第三方渲染器构造成功，模型/贴图一个都不加载）。</p>
 *
 * <p><b>注意</b>：本类引用 MC 类（{@link ModelPart}），因此<b>不进 agent JAR</b>
 * （由游戏层类加载器装载，注入的 MC 字节码按名引用）。</p>
 */
public final class EchoModelFallback {

    private EchoModelFallback() {
    }

    private static final AtomicLong EMPTY_SERVED = new AtomicLong();

    /** 注入在 catch 体里调用：只计数（真正的"返回空模型"由注入的字节码完成）。 */
    public static void noteEmpty() {
        try {
            EMPTY_SERVED.incrementAndGet();
        } catch (final Throwable ignored) {
            // ignore
        }
    }

    /** 带常用部件名的空模型（供注入的 catch 体调用；缺件兜底也有东西可拿）。 */
    public static ModelPart emptyModelWithParts() {
        try {
            final Map<String, ModelPart> parts = new HashMap<>();
            final String[] names = {
                    "root", "main", "body", "head", "hat", "hair", "cape", "face", "eyes", "mouth",
                    "left_arm", "right_arm", "left_leg", "right_leg", "left_wing", "right_wing", "tail",
                    "armorHead", "armorBody", "armorRightArm", "armorLeftArm", "armorRightLeg", "armorLeftLeg"
            };
            for (final String n : names) {
                parts.put(n, new ModelPart(Collections.emptyList(), Collections.emptyMap()));
            }
            return new ModelPart(Collections.emptyList(), parts);
        } catch (final Throwable t) {
            try {
                return new ModelPart(Collections.emptyList(), Collections.emptyMap());
            } catch (final Throwable t2) {
                return null; // 极端情况：让调用方拿到 null（原版契约本就不允许，但不再抛）
            }
        }
    }
}
