package com.echoxy.agent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;

/**
 * 服务注册拦截（学习自样板 {@code ArtemisServiceFilter}）。
 *
 * <h3>做什么</h3>
 * 在 ModLauncher 的「服务提供者**实例化之前**」把第三方提供者筛掉：
 * <ul>
 *   <li>{@code ServiceLoaderUtils.streamWithErrorHandling}：{@code sl.stream()} 之后、
 *       {@code p.get()}（实例化）之前插入本过滤器 ⇒ ITS / ITransformerDiscoveryService /
 *       ICoreModProvider / 语言提供器 / 定位器等**全部覆盖**，被丢弃者**永不实例化**；</li>
 *   <li>{@code ImmediateWindowHandler.load}：把 {@code ServiceLoader.iterator()} 换成
 *       {@link #filterIwp}，第三方 IWP 的 {@code <clinit>} **永不执行**，且我方 provider
 *       排在最前（抢在其它 provider 之前武装）。</li>
 * </ul>
 *
 * <h3>白名单（只放行「我方 + 原版/加载器」）</h3>
 * <p>⚠️ 判据是**模块名**（{@code Class.getModule().getName()}），不是类名前缀：
 * 类名可被第三方伪装成 {@code net.minecraft.*} 骗过前缀白名单（历史漏洞），
 * 而模块层内模块名唯一、第三方冒名不了。声称框架命名空间但模块不可信者按**伪装**强制丢弃。
 * 白名单取值来自本机 1.20.1-Forge_47.4.26 的实测模块名（{@code jar --describe-module}）。</p>
 *
 * <h3>纪律</h3>
 * <ul>
 *   <li><b>绝不抛</b>：任何一步失败都原样返回（fail-open，等价于没装过滤器）；</li>
 *   <li><b>只写数量</b>：不写任何第三方名称；</li>
 *   <li><b>只增不减</b>：不动 ServiceLoader 自身语义，只在实例化前筛选；被放行者行为逐字节一致；</li>
 *   <li><b>可配置</b>：由「底层」段的数字配置按服务种类启用（0 = 全不拦）。</li>
 * </ul>
 */
public final class EchoServiceFilter {

    private EchoServiceFilter() {
    }

    /** 已丢弃（未实例化）的第三方提供者数。 */
    private static final AtomicLong DROPPED = new AtomicLong(0);
    /** 已放行的提供者数。 */
    private static final AtomicLong KEPT = new AtomicLong(0);
    /** 形态不符而无法判定的元素数（诊断）。 */
    private static final AtomicLong UNKNOWN = new AtomicLong(0);

    /**
     * 真白名单：**原版 / Forge / 加载器 / 框架模块**（1.20.1-Forge_47.4.26 本地实测模块名）。
     *
     * <p>⚠️ 判据升级：旧版按**类名前缀**放行（{@code net.minecraft.} 等），第三方只要把类放进
     * 这些命名空间就免检（实例：某模组把 IWP 实现放在 {@code net.minecraft.<模组名>.} 下，
     * 靠前缀骗过白名单）。现在**只看 {@code Class.getModule().getName()}**——模块层内模块名唯一，
     * 第三方无法冒名原版/框架模块；类名伪装对判据无效。</p>
     */
    private static final java.util.Set<String> TRUSTED_MODULES = java.util.Set.of(
            "minecraft",
            "forge",
            "fmlloader",
            "fmlcore",
            "javafmllanguage",
            "lowcodelanguage",
            "mclanguage",
            "accesstransformers",
            "net.minecraftforge.eventbus",
            "net.minecraftforge.coremod",
            "net.minecraftforge.forgespi",
            "cpw.mods.modlauncher",
            "cpw.mods.securejarhandler",
            "cpw.mods.bootstraplauncher",
            "org.spongepowered.mixin",
            "org.objectweb.asm",
            "org.objectweb.asm.tree",
            "org.objectweb.asm.commons",
            "org.objectweb.asm.util",
            "org.objectweb.asm.tree.analysis",
            "brigadier",
            "datafixerupper");

    /** 我方模块（MANIFEST {@code Automatic-Module-Name}；与 {@code EchoProviderOrder} 同值）。 */
    private static final String OUR_MODULE = "artemis.early.ah";

    /**
     * 框架命名空间前缀：类名以这些前缀开头的提供者，必须来自 {@link #TRUSTED_MODULES}
     * 或 {@link #OUR_MODULE}，否则判定为**伪装**（强制丢弃，与「底层服务拦截」配置无关）。
     */
    private static final String[] FRAMEWORK_NS = {
            "net.minecraft.",
            "net.minecraftforge.",
            "cpw.mods.",
            "com.mojang.",
            "org.objectweb.",
            "org.spongepowered.",
    };

    /** 取提供者类所属命名模块名；未命名（classpath）⇒ {@code null}。 */
    private static String moduleOf(final Class<?> type) {
        try {
            final Module m = type == null ? null : type.getModule();
            return m != null && m.isNamed() ? m.getName() : null;
        } catch (final Throwable ignored) {
            return null;
        }
    }

    /** 提供者是否来自「我方 / 原版 / 框架」模块（**只看模块名，不看类名前缀**）。 */
    public static boolean trusted(final Class<?> type) {
        final String mod = moduleOf(type);
        if (mod == null) {
            return false;
        }
        return OUR_MODULE.equals(mod) || TRUSTED_MODULES.contains(mod);
    }

    /** 声称原版/框架命名空间、但模块不可信 ⇒ 伪装（强制丢弃，无视配置）。 */
    public static boolean disguised(final Class<?> type) {
        if (type == null) {
            return false;
        }
        final String tn = type.getName();
        boolean claims = false;
        for (final String ns : FRAMEWORK_NS) {
            if (tn.startsWith(ns)) {
                claims = true;
                break;
            }
        }
        return claims && !trusted(type);
    }

    /** 放行判据：模块可信（伪装判定见 {@link #disguised}，由调用方强制丢弃）。 */
    public static boolean allowed(final Class<?> type) {
        return trusted(type);
    }

    /** 我方优先（越小越前）：我方最前，其次我方依赖，最后框架。 */
    private static int rank(final String typeName) {
        if (typeName == null) {
            return 9;
        }
        if (typeName.startsWith("com.echoxy.")) {
            return 0;
        }
        if (typeName.startsWith("com.llamalad7.mixinextras.")) {
            return 1;
        }
        return 5;
    }

    private static void note(final int kept, final int dropped) {
        if (kept > 0) {
            KEPT.addAndGet(kept);
        }
        if (dropped > 0) {
            DROPPED.addAndGet(dropped);
        }
    }

    /**
     * 落点 A：插在 {@code sl.stream()} 与 {@code .map(p -> p.get())} 之间。
     *
     * @param in {@code Stream<ServiceLoader.Provider<T>>}（尚未实例化）
     * @return 过滤后的同型 Stream（被丢弃者永不 {@code get()}）
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static Stream<?> filterProviders(final Stream<?> in) {
        if (in == null) {
            return null;
        }
        Iterator<?> it;
        try {
            it = in.iterator();
        } catch (final Throwable t) {
            return in;                                  // 还没消费任何元素 ⇒ 原样返回（fail-open）
        }
        final List<ServiceLoader.Provider<?>> kept = new ArrayList<>();
        int dropped = 0;
        try {
            while (it.hasNext()) {
                final Object o = it.next();
                if (!(o instanceof ServiceLoader.Provider<?>)) {
                    // 形态不符：宁可保留也不丢（绝不因我方判断失误砍掉框架服务）
                    if (o != null) {
                        UNKNOWN.incrementAndGet();
                    }
                    continue;
                }
                final ServiceLoader.Provider<?> p = (ServiceLoader.Provider<?>) o;
                Class<?> t = null;
                String tn = null;
                try {
                    t = p.type();
                    tn = t.getName();
                } catch (final Throwable ignored) {
                    // 取不到类型名 ⇒ 当作放行
                }
                if (tn == null) {
                    kept.add(p);                            // 形态不可判：保留（绝不误砍）
                } else if (trusted(t)) {
                    kept.add(p);                            // 我方/原版/框架
                } else if (disguised(t) || serviceTypeEnabled(tn)) {
                    dropped++;                              // 伪装 ⇒ 强制丢；第三方 ⇒ 按配置
                } else {
                    kept.add(p);                            // 第三方但该种类未启用拦截 ⇒ 放行
                }
            }
        } catch (final Throwable t) {
            // 迭代中途异常：已收集的照常保留 ⇒ 绝不会"因为异常而丢服务"
        }
        try {
            kept.sort((a, b) -> Integer.compare(rank(nameOf(a)), rank(nameOf(b))));
        } catch (final Throwable ignored) {
            // 排序失败不影响放行
        }
        note(kept.size(), dropped);
        return kept.stream();
    }

    private static String nameOf(final ServiceLoader.Provider<?> p) {
        try {
            return p == null ? null : p.type().getName();
        } catch (final Throwable t) {
            return null;
        }
    }

    /**
     * 落点 B：替换 {@code ImmediateWindowHandler.load} 里的 {@code ServiceLoader.iterator()}。
     * 返回「我方最前 + 原版其后 + 第三方已丢弃」的迭代器。
     */
    public static Iterator<?> filterIwp(final ServiceLoader<?> sl) {
        if (sl == null) {
            return java.util.Collections.emptyIterator();
        }
        final List<ServiceLoader.Provider<?>> kept = new ArrayList<>();
        int dropped = 0;
        try {
            final Iterator<? extends ServiceLoader.Provider<?>> it = sl.stream().iterator();
            while (it.hasNext()) {
                final ServiceLoader.Provider<?> p = it.next();
                Class<?> t = null;
                String tn = null;
                try {
                    t = p.type();
                    tn = t.getName();
                } catch (final Throwable ignored) {
                    // 当作放行
                }
                if (tn == null) {
                    kept.add(p);                            // 形态不可判：保留
                } else if (trusted(t)) {
                    kept.add(p);                            // 我方/原版/框架
                } else if (disguised(t) || serviceTypeEnabled(tn)) {
                    dropped++;                              // 伪装 ⇒ 强制丢；第三方 ⇒ 按配置
                } else {
                    kept.add(p);
                }
            }
        } catch (final Throwable t) {
            // 异常：已收集的照常保留
        }
        try {
            kept.sort((a, b) -> Integer.compare(rank(nameOf(a)), rank(nameOf(b))));
        } catch (final Throwable ignored) {
            // 忽略
        }
        note(kept.size(), dropped);
        return kept.iterator();
    }

    // ==================== 按服务种类配置（底层服务拦截1..8 / 9） ====================

    /** 配置缓存：只读一次。 */
    private static volatile int[] cachedBits = null;

    /**
     * 该服务种类是否被配置为拦截（{@code 底层服务拦截9} 总开关优先，留空再按 1..8 逐项）。
     */
    private static boolean serviceTypeEnabled(final String typeName) {
        try {
            if (cachedBits == null) {
                synchronized (EchoServiceFilter.class) {
                    if (cachedBits == null) {
                        cachedBits = loadBits();
                    }
                }
            }
            final int idx = bitOf(typeName);              // 0..7，-1 = 未识别
            if (idx < 0) {
                return false;                             // 未识别的服务类型 ⇒ 不拦
            }
            return (cachedBits[idx] & 1) != 0;
        } catch (final Throwable t) {
            return false;                                 // fail-open
        }
    }

    /** 读配置生成 8 位开关表（1 = 拦该种）。 */
    private static int[] loadBits() {
        final int[] bits = new int[8];
        try {
            final com.echoxy.boot.EchoConfig cfg = com.echoxy.boot.EchoConfig.get();
            final String all = cfg.getString("底层服务拦截9", "");
            final String v = all == null ? "" : all.trim();
            if ("true".equalsIgnoreCase(v)) {
                for (int i = 0; i < 8; i++) {
                    bits[i] = 1;                          // 总开关开 ⇒ 全拦
                }
                return bits;
            }
            if ("false".equalsIgnoreCase(v)) {
                return bits;                              // 总开关关 ⇒ 全不拦
            }
            // 留空 ⇒ 按 1..8 逐项
            for (int i = 0; i < 8; i++) {
                bits[i] = cfg.getBoolean("底层服务拦截" + (i + 1), true) ? 1 : 0;
            }
        } catch (final Throwable ignored) {
            // 读配置失败 ⇒ 全部不拦（fail-open）
        }
        return bits;
    }

    /**
     * 服务种类 → 位号（从 1 开始数）：
     * 1 = ITransformationService；2 = ILaunchPluginService；3 = ITransformerDiscoveryService；
     * 4 = ImmediateWindowProvider；5 = ILanguageProvider；6 = ICoreModProvider；
     * 7 = IModLocator；8 = IDependencyLocator。
     */
    private static int bitOf(final String typeName) {
        if (typeName == null) {
            return -1;
        }
        if (typeName.contains("ITransformationService")) {
            return 0;
        }
        if (typeName.contains("ILaunchPluginService")) {
            return 1;
        }
        if (typeName.contains("ITransformerDiscoveryService")) {
            return 2;
        }
        if (typeName.contains("ImmediateWindowProvider")) {
            return 3;
        }
        if (typeName.contains("LanguageProvider") || typeName.contains("ILanguageLoader")) {
            return 4;
        }
        if (typeName.contains("ICoreModProvider")) {
            return 5;
        }
        if (typeName.contains("IModLocator")) {
            return 6;
        }
        if (typeName.contains("IDependencyLocator")) {
            return 7;
        }
        return -1;
    }

    /** 公开包装：给 {@link EchoServiceCleaner} 复用同一套配置语义。 */
    public static boolean serviceTypeEnabledPublic(final String typeName) {
        return serviceTypeEnabled(typeName);
    }

    /** 诊断：已丢弃数量。 */
    public static long dropped() {
        return DROPPED.get();
    }

    /** 诊断：已放行数量。 */
    public static long kept() {
        return KEPT.get();
    }
}
