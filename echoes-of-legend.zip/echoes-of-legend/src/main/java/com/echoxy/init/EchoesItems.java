package com.echoxy.init;

import com.echoxy.EchoesOfLegendMod;
import com.echoxy.item.ConfigItem;
import com.echoxy.item.EchoArtifactItem;
import com.echoxy.item.RenderFuckerItem;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 回响物语物品注册表。 */
public final class EchoesItems {

    private EchoesItems() {
    }

    public static final DeferredRegister<Item> REGISTRY =
            DeferredRegister.create(ForgeRegistries.ITEMS, EchoesOfLegendMod.MODID);

    /** 神器 · 阿尔忒弥斯。 */
    public static final RegistryObject<Item> ARTEMIS = REGISTRY.register("artemis", EchoArtifactItem::new);

    /** 摧毁渲染（右键切换整屏白屏，再右键恢复）。 */
    public static final RegistryObject<Item> RENDERFUCKER = REGISTRY.register("renderfucker", RenderFuckerItem::new);

    /** 配置界面（右键打开纯原生配置界面）。 */
    public static final RegistryObject<Item> CONFIG_ITEM = REGISTRY.register("configitem", ConfigItem::new);
}
