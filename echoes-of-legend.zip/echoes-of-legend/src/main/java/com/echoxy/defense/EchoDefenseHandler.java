package com.echoxy.defense;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.echoxy.boot.EchoConfig;
import com.echoxy.boot.EchoLog;
import com.echoxy.item.EchoArtifactItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.loading.FMLPaths;

/**
 * 神器 · 防御处理器：防改血 / 字段回溯 / 防死亡（含死亡数据回拉）/ BZD / 受击渲染压制。
 *
 * <p>全配置化，但只有一个开关 —— {@code 基础防御}（见 {@link #BASE_DEFENSE}）：</p>
 * <ul>
 *   <li><b>开启</b>：受保护玩家受击伤害不落地 + 每 tick 锁血 + 死亡拦截与存活数据回拉 +
 *       受击渲染字段清 + BZD；</li>
 *   <li><b>关闭</b>：{@link #isProtected(Player)} 恒 {@code false}，以上一律不执行。</li>
 * </ul>
 *
 * <p><b>为什么闸落在判定入口，而不是各个行为内部：</b>行为侧的开关只能拦住"执行"，
 * 拦不住"资格"。{@link #isProtected(Player)} 的四个来源中，NBT / 记分板 / 本地文件是
 * 一次性固化（拿过神器即永久），而"此刻持有神器"是<b>现查</b> —— 只要背包里有神器就恒为真。
 * 因此只有把闸放在判定入口，关掉开关才能真正让旧存档里的既有标记一并失效。</p>
 */
public final class EchoDefenseHandler {

    /** 防御标签（参照样板同名）：NBT 持久标记 + 记分板标签 + 神器持有，三来源任一命中即受保护。 */
    public static final String FLAG = "artemis_protected";
    public static final String TAG = "artemis_protected";

    /**
     * 「基础防御」总闸（配置项 {@code 基础防御}，默认 {@code true}）。
     *
     * <p>它是神器一切防御的<b>唯一开关</b>：关闭后 {@link #isProtected(Player)} 恒 {@code false}，
     * 于是伤害/死亡/移除拦截（Mixin 侧）、每 tick 锁血与字段回溯、死亡界面与护盾、
     * BZD、受击渲染压制全部同时失效 —— 一处判定覆盖全部下游。</p>
     *
     * <p><b>为什么固化成常量而不是每次读配置：</b>{@link EchoConfig} 只在进程内首次访问时
     * 读盘一次、不热重载（改配置需重启），所以该值在整个进程内恒定；而
     * {@code LivingEntity#isDeadOrDying} 是本类判定里调用最频繁的入口（每实体每 tick 多次），
     * 若每次都走 {@code EchoConfig.get()} 会反复进出 {@code synchronized} 静态方法。
     * 固化后热路径只读一个 {@code static final boolean}，JIT 可当常量折叠。</p>
     *
     * <p>读取失败（极早期）回退 {@code true}，与原「无条件生效」行为一致 —— 宁可关不掉，
     * 也不能因为读不到配置把防御误关。</p>
     */
    public static final boolean BASE_DEFENSE = readBaseDefense();

    private static boolean readBaseDefense() {
        try {
            return EchoConfig.get().getBoolean("基础防御", true);
        } catch (Throwable t) {
            return true;
        }
    }

    /**
     * 「防缴械」系统变量（配置项 {@code 防缴械}，默认 {@code true}）。
     *
     * <p><b>判据完全独立</b>：不读 {@link #BASE_DEFENSE}，不走 {@link #isProtected(Player)}、
     * 也不走 {@link #isEligible(Player)} 的"永久资格"——只看这一个变量 +
     * "背包此刻有没有神器"（{@link #hasArtifact(Player)}）。</p>
     *
     * <p>与 {@link #BASE_DEFENSE} 一样固化成常量：配置不热重载、值恒定，
     * 且它跑在每 tick 每玩家的热路径上，不便反复进 {@code synchronized} 的
     * {@code EchoConfig.get()}。</p>
     */
    public static final boolean ANTI_DISARM = readAntiDisarm();

    private static boolean readAntiDisarm() {
        try {
            return EchoConfig.get().getBoolean("防缴械", true);
        } catch (Throwable t) {
            return true;
        }
    }

    private static final Map<UUID, Snapshot> SNAPSHOTS = new ConcurrentHashMap<>();

    /** 本地版本目录持久化标记（参照样板 artemis-defense-marks.txt，每行 UUID；跨存档/跨重启）。 */
    private static final Set<UUID> LOCAL_MARKS = ConcurrentHashMap.newKeySet();
    private static volatile boolean marksLoaded = false;

    private static Path markFilePath() {
        try {
            return FMLPaths.GAMEDIR.get().resolve("artemis-defense-marks.txt");
        } catch (Throwable t) {
            return Path.of(System.getProperty("user.dir", "."), "artemis-defense-marks.txt");
        }
    }

    private static void loadLocalMarks() {
        if (marksLoaded) {
            return;
        }
        marksLoaded = true;
        try {
            Path p = markFilePath();
            if (!Files.exists(p)) {
                return;
            }
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                try {
                    String s = line == null ? "" : line.trim();
                    if (!s.isEmpty()) {
                        LOCAL_MARKS.add(UUID.fromString(s));
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /** 本地持久化标记是否命中（曾持有神器）。 */
    public static boolean isLocallyMarked(UUID uuid) {
        loadLocalMarks();
        return LOCAL_MARKS.contains(uuid);
    }

    /** 落盘本地持久化标记（去重、失败静默——内存标记仍生效）。 */
    private static void writeLocalMark(UUID uuid) {
        if (uuid == null || !LOCAL_MARKS.add(uuid)) {
            return;
        }
        try {
            Files.write(markFilePath(), (uuid + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            EchoLog.get().info("防御标记已落盘（版本目录 artemis-defense-marks.txt）：" + uuid);
        } catch (Throwable ignored) {
        }
    }

    private static final sun.misc.Unsafe UNSAFE;

    static {
        sun.misc.Unsafe u = null;
        try {
            Field f = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            u = (sun.misc.Unsafe) f.get(null);
        } catch (Throwable ignored) {
            u = null;
        }
        UNSAFE = u;
    }

    private EchoDefenseHandler() {
    }

    public record Snapshot(double x, double y, double z, float yRot, float xRot, float health, float absorption,
            int food, float saturation, int air, float fallDistance, double maxHealth, ListTag inventory) {
    }

    // ===== 保护判定 =====

    /**
     * 资格判定（四来源任一命中：NBT 持久标记 / 记分板标签 / 本地版本目录标记 / 此刻持有神器）。
     *
     * <p>仅供 {@link #isProtected(Player)} 使用 —— 它<b>不</b>判 {@code 基础防御} 总闸，
     * 总闸由 {@code isProtected} 外层合并。</p>
     *
     * <p>⚠ 常驻增益（BZD / 清负面锁饥饿 / 飞行）<b>不</b>用本方法：用户裁决那三个
     * "只需玩家背包有神器即可"，判据是 {@link #hasArtifact(Player)}，
     * 既不看永久标记、也不受总闸影响。</p>
     */
    private static boolean isEligible(Player player) {
        if (player == null) {
            return false;
        }
        try {
            if (player.getPersistentData().getBoolean(FLAG)) {
                return true;
            }
        } catch (Throwable ignored) {
        }
        try {
            if (player.getTags().contains(TAG)) {
                return true;
            }
        } catch (Throwable ignored) {
        }
        try {
            if (isLocallyMarked(player.getUUID())) {
                return true;
            }
        } catch (Throwable ignored) {
        }
        return hasArtifact(player);
    }

    /**
     * 是否受保护 = 资格 ∧ 基础防御总闸。
     *
     * <p>★ 总闸在这里 —— {@code 基础防御=false} 时恒 {@code false}，不看任何来源。
     * 这是"伤害/死亡/移除/死亡界面/护盾"这组防御的唯一收敛点：
     * 服务端锁血、Mixin 的伤害/死亡/移除拦截、客户端死亡界面与护盾，全部经由本方法判定。</p>
     *
     * <p>常驻增益（BZD / 清负面锁饥饿 / 飞行）<b>不</b>走本方法，它们用
     * {@link #isEligible(Player)} —— 关掉总闸不会把它们一起关掉。</p>
     */
    public static boolean isProtected(Player player) {
        return BASE_DEFENSE && isEligible(player);
    }

    public static boolean isProtected(LivingEntity le) {
        return le instanceof Player p && isProtected(p);
    }

    /**
     * 授予防御资格（参照样板：NBT 持久标记 + 记分板标签 + 本地版本目录文件，三写）。
     *
     * <p>★ 总闸同时在这里 —— {@code 基础防御=false} 时不授予任何标记。
     * 与 {@link #isProtected(Player)} 入口闸互为双保险：入口闸负责让<b>旧存档里已有的</b>
     * 标记失效，这里负责不往存档里写<b>新的</b>脏标记。</p>
     */
    public static void markProtected(Player player) {
        if (!BASE_DEFENSE || player == null) {
            return;
        }
        try {
            CompoundTag tag = player.getPersistentData();
            if (!tag.getBoolean(FLAG)) {
                tag.putBoolean(FLAG, true);
            }
        } catch (Throwable ignored) {
        }
        try {
            if (!player.getTags().contains(TAG)) {
                player.addTag(TAG);
            }
        } catch (Throwable ignored) {
        }
        // 本地版本目录落盘（跨存档/跨重启；对手在游戏内清不掉）
        if (player instanceof ServerPlayer sp) {
            writeLocalMark(sp.getUUID());
        }
    }

    /** 背包（含副手）是否持有神器。 */
    public static boolean hasArtifact(Player player) {
        try {
            for (ItemStack s : player.getInventory().items) {
                if (s != null && s.getItem() instanceof EchoArtifactItem) {
                    return true;
                }
            }
            return player.getOffhandItem().getItem() instanceof EchoArtifactItem;
        } catch (Throwable t) {
            return false;
        }
    }

    // ===== 快照 =====

    public static void capture(ServerPlayer sp, boolean full) {
        try {
            Snapshot prev = SNAPSHOTS.get(sp.getUUID());
            ListTag inv = (full || prev == null) ? sp.getInventory().save(new ListTag()) : prev.inventory();
            SNAPSHOTS.put(sp.getUUID(), new Snapshot(
                    sp.getX(), sp.getY(), sp.getZ(), sp.getYRot(), sp.getXRot(),
                    sp.getHealth(), sp.getAbsorptionAmount(),
                    sp.getFoodData().getFoodLevel(), sp.getFoodData().getSaturationLevel(),
                    sp.getAirSupply(), sp.fallDistance,
                    sp.getAttributeValue(Attributes.MAX_HEALTH), inv));
        } catch (Throwable ignored) {
        }
    }

    // ===== 死亡拦截 =====

    /** 死亡被拦截后的处理（Mixin 主路径）：回拉全部存活数据、清火、清负面效果。 */
    public static void onDeathBlocked(LivingEntity le) {
        if (!BASE_DEFENSE) {
            return;
        }
        if (!(le instanceof ServerPlayer sp)) {
            return;
        }
        if (!isProtected(sp)) {
            return;
        }
        Snapshot s = SNAPSHOTS.get(sp.getUUID());
        if (s == null) {
            s = new Snapshot(sp.getX(), sp.getY(), sp.getZ(), sp.getYRot(), sp.getXRot(),
                    20.0F, 0.0F, 20, 5.0F, sp.getMaxAirSupply(), 0.0F, 20.0D, null);
        }
        if (sp.isRemoved()) {
            reRegister(sp);
        }
        restore(sp, s);
        try {
            sp.clearFire();
            sp.setDeltaMovement(Vec3.ZERO);
            sp.fallDistance = 0.0F;
            sp.setAirSupply(sp.getMaxAirSupply());
        } catch (Throwable ignored) {
        }
        try {
            for (MobEffectInstance eff : new ArrayList<>(sp.getActiveEffects())) {
                if (!eff.getEffect().isBeneficial()) {
                    sp.removeEffect(eff.getEffect());
                }
            }
        } catch (Throwable ignored) {
        }
        // 视觉反馈：客户端护盾（包 2 由客户端护盾渲染消费——我方无自定义包，用事件/本地状态替代）
    }

    private static void restore(ServerPlayer sp, Snapshot s) {
        try {
            AttributeInstance max = sp.getAttribute(Attributes.MAX_HEALTH);
            if (max != null) {
                max.setBaseValue(s.maxHealth());
            }
            sp.setHealth(s.health());
            forceRestoreSyncedHealth(sp, (float) Math.max(20.0D, s.maxHealth()));
            sp.setAbsorptionAmount(s.absorption());
            sp.teleportTo(s.x(), s.y(), s.z());
            sp.setYRot(s.yRot());
            sp.setXRot(s.xRot());
            sp.setYHeadRot(s.yRot());
            sp.getFoodData().setFoodLevel(s.food());
            sp.getFoodData().setSaturation(s.saturation());
            sp.setAirSupply(s.air());
            sp.fallDistance = s.fallDistance();
            if (s.inventory() != null) {
                sp.getInventory().load(s.inventory());
            }
        } catch (Throwable ignored) {
        }
    }

    // ===== 字段回溯 =====

    /** 把被移出世界的受保护玩家拉回世界（removalReason 清空 + 官方通道重注册）。 */
    public static void reRegister(ServerPlayer sp) {
        try {
            Method unset = Entity.class.getDeclaredMethod("unsetRemoved");
            unset.setAccessible(true);
            unset.invoke(sp);
        } catch (Throwable ignored) {
        }
        Field removal = findField(Entity.class, "removalReason", "f_146795_");
        if (removal != null) {
            try {
                removal.set(sp, null);
            } catch (Throwable ignored) {
            }
        }
        if (sp.isRemoved()) {
            return;
        }
        try {
            sp.serverLevel().addFreshEntity(sp);
        } catch (Throwable ignored) {
        }
    }

    /** 死亡状态字段清零（deathTime/hurtTime/dead/removalReason；dev 名 + SRG 名双查）。 */
    public static void clearDeathStateFields(LivingEntity le) {
        try {
            if (le instanceof ServerPlayer sp && (sp.isRemoved() || rawIsRemoved(sp))) {
                reRegister(sp);
            }
        } catch (Throwable ignored) {
        }
    }

    private static Field F_DEATH_TIME;
    private static Field F_HURT_TIME;
    private static Field F_DEAD;
    private static Field F_REMOVAL;

    public static boolean rawIsRemoved(Entity e) {
        try {
            if (F_REMOVAL == null) {
                F_REMOVAL = findField(Entity.class, "removalReason", "f_146795_");
            }
            if (F_REMOVAL != null) {
                return F_REMOVAL.get(e) != null;
            }
        } catch (Throwable ignored) {
        }
        try {
            return e.isRemoved();
        } catch (Throwable t) {
            return false;
        }
    }

    private static Field findField(Class<?> clz, String... names) {
        Class<?> cur = clz;
        while (cur != null && cur != Object.class) {
            for (String n : names) {
                try {
                    Field f = cur.getDeclaredField(n);
                    f.setAccessible(true);
                    return f;
                } catch (Throwable ignored) {
                }
            }
            cur = cur.getSuperclass();
        }
        return null;
    }

    // ===== 锁血（防改血） =====

    /** 字段级锁血：SynchedEntityData 深锁 + 字段扫描 + Unsafe 双路。 */
    public static void forceRestoreHealth(LivingEntity le) {
        float target = 20.0F;
        try {
            target = Math.max(20.0F, le.getMaxHealth());
        } catch (Throwable ignored) {
        }
        forceRestoreSyncedHealth(le, target);
        float current = -1.0F;
        try {
            current = le.getHealth();
        } catch (Throwable ignored) {
        }
        Class<?> c = le.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                if (f.getType() != float.class && f.getType() != Float.class) {
                    continue;
                }
                String n = f.getName().toLowerCase(Locale.ROOT);
                boolean hit = n.contains("health");
                if (!hit && current >= 0.0F) {
                    try {
                        f.setAccessible(true);
                        if (Math.abs(f.getFloat(le) - current) < 0.001F) {
                            hit = true;
                        }
                    } catch (Throwable ignored) {
                    }
                }
                if (!hit) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    f.setFloat(le, target);
                } catch (Throwable ignored) {
                }
                try {
                    if (UNSAFE != null) {
                        UNSAFE.putFloat(le, UNSAFE.objectFieldOffset(f), target);
                    }
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
        // 清死亡/移除状态字段
        c = le.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                String n = f.getName().toLowerCase(Locale.ROOT);
                try {
                    if (f.getType() == boolean.class && (n.contains("dead") || n.contains("removed"))) {
                        f.setAccessible(true);
                        f.setBoolean(le, false);
                        if (UNSAFE != null) {
                            UNSAFE.putBoolean(le, UNSAFE.objectFieldOffset(f), false);
                        }
                    } else if (f.getType() == int.class && (n.contains("deathtime") || n.contains("deathprogress"))) {
                        f.setAccessible(true);
                        f.setInt(le, 0);
                        if (UNSAFE != null) {
                            UNSAFE.putInt(le, UNSAFE.objectFieldOffset(f), 0);
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }

    /** 深锁 SynchedEntityData 血量：官方 set 通道 + DataItem.value Unsafe 直写兜底。 */
    public static void forceRestoreSyncedHealth(LivingEntity le, float target) {
        try {
            Object entityData = getEntityData(le);
            Object accessor = getHealthAccessor(le);
            if (entityData == null || accessor == null) {
                return;
            }
            try {
                Method set = findSyncSetMethod(entityData.getClass());
                if (set != null) {
                    set.invoke(entityData, accessor, target);
                }
            } catch (Throwable ignored) {
            }
            deepWriteDataItem(entityData, accessor, target);
        } catch (Throwable ignored) {
        }
    }

    private static Object getEntityData(LivingEntity le) {
        try {
            Class<?> synced = Class.forName("net.minecraft.network.syncher.SynchedEntityData");
            Class<?> c = le.getClass();
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (Modifier.isStatic(f.getModifiers())) {
                        continue;
                    }
                    if (f.getType() == synced) {
                        f.setAccessible(true);
                        return f.get(le);
                    }
                }
                c = c.getSuperclass();
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static Object getHealthAccessor(LivingEntity le) {
        try {
            Class<?> c = LivingEntity.class;
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (!Modifier.isStatic(f.getModifiers())) {
                        continue;
                    }
                    if (!f.getType().getName().equals("net.minecraft.network.syncher.EntityDataAccessor")) {
                        continue;
                    }
                    try {
                        Type g = f.getGenericType();
                        if (g instanceof ParameterizedType pt && pt.getActualTypeArguments().length == 1
                                && pt.getActualTypeArguments()[0] == Float.class) {
                            f.setAccessible(true);
                            Object a = f.get(null);
                            if (a != null) {
                                return a;
                            }
                        }
                    } catch (Throwable ignored) {
                    }
                }
                c = c.getSuperclass();
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static Method findSyncSetMethod(Class<?> c) {
        for (Method m : c.getMethods()) {
            Class<?>[] ps = m.getParameterTypes();
            if (ps.length == 2 && ps[0].getName().equals("net.minecraft.network.syncher.EntityDataAccessor")
                    && ps[1] == Object.class && m.getReturnType() == void.class) {
                return m;
            }
        }
        return null;
    }

    private static void deepWriteDataItem(Object entityData, Object accessor, float target) {
        Class<?> c = entityData.getClass();
        while (c != null && c != Object.class) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                try {
                    f.setAccessible(true);
                    Object v = f.get(entityData);
                    if (v == null) {
                        continue;
                    }
                    if (v instanceof Map<?, ?> map) {
                        for (Object item : map.values()) {
                            writeDataItemValue(item, accessor, target);
                        }
                    } else if (v instanceof Iterable<?> it) {
                        for (Object item : it) {
                            writeDataItemValue(item, accessor, target);
                        }
                    } else if (v.getClass().isArray()) {
                        int len = java.lang.reflect.Array.getLength(v);
                        for (int i = 0; i < len; i++) {
                            writeDataItemValue(java.lang.reflect.Array.get(v, i), accessor, target);
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
            c = c.getSuperclass();
        }
    }

    private static void writeDataItemValue(Object item, Object accessor, float target) {
        if (item == null || accessor == null) {
            return;
        }
        Field accF = null;
        Field valF = null;
        Class<?> c = item.getClass();
        while (c != null && c != Object.class && (accF == null || valF == null)) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) {
                    continue;
                }
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (accF == null && (n.equals("accessor") || f.getType().isAssignableFrom(accessor.getClass()))) {
                    accF = f;
                } else if (valF == null && (n.equals("value") || (f.getType() == Object.class && !n.equals("accessor")))) {
                    valF = f;
                }
            }
            if (accF != null && valF != null) {
                break;
            }
            c = c.getSuperclass();
        }
        if (accF == null || valF == null) {
            return;
        }
        try {
            accF.setAccessible(true);
            if (accF.get(item) != accessor) {
                return;
            }
        } catch (Throwable ignored) {
            return;
        }
        try {
            valF.setAccessible(true);
            valF.set(item, target);
        } catch (Throwable ignored) {
        }
        try {
            if (UNSAFE != null) {
                UNSAFE.putObject(item, UNSAFE.objectFieldOffset(valF), target);
            }
        } catch (Throwable ignored) {
        }
    }

    // ===== 服务端每 tick =====

    /**
     * 服务端每 tick（由 EchoGuardServerTickMixin 调用）。
     *
     * <p>分成两组，判据不同：</p>
     * <ol>
     *   <li><b>基础防御组</b>（锁血 / 死亡字段回溯 / 受击渲染压制 / 快照）——
     *       判 {@link #isProtected(Player)}，<b>受 {@code 基础防御} 总闸控制</b>；</li>
     *   <li><b>常驻增益组</b>（BZD / 清负面锁饥饿 / 飞行）——
     *       判 {@link #hasArtifact(Player)}（此刻背包或副手持有神器），
     *       <b>不受 {@code 基础防御} 总闸影响</b>，各自有独立开关。</li>
     * </ol>
     */
    public static void serverTick(MinecraftServer server) {
        if (server == null) {
            return;
        }
        for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
            try {
                // 先授予永久防御资格：只要持有神器（任意获得方式）即写入 NBT 持久标记 + 记分板标签
                // ——之后即使丢弃/被清物品栏，资格仍在（永久防御）
                // 注：markProtected 内部受 基础防御 总闸约束，总闸关闭时不写脏标记
                if (hasArtifact(sp)) {
                    markProtected(sp);
                }

                // ===== 组一：基础防御（受总闸控制）=====
                if (isProtected(sp)) {
                    // 锁血
                    try {
                        if (sp.isDeadOrDying() || sp.getHealth() < sp.getMaxHealth()) {
                            forceRestoreHealth(sp);
                        }
                    } catch (Throwable ignored) {
                    }
                    // 防死亡：字段回溯
                    if (sp.isRemoved() || rawIsRemoved(sp)) {
                        reRegister(sp);
                    }
                    // 受击渲染压制
                    clearHurtRenderFields(sp);
                    capture(sp, server.getTickCount() % 20 == 0);
                }

                // ===== 组二：常驻增益（只需背包有神器，不受总闸影响）=====
                // ★ 防缴械必须排在最前：它负责在"背包被掏空"时把神器补回来。
                //   若放到 hasArtifact 的 continue 之后，它将永远没有机会执行。
                if (ANTI_DISARM) {
                    ensureMainHandArtifact(sp);
                }
                if (!hasArtifact(sp)) {
                    continue;
                }
                // 护盾 + 防火：吸收护盾锁 100 / 火焰免疫
                if (EchoConfig.get().getBoolean("护盾+防火", true)) {
                    try {
                        if (sp.getAbsorptionAmount() < 100.0F) {
                            sp.setAbsorptionAmount(100.0F);
                        }
                    } catch (Throwable ignored) {
                    }
                    try {
                        if (sp.getRemainingFireTicks() > 0) {
                            sp.setRemainingFireTicks(0);
                        }
                    } catch (Throwable ignored) {
                    }
                }
                // 永不饥饿 + 清理负面效果
                if (EchoConfig.get().getBoolean("永不饥饿+清理负面效果", true)) {
                    clearNegativeEffects(sp);
                    lockFood(sp);
                }
                // 飞行：强制飞行资格并保持飞行中
                // 注：mayfly/flying 是服务端权威字段，客户端由 onUpdateAbilities 的同步包更新
                if (EchoConfig.get().getBoolean("飞行", true)) {
                    try {
                        final net.minecraft.world.entity.player.Abilities ab = sp.getAbilities();
                        if (!ab.mayfly || !ab.flying) {
                            ab.mayfly = true;
                            ab.flying = true;
                            sp.onUpdateAbilities();
                        }
                    } catch (Throwable ignored) {
                    }
                }
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * 清负面效果：移除一切 {@code HARMFUL} 类状态（毒/凋零/缓慢/虚弱/失明/反胃/漂浮/霉运…）。
     *
     * <p>判据是<b>状态分类</b>（{@link net.minecraft.world.effect.MobEffectCategory#HARMFUL}），
     * 不是效果名清单 —— 任何模组新增的有害状态同样被清，无需维护名单。</p>
     */
    private static void clearNegativeEffects(ServerPlayer sp) {
        try {
            final java.util.Collection<MobEffectInstance> active = sp.getActiveEffects();
            if (active == null || active.isEmpty()) {
                return;
            }
            final ArrayList<net.minecraft.world.effect.MobEffect> remove = new ArrayList<>();
            for (MobEffectInstance inst : active) {
                if (inst == null) {
                    continue;
                }
                final net.minecraft.world.effect.MobEffect eff = inst.getEffect();
                if (eff != null
                        && eff.getCategory() == net.minecraft.world.effect.MobEffectCategory.HARMFUL) {
                    remove.add(eff);
                }
            }
            for (net.minecraft.world.effect.MobEffect eff : remove) {
                sp.removeEffect(eff);
            }
        } catch (Throwable ignored) {
        }
    }

    /** 锁饥饿：饥饿值与饱和度锁满（永不掉饥饿）。 */
    private static void lockFood(ServerPlayer sp) {
        try {
            if (sp.getFoodData().getFoodLevel() < 20) {
                sp.getFoodData().setFoodLevel(20);
            }
            if (sp.getFoodData().getSaturationLevel() < 20.0F) {
                sp.getFoodData().setSaturation(20.0F);
            }
        } catch (Throwable ignored) {
        }
    }

    /**
     * 防缴械：整个背包（含副手）都没有神器时，把<b>主手</b>强行设置为神器。
     *
     * <p>判据是 {@link #hasArtifact(Player)} —— 只要背包任意槽位或副手还有神器，
     * 就<b>完全不动主手</b>。所以平时不抢占主手，与「摧毁渲染」等需要主手的物品无冲突；
     * 只有神器被第三方从背包清空 / 玩家把最后一把丢光时才会补齐。</p>
     *
     * <p>补齐后 {@code hasArtifact} 立刻为真，下一 tick 不再重复补 —— <b>不会无限刷物品</b>。</p>
     */
    private static void ensureMainHandArtifact(ServerPlayer sp) {
        try {
            if (hasArtifact(sp)) {
                return;
            }
            sp.setItemInHand(InteractionHand.MAIN_HAND,
                    new ItemStack(com.echoxy.init.EchoesItems.ARTEMIS.get()));
        } catch (Throwable ignored) {
        }
    }

    /** 受击渲染压制：清 hurtTime/hurtDuration/deathTime（服务端字段同步到客户端渲染）。 */
    private static void clearHurtRenderFields(LivingEntity le) {
        try {
            if (F_HURT_TIME == null) {
                F_HURT_TIME = findField(LivingEntity.class, "hurtTime", "f_20918_", "f_20916_");
            }
            if (F_HURT_TIME != null) {
                F_HURT_TIME.setInt(le, 0);
            }
            if (F_DEATH_TIME == null) {
                F_DEATH_TIME = findField(LivingEntity.class, "deathTime", "f_20919_");
            }
            if (F_DEATH_TIME != null) {
                F_DEATH_TIME.setInt(le, 0);
            }
        } catch (Throwable ignored) {
        }
    }
}
