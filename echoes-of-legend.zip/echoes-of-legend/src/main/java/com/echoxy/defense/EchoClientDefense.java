package com.echoxy.defense;

import java.lang.reflect.Field;

import com.echoxy.boot.EchoConfig;
import com.echoxy.boot.EchoLog;
import com.echoxy.item.EchoArtifactItem;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * 神器 · 客户端防御（渲染相关）。
 *
 * <ul>
 *   <li><b>防御模式</b>（{@code 防御模式}）：<b>潜行+左键开启 / 潜行+右键关闭</b>——
 *       HUD 全隐藏 + 一切 GUI 关闭（纯 3D 世界视图）+ 右上角"ON"指示器；</li>
 *   <li><b>死亡 GUI 拦截</b>（受 {@code 基础防御} 总闸控制）：受保护玩家死亡界面永不渲染，
 *       每 tick 兜底清除被注入的死亡界面；</li>
 *   <li><b>护盾</b>（受 {@code 基础防御} 总闸控制）：死亡瞬间启动全屏护盾覆盖，覆盖一切画面。</li>
 * </ul>
 *
 * <p>★ 本类的 {@link #clientProtected(Player)} 是<b>客户端一侧</b>的受保护判定入口，
 * 与 {@link EchoDefenseHandler#isProtected(Player)} 同源同闸 —— 两者都不读细分开关，
 * 只看 {@link EchoDefenseHandler#BASE_DEFENSE} 总闸 + 四来源判定。</p>
 */
public final class EchoClientDefense {

    /** 防御模式（手动，潜行+左键开 / 潜行+右键关）。 */
    public static volatile boolean modeActive = false;
    /** 护盾重绘剩余帧数（0 = 关闭）。 */
    public static int shieldTimer = 0;

    private static boolean prevAttack = false;
    private static boolean prevUse = false;

    private EchoClientDefense() {
    }

    /** 客户端每 tick（由 EchoesClientRenderEvents 调用）。 */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.player == null || mc.options == null) {
            return;
        }
        // 防御模式开关：潜行+左键开 / 潜行+右键关（边沿触发，按住不重复）
        // 只在玩家确实持有防御资格（背包持有神器）时才生效——没有资格按快捷键无效
        if (EchoConfig.get().getBoolean("防御模式", true)) {
            try {
                boolean shift = mc.player.isShiftKeyDown();
                boolean atk = mc.options.keyAttack.isDown();
                boolean use = mc.options.keyUse.isDown();
                if (shift && atk && !prevAttack && clientProtected(mc.player)) {
                    setMode(true);
                } else if (shift && use && !prevUse) {
                    setMode(false);
                }
                prevAttack = shift && atk;
                prevUse = shift && use;
            } catch (Throwable ignored) {
            }
        }
        // 护盾计时
        if (shieldTimer > 0) {
            shieldTimer--;
        }
        // 死亡 GUI 兜底（GameRenderer Mixin 每帧也会调用；此处 tick 冗余）
        clearDeathScreens();
        // 防御模式：一切 GUI 关闭（第三方直写 mc.screen 也在此清掉）
        if (modeActive && mc.screen != null) {
            try {
                mc.setScreen(null);
            } catch (Throwable ignored) {
            }
        }
    }

    /** 死亡界面清除（tick 与 GameRenderer 每帧共用）：受保护玩家强制清除死亡界面并启动护盾。 */
    public static void clearDeathScreens() {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.player == null) {
            return;
        }
        if (!clientProtected(mc.player)) {
            return;
        }
        try {
            boolean hadDeathGui = mc.screen instanceof DeathScreen;
            if (hadDeathGui) {
                mc.setScreen(null);
            }
            for (Field f : Minecraft.class.getDeclaredFields()) {
                if (Screen.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    Object v = f.get(mc);
                    if (v instanceof DeathScreen) {
                        f.set(mc, null);
                        hadDeathGui = true;
                    }
                }
            }
            if (hadDeathGui) {
                startShield();
            }
        } catch (Throwable ignored) {
        }
    }

    /** 防御模式开/关（开启瞬间关闭当前界面）。 */
    public static void setMode(boolean on) {
        modeActive = on;
        if (on) {
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && mc.screen != null) {
                try {
                    mc.setScreen(null);
                } catch (Throwable ignored) {
                }
            }
            EchoLog.get().info("防御模式开启（HUD 隐藏 + GUI 拦截）；潜行+右键 关闭");
        } else {
            EchoLog.get().info("防御模式关闭");
        }
    }

    public static boolean defenseModeActive() {
        return modeActive;
    }

    public static boolean shieldActive() {
        return shieldTimer > 0;
    }

    public static void startShield() {
        if (!EchoDefenseHandler.BASE_DEFENSE) {
            return;
        }
        shieldTimer = 60;
    }

    /** Gui.render 守卫（HEAD）：返回 true ⇒ 取消整个 HUD 渲染。 */
    public static boolean hudGuard(GuiGraphics g) {
        if (shieldTimer > 0) {
            renderShield(g);
            return true;
        }
        if (modeActive) {
            renderIndicator(g);
            return true;
        }
        return false;
    }

    /** 右上角 "ON" 指示器（HUD 全隐藏后唯一状态凭据）。 */
    public static void renderIndicator(GuiGraphics g) {
        if (!modeActive) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.font == null) {
            return;
        }
        int w = mc.getWindow().getGuiScaledWidth();
        String s = "\u00a7bON";
        int tw = mc.font.width(s);
        int x1 = w - tw - 14;
        int y1 = 4;
        g.fill(x1, y1, w - 4, y1 + 12, 0xAA000000);
        g.drawString(mc.font, s, x1 + 5, y1 + 2, 0xFFFFFF);
    }

    /** 最高图层护盾覆盖（覆盖世界与全部 GUI）。 */
    public static void renderShield(GuiGraphics g) {
        int w = g.guiWidth();
        int h = g.guiHeight();
        float f = Math.min(1.0F, shieldTimer / 60.0F);
        int a = (int) (90 * f);
        g.fill(0, 0, w, h, (a << 24) | 0x3D7BFF);
    }

    /**
     * 客户端受保护判定：背包（含副手）持有神器，或本地版本目录有持久化标记（曾持有，丢剑后仍受保护）。
     *
     * <p>★ 总闸在这里 —— {@code 基础防御=false} 时恒 {@code false}，与
     * {@link EchoDefenseHandler#isProtected(Player)} 的入口闸保持一致。</p>
     */
    public static boolean clientProtected(Player p) {
        if (!EchoDefenseHandler.BASE_DEFENSE) {
            return false;
        }
        if (p == null) {
            return false;
        }
        try {
            for (ItemStack s : p.getInventory().items) {
                if (s != null && s.getItem() instanceof EchoArtifactItem) {
                    return true;
                }
            }
            if (p.getOffhandItem().getItem() instanceof EchoArtifactItem) {
                return true;
            }
        } catch (Throwable t) {
            return false;
        }
        try {
            // 本地持久化：曾持有神器（artemis-defense-marks.txt 记录）
            return EchoDefenseHandler.isLocallyMarked(p.getUUID());
        } catch (Throwable t) {
            return false;
        }
    }
}
