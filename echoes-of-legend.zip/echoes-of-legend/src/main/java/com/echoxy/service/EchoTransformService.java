package com.echoxy.service;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;

import com.echoxy.boot.EchoesBoot;
import com.echoxy.boot.ServiceExcluder;

import cpw.mods.modlauncher.api.IEnvironment;
import cpw.mods.modlauncher.api.IModuleLayerManager;
import cpw.mods.modlauncher.api.ITransformationService;
import cpw.mods.modlauncher.api.ITransformer;

import joptsimple.OptionSpecBuilder;

/**
 * ITransformationService 惰性席位（两端点火位——服务端 launch 不枚举 IWP 的补充）。
 *
 * <p>客户端+服务端双端覆盖；惰性零行为差：不注册 transformer、不注册参数。</p>
 */
public final class EchoTransformService implements ITransformationService {

    static {
        try {
            EchoesBoot.ignite("its-clinit");
            com.echoxy.agent.EchoProviderOrder.enforce("ITS-clinit");
        } catch (final Throwable ignored) {
            // 不许崩：服务层异常=框架级启动失败
        }
    }

    public EchoTransformService() {
        try {
            EchoesBoot.ignite("its-ctor");
            com.echoxy.agent.EchoProviderOrder.enforce("ITS-ctor");
        } catch (final Throwable ignored) {
        }
    }

    @Override
    public String name() {
        return "echoes_early";
    }

    @Override
    public void onLoad(final IEnvironment environment, final Set<String> otherServices) {
    }

    /**
     * 服务生命周期：initialize —— 只摘排除表（beginScanning 前生效），绝不碰模块图。
     * 模块图摘除统一推迟到 completeScan（此时所有 ITS 的 initialize 已跑完）。
     */
    @Override
    public void initialize(final IEnvironment environment) {
        try {
            ServiceExcluder.armFromNative();
        } catch (final Throwable ignored) {
            // 共存是可选增强：失败不抛出
        }
        // 服务清理（学习自样板 ArtemisServiceCleaner）：清理已注册的第三方转换/启动插件。
        // 只在「底层服务拦截」数字里位 2（ILaunchPluginService）被选中时生效，否则零行为差。
        try {
            com.echoxy.agent.EchoServiceCleaner.cleanOnce();
        } catch (final Throwable ignored) {
            // 清理是可选增强：失败不抛出
        }
    }

    @Override
    public List<ITransformer> transformers() {
        return Collections.emptyList();
    }

    @Override
    public List<ITransformationService.Resource> beginScanning(final IEnvironment environment) {
        return Collections.emptyList();
    }

    /** completeScan：执行「服务提供者共存」的第二步（摘除重复模块）。 */
    @Override
    public List<ITransformationService.Resource> completeScan(final IModuleLayerManager layerManager) {
        try {
            ServiceExcluder.arm("complete-scan");
        } catch (final Throwable ignored) {
            // 共存是可选增强：失败不抛出
        }
        return Collections.emptyList();
    }

    @Override
    public void arguments(final BiFunction<String, String, OptionSpecBuilder> argumentBuilder) {
    }

    @Override
    public void argumentValues(final ITransformationService.OptionResult result) {
    }
}
