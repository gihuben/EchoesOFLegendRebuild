package com.echoxy.service;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import com.echoxy.boot.EchoesBoot;

import net.minecraftforge.fml.loading.ImmediateWindowProvider;

/**
 * ImmediateWindowProvider 早期点火位（客户端最早 mods jar 执行点）。
 *
 * <p>本 jar 经 META-INF/services 声明进入 SERVICE 层；枚举循环对不匹配的 provider
 * 仍实例化（clinit+ctor 必执行）；name() 恒返回 "ah"（不匹配任何官方窗口名）
 * ⇒ 永不被选中 ⇒ 不接管窗口、零行为差；而 ServiceLoader 的 next() 仍会实例化
 * 本类 ⇒ {@code <clinit>} 照常点火。</p>
 */
public final class EchoWindowProvider implements ImmediateWindowProvider {

    static {
        try {
            EchoesBoot.ignite("iwp-clinit");
            com.echoxy.agent.EchoProviderOrder.enforce("IWP-clinit");
        } catch (final Throwable ignored) {
            // 不许崩
        }
    }

    public EchoWindowProvider() {
        try {
            EchoesBoot.ignite("iwp-ctor");
            com.echoxy.agent.EchoProviderOrder.enforce("IWP-ctor");
        } catch (final Throwable ignored) {
        }
    }

    @Override
    public String name() {
        // 用户裁决：本方 IWP 名固定为 "ah"
        return "ah";
    }

    @Override
    public Runnable initialize(final String[] arguments) {
        return (Runnable) () -> {
        };
    }

    @Override
    public void updateFramebufferSize(final IntConsumer width, final IntConsumer height) {
    }

    @Override
    public long setupMinecraftWindow(final IntSupplier width, final IntSupplier height,
            final Supplier<String> title, final LongSupplier monitor) {
        return 0L;
    }

    @Override
    public boolean positionWindow(final Optional<Object> monitor, final IntConsumer width,
            final IntConsumer height, final IntConsumer x, final IntConsumer y) {
        return false;
    }

    @Override
    public <T> Supplier<T> loadingOverlay(final Supplier<?> minecraft, final Supplier<?> reload,
            final Consumer<Optional<Throwable>> exception, final boolean fade) {
        return null;
    }

    @Override
    public void updateModuleReads(final ModuleLayer layer) {
    }

    @Override
    public void periodicTick() {
    }

    @Override
    public String getGLVersion() {
        // 【GL 版本修复】返回 1.20.1 环境合适的 GL 版本（实测：返回 null 时与某些 IWP 模组共存
        // 会导致 fmlearlywindow 创建 GLFW 窗口失败 "WGL: The driver does not appear to support OpenGL"）。
        return "4.6";
    }
}
