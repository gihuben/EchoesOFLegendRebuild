package com.echoxy.mixin;

import com.echoxy.attack.EchoAttackHandler;

import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 攻击加强 · 服务端交互包劫持（主 Mixin 路径）：
 * 服务端收到实体交互包时，若主手为神器且是 ATTACK（左键），先自行执行左键秒杀并取消原版处理
 * —— 顺带绕开原版 3.0 格距离检查，以及原版对掉落物/经验球/箭攻击包直接踢人的分支。
 * 右键（INTERACT）不拦截，由物品 use 触发全存档秒杀。
 */
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class EchoGuardInteractMixin {

    @Inject(method = "handleInteract(Lnet/minecraft/network/protocol/game/ServerboundInteractPacket;)V",
            at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$attackPacket(ServerboundInteractPacket packet, CallbackInfo ci) {
        ServerGamePacketListenerImpl self = (ServerGamePacketListenerImpl) (Object) this;
        ServerPlayer sp = self.player;
        if (sp == null || sp.level() == null || sp.level().getServer() == null) {
            return;
        }
        if (!EchoAttackHandler.isHoldingArtemis(sp)) {
            return;
        }
        Entity target = packet.getTarget(sp.serverLevel());
        if (target == null || target instanceof Player) {
            return;
        }
        final boolean[] attacked = {false};
        packet.dispatch(new ServerboundInteractPacket.Handler() {
            @Override
            public void onInteraction(InteractionHand hand) {
            }

            @Override
            public void onInteraction(InteractionHand hand, Vec3 location) {
            }

            @Override
            public void onAttack() {
                attacked[0] = true;
                EchoAttackHandler.onLeftClick(sp, target);
            }
        });
        if (attacked[0]) {
            ci.cancel();
        }
    }
}
