package com.echoxy.mixin;

import com.echoxy.client.ArtemisCosmicRenderer;
import com.echoxy.item.EchoArtifactItem;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 第一人称格挡与星空绘制：
 * <ul>
 *   <li>格挡时手臂跟随剑一起移动到屏幕中央（复刻 1.7.10 的位移）；</li>
 *   <li>手部渲染返回时统一绘制收集到的星空 pass（此时剑已上屏，星空画在剑之上）。</li>
 * </ul>
 */
@Mixin(ItemInHandRenderer.class)
public abstract class EchoGuardHandMixin {

    @Inject(method = "renderPlayerArm", at = @At("HEAD"))
    private void echoesOfLegend$blockingArm(PoseStack pose, MultiBufferSource buffer, int light, float partialTick,
            float interpolatedPitch, HumanoidArm arm, CallbackInfo ci) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null || !p.isUsingItem()) {
            return;
        }
        ItemStack using = p.getUseItem();
        if (!(using.getItem() instanceof EchoArtifactItem)) {
            return;
        }
        // 1.7.10 格挡时手臂位移：向左平移 0.5、向下 0.2
        pose.translate(-0.5F, 0.2F, 0.0F);
    }

    @Inject(method = "renderHandsWithItems", at = @At("RETURN"))
    private void echoesOfLegend$flushCosmic(float partialTicks, PoseStack pose, MultiBufferSource.BufferSource buffer,
            LocalPlayer player, int light, CallbackInfo ci) {
        ArtemisCosmicRenderer.renderPending();
    }
}
