package com.echoxy.mixin;

import com.echoxy.attack.EchoAttackHandler;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 左键挥击秒杀（主 Mixin 路径，不依赖 Forge 事件总线）：
 * 在 {@code Player.attack} 开头拦截，秒杀被挥到的实体及其横扫范围内的全部非玩家实体。
 * 是否生效由配置 {@code 神器左键秒杀} 控制。
 */
@Mixin(Player.class)
public abstract class EchoGuardPlayerAttackMixin {

    @Inject(method = "attack(Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"))
    private void echoesOfLegend$attackSweep(Entity target, CallbackInfo ci) {
        EchoAttackHandler.onLeftClick((Player) (Object) this, target);
    }
}
