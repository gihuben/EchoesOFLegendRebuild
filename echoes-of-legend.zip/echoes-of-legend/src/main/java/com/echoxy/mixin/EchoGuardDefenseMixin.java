package com.echoxy.mixin;

import com.echoxy.defense.EchoDefenseHandler;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 实体存活/伤害系统劫持（主 Mixin 路径，不依赖 Forge 事件总线）：
 *  - hurt / actuallyHurt：受保护玩家受伤时取消（伤害不落地 → 防改血）；
 *  - die / kill：受保护玩家死亡时取消并回拉存活数据（防死亡）；
 *  - isDeadOrDying：受保护玩家恒为 false（防死亡状态渲染）。
 */
@Mixin(LivingEntity.class)
public abstract class EchoGuardDefenseMixin {

    @Inject(method = "hurt(Lnet/minecraft/world/damagesource/DamageSource;F)Z", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$cancelAttack(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (EchoDefenseHandler.isProtected(self)) {
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "actuallyHurt(Lnet/minecraft/world/damagesource/DamageSource;F)V", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$cancelHurt(DamageSource source, float amount, CallbackInfo ci) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (EchoDefenseHandler.isProtected(self)) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$cancelDeath(DamageSource source, CallbackInfo ci) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (EchoDefenseHandler.isProtected(self)) {
                ci.cancel();
                EchoDefenseHandler.onDeathBlocked(self);
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "kill", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$cancelKill(CallbackInfo ci) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (EchoDefenseHandler.isProtected(self)) {
                ci.cancel();
                EchoDefenseHandler.onDeathBlocked(self);
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "isDeadOrDying", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$hijackDeadState(CallbackInfoReturnable<Boolean> cir) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (EchoDefenseHandler.isProtected(self)) {
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void echoesOfLegend$suppressHurtRender(CallbackInfo ci) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            // 防受击渲染：受保护玩家每 tick 清空受伤/死亡渲染字段（红屏/镜头晃动/死亡镜头）
            if (EchoDefenseHandler.isProtected(self)) {
                self.hurtTime = 0;
                self.hurtDuration = 0;
                self.deathTime = 0;
            }
        } catch (Throwable ignored) {
        }
    }
}
