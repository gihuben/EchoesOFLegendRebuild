package com.echoxy.mixin;

import com.echoxy.client.EchoGuardTextRenderer;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 彩字文本接管：{@code GuiGraphics.drawString(Font, Component, …)} 的 HEAD。
 *
 * <p>快捷栏上方的物品名与创造模式选项卡标题都走这一个原版方法绘制，
 * 命中神器名/我方选项卡标题时取消原版白字并改画渐变波浪彩字，其余文本不碰。</p>
 */
@Mixin(GuiGraphics.class)
public abstract class EchoGuardTextMixin {

    @Inject(method = "drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)I",
            at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$drawStringComponent(Font font, Component text, int x, int y, int color, boolean shadow,
            CallbackInfoReturnable<Integer> cir) {
        try {
            if (EchoGuardTextRenderer.tryRenderText((GuiGraphics) (Object) this, font, text, x, y)) {
                cir.setReturnValue(font.width(text));
            }
        } catch (Throwable ignored) {
            // 类加载/渲染异常不得崩游戏（回退原版白字）
        }
    }
}
