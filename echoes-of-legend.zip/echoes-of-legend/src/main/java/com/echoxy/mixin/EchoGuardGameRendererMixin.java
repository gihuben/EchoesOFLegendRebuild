package com.echoxy.mixin;

import com.echoxy.defense.EchoClientDefense;

import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 死亡界面拦截（每帧）：{@code GameRenderer.render} 是整帧渲染入口，执行于死亡界面绘制之前。
 * 在 HEAD 解除受保护玩家屏幕上的死亡界面——本帧便不会渲染死亡界面（消除一帧闪现）。
 */
@Mixin(GameRenderer.class)
public abstract class EchoGuardGameRendererMixin {

    @Inject(method = "render(FJZ)V", at = @At("HEAD"))
    private void echoesOfLegend$disarmDeathScreen(float partialTicks, long nanoTime, boolean renderLevel,
            CallbackInfo ci) {
        try {
            EchoClientDefense.clearDeathScreens();
        } catch (Throwable ignored) {
        }
    }
}
