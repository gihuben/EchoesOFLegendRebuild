package com.echoxy.mixin;

import com.echoxy.defense.EchoClientDefense;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 防渲染主路径（不依赖 Forge 事件总线）：
 * 护盾窗口 / 防御模式下取消整个 Gui.render（原版 HUD、屏幕、全部叠加层全部跳过），
 * 仅保留指示器与护盾覆盖（RETURN 在帧末最高图层绘制）。
 */
@Mixin(Gui.class)
public abstract class EchoGuardGuiShieldMixin {

    @Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;F)V", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$shieldCancel(GuiGraphics graphics, float partialTick, CallbackInfo ci) {
        try {
            if (EchoClientDefense.hudGuard(graphics)) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
            // 异常不得崩游戏（回退原版 HUD）
        }
    }

    @Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;F)V", at = @At("RETURN"))
    private void echoesOfLegend$shieldTopLayer(GuiGraphics graphics, float partialTick, CallbackInfo ci) {
        try {
            // 帧末最高图层重绘：护盾永远在最顶
            if (EchoClientDefense.shieldActive()) {
                EchoClientDefense.renderShield(graphics);
            }
        } catch (Throwable ignored) {
        }
    }
}
