package com.echoxy.mixin;

import com.echoxy.client.ArtemisCosmicRenderer;
import com.echoxy.item.EchoArtifactItem;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 星空 pass 注入：物品模型渲染时只收集神器的渲染数据（快照矩阵），
 * 由 {@link ArtemisCosmicRenderer} 在帧末用剑自身四边形 + 星空着色器统一绘制
 * ——星空与剑共用同一套几何，且永远绘制在剑之上，不会被剑体遮挡。
 */
@Mixin(ItemRenderer.class)
public abstract class EchoGuardItemRendererMixin {

    @Inject(method = "render(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IILnet/minecraft/client/resources/model/BakedModel;)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/ItemRenderer;renderModelLists(Lnet/minecraft/client/resources/model/BakedModel;Lnet/minecraft/world/item/ItemStack;IILcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;)V",
                    ordinal = 0, shift = At.Shift.AFTER))
    private void echoesOfLegend$collectCosmic(ItemStack stack, ItemDisplayContext context, boolean leftHand,
            PoseStack pose, MultiBufferSource buffer, int light, int overlay, BakedModel model, CallbackInfo ci) {
        if (!(stack.getItem() instanceof EchoArtifactItem)) {
            return;
        }
        // 只收集手持上下文（第一/第三人称）；GUI/掉落物/展示框等保持原版外观
        if (context != ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                && context != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                && context != ItemDisplayContext.THIRD_PERSON_LEFT_HAND
                && context != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND) {
            return;
        }
        ArtemisCosmicRenderer.collect(stack, pose, light, overlay);
    }
}
