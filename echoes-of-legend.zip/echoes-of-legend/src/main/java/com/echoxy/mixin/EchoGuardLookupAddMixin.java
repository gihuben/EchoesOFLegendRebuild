package com.echoxy.mixin;

import com.echoxy.attack.EchoDoomList;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.entity.EntityAccess;
import net.minecraft.world.level.entity.EntityLookup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 禁生成表最终防线：EntityLookup.add（byId/byUuid 的最后一道门）。
 * 被禁类型不可进入任何实体表（客户端/服务端通用）。
 */
@Mixin(EntityLookup.class)
public abstract class EchoGuardLookupAddMixin {

    @Inject(method = "add", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$blockBannedAdd(EntityAccess entityAccess, CallbackInfo ci) {
        if (entityAccess instanceof Entity entity && EchoDoomList.isBannedType(entity)) {
            ci.cancel();
        }
    }
}
