package com.echoxy.mixin;

import com.echoxy.attack.EchoAttackHandler;
import com.echoxy.defense.EchoDefenseHandler;

import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 宿主为盾（服务端）：tick 结尾执行「每 tick 巡检驱逐」与「防御 tick」（锁血/字段回溯/受击渲染压制）。
 *
 * <p>清扫放在 tick 结尾（而非开头）：隐藏类实体可能在 tick 中段把自己"塞回"列表，
 * 开头清会被当轮覆盖；结尾清完 → 下一 tick 从干净状态开始。</p>
 */
@Mixin(MinecraftServer.class)
public abstract class EchoGuardServerTickMixin {

    @Inject(method = "tickServer(Ljava/util/function/BooleanSupplier;)V", at = @At("TAIL"))
    private void echoesOfLegend$serverTickSweep(CallbackInfo ci) {
        try {
            EchoAttackHandler.sweep((MinecraftServer) (Object) this);
        } catch (Throwable ignored) {
            // 巡检异常不得影响服务端 tick
        }
        try {
            EchoDefenseHandler.serverTick((MinecraftServer) (Object) this);
        } catch (Throwable ignored) {
            // 防御 tick 异常不得影响服务端 tick
        }
    }
}
