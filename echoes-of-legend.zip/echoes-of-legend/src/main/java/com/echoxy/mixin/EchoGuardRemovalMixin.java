package com.echoxy.mixin;

import com.echoxy.defense.EchoDefenseHandler;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 实体移除系统劫持（主 Mixin 路径）：受保护玩家调用的 {@code remove(RemovalReason)} 一律取消
 * ——玩家永远不会被移出世界。原版 {@code discard()} 内部转发到 remove，因此也被顺带拦截。
 */
@Mixin(Entity.class)
public abstract class EchoGuardRemovalMixin {

    @Inject(method = "remove(Lnet/minecraft/world/entity/Entity$RemovalReason;)V", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$blockRemoval(Entity.RemovalReason reason, CallbackInfo ci) {
        try {
            Entity self = (Entity) (Object) this;
            if (self instanceof LivingEntity le && EchoDefenseHandler.isProtected(le)) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
        }
    }
}
