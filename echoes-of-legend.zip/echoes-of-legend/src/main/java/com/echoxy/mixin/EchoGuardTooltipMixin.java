package com.echoxy.mixin;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.echoxy.client.ArtifactTooltipRenderer;
import com.mojang.datafixers.util.Either;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 神器提示框接管：原版提示框的各公开入口全部在这里被接管（纯原版方法，
 * 与事件总线完全无关）。只要目标物品是神器，就取消原版渲染并交给
 * {@link ArtifactTooltipRenderer} 全自绘；其他物品一步不碰，走原版路径。
 */
@Mixin(GuiGraphics.class)
public abstract class EchoGuardTooltipMixin {

    @Inject(method = "renderTooltip(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;II)V",
            at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$tooltipItemStack(Font font, ItemStack stack, int mouseX, int mouseY, CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRender(stack, (GuiGraphics) (Object) this, mouseX, mouseY)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;Lnet/minecraft/world/item/ItemStack;II)V",
            remap = false, at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$tooltipListWithStack(Font font, List<Component> components,
            Optional<TooltipComponent> visual, ItemStack stack, int mouseX, int mouseY, CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRender(stack, (GuiGraphics) (Object) this, mouseX, mouseY)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;II)V",
            at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$tooltipList(Font font, List<Component> components,
            Optional<TooltipComponent> visual, int mouseX, int mouseY, CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRenderComponents(components, (GuiGraphics) (Object) this, mouseX, mouseY)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderTooltip(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;II)V",
            at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$tooltipSingle(Font font, Component text, int mouseX, int mouseY, CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRenderComponents(Collections.singletonList(text), (GuiGraphics) (Object) this,
                mouseX, mouseY)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderComponentTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;II)V",
            at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$componentTooltip(Font font, List<Component> components, int mouseX, int mouseY,
            CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRenderComponents(components, (GuiGraphics) (Object) this, mouseX, mouseY)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderComponentTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;IILnet/minecraft/world/item/ItemStack;)V",
            remap = false, at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$componentTooltipWithStack(Font font, List<? extends FormattedText> elements,
            int mouseX, int mouseY, ItemStack stack, CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRender(stack, (GuiGraphics) (Object) this, mouseX, mouseY)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderComponentTooltipFromElements(Lnet/minecraft/client/gui/Font;Ljava/util/List;IILnet/minecraft/world/item/ItemStack;)V",
            remap = false, at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$componentTooltipFromElements(Font font,
            List<Either<FormattedText, TooltipComponent>> elements, int mouseX, int mouseY, ItemStack stack,
            CallbackInfo ci) {
        if (ArtifactTooltipRenderer.tryRender(stack, (GuiGraphics) (Object) this, mouseX, mouseY)) {
            ci.cancel();
        }
    }
}
