package com.echoxy.mixin;

import com.echoxy.defense.EchoClientDefense;
import com.echoxy.defense.EchoDefenseHandler;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.DeathScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 死亡 GUI 拦截（主 Mixin 路径）：{@code DeathScreen.render} 是死亡界面渲染的唯一入口。
 * 受保护玩家（背包持有神器或持标记）的死亡界面任何来源渲染一律取消。
 */
@Mixin(DeathScreen.class)
public abstract class EchoGuardDeathScreenMixin {

    @Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$blockDeathRender(GuiGraphics graphics, int mouseX, int mouseY, float partialTick,
            CallbackInfo ci) {
        if (!EchoDefenseHandler.BASE_DEFENSE) {
            return;
        }
        try {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.player != null && (EchoClientDefense.clientProtected(mc.player)
                    || EchoDefenseHandler.isProtected(mc.player))) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
        }
    }
}
