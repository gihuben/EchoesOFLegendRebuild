package com.echoxy.mixin;

import com.echoxy.attack.EchoDoomList;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 禁生成表主路径（不依赖 Forge 事件总线）：
 * 实体加入世界（生成/召唤/维度迁移）时与禁生成表匹配，命中则禁止加入并移除。
 */
@Mixin(ServerLevel.class)
public abstract class EchoGuardEntityGateMixin {

    @Inject(method = "addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z", at = @At("HEAD"), cancellable = true)
    private void echoesOfLegend$banGate(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (EchoDoomList.isBannedType(entity)) {
            try {
                entity.discard();
            } catch (Throwable ignored) {
            }
            cir.setReturnValue(false);
        }
    }
}
